---
type: technique
author: Andresa Molina
tags: [dialogo-somatico, corpo-fisico, personificação-da-dor, dor-cronica]
sources: ["[[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]"]
---

# Prática do Diálogo Direto com a Dor Somática (A personificação visceral)

- **Definição**: A intervenção de contingência que redireciona a visão do paciente na Câmara. Quando a mente do assistido falha em visualizar cenários externos (pai, inimigos, hologramas) e enxerga apenas o próprio corpo físico urrando de dor, o terapeuta transforma o "órgão ferido" no interlocutor do transe.
- **Como praticar e seu Propósito**:
  1. **Personificação da Região**: O paciente em transe relata dor física e peso agudo (ex: costas) e não vê cenários. O terapeuta ordena: "O que que essa dor te diz? Conversa com ela, conversa com as suas costas".
  2. **Interrogação Ativa**: Estimular a verbalização direcionada: "O que você tem para dizer para isso que tá te pesando?".
  3. **Catarse Física Ativa**: Guiar o ato de desapego mecânico: "Você quer tirar esse peso das costas? O que que tem aí? Tira o peso, passa a mão, tira o peso".
  O propósito somático é usar a própria dor física como âncora de comunicação direta com as memórias biológicas retidas nas fáscias e músculos, permitindo sua drenagem ("colocaria ela em contato com o corpo dela para conversar").
- **Evidências**: "Ela começou a ter eh eh a dizer que sentia um peso muito grande na cabeça, a curvar, portanto o corpo dela começou a manifestar e ela só dizia que tinha dor... mas não via nada, não via ninguém... O que que essa dor te diz? Conversa com ela, conversa com as suas costas. O que você tem para dizer para isso que tá te pesando? Você quer tirar esse peso das costas? O que que tem aí? Tira o peso, passa a mão, tira o peso. Eu eu colocaria ela em contato com o corpo dela para conversar, né? ...olhar pro seu braço e aí ia conversando, tá muito, tá com muita força e vai falando para ele o que que você sente."
- **Conexões**: [[Conceito de Gatilho Somatico]], [[Tecnica da Posicao Somatica ou Cadeira]]

## Perguntas Frequentes / Didática de Atendimento

### 16. Como se conduz o diálogo e a personificação visceral direta da dor somática quando o assistido apresenta peso físico, mas não visualiza cenários?
**Resposta**: Quando a paciente entra na Câmara, não vê ninguém, mas começa a se **"curvar"** e a **"dizer que sentia um peso muito grande na cabeça"**, o terapeuta redireciona o transe transformando o próprio corpo do paciente no interlocutor.

A nível somático, o terapeuta extrai o foco da mente (que não consegue criar cenários astrais) e exige que a pessoa encare a matéria em dor: **"O que que essa dor te diz? Conversa com ela, conversa com as suas costas. O que você tem para dizer para isso que tá te pesando?"**. O terapeuta exige também a manipulação física imaginária daquela carga somática: **"Tira o peso, passa a mão, tira o peso"**. O propósito é **"colocaria ela em contato com o corpo dela para conversar"**, fazendo com que o assistido dialogue com o órgão ferido (ex: **"olhar pro seu braço e aí ia conversando, tá muito, tá com muita força"**).


## Referencia

ANDRESA MOLINA. *Prática do Diálogo Direto com a Dor Somática*. Aula 10 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]].
