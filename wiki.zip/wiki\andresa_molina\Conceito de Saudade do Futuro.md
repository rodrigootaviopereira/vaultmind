---
type: conceito
author: Andresa Molina
tags: [autoabandono, saudade-do-futuro, programa-de-vida, missao, 4a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito de Saudade do Futuro (Programa de Vida)

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: A Saudade do Futuro é a sensação íntima e inexplicável de melancolia, saudade ou nostalgia de algo que o indivíduo sente que "nunca viveu nesta vida" ou de alguém que ele não sabe quem é. Trata-se da lembrança inconsciente do **programa ou plano de vida** (sonhos, projetos e missão) planejado e estruturado pela alma antes de encarnar, mas que foi deixado de lado (arquivado no corpo) devido a traumas e bloqueios emocionais da infância ou herdados de ancestrais.
- **Formulação de apoio**: Essa saudade é o rastro da essência da alma. Andresa ensina que os sonhos e aspirações genuínas de ajudar o mundo ou viver de forma plena não são delírios ou fantasias; eles fazem parte do projeto original que a alma planejou executar. Ao nos desvincularmos de nossa essência para agradar aos outros (autoabandono), a saudade do projeto não executado se instala como um vazio crônico.

## Contexto de Uso

- Usado para acolher e diagnosticar assistidos que chegam à terapia com sentimentos de "vazio existencial inexplicável", insatisfação profissional crônica ou melancolia persistente que não cede com conquistas materiais (como bens, carreira ou relacionamentos externos).

## Relação com Princípios

- [[Principio da Causa Inconsciente e da Reconsolidacao]]
- [[Principio da Liberdade Consciente]]
- [[Principio da Memoria Celular Ancestral]]

## Exemplos do Material

- *"Sabe aquela saudade de uma coisa que você nunca viveu? Aquela saudade de uma coisa que você não sabe o que é? Parece que você sente uma saudade, parece que é um alguém que você não sabe quem é. [...] É como se você tivesse saudade de um plano que você teve, um projeto que você teve, mas que você não executou. Mas antes de encarnar, você sonhou com ele..."*
- O sentimento de melancolia existencial que o indivíduo projeta na perda de entes queridos, quando na verdade é a saudade do seu próprio propósito adormecido.

## Aplicação Prática

1. **Investigar o Vazio**: Validar o sentimento de vazio do assistido, explicando que esse vazio é, na verdade, um indicativo de que ele abandonou o seu próprio programa de vida.
2. **Localizar a Gaveta Corporal**: Ajudar o assistido a rastrear em qual local do corpo físico a energia desse plano não executado está arquivada/bloqueada (ombros, estômago, etc.).
3. **Resgate de Propósito**: Utilizar a reconsolidação celular para remover os emaranhamentos de dor familiar que impedem o assistido de ter coragem para manifestar seus sonhos, despertando a potência pessoal.

## Referência

ANDRESA MOLINA. *Conceito de Saudade do Futuro (Programa de Vida)*. Aula 04 - Coordenada 4 (A Mulher Antes de Ser de Todos). Fontes: [[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]].
