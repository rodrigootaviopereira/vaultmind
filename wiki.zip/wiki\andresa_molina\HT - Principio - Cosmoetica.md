---
type: principio
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, principio, cosmoetica, etica]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_147_etica_moral_e_cosmoetica.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_148_a_etica.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_149_a_moral.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_150_relacionamentos_baseados_em_comportamentos_eticos.md]]"]
---

# HT - Principio - Cosmoetica

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_147_etica_moral_e_cosmoetica.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_148_a_etica.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_149_a_moral.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_150_relacionamentos_baseados_em_comportamentos_eticos.md]]

## Definição

- **Definição**: [INFERÊNCIA] HT - Principio - Cosmoetica expressa uma regra estrutural do sistema terapêutico de Andresa Molina: sem este princípio, a técnica perde força, segurança ou coerência no atendimento.
- **Formulação de apoio**: Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_01_apresentacao.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_03_metodologia_humanoterapeuta.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_147_etica_moral_e_cosmoetica.md]].

## Justificativa

- [INFERÊNCIA] É central porque transforma conteúdo em postura terapêutica: não basta conhecer o método, é preciso aplicá-lo com presença, ordem, respeito ao campo e leitura da raiz da dor.

## Evidências

- Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_01_apresentacao.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_03_metodologia_humanoterapeuta.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_147_etica_moral_e_cosmoetica.md]]. (HT - Apostila Humanoterapeuta - Andresa Molina)
- Nesta wiki, as notas do Humanoterapeuta ficam nomeadas explicitamente como `Humanoterapeuta`. - Para uma visao integrada sem mistura de sistemas, usar [[Mapa dos Sistemas Terapeuticos de Andresa Molina]]. ## Leitura Integrada - O material sustenta uma visao tripla do ser humano: corpo, mente e espirito. - A cura e descrita como ganho de consciencia, desbloqueio energetico, tratamento espiritual e restabelecimento da informacao original. - A obra insiste na ordem, no metodo e na integridade da aplicacao. - O fechamento em cosmoetica impede que a tecnica seja lida apenas como instrumento de poder. ## Referencia ANDRESA MOLINA. *HT - Apostila Humanoterapeuta - Andresa Molina*. (HT - Apostila Humanoterapeuta - Andresa Molina)

## Implicações

- [INFERÊNCIA] O terapeuta deve usar este princípio como critério de decisão antes de improvisar, interpretar ou conduzir o assistido.
- [INFERÊNCIA] Quando o princípio é ignorado, a sessão tende a ficar mental, apressada, fragmentada ou desconectada da equipe/campo de trabalho.

## Conexões

- [[HT - Apostila Humanoterapeuta - Andresa Molina]]

## Notas Pessoais

- Reservado para observações do usuário no uso prático da técnica.

## Referencia

ANDRESA MOLINA. *HT - Principio - Cosmoetica*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_147_etica_moral_e_cosmoetica.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_148_a_etica.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_149_a_moral.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_150_relacionamentos_baseados_em_comportamentos_eticos.md]]. Acesso em: 17 jun. 2026.
