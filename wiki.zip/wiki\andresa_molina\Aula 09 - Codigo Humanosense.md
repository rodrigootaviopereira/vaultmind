---
type: aula
author: Andresa Molina
tags: [codigo-humanosense, humanosense, aula-09, reingestao-2026-06-19]
sources:
  - "[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"
---
# Aula 09 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `09   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 12.797 palavras; 448 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- É claro que uma é completamente diferente da outra, né? não tem um atendimento que é igual, eles são completamente diferentes, porque eles são eh o o campo energético, espiritual, inconsciente da pessoa.
- Então, nós vamos conduzi-la no inconsciente, no energético e no espiritual, no plano multidimensional de outras vidas, enfim, da pessoa.
- Então, eh, nós temos uma base estruturada, né, de como fazer e aí tem aquele momento em que o terapeuta tem que ter a habilidade.
- Então, eu vou trazer aqui um pouquinho onde aquilo flui de uma maneira natural e precisa ter um processo de presença e de condução, de escuta, atenta e condução daquele processo.
- Porque quanto mais você fizer, mais habilidade você vai tendo, mais você conecta com o campo da pessoa dentro da Câmara Humanocense.
- Eu queria saber se de vocês que estão com as mãos levantadas se tem alguém que não passou por nada, nunca foi cliente do espaço humanidade, nunca fez metodologia terapeuta, nunca fez código não sabe de nada.
- Então eu só vou pedir para você e vou te pedir um favor que você fale e eu vou perguntar e aí eu gostaria que você repetisse seu nome completo em data de nascimento e dissesse eu, Patrícia, nome completo, e autorizo a divulgação dessa imagem pro código tá só pra gente deixar esse documentado para não ter problema.
- Porque você disse, e eu te fiz uma pergunta lá atrás que que falou agora, conforme eu falei da confiança, eu me lembrei e vou falar o que eu estou sentindo, que eu acho que eu não recebi dos meus pais o afeto, né, o amor, enfim, que eu deveria, que eu merecia o que eu precisava.
- Eu estou a falar, eu estou triste, eu estou com medo, falo tudo que você, eu estou triste, eu estou com medo, eu estou perdida, eu não consigo perceber o que é que se está a passar, nem consigo que as coisas entrem na minha cabeça, porque eu estou sempre a pensar outras coisas e eu estou sempre a tentar entender porque é que eu não não sou vista, porque é…
- Mas assim, se por acaso vocês não tivessem visto nada disso, não soubesse nome, não importa a energia que vem fazer esses recolhimentos de almas, de frações que precisam de cuidado, né, de um pequeno nível ali daquela consciência dela que você encontrou que tava perdido, que tava precisando de ajuda e você falou: "Não consigo ajudar", mas ele precisava de…
- E aí depois eu, se fosse meu cliente e eu precisasse usar essas fichinhas, eu apagaria e colocaria a pergunta aqui, porque depois quando eu for falar com ele aqui três meses, que ele quis quer fazer outro manência, por exemplo, eu sei o que aconteceu aqui.
- E todo o estudo, todo o processo de entendimento de padrão, isso facilita, mas não significa que vocês não vão conseguir conduzir todo o processo, porque a equipe espiritual da Câmara Manuciense tá atuando.

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-56
- É claro que uma é completamente diferente da outra, né? não tem um atendimento que é igual, eles são completamente diferentes, porque eles são eh o o campo energético, espiritual, inconsciente da pessoa.
- Eu queria saber se de vocês que estão com as mãos levantadas se tem alguém que não passou por nada, nunca foi cliente do espaço humanidade, nunca fez metodologia terapeuta, nunca fez código não sabe de nada.
- Então eu só vou pedir para você e vou te pedir um favor que você fale e eu vou perguntar e aí eu gostaria que você repetisse seu nome completo em data de nascimento e dissesse eu, Patrícia, nome completo, e autorizo a divulgação dessa imagem pro código tá só pra gente deixar esse documentado para não ter problema.

### Bloco 2 - frases 57-112
- A dificuldade que eu tenho é materializar e eu com o curso percebi que preciso de equilibrar a minha energia masculina e feminina.
- Então, não é sobre materializar o ser terapeuta, você se sente terapeuta, você já é terapeuta, você não tem clientes, é sobre viver de terapia e não sobre ser terapeuta, só para eu entender melhor onde tá esse perceb?
- Então tô colocando, tô construindo aqui uma pirâmide nessa sala virtual, colocando eu padrista Martins dentro da pirâmide, isolando essa pirâmide e isso de toda e qualquer energia que seja ausente de nós duas dentro desse campo de força de proteção.

### Bloco 3 - frases 113-168
- OK. aqui o que uma das coisas que ficaram bem latentes e que eu acho que é importante você observar é que quando você traz a sua questão principal, quando você eh quando você traz a sobre a materialização, eh aí você fala, né, tem aquela aquele viés invertido de segurança, ter ter o cliente para ter segurança, aí a gente conversou sobre ter a segurança para depois poder ter o cliente.
- Então, o quanto você está sem paciência, né, para construir, para se tornar a terapeuta, porque olha, a sua pergunta principal foi: "Eu quero materializar ser terapeuta".
- Então, materializar ser terapeuta significa estudar, significa buscar aperfeiçoamento.

### Bloco 4 - frases 169-224
- Aí eu vou me sentir confiante e vou conseguir materializar os meus clientes, automaticamente eu vou me sentir pronto o suficiente para atendê-lo.
- Quando você precisa ir para a batalha, se pôr na linha de frente, fazer as experiências, fazer gratuito, fazer cobrando barato, fazer nas pessoas isso que você tá aprendendo, então estudei bastante, legal, faz um ano e pouco tô estudando, acho legal, tá?
- Relacionamento nesse caso é se você for progredir, tá, como terapeuta, materializar e conseguir viver bem disso, ter os clientes, enfim, o quanto você acredita que tem dois pontos aqui que eu quero perguntar para você para entender se é mais um ou mais o outro.

### Bloco 5 - frases 225-280
- Porque você disse, e eu te fiz uma pergunta lá atrás que que falou agora, conforme eu falei da confiança, eu me lembrei e vou falar o que eu estou sentindo, que eu acho que eu não recebi dos meus pais o afeto, né, o amor, enfim, que eu deveria, que eu merecia o que eu precisava.
- Só que agora você tem uma um agora com essa conversa que a gente teve, a o seu desejo está mais alinhado, porque você entende que para ser terapeuta você precisa experienciar, ganhar a confiança, não ganhar, não ter cliente.
- O que que a gente Então mudou tudo porque você chegou querer materializar uma coisa e eu tô te dando consciência que tá vendo como não é isso ou tem algo a mais e aí você fala que você não se sentiu.

### Bloco 6 - frases 281-336
- Repare que a respiração já tá mais calma, que os batimentos cardíacos já estão mais tranquilos, que tudo já tá mais leve.
- Ajusto a coordenada e códigos de acesso para abertura da câmara humanocense anexa ao hospital astral do espaço de humanidade.
- Eu estou a falar, eu estou triste, eu estou com medo, falo tudo que você, eu estou triste, eu estou com medo, eu estou perdida, eu não consigo perceber o que é que se está a passar, nem consigo que as coisas entrem na minha cabeça, porque eu estou sempre a pensar outras coisas e eu estou sempre a tentar entender porque é que eu não não sou vista, porque é que vocês não me ajudam, porque é que vocês não não falam…

### Bloco 7 - frases 337-392
- Tô enquadrando essa cena, fazendo tratamento convencional, trazendo a energia de todo balu aí e recolhendo toda e qualquer consciência que tenha ficado nesse plano de nos planos astrais dessa fração, dessa consciência que precisa seguir colocando muito amor, muito caminho.
- Então eu consegui identificar que você tava muito acreditando que era a guerreira, mas quando você tá na guerreira guerreando, eu tô, eu tô fazendo, mas você não está fazendo porque só no seu inconsciente, na verdade, ele não tá fazendo, eu percebo que você não está tão na guerreira, você tá na donzela porque você tá acreditando que tá fazendo uma coisa que não tá.
- Mas assim, se por acaso vocês não tivessem visto nada disso, não soubesse nome, não importa a energia que vem fazer esses recolhimentos de almas, de frações que precisam de cuidado, né, de um pequeno nível ali daquela consciência dela que você encontrou que tava perdido, que tava precisando de ajuda e você falou: "Não consigo ajudar", mas ele precisava de ajuda e eu falei: "Você quer?" você ajudou porque o tempo em…

### Bloco 8 - frases 393-448
- E aí depois eu, se fosse meu cliente e eu precisasse usar essas fichinhas, eu apagaria e colocaria a pergunta aqui, porque depois quando eu for falar com ele aqui três meses, que ele quis quer fazer outro manência, por exemplo, eu sei o que aconteceu aqui.
- E porque o que eu falei com a Patrícia, ela falou, ela trouxe todas essas perguntas, síntese do sentimento, qual era o sentimento?
- E todo o estudo, todo o processo de entendimento de padrão, isso facilita, mas não significa que vocês não vão conseguir conduzir todo o processo, porque a equipe espiritual da Câmara Manuciense tá atuando.

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Então, eh, nós temos uma base estruturada, né, de como fazer e aí tem aquele momento em que o terapeuta tem que ter a habilidade.
- Então, eu vou trazer aqui um pouquinho onde aquilo flui de uma maneira natural e precisa ter um processo de presença e de condução, de escuta, atenta e condução daquele processo.
- Eu queria saber se de vocês que estão com as mãos levantadas se tem alguém que não passou por nada, nunca foi cliente do espaço humanidade, nunca fez metodologia terapeuta, nunca fez código não sabe de nada.
- Porque você disse, e eu te fiz uma pergunta lá atrás que que falou agora, conforme eu falei da confiança, eu me lembrei e vou falar o que eu estou sentindo, que eu acho que eu não recebi dos meus pais o afeto, né, o amor, enfim, que eu deveria, que eu merecia o que eu precisava.
- Só que agora você tem uma um agora com essa conversa que a gente teve, a o seu desejo está mais alinhado, porque você entende que para ser terapeuta você precisa experienciar, ganhar a confiança, não ganhar, não ter cliente.
- Eu acho que eu não consigo, acho que eu não sou tão forte assim, porque mas aqui você é porque você é, só que você não tá fazendo porque não lhe foi permitido fazer, porque te protegeram, não desconsideraram não por maldade, mas por falta de enfim de conhecimento, enfim, de tudo que quero que você não se sentiu amada porque justamente por isso, não é o…
- Eu estou a falar, eu estou triste, eu estou com medo, falo tudo que você, eu estou triste, eu estou com medo, eu estou perdida, eu não consigo perceber o que é que se está a passar, nem consigo que as coisas entrem na minha cabeça, porque eu estou sempre a pensar outras coisas e eu estou sempre a tentar entender porque é que eu não não sou vista, porque é…
- Tô enquadrando essa cena, fazendo tratamento convencional, trazendo a energia de todo balu aí e recolhendo toda e qualquer consciência que tenha ficado nesse plano de nos planos astrais dessa fração, dessa consciência que precisa seguir colocando muito amor, muito caminho.
- Mas assim, se por acaso vocês não tivessem visto nada disso, não soubesse nome, não importa a energia que vem fazer esses recolhimentos de almas, de frações que precisam de cuidado, né, de um pequeno nível ali daquela consciência dela que você encontrou que tava perdido, que tava precisando de ajuda e você falou: "Não consigo ajudar", mas ele precisava de…
- E aí depois eu, se fosse meu cliente e eu precisasse usar essas fichinhas, eu apagaria e colocaria a pergunta aqui, porque depois quando eu for falar com ele aqui três meses, que ele quis quer fazer outro manência, por exemplo, eu sei o que aconteceu aqui.

## Conceitos-Chave Extraídos

- É claro que uma é completamente diferente da outra, né? não tem um atendimento que é igual, eles são completamente diferentes, porque eles são eh o o campo energético, espiritual, inconsciente da pessoa.
- Então, eh, nós temos uma base estruturada, né, de como fazer e aí tem aquele momento em que o terapeuta tem que ter a habilidade.
- Porque quanto mais você fizer, mais habilidade você vai tendo, mais você conecta com o campo da pessoa dentro da Câmara Humanocense.
- Então é uma capacidade é que a gente vai desenvolvendo uma musculatura energética e espiritual, um campo de atuação que é um desenvolvimento mediúnico também, tá?
- Sem falar que a gente vai criando muito mais segurança, né? e entendendo de cara que sim, todos serão diferentes uns dos outros, porque são pessoas diferentes, com histórias diferentes, com códigos eh que que são eh desconectados de maneira diferente, enfim, só praticando.
- Eu queria saber se de vocês que estão com as mãos levantadas se tem alguém que não passou por nada, nunca foi cliente do espaço humanidade, nunca fez metodologia terapeuta, nunca fez código não sabe de nada.
- Então eu só vou pedir para você e vou te pedir um favor que você fale e eu vou perguntar e aí eu gostaria que você repetisse seu nome completo em data de nascimento e dissesse eu, Patrícia, nome completo, e autorizo a divulgação dessa imagem pro código tá só pra gente deixar esse documentado para não ter problema.
- Então Patrícia você e autoriza a divulgação desse material, né, do seu do seu vídeo pr pr as aulas do código Martins autoriza a divulgação desse material pro código aqui.
- Então tô colocando, tô construindo aqui uma pirâmide nessa sala virtual, colocando eu padrista Martins dentro da pirâmide, isolando essa pirâmide e isso de toda e qualquer energia que seja ausente de nós duas dentro desse campo de força de proteção.
- Então, materializar ser terapeuta significa estudar, significa buscar aperfeiçoamento.
- O que que a gente Então mudou tudo porque você chegou querer materializar uma coisa e eu tô te dando consciência que tá vendo como não é isso ou tem algo a mais e aí você fala que você não se sentiu.
- Tô enquadrando essa cena, fazendo tratamento convencional, trazendo a energia de todo balu aí e recolhendo toda e qualquer consciência que tenha ficado nesse plano de nos planos astrais dessa fração, dessa consciência que precisa seguir colocando muito amor, muito caminho.
- E ali e depois eu senti muito a energia de de eu vou eu vou chamar não sei se você tem conhecimento, mas como é um conhecimento para mim seria energia de um lu que traz resgates de alma e cois mais ainda que vocês não não soubessem o que é a veio, veio para resgatar outro nome mesia isso.
- Mas assim, se por acaso vocês não tivessem visto nada disso, não soubesse nome, não importa a energia que vem fazer esses recolhimentos de almas, de frações que precisam de cuidado, né, de um pequeno nível ali daquela consciência dela que você encontrou que tava perdido, que tava precisando de ajuda e você falou: "Não consigo ajudar", mas ele precisava de…
- E todo o estudo, todo o processo de entendimento de padrão, isso facilita, mas não significa que vocês não vão conseguir conduzir todo o processo, porque a equipe espiritual da Câmara Manuciense tá atuando.
- Então este essa parte do meio, ela é muito fluída e a prática, a experiência, os exemplos, milhares de exemplos é o que vai facilitar muito esse processo, tá bom?


## Técnicas, Procedimentos e Orientações Práticas

- É claro que uma é completamente diferente da outra, né? não tem um atendimento que é igual, eles são completamente diferentes, porque eles são eh o o campo energético, espiritual, inconsciente da pessoa.
- Então, eu vou trazer aqui um pouquinho onde aquilo flui de uma maneira natural e precisa ter um processo de presença e de condução, de escuta, atenta e condução daquele processo.
- Não pode cair, porque a gente tá aqui numa apresentação, né, Andresa, mas até acabei de responder uma pergunta agora lá no na no canal eh humanos.
- Eu queria saber se de vocês que estão com as mãos levantadas se tem alguém que não passou por nada, nunca foi cliente do espaço humanidade, nunca fez metodologia terapeuta, nunca fez código não sabe de nada.
- Então eu só vou pedir para você e vou te pedir um favor que você fale e eu vou perguntar e aí eu gostaria que você repetisse seu nome completo em data de nascimento e dissesse eu, Patrícia, nome completo, e autorizo a divulgação dessa imagem pro código tá só pra gente deixar esse documentado para não ter problema.
- Então, não é sobre materializar o ser terapeuta, você se sente terapeuta, você já é terapeuta, você não tem clientes, é sobre viver de terapia e não sobre ser terapeuta, só para eu entender melhor onde tá esse perceb?
- Então, o quanto você está sem paciência, né, para construir, para se tornar a terapeuta, porque olha, a sua pergunta principal foi: "Eu quero materializar ser terapeuta".
- Aí eu vou me sentir confiante e vou conseguir materializar os meus clientes, automaticamente eu vou me sentir pronto o suficiente para atendê-lo.
- Relacionamento nesse caso é se você for progredir, tá, como terapeuta, materializar e conseguir viver bem disso, ter os clientes, enfim, o quanto você acredita que tem dois pontos aqui que eu quero perguntar para você para entender se é mais um ou mais o outro.
- Porque você disse, e eu te fiz uma pergunta lá atrás que que falou agora, conforme eu falei da confiança, eu me lembrei e vou falar o que eu estou sentindo, que eu acho que eu não recebi dos meus pais o afeto, né, o amor, enfim, que eu deveria, que eu merecia o que eu precisava.
- Só que agora você tem uma um agora com essa conversa que a gente teve, a o seu desejo está mais alinhado, porque você entende que para ser terapeuta você precisa experienciar, ganhar a confiança, não ganhar, não ter cliente.
- Então eu consegui identificar que você tava muito acreditando que era a guerreira, mas quando você tá na guerreira guerreando, eu tô, eu tô fazendo, mas você não está fazendo porque só no seu inconsciente, na verdade, ele não tá fazendo, eu percebo que você não está tão na guerreira, você tá na donzela porque você tá acreditando que tá fazendo uma coisa…
- E aí depois eu, se fosse meu cliente e eu precisasse usar essas fichinhas, eu apagaria e colocaria a pergunta aqui, porque depois quando eu for falar com ele aqui três meses, que ele quis quer fazer outro manência, por exemplo, eu sei o que aconteceu aqui.
- E porque o que eu falei com a Patrícia, ela falou, ela trouxe todas essas perguntas, síntese do sentimento, qual era o sentimento?


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- Então eu só vou pedir para você e vou te pedir um favor que você fale e eu vou perguntar e aí eu gostaria que você repetisse seu nome completo em data de nascimento e dissesse eu, Patrícia, nome completo, e autorizo a divulgação dessa imagem pro código tá só pra gente deixar esse documentado para não ter problema.
- Então Patrícia você e autoriza a divulgação desse material, né, do seu do seu vídeo pr pr as aulas do código Martins autoriza a divulgação desse material pro código aqui.
- Eu sinto que ficou mais claro e que eu primeiro tenho que trabalhar em mim a minha autoestima e a minha confiança para depois então poder ajudar o outro.
- Eu tenho ganho consciência que eu eh não sei se tem a ver, mas vou dizer aquilo que eu estou a sentir que eu julguei muito os meus pais no sentido de achar que eles não tinham dado o amor que eu que achava que eles deveriam dar e eu sinto que pode vir daí essa sensação que eu tenho de abandono.
- Eh, o que eu sinto é que houve sim alturas da minha vida na na minha infância que eu senti que precisava de mais apoio e que daí vem essa sensação de abandono.
- Aí eu vou me sentir confiante e vou conseguir materializar os meus clientes, automaticamente eu vou me sentir pronto o suficiente para atendê-lo.
- Se eu não falo uma coisa pro meu filho porque ele não vai entender, ou eu não peço para ele resolver alguma coisa ou ficar perto de mim em alguma situação, ele não se sente merecedor da confiança.
- Eu acho que eu não consigo, acho que eu não sou tão forte assim, porque mas aqui você é porque você é, só que você não tá fazendo porque não lhe foi permitido fazer, porque te protegeram, não desconsideraram não por maldade, mas por falta de enfim de conhecimento, enfim, de tudo que quero que você não se sentiu amada porque justamente por isso, não é o…
- Vem uma imagem do meu pai a ralhar comigo e eu a querer me expressar e a querer falar e explicar e e sentir essa dor aqui não não conseguir e sentir-me pequena por por ver h a forma como ele tá a falar, a gritar e a expressão do corpo dele assim mais eh como se eu tivesse raiva.
- Eu estou a falar, eu estou triste, eu estou com medo, falo tudo que você, eu estou triste, eu estou com medo, eu estou perdida, eu não consigo perceber o que é que se está a passar, nem consigo que as coisas entrem na minha cabeça, porque eu estou sempre a pensar outras coisas e eu estou sempre a tentar entender porque é que eu não não sou vista, porque é…
- E todo o estudo, todo o processo de entendimento de padrão, isso facilita, mas não significa que vocês não vão conseguir conduzir todo o processo, porque a equipe espiritual da Câmara Manuciense tá atuando.
- Não tem como explicar como é esse lugar onde a gente de maneira consciente faz um trabalho espiritual, um trabalho de de processo de desobsessão e de processo autoobsessivo, né, de faixas e frações em tudo isso acabou, certo?


## Citações e Formulações de Alta Densidade

- “Então, eu vou trazer aqui um pouquinho onde aquilo flui de uma maneira natural e precisa ter um processo de presença e de condução, de escuta, atenta e condução daquele processo.”
- “Então, não é sobre materializar o ser terapeuta, você se sente terapeuta, você já é terapeuta, você não tem clientes, é sobre viver de terapia e não sobre ser terapeuta, só para eu entender melhor onde tá esse perceb?”
- “Então, o quanto você está sem paciência, né, para construir, para se tornar a terapeuta, porque olha, a sua pergunta principal foi: "Eu quero materializar ser terapeuta".”
- “Porque você disse, e eu te fiz uma pergunta lá atrás que que falou agora, conforme eu falei da confiança, eu me lembrei e vou falar o que eu estou sentindo, que eu acho que eu não recebi dos meus pais o afeto, né, o amor, enfim, que eu deveria, que eu merecia o que eu precisava.”
- “Só que agora você tem uma um agora com essa conversa que a gente teve, a o seu desejo está mais alinhado, porque você entende que para ser terapeuta você precisa experienciar, ganhar a confiança, não ganhar, não ter cliente.”
- “O que que a gente Então mudou tudo porque você chegou querer materializar uma coisa e eu tô te dando consciência que tá vendo como não é isso ou tem algo a mais e aí você fala que você não se sentiu.”
- “Eu acho que eu não consigo, acho que eu não sou tão forte assim, porque mas aqui você é porque você é, só que você não tá fazendo porque não lhe foi permitido fazer, porque te protegeram, não desconsideraram não por maldade, mas por falta de enfim de conhecimento, enfim, de tudo que quero que você…”
- “Eu estou a falar, eu estou triste, eu estou com medo, falo tudo que você, eu estou triste, eu estou com medo, eu estou perdida, eu não consigo perceber o que é que se está a passar, nem consigo que as coisas entrem na minha cabeça, porque eu estou sempre a pensar outras coisas e eu estou sempre a…”
- “Tô enquadrando essa cena, fazendo tratamento convencional, trazendo a energia de todo balu aí e recolhendo toda e qualquer consciência que tenha ficado nesse plano de nos planos astrais dessa fração, dessa consciência que precisa seguir colocando muito amor, muito caminho.”
- “Então eu consegui identificar que você tava muito acreditando que era a guerreira, mas quando você tá na guerreira guerreando, eu tô, eu tô fazendo, mas você não está fazendo porque só no seu inconsciente, na verdade, ele não tá fazendo, eu percebo que você não está tão na guerreira, você tá na…”
- “Mas assim, se por acaso vocês não tivessem visto nada disso, não soubesse nome, não importa a energia que vem fazer esses recolhimentos de almas, de frações que precisam de cuidado, né, de um pequeno nível ali daquela consciência dela que você encontrou que tava perdido, que tava precisando de…”
- “E aí depois eu, se fosse meu cliente e eu precisasse usar essas fichinhas, eu apagaria e colocaria a pergunta aqui, porque depois quando eu for falar com ele aqui três meses, que ele quis quer fazer outro manência, por exemplo, eu sei o que aconteceu aqui.”

## Conexões com a Wiki

- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Camara HumanoSense]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio da Liberdade Consciente]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Enquadramento na Piramide]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Conceito do Divorcio Energetico]]

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## FAQs para NotebookLM (Fase 2)

### Bloco 1: A Musculatura Energética e as Dinâmicas do Ego Clínico
```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
1. Como Andresa Molina conceitua a "Musculatura Energética", e de que forma a falta de prática clínica atrofia a percepção e a mediunidade do terapeuta?
2. Quais são as exigências de biossegurança do espaço físico no atendimento online, e por que a queda de internet no pico do transe é tratada como um risco biológico e espiritual grave?
3. De que maneira a "Lógica Invertida do Ego" sabota o terapeuta iniciante que condiciona a atração de clientes pagantes à conquista de sua autoconfiança?
4. Como é estruturado o "Princípio da Não-Indução" no Transe Astral e de que forma ele garante que a cura seja de autoria exclusiva do DNA emocional do assistido?
5. Por que a autora prefere atender o "Copo Vazio" (assistido leigo) a um colega de curso, e como a barreira teórica deste último atrapalha o transe na Câmara?
6. Como o pêndulo na mesa Humanosense desmascara a "Ilusão do Arquétipo" da Guerreira em clientes que operam, na verdade, na estagnação passiva da Donzela?
7. Como a "Dinâmica do Estagiário" deve ser trabalhada somática e emocionalmente pelo terapeuta em transição de carreira para esvaziar o orgulho e o medo do fracasso?
8. De que forma a superproteção familiar gera a dor da "Força Desconsiderada" na infância e como essa castração reflete na autoconfiança do adulto na vida prática?
```

### Bloco 2: A Causalidade Sistêmica, Anamnese e Blindagem de Campo
```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
9. Como a "Falsa Culpa Sistêmica" sabota o fluxo financeiro do adulto com base no seu julgamento presunçoso de que a relação ou vida dos pais é "ruim"?
10. Qual a importância clínica do arquivamento permanente das fichas cinzas com caneta após a sessão e de que forma isso otimiza o tratamento em consultas futuras?
11. Quais os passos e comandos práticos para gerenciar uma queda repentina de chamada ("resgate assíncrono") sem deixar a psique do assistido vulnerável no astral?
12. Descreva a "Anamnese por Desconstrução": como o terapeuta deve guiar as perguntas para afunilar a queixa racional do cliente até encontrar a emoção raiz?
13. Qual a diferença operacional na ativação da Pirâmide de enquadramento em sessões privadas versus apresentações públicas com plateia assistindo?
14. Como é conduzido o rebaixamento de frequência cerebral do assistido através da indução mecânica e varredura topográfica descrita pela autora?
15. Qual o decreto verbal exato para a abertura e desdobramento da Câmara Humanosense, unindo as linhagens da Terra com as tecnologias extraterrestres?
16. Por que o terapeuta deve forçar o assistido a verbalizar a dor da memória na "primeira pessoa" direcionando a fala ao holograma agressor na Câmara?
```

### Bloco 3: Operações no Transe, Esvaziamento e Selamento
```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
17. Como o terapeuta opera o "Resgate Emocional Especializado" quando a figura agressora na Câmara Astral apresenta uma resistência de "coração de pedra"?
18. Descreva os passos somáticos e vibracionais da fecundação no vácuo e da ativação da Kundalini no encerramento do processo de sangramento.
19. Quais as etapas e os comandos exatos de assepsia e fechamento do portal da Câmara Humanosense para garantir a segurança dos corpos etéricos?
20. Como é executado o giro do pêndulo na Mandala da Cura infundindo a trindade no assistido e de que forma se dá o desligamento físico do campo na placa?
21. Por que o acúmulo de estudos teóricos ("falso movimento") atua como uma barreira que impede o terapeuta iniciante de ir para a linha de frente do campo prático?
22. Como o corpo da criança reage e somatiza a raiva ao perceber que seu tamanho espiritual foi desconsiderado e poupado dos problemas dos pais?
23. De que forma o terapeuta deve propor permutas e treinos gratuitos no início do estágio sem desvalorizar a tecnologia do Humanosense?
24. O que acusa no sistema nervoso do cliente a sensação física de "calafrio intenso, prazer e tesão de ser você mesmo" na subida da Kundalini pós-fecundação?
```

## Referência

ANDRESA MOLINA. *Aula 09 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.
