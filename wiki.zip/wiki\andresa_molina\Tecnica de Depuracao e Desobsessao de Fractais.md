---
type: tecnica
author: Andresa Molina
tags: [depuracao, limpeza-energetica, fractal-de-dor, desobsessao]
sources: ["[[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]]"]
---
# Prática de Depuração e Limpeza de Solo (Esgotamento do Fractal)

- **Objetivo**: Conectar o assistido aos fractais de dor retidos, esgotar a carga magnética dessas memórias e efetuar a desobsessão de formas-pensamento autoobsessivas alimentadas por ectoplasma.
- **Pré-requisitos**: Mesa HumanoSense, autorização do assistido, e acoplamento com a equipe espiritual de amparo.
- **Passo a Passo**:
  1. Conduzir o assistido (usando comandos do kit de comandos azuis) até a ressonância do trauma/fractal de dor na linha do tempo.
  2. Orientá-lo a sentir integralmente a emoção retida (autorizar o choro, angústia, medo) descarregando a massa acumulada.
  3. Ao esgotar o fractal de seu magnetismo, a egrégora de amparo é ativada para realizar a remoção miasmática e desobsessão espiritual daquela fração.
  4. Deixar o solo sagrado (sistema energético) limpo e o 'útero renovado' para a fase de Execução.
- **Duração/Frequência**: Fase 2 de atendimento clínico. Dura o tempo necessário para o choro e a catarse emocional cessarem.
- **Indicadores de Sucesso**: O cliente experimenta alívio físico, relaxamento somático nítido na região do peito e esgotamento da dor emocional do fractal.
- **Variações**: Adaptável conforme a densidade espiritual encontrada e o acoplamento da equipe de amparo necessária.
- **Conceitos Envolvidos**: [[Conceito do Metodo HumanoSense]], [[Conceito de Automagia]], [[Conceito dos Tres Estados de Cura]]
- **Notas Pessoais**: Sangrar a dor emocional é indispensável para desfazer a obsessão interna e externa.

## Perguntas Frequentes / Didática de Atendimento

### De que forma o "esvaziamento e limpeza do terreno fértil" na fase de depuração prepara o útero/sistema do assistido para uma manifestação ou cocriação responsável?

A fase de depuração esvazia o terreno ao obrigar o paciente a sentir e esgotar os fractais de dor, atuando como uma "limpeza espiritual" profunda que afasta os processos autoobsessivos instalados no corpo. Isso desobstrui o sistema da pessoa, transformando o "terreno" estagnado em um "solo limpo, sagrado" ou num "útero renovado" (Andresa utiliza a palavra "útero" atrelada ao estado "renovado" e "fecundação" para a manifestação no texto).

Esse útero renovado é vital para que a manifestation da próxima fase (Execução) seja *responsável*. Sem o peso da dor cegando a mente, a pessoa entra num nível de extrema clareza somática. A autora explica que, após essa limpeza, muitas pessoas percebem que "não quer aquilo que ela diz que queria, que ela quer uma outra coisa". A cocriação se torna responsável e sustentável porque o indivíduo passa a semear apenas "aquilo que ela entende que ela vai dar conta de sustentar depois", evitando o nascimento de metas destrutivas.


## Referencia

ANDRESA MOLINA. *Prática de Depuração e Limpeza de Solo (Esgotamento do Fractal)*. Aula 01 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]].
