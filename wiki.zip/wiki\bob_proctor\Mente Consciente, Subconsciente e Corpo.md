---
type: transcricao
author: Bob Proctor
tags: [bob-proctor, mente-consciente, subconsciente, corpo, livre-arbitrio]
sources: ["[[raw/transcriptions/Bob Proctor - Você nasceu rico - parte 5 (dublado e legendado).md]]"]
---

# Mente Consciente, Subconsciente e Corpo

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/transcriptions/Bob Proctor - Você nasceu rico - parte 5 (dublado e legendado).md]]


## Síntese

A parte 5 estrutura a mente em consciente, subconsciente e corpo. Bob destaca que a mente consciente aceita ou rejeita ideias, enquanto o subconsciente e o corpo executam o que foi aceito repetidamente.

## 80/20

- A mente consciente escolhe.
- O subconsciente executa o padrão.
- O corpo expressa a imagem mental.

## Leitura Analítica

- O texto insiste que resultados são frutos de pensamentos treinados.
- O ambiente, as pessoas e a imagem interna moldam o que acontece.

## Conexões com a Wiki

- [[wiki/bob_proctor/Imagem Mental e Células de Reconhecimento]]
- [[wiki/bob_proctor/Princípio das Cinco Leis da Criação]]

## Referencia

BOB PROCTOR. *Mente Consciente, Subconsciente e Corpo*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/transcriptions/Bob Proctor - Você nasceu rico - parte 5 (dublado e legendado).md]]. Acesso em: 17 jun. 2026.
