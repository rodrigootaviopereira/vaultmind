---
type: technique
author: Andresa Molina
tags: [enquadramento-privado, isolamento-antecipado, plateia, egrégora]
sources: ["[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"]
---

# Técnica do Enquadramento Público vs. Privado (A antecipação da Pirâmide)

- **Definição**: O ajuste tático temporal da proteção geométrica. Em consultas particulares, a pirâmide é ativada instantes antes da régua ou da descida ao transe; contudo, se a sessão estiver sendo vista por dezenas de alunos ou plateia, o enquadramento deve ocorrer de imediato, cortando a influência externa.
- **Como praticar e seu Propósito**:
  1. **Análise de Contexto**: Se a sessão for gravada ou feita na frente de uma plateia, o terapeuta não aguarda o final da anamnese para montar o enquadramento.
  2. **Decreto Antecipado**: O terapeuta faz os estalos e visualiza a pirâmide logo após as saudações iniciais: "Tô construindo aqui uma pirâmide... isolando essa pirâmide e isso de toda e qualquer energia que seja ausente de nós duas dentro desse campo de força de proteção".
  O propósito é bloquear a projeção de sentimentos, pena, ou pensamentos da plateia/alunos no campo da pessoa assistida, garantindo pureza radiestésica absoluta e blindagem neurológica para o transe.
- **Evidências**: "Antes de mais nada, eu vou é enquadrar a gente numa pirâmide... Se tivesse só eu e você sem as pessoas assistindo, não precisaria fazer nesse momento. Eu faria as perguntas e no começo do tratamento energético eu iria colocar a pirâmide. Mas como a gente tá em muitas pessoas, eu já vou fazer esse trabalho agora, tá? Pra gente se isolar. Então tô colocando, tô construindo aqui uma pirâmide nessa sala virtual, colocando eu padrista Martins dentro da pirâmide, isolando essa pirâmide e isso de toda e qualquer energia que seja ausente de nós duas dentro desse campo de força."
- **Conexões**: [[Tecnica de Isolamento em Piramide]], [[Tecnica de Enquadramento na Piramide]]

## Perguntas Frequentes / Didática de Atendimento

### 10. Qual a diferença operacional na ativação da Pirâmide de enquadramento em sessões privadas versus apresentações públicas?
**Resposta**: A diferença é a urgência e o momento de ativação do escudo magnético.

Em sessões estritamente privadas (terapeuta e paciente), o enquadramento não precisa acontecer na entrevista inicial: **"Se tivesse só eu e você sem as pessoas assistindo, não precisaria fazer nesse momento. Eu faria as perguntas e no começo do tratamento energético eu iria colocar a pirâmide"**.

Já em apresentações públicas, com o olhar de uma plateia, o terapeuta ergue a proteção magnética imediatamente após o primeiro "oi". A nível vibracional, a pirâmide é armada no ato das perguntas para bloquear a invasão psíquica dos espectadores na biologia do paciente: **"Mas como a gente tá em muitas pessoas, eu já vou fazer esse trabalho agora, tá? Pra gente se isolar. Então tô colocando, tô construindo aqui uma pirâmide... isolando essa pirâmide e isso de toda e qualquer energia que seja ausente de nós duas dentro desse campo de força"**.


## Referencia

ANDRESA MOLINA. *Técnica do Enquadramento Público vs. Privado*. Aula 09 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]].
