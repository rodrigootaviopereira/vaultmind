---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_46_producao_das_particulas.md]]"]
---

# Cap 046 - Producao Das Particulas

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_46_producao_das_particulas.md]]

## Referencia

ANDRESA MOLINA. *Cap 046 - Producao Das Particulas*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_46_producao_das_particulas.md]]. Acesso em: 17 jun. 2026.
