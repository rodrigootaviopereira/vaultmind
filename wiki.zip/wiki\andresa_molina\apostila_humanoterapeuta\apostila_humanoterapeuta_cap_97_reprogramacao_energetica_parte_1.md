---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_97_reprogramacao_energetica_parte_1.md]]"]
---

# Cap 097 - Reprogramacao Energetica Parte 1

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_97_reprogramacao_energetica_parte_1.md]]

## Referencia

ANDRESA MOLINA. *Cap 097 - Reprogramacao Energetica Parte 1*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_97_reprogramacao_energetica_parte_1.md]]. Acesso em: 17 jun. 2026.
