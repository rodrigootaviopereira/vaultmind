---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_50_descricao_da_experiencia_da_fenda_dupla.md]]"]
---

# Cap 050 - Descricao Da Experiencia Da Fenda Dupla

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_50_descricao_da_experiencia_da_fenda_dupla.md]]

## Referencia

ANDRESA MOLINA. *Cap 050 - Descricao Da Experiencia Da Fenda Dupla*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_50_descricao_da_experiencia_da_fenda_dupla.md]]. Acesso em: 17 jun. 2026.
