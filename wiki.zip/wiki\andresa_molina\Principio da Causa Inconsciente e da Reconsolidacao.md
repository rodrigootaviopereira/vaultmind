---
type: principio
author: Andresa Molina
tags: [ancestralidade, inconsciente, reconsolidacao, cura-real, 7a-coordenada, desipnose]
sources: ["[[raw/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]]", "[[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]]"]
---

# Princípio da Causa Inconsciente e da Reconsolidação

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]]
  - [[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]]

## Definição

- **Definição**: O Princípio da Causa Inconsciente e da Reconsolidação estabelece que todo sintoma crônico (dor física, cansaço, escassez ou crise emocional) tem sua causa estrutural em registros e memórias armazenados no inconsciente (nesta vida, gestacional ou ancestral). A cura real e definitiva do assistido só ocorre quando se acessa a causa originária no corpo físico e realiza-se a reconsolidação (desprogramação celular) dessa marca, alterando a resposta vibracional e o registro informacional da dor.
- **Formulação de apoio**: Não é possível solucionar problemas de base inconsciente através do esforço do cérebro lógico ou de terapias baseadas em raciocínio verbal (ressignificação mental). O processo exige a desipnose da trilha neural de sobrevivência e a liberação somática da energia retida no local do trauma.

## Justificativa

- Este princípio é o alicerce metodológico do HumanoSense e da Humanoterapia. Ele explica por que tratamentos paliativos e analíticos falham repetidamente em resolver sintomas crônicos: eles gerenciam a mente consciente racional, enquanto a causa real permanece rodando de forma hipnótica e oculta sob a forma de memórias celulares.

## Evidências

- *"A ciência já comprovou que a gente pode caminhar para a reconsolidação dessas informações. O que significa isso? compreendendo, mudando, ganhando consciência desse processo... fazendo a transformação dessa informação no corpo..."*
- *"É como se a gente pudesse mudar o passado. [...] dá para ir lá acessar o momento dessa dor ou dessas dores suas ou dos seus ancestrais e fazer um trabalho de reconsolidação nesta marca que habita o seu corpo, desprogramar..."*

## Implicações

- **Foco na Raiz**: O terapeuta deve ignorar a "máscara" ou a queixa lógica superficial do assistido e rastrear a causa oculta no inconsciente por meio da leitura de campo e do corpo físico.
- **Necessidade de Catarse**: A cura exige que a informação dolorosa seja acessada de forma somática e drenada (sangria), permitindo que a célula desinflame energeticamente.

## Conexões

- [[Conceito de Ressignificacao vs Reconsolidacao]]
- [[Principio da Memoria Corporal Inconsciente]]
- [[Conceito do Mapa da Alma]]

## Perguntas Frequentes / Didática de Atendimento

### O que é a desipnose e como ela cura o corpo?

A **desipnose** (ou desprogramação) é um processo profundo de **reconsolidação de memória**, apresentado na aula como um contraponto à tradicional "hipnose" ou "reprogramação mental". Em vez de tentar apenas "ressignificar" o passado de forma racional, pensar positivo ou inserir uma nova crença mental, a desipnose atua para **desfazer e desprogramar o condicionamento hipnótico e emocional** que manipula as nossas reações automáticas desde a infância ou que foi herdado da ancestralidade.

**Como a desipnose cura o corpo na prática:**

*   **Acesso à Coordenada Física:** O processo não ocorre apenas na mente, mas começa rastreando e localizando a "marca" física exata por meio da [[Tecnica de Mapeamento Somatico da Raiva|Prática de Mapeamento Somático da Raiva]].
*   **Limpeza e "Sangria" da Ferida:** Ao localizar essa marca e autorizar a emoção reprimida a existir, o corpo passa por uma espécie de cirurgia emocional — a "sangria" executada pelo [[Tecnica do Trabalho Energetico de Sangria|Trabalho Energético de "Sangria"]]. Isso significa drenar a pressão e a dor acumuladas, desinflamando o sistema (que causava gastrites, dores crônicas e úlceras) para que o curativo seja feito e a cicatrização celular aconteça.
*   **Mudança do "Passado" Vibracional:** Apoiada por trabalhos energéticos e espirituais, a desipnose transmuta a carga daquela dor direto na base celular, operando quase como se fosse possível **"mudar o passado" dentro do indivíduo**.

Ao realizar essa desprogramação, o corpo deixa de operar em estado de alarme e inflamação crônica. O indivíduo recupera sua autonomia (sistema *Rage*) e se liberta das crises de ansiedade, culpa e surtos emocionais que pareciam surgir "do nada", parando de ser refém das programações de sobrevivência do passado.

## Notas Pessoais

- Reservado para observações do usuário no uso prático do princípio.

## Referência

ANDRESA MOLINA. *Princípio da Causa Inconsciente e da Reconsolidação*. Aula 03 (A Raiva que Virou Culpa) e Aula 07 (A Cura Buscada em Todo Lugar). Fontes: [[raw/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]] e [[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]].
