---
type: conceito
author: Andresa Molina
tags: [mediunidade, intuicao, influencia, canalizacao]
sources: ["[[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]"]
---
# Influência vs. Intuição (A Dinâmica da Mediunidade Livre)

- **Definição Precisa**: Os dois polos operacionais da espiritualidade livre no método: a Influência (polaridade masculina externa de magnetizar e engajar) e a Intuição (polaridade feminina interna de captar o sentir do coração superior).
- **Sinônimos/Variações**: Influência e Intuição, Mediunidade Proativa vs Receptiva, Polaridade da Mediunidade
- **Contexto de Uso**: Avaliação do uso equilibrado da sensibilidade e da inteligência espiritual nos atendimentos e na vida.
- **Relação com Princípios**: [[Principio da Inteligencia Espiritual]], [[Principio da Fusao Criacional]]
- **Exemplos do Material**: "A influência é uma energia masculina porque ela vai para fora para influenciar o outro... é a força que envolve, seduz e engaja... Intuição é a informação do coração, é uma sensação, capta além dos cinco sentidos, é interno, é feminino. É ouvir o seu coração... A espiritualidade livre nasce da união entre a intuição que sente e a inspiração que move."
- **Aplicação Prática**: Unir a captação interna da intuição (sinalizando caminhos) à força de expressão externa (Influência) para agir com coerência e brilho magnético.
- **Conexões Externas**: [[Conceito do Metodo HumanoSense]]

## Perguntas Frequentes / Didática de Atendimento

**Pergunta 21: Como a mediunidade é operada na Mandala através da polaridade entre "Influência" (masculino/externo) e "Intuição" (feminino/interno)?**

Na Mandala do Amor, a "Mediunidade" é tratada como "a energia que movimenta o espírito. É a capacidade de captar, de traduzir e manifestar o invisível". Ela opera através do balanço magnético entre o externo e o interno:
*   **Influência (Polo Masculino):** É a externalização energética. A autora define que "é uma energia masculina porque ela vai para fora para influenciar o outro... é a força que envolve, seduz e engaja". É a inspiração colocada no mundo para movimentar pessoas e projetos.
*   **Intuição (Polo Feminino):** É o recolhimento e a escuta visceral. É "a informação do coração, é uma sensação, capta além dos cinco sentidos, é interno, é feminino". É a capacidade de silenciar o externo para ouvir o mental superior.

## Referencia

ANDRESA MOLINA. *Influência vs. Intuição (A Dinâmica da Mediunidade Livre)*. Aula 02 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]].
