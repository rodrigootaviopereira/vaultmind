---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_107_frequencia_inicial_frequencia_x_palavra.md]]"]
---

# Cap 107 - Frequencia Inicial Frequencia X Palavra

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_107_frequencia_inicial_frequencia_x_palavra.md]]

## Referencia

ANDRESA MOLINA. *Cap 107 - Frequencia Inicial Frequencia X Palavra*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_107_frequencia_inicial_frequencia_x_palavra.md]]. Acesso em: 17 jun. 2026.
