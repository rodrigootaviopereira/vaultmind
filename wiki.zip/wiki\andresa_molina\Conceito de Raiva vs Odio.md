---
type: concept
author: Andresa
tags: [raiva, odio, diferencas, apodrecimento-emocional]
sources: ["[[raw/archive/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]]"]
---

# Raiva vs. Ódio

**A distinção existencial entre uma emoção biológica e motriz essencial (a raiva) e o seu estado doentio, paralisante e apodrecido causado pela cronificação e falta de externalização (o ódio).**

Muitas pessoas fundem as duas palavras, acreditando que devem abolir a raiva de suas vidas para serem pessoas boas. A autora separa categoricamente as duas frequências:
* **Raiva:** É uma *emoção* natural e pontual. Ela serve como força propulsora (sistema Rage) para proteger o campo, demarcar território e fornecer combustível para destruir cenários nocivos (como um abuso ou um limite violado).
* **Ódio:** É um *sentimento* arraigado e tóxico. Ele não nasce por si só; ele é a raiva que foi trancada dentro do corpo e não pôde ser externalizada no momento certo. O ódio é corrosivo ("corroi o nosso coração"), gerando raízes profundas que matam a empatia e a saúde do indivíduo.

> **Citação Literal:** "claro, a gente não tá falando de ódio, né? ódio é um sentimento que corroi o nosso coração. Nós estamos falando de raiva e raiva é uma emoção, né, que se ela não for externalizada, ela pode sim evoluir, criar raízes que vai fazendo a gente ficar tão magoado, tão machucado, que isso vira um ódio."

---

## Perguntas Frequentes / Didática de Atendimento

**1. Qual é a diferença fundamental entre raiva e ódio de acordo com a autora Andresa Molina?**

**Resposta:** A raiva é uma *emoção* natural e necessária que, se não for externalizada, pode evoluir, criar raízes e fazer a pessoa ficar tão magoada e machucada a ponto de virar ódio. O ódio, por sua vez, é um *sentimento* rancoroso que corrói o coração. O objetivo da coordenada é colocar cada coisa em seu lugar para usar a raiva como potencializador e proteção, sem que ela degenere em ódio.
