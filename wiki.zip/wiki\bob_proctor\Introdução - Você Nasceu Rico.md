---
type: principio
author: Bob Proctor
tags: [bob-proctor, livro, introducao, liberdade, pensamento]
sources: ["[[raw/archive/bob_proctor_você_nasceu_rico_1/bob_proctor_você_nasceu_rico_1_cap_02_introdução.txt]]"]
---

# Princípio: Ler com abertura pode mudar a vida

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/bob_proctor_você_nasceu_rico_1/bob_proctor_você_nasceu_rico_1_cap_02_introdução.txt]]


## Síntese Analítica

A introdução apresenta o livro como uma virada de rota. A mensagem central é que a pessoa pode sair do modo automático, reconhecer o próprio potencial e escolher um caminho mais livre e consciente.

## Referencia

BOB PROCTOR. *Princípio: Ler com abertura pode mudar a vida*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/bob_proctor_você_nasceu_rico_1/bob_proctor_você_nasceu_rico_1_cap_02_introdução.txt]]. Acesso em: 17 jun. 2026.
