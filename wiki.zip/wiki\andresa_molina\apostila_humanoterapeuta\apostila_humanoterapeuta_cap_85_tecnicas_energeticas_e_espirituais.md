---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_85_tecnicas_energeticas_e_espirituais.md]]"]
---

# Cap 085 - Tecnicas Energeticas E Espirituais

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_85_tecnicas_energeticas_e_espirituais.md]]

## Referencia

ANDRESA MOLINA. *Cap 085 - Tecnicas Energeticas E Espirituais*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_85_tecnicas_energeticas_e_espirituais.md]]. Acesso em: 17 jun. 2026.
