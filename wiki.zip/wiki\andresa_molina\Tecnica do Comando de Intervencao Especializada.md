---
type: tecnica
author: Andresa Molina
tags: [intervencao-especializada, entidades-especialistas, solucao-mecanica, equipes-astrais]
sources: ["[[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]]"]
---

# Comando de Intervenção Especializada (Invocação de equipes específicas para destravar mecanismos ou curar ferimentos na cena)

- **Objetivo**: Convocar equipes astrais especializadas (médicos, engenheiros, bombeiros astrais, cirurgiões) para realizar reparos mecânicos, cirúrgicos ou desobstruções de alta complexidade em cenários e contrapartes presas no campo astral do assistido.
- **Pré-requisitos**: Identificação de barreiras intransponíveis ao resgate padrão (correntes, desabamentos, ferimentos graves, etc.).
- **Passo a Passo**:
  1. O terapeuta observa ou pergunta o que impede a contraparte de se libertar na cena.
  2. Identificada a barreira mecânica ou física na tela mental do assistido, decreta o comando exato em voz alta:
     *"Em nome da minha amada presença de Deus, eu sou em mim, pela chama trina que brilha em meu coração, eu invoco a presença de todas as entidades especialistas boas e excelentes na execução dessa tarefa que tiverem interesse em contribuir. Podem se aproximar e executar as suas funções."*
  3. O terapeuta guia o assistido a visualizar a equipe de especialistas executando o destravamento (ex: cerrando as correntes, curando os ferimentos ou limpando os destroços) para viabilizar o resgate.
- **Duração/Frequência**: Aplicada exclusivamente quando o cenário espiritual exige atuação além do recolhimento padrão.
- **Indicadores de Sucesso**: Dissolução da barreira astral visualizada, permitindo que a contraparte seja recolhida à [[Conceito da Camara HumanoSense|Câmara HumanoSense]].
- **Variações**: Convocação de cirurgiões astrais para ferimentos em corpos sutis vs. engenheiros astrais para destruição de masmorras ou amarras.
- **Conceitos Envolvidos**: [[Conceito de Entidades de Resgate vs Especialistas]], [[Tecnica do Comando de Encaminhamento Padrao]]

## Perguntas Frequentes / Didática de Atendimento

## Perguntas Frequentes / Didática de Atendimento

### 17. Em quais situações clínicas específicas o terapeuta deve evocar as equipes especializadas e de que maneira atuam?
**Resposta**: O terapeuta deve evocar esse comando especializado para "tratamentos de situações específicas que necessitem de entidades especializadas em alguma função", ou seja, quando o problema na cena astral é físico ou mecânico, e "não tem a ver com o recolhimento em si".

A nível energético, essas equipes astrais atuam como engenheiros ou socorristas do holograma: "precisava de estravar que era a roda da carroça... Pode vir um pedreiro porque a casa caiu. Pode vir um bombeiro para tirar dos resgat para tirar dos destroços. Pode vir um piloto para ajudar a retomar uma rota... pode vir um conhecedor de medicina da floresta". A verbalização convoca as "entidades especialistas boas e excelentes na execução dessa tarefa".

## Referencia

ANDRESA MOLINA. *Comando de Intervenção Especializada*. Aula 06 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]].
