---
type: conceito
author: Andresa Molina
tags: [inteligencia-emocional, repressao, mascara, somatizacao, conveniencia, 3a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito da Falsa Inteligência Emocional

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: A Falsa Inteligência Emocional refere-se à distorção social e corporativa de usar o autocontrole e o equilíbrio artificial para embotar, reprimir e silenciar emoções legítimas. Trata-se da romantização de "engolir sapos" para manter a conveniência externa e a validação social em troca de estrelinhas comportamentais, resultando em inflamação física e desvalor próprio.
- **Formulação de apoio**: O sistema social e corporativo costuma exigir obediência e docilidade, aplaudindo quem não demonstra alteração de humor sob pressão extrema. No entanto, conter a raiva gera uma inflamação emocional crônica invisível que corrói os tecidos, bloqueia processos biológicos saudáveis (dificultando inclusive o emagrecimento) e se manifesta em gastrites nervosas, úlceras e perda de senso de merecimento financeiro.

## Contexto de Uso

- Usado para analisar a resistência de assistidos altamente racionalizados ou que consideram seu autocontrole (a máscara de "equilibrado") como uma virtude inquestionável. O terapeuta demonstra que o excesso de conveniência social é, na verdade, uma autonegação que adoece o corpo e impede a prosperidade.

## Relação com Princípios

- [[Principio da Raiva como Potencial de Autonomia]]
- [[Principio do Amor Condicionado e Autoabandono]]
- [[Conceito das Camadas da Dor]]

## Exemplos do Material

- *"Você começou a manifestar sua raiva sorrindo, só que por dentro você tava explodindo, só que você aprendeu a controlar isso. E o problema é que você começou a achar que isso era bom... E aí você chamou de inteligência emocional, engoli o que você tava sentindo para ter uma uma úlcera, uma mais leve, é uma gastrite nervosa."*
- O indivíduo que é elogiado e recebe "estrelinhas" (como na escola) por ser obediente e manter a postura diante de graves injustiças no ambiente de trabalho, mas que sofre de inflamação crônica e não consegue emagrecer.

## Aplicação Prática

1. **Desmistificar o Controle**: Mostrar ao assistido que "engolir sapos com elegância" não é evolução espiritual ou inteligência, mas sim uma violência cometida contra as próprias células.
2. **Autorizar a Indignação**: Permitir que o assistido sinta e expresse a raiva legítima diante de abusos, desvinculando a expressão saudável da agressividade descontrolada.
3. **Tratar a Causa**: Em vez de gerenciar o sintoma com técnicas de controle mental, descer até a raiz do trauma gestacional ou de infância para reconsolidar a memória e liberar a pressão do sistema RAGE de forma definitiva.

## Perguntas Frequentes / Didática de Atendimento

### Como identificar se minha inteligência emocional é falsa?

Para identificar se a sua inteligência emocional é, na verdade, uma [[Conceito da Falsa Inteligencia Emocional|Falsa Inteligência Emocional]], você deve observar se o controle das suas reações está sendo usado para anular a si mesmo e manter conveniências externas, em vez de validar e processar o que você realmente sente.

Você pode identificar esse padrão de repressão disfarçado de inteligência emocional através dos seguintes sinais práticos:

*   **Você sorri enquanto explode por dentro:** Você aprendeu a engolir a raiva e a dor com "elegância", mantendo uma aparência dócil ou pacífica para não desagradar os outros, mesmo quando está vivenciando pressões extremas ou abusos. 
*   **Você reprime emoções para não parecer "louca" ou "surtada":** A sua tentativa de ter inteligência emocional se baseia em atender a uma expectativa social ou corporativa de nunca se alterar. Você "engole o choro" e se cala diante do que a machuca para continuar sendo bem aceita no ambiente.
*   **Você se orgulha de invalidar a própria dor:** Você se dá uma "estrelinha" mental e se parabeniza toda vez que consegue não expressar sua raiva ou frustração. Ao fazer isso, você comemora o fato de ter desconsiderado os seus próprios sentimentos, repetindo o padrão de obediência cega exigido na sua infância para não perder o amor e a aprovação, estudado no [[Principio do Amor Condicionado e Autoabandono|Princípio do Amor Condicionado e Autoabandono]].
*   **Seu corpo manifesta doenças e dores crônicas:** Como a emoção reprimida não desaparece, ela se converte em inflamação celular nas [[Conceito das Camadas da Dor|Camadas da Dor]]. Se a sua inteligência emocional for falsa, seu corpo dará sinais físicos através de úlceras, gastrites nervosas, dores nas costas, dores no pescoço ou até dificuldade de emagrecer por causa do corpo emocionalmente inflamado.
*   **Você vive um ciclo de desvalorização e escassez:** A recusa em expressar o que sente e se impor destrói o seu senso de valor pessoal. Como consequência de desvalorizar a si mesma, você passa a atrair relacionamentos mornos ou abusivos, além de vivenciar perdas financeiras crônicas, dívidas e boletos, ativando o [[Conceito do Ciclo de Autopunicao|Ciclo de Autopunição]], pois o mundo externo apenas reflete a sua falta de autovalorização.

Em suma, **a falsa inteligência emocional é a romantização do ato de engolir emoções**. Se o seu controle emocional serve apenas para manter os outros confortáveis enquanto você adoece, perde dinheiro ou fica extremamente exausta, isso não é inteligência, é uma anulação contínua do seu próprio ser, privando-o do [[Principio da Raiva como Potencial de Autonomia|Princípio da Raiva como Potencial de Autonomia]].

## Referência

ANDRESA MOLINA. *Conceito da Falsa Inteligência Emocional*. Aula 03 - Coordenada 3 (A Raiva que Virou Culpa). Fontes: [[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]].
