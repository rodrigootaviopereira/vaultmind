---
type: aula
author: Andresa Molina
tags: [codigo-humanosense, humanosense, aula-05, reingestao-2026-06-19]
sources:
  - "[[raw/archive/andresa_molina/transcriptions/05   Código Humanosense - Andresa Molina.md]]"
---
# Aula 05 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/05   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `05   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 25.777 palavras; 876 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- Então, eh, o que você precisa fazer precisa ser feito, o que você traz na alma, porque você tá falando de expansão de consciência, certo?
- E aqui quando a gente coloca o consciente e o inconsciente, né, na folhinha de decuração, eh, já tava até conversando com um colega que tá aqui também e e aí aqui a gente vai tá perguntando, né, sobre todas as pétalas e fazendo as perguntas e tendo consciente, neconsciente, só que a gente vai tá sempre dando foco naquela questão que deu, no caso, né, um…
- Eu vou, então eu coloquei três, só que quando eu fui lá e na na energia deu nove, falei na verdade não é o que eu tenho parece uma questão que vai dando visualização para visualização.
- É mais essa visualização tanto pra gente poder ir decurando no decorrer no final e pro cliente ele não vai precisar explicar esse ponto, né? a gente vai pegar o o assunto geral do que tirar um denominador comum e falar: "Olha, por esse caminho, é depende, depende, depende do cliente, depende da necessidade dele, depende da gente estar super presente pro…
- Aí fui, eu mostrei para ela e fiz uma pergunta, um exemplo, ela pegou assim: "Ah, eu nem sei como responder essa pergunta, porque muita gente nem tem consciência das perguntas dela parar de pensar." É, mas é porque assim, ó, a gente precisa entender que a gente tá sobre um campo de energia.
- Código humanosense não é um código à toa, ele é um campo, tem uma egrégora, tem um campo de força, não tem essa simulação.
- Eh, a minha questão, né, eu acho que tem a ver também com com isso, porque tá nas perguntas, eh, que eu entendi isso, que a gente vai seguir sempre o mesmo número de perguntas e aí na mandala do amor a gente tem femino masculino.
- É, por exemplo, no caso, mas uma coisa é fato, é um feminino extremamente ferido, mas ele não fica sempre num único comportamento, ele vai ser não, porque ele joga, ele é um bom jogador, na verdade é uma é uma manipuladora, é uma rainha manipulando.
- Então essas dores profundas que eles têm, mas nesses corpos, essas mentes, essas almas que estão ali se cortando para caber nessa nossa sociedade, sabe?
- Uma outra pergunta que eu tenho, que é uma coisa que me angustia um pouco, eh, por exemplo, a gente, eu fiz o humanoterapeuta, né, e a gente viu que tudo tá no energético, tá no espiritual e quando ele se manifesta no corpo, ele já tava lá se manifestando, né?
- Mas depende, ele é super meu cliente de terapia, eu sou psicólogo, eu sou psicanalista, ele é super meu cliente e tá tranquilo a gente mexer nessa dor de novo, porque quando eu mexo numa dor, automaticamente todo o meu mecanismo de defesa vai subir, aí eu tenho uma semana para me calçar, entende?
- Então fique em paz que vocês vão conseguir absorver bastante coisa e entender aí por uma outra via também que é a via dos códigos, a via do campo energético e espiritual.

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-88
- Então, eh, o que você precisa fazer precisa ser feito, o que você traz na alma, porque você tá falando de expansão de consciência, certo?
- Então, esses você vai ter que lidar com eles e fazer nascer aquilo, parar de fugir daquilo que você precisa colocar no mundo, que você trouxe como missão na sua alma.
- Você não falou de uma pergunta, de uma questão onde o seu assistido está com problema, é isso e ele não tá conseguindo identificar isso.

### Bloco 2 - frases 89-176
- Então a gente tem essas frentes para ele, ganhando consciência e também se permitindo ser tratado, percebendo que é mais difícil do que ele imaginava, percebendo que muitas coisas não dão certo, porque ele no fundo quer querer aquilo, quanto ele quer sustentar, suportar tudo que vem com aquilo, né?
- Você perguntou uma coisa, responde um monte de outra, não sei se respondeu, tava perguntando, não faz sentido com que acontece no entendimento, mas então ficou claro que no eu vou sempre voltar para aquela questão que ele trouxe para conseguir esvaziar aquela questão e aí depois se de repente ele perceber que não faz mais sentido ou não, aí a gente pode dar um suporte para ele de uma outra forma.
- Então a gente como tem um potencial, um estudo, um aprofundamento maior, a gente consegue buscar coisas muito mais profundas e memórias muito enraizadas que ele nem tem consciência que isso fica no seu campo, é nas suas células, isso fica na Então se você acabou de estudar oaputa, o homoterapeuta você estudou epigenética, você entendeu que aquilo que você traz que ele não tem consciência de tudo isso.

### Bloco 3 - frases 177-264
- Então aí sempre ficou uma dúvida muito grande na minha cabeça de qual é que você tem você, não tem como, porque se eu rejeito o pai de um ou o meu mesmo ou o biológico, o biológico ou o adutivo, mas principalmente o biológico, eu rejeito metade de mim.
- A gente pode eh ferida, a gente pode ter essas duas energias eh feridas, mas assim intercaladas eh por exemplo, em situações diferentes, né?
- E no mesmo instante o meu feminino, que é melindroso, ofendido, magoado, eh, enfim, dolorido, ele quentra em dor na dor dele.

### Bloco 4 - frases 265-352
- Então a gente tá caminhando num campo energético, espiritual, então vamos ter pra gente ter um pouquinho de cuidado e aí conforme a coisa for acontecendo a gente vai entendendo melhor como vai sendo essas respostas, tá bom?
- Então se eu tiver a força, eu tenho força para fazer, eu tenho força para sustentar morar fora do país, mas aí a minha mãe que é uma exploradora não me autoriza aí e eu não consigo me autorizar.
- E aí tentar explicar de um jeito algum exemplo que fica mais fácil, porque desse voltar pro útero é desafio do eu tenho que nascer, eu tenho que sair da origem e ir pro destino e ir embora e deixar essa mãe seguir, entendendo que essa consciência ela não é a criadora do meu espírito.

### Bloco 5 - frases 353-440
- E aqui quando a gente coloca o consciente e o inconsciente, né, na folhinha de decuração, eh, já tava até conversando com um colega que tá aqui também e e aí aqui a gente vai tá perguntando, né, sobre todas as pétalas e fazendo as perguntas e tendo consciente, neconsciente, só que a gente vai tá sempre dando foco naquela questão que deu, no caso, né, um desequilíbrio ali da questão que ela trouxe pra gente, né,…
- Então eu sou aquela pessoa que nunca tem dinheiro, que não tem cliente, porque não cobra, porque tá salvador.
- O Salvador é o que não tem cliente, porque ele acredita que ele é o Salvador.

### Bloco 6 - frases 441-528
- Eu vou, então eu coloquei três, só que quando eu fui lá e na na energia deu nove, falei na verdade não é o que eu tenho parece uma questão que vai dando visualização para visualização.
- É mais essa visualização tanto pra gente poder ir decurando no decorrer no final e pro cliente ele não vai precisar explicar esse ponto, né? a gente vai pegar o o assunto geral do que tirar um denominador comum e falar: "Olha, por esse caminho, é depende, depende, depende do cliente, depende da necessidade dele, depende da gente estar super presente pro que ele precisa." Depende.
- Aí fui, eu mostrei para ela e fiz uma pergunta, um exemplo, ela pegou assim: "Ah, eu nem sei como responder essa pergunta, porque muita gente nem tem consciência das perguntas dela parar de pensar." É, mas é porque assim, ó, a gente precisa entender que a gente tá sobre um campo de energia.

### Bloco 7 - frases 529-616
- Então é foi mais nesse sentido porque parou e aí dá para trabalhar no manocência e buscar mais dentro do racional dela para ela ir em busca desse movimento racionalmente ela ir em busca ela porque aí a gente vai tá trabalhando nesse porque a ciclino é aquele que ia lá e traía ela tinha essa ela tinha esse ímp e acabava fazendo, mas ela tava eu não sei até trabalhar tá cortando muito je tô conseguindo escut mas é um…
- Aí faz todo aquele link com tudo que você apresentou e aí você começa a fazer porque que ela tá usando aquilo, a dor que ela traz.
- Sim, porque senão a gente precisa entender que no mesmo pai da mesma mãe nascem consciências completamente distintas, com potências e comportamentos completamente e às vezes com índoles e caráter completamente distinto.

### Bloco 8 - frases 617-704
- Então aí nesse caso de fazer pergunta, eu teria que perguntar, por exemplo, se tá mais a ver com o biológico, não para ajudar a consciência, tipo, ah, é mais a esse lado ou eu acho que eu perguntaria, nesse caso que é uma um eu perguntaria dos dois, perguntaria dos dois.
- Tem muita coisa que tá no nosso inconsciente, mas que não é verdade no sentido de não ter acontecido efetivamente, mas que a gente carrega como verdade, que é tipo o sentimento de abandono da mãe que nunca nos abandonou.
- Só que o sentimento é esse, porque o campo de energia se esva de tal maneira, porque algo muito mais potente, não, Deus foi o macho alfa da história, ele foi lá, não é Deus, entende?

### Bloco 9 - frases 705-792
- É, por exemplo, no caso, mas uma coisa é fato, é um feminino extremamente ferido, mas ele não fica sempre num único comportamento, ele vai ser não, porque ele joga, ele é um bom jogador, na verdade é uma é uma manipuladora, é uma rainha manipulando.
- Então essas dores profundas que eles têm, mas nesses corpos, essas mentes, essas almas que estão ali se cortando para caber nessa nossa sociedade, sabe?
- Uma outra pergunta que eu tenho, que é uma coisa que me angustia um pouco, eh, por exemplo, a gente, eu fiz o humanoterapeuta, né, e a gente viu que tudo tá no energético, tá no espiritual e quando ele se manifesta no corpo, ele já tava lá se manifestando, né?

### Bloco 10 - frases 793-876
- Ah, então é como no na mandala da dor eu tenho que identificar mais aonde eu tô e pot aonde isso está em dores.
- Mas depende, ele é super meu cliente de terapia, eu sou psicólogo, eu sou psicanalista, ele é super meu cliente e tá tranquilo a gente mexer nessa dor de novo, porque quando eu mexo numa dor, automaticamente todo o meu mecanismo de defesa vai subir, aí eu tenho uma semana para me calçar, entende?
- Então fique em paz que vocês vão conseguir absorver bastante coisa e entender aí por uma outra via também que é a via dos códigos, a via do campo energético e espiritual.

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Então, eh, o que você precisa fazer precisa ser feito, o que você traz na alma, porque você tá falando de expansão de consciência, certo?
- E aqui quando a gente coloca o consciente e o inconsciente, né, na folhinha de decuração, eh, já tava até conversando com um colega que tá aqui também e e aí aqui a gente vai tá perguntando, né, sobre todas as pétalas e fazendo as perguntas e tendo consciente, neconsciente, só que a gente vai tá sempre dando foco naquela questão que deu, no caso, né, um…
- Então eu sou aquela pessoa que nunca tem dinheiro, que não tem cliente, porque não cobra, porque tá salvador.
- Mas nessas perguntas, então assim, eh, na questão da pessoa nunca vai, sempre vai ter que dar de um a 10.
- Eu vou, então eu coloquei três, só que quando eu fui lá e na na energia deu nove, falei na verdade não é o que eu tenho parece uma questão que vai dando visualização para visualização.
- É mais essa visualização tanto pra gente poder ir decurando no decorrer no final e pro cliente ele não vai precisar explicar esse ponto, né? a gente vai pegar o o assunto geral do que tirar um denominador comum e falar: "Olha, por esse caminho, é depende, depende, depende do cliente, depende da necessidade dele, depende da gente estar super presente pro…
- Aí fui, eu mostrei para ela e fiz uma pergunta, um exemplo, ela pegou assim: "Ah, eu nem sei como responder essa pergunta, porque muita gente nem tem consciência das perguntas dela parar de pensar." É, mas é porque assim, ó, a gente precisa entender que a gente tá sobre um campo de energia.
- Eh, a minha questão, né, eu acho que tem a ver também com com isso, porque tá nas perguntas, eh, que eu entendi isso, que a gente vai seguir sempre o mesmo número de perguntas e aí na mandala do amor a gente tem femino masculino.
- Aqui não tem como porque base a base é consciência, então teria que fazer a aplicação do manoterapeuta, entendeu?
- É, por exemplo, no caso, mas uma coisa é fato, é um feminino extremamente ferido, mas ele não fica sempre num único comportamento, ele vai ser não, porque ele joga, ele é um bom jogador, na verdade é uma é uma manipuladora, é uma rainha manipulando.

## Conceitos-Chave Extraídos

- Então, eh, o que você precisa fazer precisa ser feito, o que você traz na alma, porque você tá falando de expansão de consciência, certo?
- Então sim, ele é um contexto, é um trabalho para fazer materialização, só que ninguém materializa, ninguém planta nada se não tiver consciência e não limpar aquilo, porque por isso que as coisas não acontecem, não acontecem porque a pessoa ela só quer, mas no fundo ela não quer, porque o que ela quer vem com um monte de coisa, então por isso que não dá…
- Então a gente tem essas frentes para ele, ganhando consciência e também se permitindo ser tratado, percebendo que é mais difícil do que ele imaginava, percebendo que muitas coisas não dão certo, porque ele no fundo quer querer aquilo, quanto ele quer sustentar, suportar tudo que vem com aquilo, né?
- Então a gente como tem um potencial, um estudo, um aprofundamento maior, a gente consegue buscar coisas muito mais profundas e memórias muito enraizadas que ele nem tem consciência que isso fica no seu campo, é nas suas células, isso fica na Então se você acabou de estudar oaputa, o homoterapeuta você estudou epigenética, você entendeu que aquilo que você…
- Então a gente tá caminhando num campo energético, espiritual, então vamos ter pra gente ter um pouquinho de cuidado e aí conforme a coisa for acontecendo a gente vai entendendo melhor como vai sendo essas respostas, tá bom?
- E aí tentar explicar de um jeito algum exemplo que fica mais fácil, porque desse voltar pro útero é desafio do eu tenho que nascer, eu tenho que sair da origem e ir pro destino e ir embora e deixar essa mãe seguir, entendendo que essa consciência ela não é a criadora do meu espírito.
- Ela tem cois, então precisamos trabalhar isso, só que a força você não tá conseguindo e aí vamos trabalhando masculino e vamos mudando consciência para ela.
- E aí lá a gente vai ter, mas vamos e aí a gente muda de jogo porque quando você fechou o olho, muda é outra coisa quando a gente vai entrar no campo, vão ter comandos energéticos, espirituais, vai ter gregra domand cuidando, vai acontecer mon coisa tá essa é uma outra outra isso.
- O Salvador é o que não tem cliente, porque ele acredita que ele é o Salvador.
- Eu vou, então eu coloquei três, só que quando eu fui lá e na na energia deu nove, falei na verdade não é o que eu tenho parece uma questão que vai dando visualização para visualização.
- Aí fui, eu mostrei para ela e fiz uma pergunta, um exemplo, ela pegou assim: "Ah, eu nem sei como responder essa pergunta, porque muita gente nem tem consciência das perguntas dela parar de pensar." É, mas é porque assim, ó, a gente precisa entender que a gente tá sobre um campo de energia.
- Código humanosense não é um código à toa, ele é um campo, tem uma egrégora, tem um campo de força, não tem essa simulação.
- Eh, a minha questão, né, eu acho que tem a ver também com com isso, porque tá nas perguntas, eh, que eu entendi isso, que a gente vai seguir sempre o mesmo número de perguntas e aí na mandala do amor a gente tem femino masculino.
- Aqui não tem como porque base a base é consciência, então teria que fazer a aplicação do manoterapeuta, entendeu?
- Ah, então é como no na mandala da dor eu tenho que identificar mais aonde eu tô e pot aonde isso está em dores.
- Então fique em paz que vocês vão conseguir absorver bastante coisa e entender aí por uma outra via também que é a via dos códigos, a via do campo energético e espiritual.


## Técnicas, Procedimentos e Orientações Práticas

- Você não falou de uma pergunta, de uma questão onde o seu assistido está com problema, é isso e ele não tá conseguindo identificar isso.
- A minha pergunta é o seguinte, a gente sempre vai se atendendo processo naquela questão que o assistido trouxer ou pode desobrar em outras questões que nem por exemplo acontece no mano terapeuta, pessoas à vezes vai tratar relacionamento, mas ao longo do processo é a vida financeira que deslancha ou vai tratar uma questão familiar relacionamento que…
- E aqui quando a gente coloca o consciente e o inconsciente, né, na folhinha de decuração, eh, já tava até conversando com um colega que tá aqui também e e aí aqui a gente vai tá perguntando, né, sobre todas as pétalas e fazendo as perguntas e tendo consciente, neconsciente, só que a gente vai tá sempre dando foco naquela questão que deu, no caso, né, um…
- Então eu sou aquela pessoa que nunca tem dinheiro, que não tem cliente, porque não cobra, porque tá salvador.
- O Salvador é o que não tem cliente, porque ele acredita que ele é o Salvador.
- Mas nessas perguntas, então assim, eh, na questão da pessoa nunca vai, sempre vai ter que dar de um a 10.
- Eu vou, então eu coloquei três, só que quando eu fui lá e na na energia deu nove, falei na verdade não é o que eu tenho parece uma questão que vai dando visualização para visualização.
- É mais essa visualização tanto pra gente poder ir decurando no decorrer no final e pro cliente ele não vai precisar explicar esse ponto, né? a gente vai pegar o o assunto geral do que tirar um denominador comum e falar: "Olha, por esse caminho, é depende, depende, depende do cliente, depende da necessidade dele, depende da gente estar super presente pro…
- Aí fui, eu mostrei para ela e fiz uma pergunta, um exemplo, ela pegou assim: "Ah, eu nem sei como responder essa pergunta, porque muita gente nem tem consciência das perguntas dela parar de pensar." É, mas é porque assim, ó, a gente precisa entender que a gente tá sobre um campo de energia.
- Eh, a minha questão, né, eu acho que tem a ver também com com isso, porque tá nas perguntas, eh, que eu entendi isso, que a gente vai seguir sempre o mesmo número de perguntas e aí na mandala do amor a gente tem femino masculino.
- Aqui não tem como porque base a base é consciência, então teria que fazer a aplicação do manoterapeuta, entendeu?
- Uma outra pergunta que eu tenho, que é uma coisa que me angustia um pouco, eh, por exemplo, a gente, eu fiz o humanoterapeuta, né, e a gente viu que tudo tá no energético, tá no espiritual e quando ele se manifesta no corpo, ele já tava lá se manifestando, né?
- Ah, então é como no na mandala da dor eu tenho que identificar mais aonde eu tô e pot aonde isso está em dores.
- Mas depende, ele é super meu cliente de terapia, eu sou psicólogo, eu sou psicanalista, ele é super meu cliente e tá tranquilo a gente mexer nessa dor de novo, porque quando eu mexo numa dor, automaticamente todo o meu mecanismo de defesa vai subir, aí eu tenho uma semana para me calçar, entende?


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- Então se eu tiver a força, eu tenho força para fazer, eu tenho força para sustentar morar fora do país, mas aí a minha mãe que é uma exploradora não me autoriza aí e eu não consigo me autorizar.
- E aí tentar explicar de um jeito algum exemplo que fica mais fácil, porque desse voltar pro útero é desafio do eu tenho que nascer, eu tenho que sair da origem e ir pro destino e ir embora e deixar essa mãe seguir, entendendo que essa consciência ela não é a criadora do meu espírito.
- Então eu sou aquela pessoa que nunca tem dinheiro, que não tem cliente, porque não cobra, porque tá salvador.
- O Salvador é o que não tem cliente, porque ele acredita que ele é o Salvador.
- Então a gente precisa amadurecer isso, mas sim, isso é algo que é possível de acontecer e é vaidade, porque o salvador é vaidoso, de todo mundo.
- Então para eu identificar, por exemplo, ou para qualquer outra terapeuta identificar se ela está nesse papel de salvadora e não na missão, ela teria que estar nessas condições.
- É mais essa visualização tanto pra gente poder ir decurando no decorrer no final e pro cliente ele não vai precisar explicar esse ponto, né? a gente vai pegar o o assunto geral do que tirar um denominador comum e falar: "Olha, por esse caminho, é depende, depende, depende do cliente, depende da necessidade dele, depende da gente estar super presente pro…
- Então, uma coisa é a distância e outra coisa é com a pessoa que aqui não tem como a gente fazer a distância eh com a pessoa dormindo, por exemplo, como a gente consegue com a metodologia com a pessoa no hospital ou com a pessoa quetinha lá que me autorizou e eu ponho aqui, ok, mas ela tá no hospital.
- É, por exemplo, no caso, mas uma coisa é fato, é um feminino extremamente ferido, mas ele não fica sempre num único comportamento, ele vai ser não, porque ele joga, ele é um bom jogador, na verdade é uma é uma manipuladora, é uma rainha manipulando.
- Então essas dores profundas que eles têm, mas nesses corpos, essas mentes, essas almas que estão ali se cortando para caber nessa nossa sociedade, sabe?
- Ah, então é como no na mandala da dor eu tenho que identificar mais aonde eu tô e pot aonde isso está em dores.
- Mas depende, ele é super meu cliente de terapia, eu sou psicólogo, eu sou psicanalista, ele é super meu cliente e tá tranquilo a gente mexer nessa dor de novo, porque quando eu mexo numa dor, automaticamente todo o meu mecanismo de defesa vai subir, aí eu tenho uma semana para me calçar, entende?


## Citações e Formulações de Alta Densidade

- “Então, eh, o que você precisa fazer precisa ser feito, o que você traz na alma, porque você tá falando de expansão de consciência, certo?”
- “Então, esses você vai ter que lidar com eles e fazer nascer aquilo, parar de fugir daquilo que você precisa colocar no mundo, que você trouxe como missão na sua alma.”
- “E aqui quando a gente coloca o consciente e o inconsciente, né, na folhinha de decuração, eh, já tava até conversando com um colega que tá aqui também e e aí aqui a gente vai tá perguntando, né, sobre todas as pétalas e fazendo as perguntas e tendo consciente, neconsciente, só que a gente vai tá…”
- “Mas nessas perguntas, então assim, eh, na questão da pessoa nunca vai, sempre vai ter que dar de um a 10.”
- “Eu vou, então eu coloquei três, só que quando eu fui lá e na na energia deu nove, falei na verdade não é o que eu tenho parece uma questão que vai dando visualização para visualização.”
- “É mais essa visualização tanto pra gente poder ir decurando no decorrer no final e pro cliente ele não vai precisar explicar esse ponto, né? a gente vai pegar o o assunto geral do que tirar um denominador comum e falar: "Olha, por esse caminho, é depende, depende, depende do cliente, depende da…”
- “Aí fui, eu mostrei para ela e fiz uma pergunta, um exemplo, ela pegou assim: "Ah, eu nem sei como responder essa pergunta, porque muita gente nem tem consciência das perguntas dela parar de pensar." É, mas é porque assim, ó, a gente precisa entender que a gente tá sobre um campo de energia.”
- “Código humanosense não é um código à toa, ele é um campo, tem uma egrégora, tem um campo de força, não tem essa simulação.”
- “Eh, a minha questão, né, eu acho que tem a ver também com com isso, porque tá nas perguntas, eh, que eu entendi isso, que a gente vai seguir sempre o mesmo número de perguntas e aí na mandala do amor a gente tem femino masculino.”
- “É, por exemplo, no caso, mas uma coisa é fato, é um feminino extremamente ferido, mas ele não fica sempre num único comportamento, ele vai ser não, porque ele joga, ele é um bom jogador, na verdade é uma é uma manipuladora, é uma rainha manipulando.”
- “Uma outra pergunta que eu tenho, que é uma coisa que me angustia um pouco, eh, por exemplo, a gente, eu fiz o humanoterapeuta, né, e a gente viu que tudo tá no energético, tá no espiritual e quando ele se manifesta no corpo, ele já tava lá se manifestando, né?”
- “Mas depende, ele é super meu cliente de terapia, eu sou psicólogo, eu sou psicanalista, ele é super meu cliente e tá tranquilo a gente mexer nessa dor de novo, porque quando eu mexo numa dor, automaticamente todo o meu mecanismo de defesa vai subir, aí eu tenho uma semana para me calçar, entende?”

## Conexões com a Wiki

- [[Conceito do Metodo HumanoSense]]
- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Camara HumanoSense]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio da Liberdade Consciente]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Conceito do Parceiro da Missao]]

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## Referência

ANDRESA MOLINA. *Aula 05 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/05   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.
