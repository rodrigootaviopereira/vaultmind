---
type: tecnica
author: Andresa Molina
tags: [precificacao, tempo-de-sessao, honorarios, valor-terapeutico]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# Prática de Precificação e Duração Teto (A ancoragem temporal e financeira)

- **Objetivo**: Estruturar a sessão material do Humanosense delimitando um tempo teto para impedir o desgaste energético do terapeuta e estabelecer honorários elevados (High-Ticket) para forçar o comprometimento somático da cura pelo cliente.
- **Pré-requisitos**: Posicionamento de valor e autovalorização profissional.
- **Passo a Passo**:
  1. **Teto de Tempo**: Delimitar a sessão em um tempo teto absoluto de 2 horas. O terapeuta deve interromper e cortar conversações circulares do assistido que tentam fugir do foco da dor (*"aprender a cortar"*). Sessões de 4 horas caracterizam desgaste desnecessário e falta de domínio técnico.
  2. **Ancoragem Financeira**: Estabelecer e cobrar honorários elevados compatíveis com a desobsessão realizada. O valor sugerido no mercado de alunos formados é de R$ 880 a R$ 1.000. Terapeutas em fase inicial de testes podem cobrar uma taxa reduzida (mínimo de R$ 400 a R$ 500), mas devem evitar a desvalorização que drena o magnetismo pessoal.
- **Duração/Frequência**: Praticado na organização de agenda e precificação do consultório.
- **Indicadores de Sucesso**: Encerramento da sessão no tempo planejado sem cansaço extremo do terapeuta e comprometimento financeiro consciente do assistido.
- **Variações**: Adaptação de prazos e valores conforme a região ou formato de mentoria complementar.
- **Conceitos Envolvidos**: [[Principio do Posicionamento de Valor]], [[Conceito de Esgotamento Magnetico]]

## Perguntas Frequentes / Didática de Atendimento

### 24. Quais os limites de tempo recomendados para a sessão e as faixas de honorários indicadas?
**Resposta**: A autora decreta que "4 horas de trabalho, gente, é um exagero dos exageros... O processo todo de verdade não vai durar mais que 2 horas me fiz inteiro. Não vai". Financeiramente, a autora sustenta um alto valor devido à profundidade da tecnologia, informando que os parceiros maduros cobram "em média R$ 900, R$ 1.000... quem tando menos, tá cobrando 880". Para terapeutas em fase inicial, ela sugere que não se rebaixem demasiadamente: "eu não cobraria muito menos de R$ 400, R$ 500, não... Pelo menos nessas primeiras vezes até vocês se sentirem mais fortalecidos".


## Referencia

ANDRESA MOLINA. *Prática de Precificação e Duração Teto*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
