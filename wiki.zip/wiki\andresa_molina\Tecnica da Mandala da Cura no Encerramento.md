---
type: technique
author: Andresa Molina
tags: [mandala-cura, harmonizacao, trindade-vibracional, desconexao-magnetica]
sources: ["[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"]
---

# Técnica da Mandala da Cura no Encerramento (O selo radiestésico e a desconexão)

- **Definição**: O procedimento magnético final, aplicado no pêndulo, focado em irradiar a trindade da metodologia no corpo atordoado do assistido para ancorar os sentimentos de coragem e permissão, antes do desligamento total da sessão.
- **Como praticar e seu Propósito**:
  1. **Ancoragem Central**: Colocar o dedo centralizador no selo da Mandala da Cura.
  2. **Emissão de Frequências**: Girar o pêndulo no sentido horário proferindo dezenas de vezes a trindade corretora: "Harmoniza, potencializa e liberta. Harmoniza, potencializa desejo e liberta de tudo que prende".
  3. **Desconexão de Campo**: Realizar a desconexão final para puxar a sintonia magnética do cliente para fora da mesa quântica: "Tô te tirando da câmera do três. Prontinho".
  O propósito somático é suavizar os efeitos colaterais da cirurgia emocional (tonteiras, calafrios), selando a nova egrégora de saúde no sistema nervoso do assistido.
- **Evidências**: "Sinto como se fosse uma força muito grande e uma vibração. Sinto meio que o corpo e quando às vezes a gente perde a força nos músculos... E muito calor também. Meio tonta. ...Então vou só harmonizar e tirar você da mesa... Então aí ó, colocando na mesa aqui, forçando a Patrícia e eu tô harmoniza, potencializa e liberta. Harmoniza, potencializa e liberta. Harmoniza, potencializa, liberta. Harmoniza, potencializa liberta... Patrícia harmoniza, potencializa e liberta... Harmoniza, potencializa desejo e liberta de tudo que prende. Tô te tirando da câmera do três. Prontinho. É isso."
- **Conexões**: [[Tecnica de Ativacao da Mandala da Cura]], [[Tecnica de Retorno a Consciencia e Harmonizacao]]

## Perguntas Frequentes / Didática de Atendimento

### 24. Como é executada a infusão na mesa e de que forma se dá o desligamento físico do campo da paciente?
**Resposta**: A nível vibracional, o terapeuta ancora o campo na mesa e começa a infundir a trindade repetitivamente para calibrar as células do assistido pós-transe. A autora narra o ato: **"colocando na mesa aqui, forçando a Patrícia e eu tô harmoniza, potencializa e liberta. Harmoniza, potencializa e liberta. Harmoniza, potencializa, liberta..."**.

O desligamento final (a retirada magnética do paciente) se dá através de um decreto verbal que corta o vínculo do campo energético da pessoa com a mesa: **"Harmoniza, potencializa desejo e liberta de tudo que prende. Tô te tirando da câmera do três. Prontinho. É isso."**.


## Referencia

ANDRESA MOLINA. *Técnica da Mandala da Cura no Encerramento*. Aula 09 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]].
