---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_116_o_que_e_a_energia_taquionica.md]]"]
---

# Cap 116 - O Que E A Energia Taquionica

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_116_o_que_e_a_energia_taquionica.md]]

## Referencia

ANDRESA MOLINA. *Cap 116 - O Que E A Energia Taquionica*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_116_o_que_e_a_energia_taquionica.md]]. Acesso em: 17 jun. 2026.
