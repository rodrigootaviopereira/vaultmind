---
type: concept
author: Andresa
tags: [meditacao, dialogo-interno, autoconhecimento, escuta-somatica]
sources: ["[[raw/archive/transcriptions/01 - O CANSAÇO QUE NÃO PARA 1ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito de Meditar ("Me-Ditar")

**A reinterpretação prática e semântica do ato de meditar, deixando de ser a busca impossível de "calar a mente" para se tornar o ato consciente de "Me-Ditar", ou seja, escutar ativamente o que o próprio corpo e alma têm a dizer.**

A sociedade costuma ensinar a meditação como um bloqueio absoluto de pensamentos, focado em aquietar a mente de maneira forçada e manter silêncio total. Essa imposição frequentemente gera frustração no praticante. Andresa Molina ressignifica o conceito ensinando que a meditação, no contexto terapêutico de descoberta das coordenadas do Mapa da Alma, é um momento de escuta ativa e direcionamento interno. É o ato de pedir para o seu próprio sistema emocional, corporal e espiritual ditar, contar e apontar quais são as feridas escondidas, e simplesmente acolher essas respostas.

> **Citação Literal:** "Quando nós falamos num processo de meditar, muitas pessoas acreditam que meditar é sobre aquietar a mente, sobre a mente, não falar, ficar em silêncio, parar de pensar. Mas uma das bases do meditar é sobre meditar, né? Sobre ditar o que está acontecendo dentro de mim. Então, quando a gente olha para essa base e fala: 'Eu quero meditar, eu quero ditar para mim mesmo o que é que tá acontecendo dentro de mim'."

---

## Perguntas Frequentes / Didática de Atendimento

**27. Como a reinterpretação prática de meditar como "Me-Ditar" desmistifica o bloqueio racional do silêncio absoluto no processo terapêutico do Mapa da Alma?**

O bloqueio racional surge porque a sociedade condicionou as pessoas a acreditarem que "meditar é sobre aquietar a mente, sobre a mente, não falar, ficar em silêncio, parar de pensar", o que gera enorme desgaste e frustração em quem possui um sistema nervoso acelerado e cansado. Andresa desmistifica essa barreira interpretando a etimologia da prática: "uma das bases do meditar é sobre meditar, né? Sobre ditar o que está acontecendo dentro de mim".

A nível somático, essa reinterpretação transforma a meditação em uma ferramenta clínica ativa. Em vez de lutar para silenciar o cérebro, a pessoa é conduzida a usar a meditação para "meditar, me falar, me contar", permitindo que o próprio corpo indique "aonde no seu corpo isso está armazenado, aonde essa informação está gravada no seu corpo". A prática abandona o silêncio passivo e exige que o indivíduo preste atenção à biologia, respondendo "com a primeira coisa que vier na sua cabeça ou sair pela sua boca" para mapear somaticamente aonde a dor ancestral "pega no seu corpo, na cabeça, nos ombros, no peito, no abdômen".

