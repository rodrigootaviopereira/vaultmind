---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_23_o_hemisferios_cerebrais_parte_2.md]]"]
---

# Cap 023 - O Hemisferios Cerebrais Parte 2

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_23_o_hemisferios_cerebrais_parte_2.md]]

## Referencia

ANDRESA MOLINA. *Cap 023 - O Hemisferios Cerebrais Parte 2*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_23_o_hemisferios_cerebrais_parte_2.md]]. Acesso em: 17 jun. 2026.
