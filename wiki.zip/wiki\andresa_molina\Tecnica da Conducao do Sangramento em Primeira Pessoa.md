---
type: technique
author: Andresa Molina
tags: [sangramento-em-primeira-pessoa, dor-raiz, enfrentamento, expressao-verbal]
sources: ["[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"]
---

# A Condução do Sangramento em Primeira Pessoa (O enfrentamento do holograma)

- **Definição**: A indução intervencionista que força o assistido a direcionar a sua fúria e a sua dor diretamente à matriz originária (como um pai ou mãe projetado na cena), abolindo a terceirização do relato de vitimização (o falar "sobre" eles).
- **Como praticar e seu Propósito**:
  1. **Corta a Triangulação**: Se o assistido começa a descrever a cena falando com o terapeuta ("meu pai estava com raiva..."), o terapeuta interfere: "Não é para mim que você tem que falar. É para ele. Fala para ele. Olha para ele e fala com ele".
  2. **Exigir Primeira Pessoa**: Instruir a verbalização direcionada: "Pai, eu preciso de ajuda... eu não consigo sozinha".
  3. **Esvaziamento Completo**: Incentivar o esgotamento biológico da dor: "Fala, pode sangrar tudo isso, chora tudo isso".
  O propósito somático é desatar o bloqueio físico garganta-peito-abdômen do trauma infantil represado, purificando as células através da catarse verbal ativa de enfrentamento direto.
- **Evidências**: "O que você queria ter feito aí? ...Pat >> eu queria ter expressado que eu precisava de ajuda... >> Então faz isso agora. Para quem você tem que falar isso? ...>> Para meu pai. >> Então, fala para ele. Pai, eu preciso de ajuda... Fala, eu não consigo sozinha. Eu não, eu não sei. Fala, pode sangra tudo isso, chora tudo isso... Fala para ele em primeira pessoa. Pai, eu não tô entendendo o que era para fazer. Não é para mim que você tem que falar. É para ele. Fala para ele. Olha para ele e fala com ele."
- **Conexões**: [[Principio da Autossustentacao Fisica]], [[Tecnica de Desdobramento e Conducao do Sangramento]]

## Perguntas Frequentes / Didática de Atendimento

### 19. Por que o terapeuta deve forçar o assistido a verbalizar a dor na "primeira pessoa" ao projetor originário da cena?
**Resposta**: O terapeuta exige o uso da primeira pessoa para **impedir que o assistido fuja da estagnação emocional** usando o terapeuta como um mediador ou diário intelectual. Quando a paciente tenta narrar passivamente para a terapeuta o que ocorreu, recebe uma interrupção diretiva: **"Não é para mim que você tem que falar. É para ele. Fala para ele. Olha para ele e fala com ele"**.

A nível somático, a toxina do trauma está encravada no corpo (a paciente relatou um aperto físico imediato: **"Sinto o coração apertado e um nó na garganta"**). Para a purgação biológica acontecer, o corpo precisa jorrar a emoção crua diretamente para a figura que causou a dor na memória. O terapeuta força o sistema nervoso a expurgar o trauma exigindo a fala presencial: **"Fala para ele em primeira pessoa. Pai, eu não tô entendendo o que era para fazer... Fala, pode sangra tudo isso, chora tudo isso"**.


## Referencia

ANDRESA MOLINA. *A Condução do Sangramento em Primeira Pessoa*. Aula 09 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]].
