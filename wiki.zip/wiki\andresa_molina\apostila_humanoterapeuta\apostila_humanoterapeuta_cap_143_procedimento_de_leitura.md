---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_143_procedimento_de_leitura.md]]"]
---

# Cap 143 - Procedimento De Leitura

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_143_procedimento_de_leitura.md]]

## Referencia

ANDRESA MOLINA. *Cap 143 - Procedimento De Leitura*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_143_procedimento_de_leitura.md]]. Acesso em: 17 jun. 2026.
