---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_82_processos_carmicos_nao_obsessivos.md]]"]
---

# Cap 082 - Processos Carmicos Nao Obsessivos

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_82_processos_carmicos_nao_obsessivos.md]]

## Referencia

ANDRESA MOLINA. *Cap 082 - Processos Carmicos Nao Obsessivos*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_82_processos_carmicos_nao_obsessivos.md]]. Acesso em: 17 jun. 2026.
