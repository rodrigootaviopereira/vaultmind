---
type: aula
author: Andresa Molina
tags: [codigo-humanosense, humanosense, aula-04, reingestao-2026-06-19]
sources:
  - "[[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]]"
---
# Aula 04 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `04   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 16.214 palavras; 575 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- A autorização liberta porque rompe o aprisionamento que te mantinha pequena e abre caminho para que a alma expanda e caminhe inteira.
- Percebe que eu voltei pro padrão, então eu não vou conseguir, porque tem uma parte minha que não quer conseguir para ajudar os outros, quer conseguir para eu ser livre, para eu me autorizar.
- Todas as perguntas que a gente fez, se ela não se autorizar parar de ser uma lixeira, se ela não se autorizar parar de ser explorada pelo explorador, ela precisa se autorizar tudo.
- Para isso, você precisa conseguir identificar todos aqueles processos que a gente trouxe na mandala do amor e na mandala da dor e ter habilidade, disponibilidade e autorização para resolver todos eles.
- E aí é que a gente vai pro restante da mandala, que é então, só pra gente fechar que a liberdade consciente acontece quando você reconhece o que carrega com habilidade, se permite ir com a autorização e faz o que precisa ser feito com a disponibilidade.
- A parte que me chamou atenção foi agora se depois você foi sem as suas cautelas quente entende então o medo não é para parar é para que a gente vá assim com mais cuidado, com mais atenção, com mais presença, mas isso não significa não ir e não fazer o que precisa ser feito.
- Então, todo esse conteúdo da primeira parte, gente, ele tem a ver com dar consciência pro meu cliente, dar consciência pro meu assistido, levar ele para um nível racional, onde ele decida fazer a mudança.
- Então você consegue identificar a frequência da pessoa dentro desse padrão, dentro da dor que ela te traz.
- Então, toda parte desta primeira parte tem a ver com entender o campo energético, entender tudo isso, mas trazer racionalidade pro meu cliente, base racional para ele, para ele entender, para a partir do momento que ele começa a entender o porque aquilo que ele quer não funciona e o que ele precisa fazer para funcionar, ele começa a pôr os pés no chão, ele…
- Porque assim, o que que vai fazer a pessoa conseguir fazer isso? tratar os enroscos da mandala da dor e da cura, da mandala da dor e do amor.
- Se ela não estabelecer amor, equilíbrio no amor, ela nunca vai se autorizar, porque ela tá sempre culpando algo ou alguém.
- Então é também como se a gente só tivesse abrindo fichaz aqui você fazer uma limpeza depois não é você vai dar consciência para ele sobre a questão que ele trouxe a gente sempre precisa se apegar porque ele traz uma frequência e a gente vai acessar essa frequência.

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-72
- Todas as perguntas que a gente fez, se ela não se autorizar parar de ser uma lixeira, se ela não se autorizar parar de ser explorada pelo explorador, ela precisa se autorizar tudo.
- Para isso, você precisa conseguir identificar todos aqueles processos que a gente trouxe na mandala do amor e na mandala da dor e ter habilidade, disponibilidade e autorização para resolver todos eles.
- E aí é que a gente vai pro restante da mandala, que é então, só pra gente fechar que a liberdade consciente acontece quando você reconhece o que carrega com habilidade, se permite ir com a autorização e faz o que precisa ser feito com a disponibilidade.

### Bloco 2 - frases 73-144
- Sempre foi com mais habilidade o banho do bebê, lá no comecinho com medo dele escorregar, as crianças vai cair na banheira, você também não v fazer depois de repente você pega, vira assim, vira assim, passa baixo, passa em cima, porque você ganhou habilidade.
- A parte que me chamou atenção foi agora se depois você foi sem as suas cautelas quente entende então o medo não é para parar é para que a gente vá assim com mais cuidado, com mais atenção, com mais presença, mas isso não significa não ir e não fazer o que precisa ser feito.
- A prosperidade flui como consequência natural, porque você está no espaço certo, fazendo o que você nasceu para fazer, com a energia viva que transforma, não só a sua história, mas também a de quem você toca.

### Bloco 3 - frases 145-216
- Então não é que é só um arquétipo, é um campo de energia.
- Então, todo esse conteúdo da primeira parte, gente, ele tem a ver com dar consciência pro meu cliente, dar consciência pro meu assistido, levar ele para um nível racional, onde ele decida fazer a mudança.
- Já falei, vou repetir, presta bastante atenção que essa parte teve bastante gente com dúvida, então acho que é válido eu retomar isso.

### Bloco 4 - frases 217-288
- Então você aqui vai fazer as perguntas aqui, você vai perguntar pra pessoa e aí você vai pegar a sua folha, a sua ficha, tá?
- Energia mandada do amor, primeiras perguntas da energia cliente veio e aí tá e aí ela foi falando com você, um monte de coisas, trouxe ali um conteúdo, ai t problema com meu marido, a gente tá se separando, a gente tá com problema, não sabemos ficamos juntos, enfim.
- E aí o inconsciente dela vai responder, o campo inconsciente dela, energético, espiritual.

### Bloco 5 - frases 289-360
- Então dependendo do que acontece aqui, consciente, inconsciente, ou está distuando demais, eu vou falar para ela, olha, você precisa falar tudo para ela?
- Então você consegue identificar a frequência da pessoa dentro desse padrão, dentro da dor que ela te traz.
- Então, toda parte desta primeira parte tem a ver com entender o campo energético, entender tudo isso, mas trazer racionalidade pro meu cliente, base racional para ele, para ele entender, para a partir do momento que ele começa a entender o porque aquilo que ele quer não funciona e o que ele precisa fazer para funcionar, ele começa a pôr os pés no chão, ele começa a sair da ilusão, ele começa a entender porque não…

### Bloco 6 - frases 361-432
- Esse é o trabalho do terapeuta, principalmente o terapeuta que trabalha com propósito, com energia, não tá nem aí pro cliente, né? uma pessoa que quer ajudar o outro a caminhar com mais alegria, com mais felicidade e muitas vezes sofrimento ele fica, porque tem coisas na nossa cabeça que a gente acredita que esse seria o ideal.
- Porque assim, o que que vai fazer a pessoa conseguir fazer isso? tratar os enroscos da mandala da dor e da cura, da mandala da dor e do amor.
- Se ela não estabelecer amor, equilíbrio no amor, ela nunca vai se autorizar, porque ela tá sempre culpando algo ou alguém.

### Bloco 7 - frases 433-504
- Então vai ter muitas nuances aí, vão ser muitas, tem muita informação para vocês terem muita base para ir ajudando o cliente de vocês caso a caso, entendeu?
- Eu tô com na primeira pergunta masculina que fala assim: "O quanto você consegue executar suas ideias até o fim sem abandonar no meio do caminho?" Para mim ficou confuso porque a questão do não abandonar para mim parece energia feminina que é a questão da sustentação.
- Então eu ter essa ideia e começar a executar essa ideia é uma energia masculina, porque eu não estou abandonando a minha ideia, mas o fato de eu ir lá fazer, por exemplo, ah, tem contar essa pessoa, tem que pegar o fornecedor, daí isso da energia feminina, porque eu tô sustentando isso.

### Bloco 8 - frases 505-575
- Então a minha dúvida é assim, quando você lá naquelas fichas, eu entendo comência, acho que é uma dúvida mais geral assim sobre qual objetivo final do manência porque entala ali eu teria que dar a consciência pra pessoa sobre todos aqueles pontos ou isso opcional assim tá aberto para receber vou falar.
- Então é também como se a gente só tivesse abrindo fichaz aqui você fazer uma limpeza depois não é você vai dar consciência para ele sobre a questão que ele trouxe a gente sempre precisa se apegar porque ele traz uma frequência e a gente vai acessar essa frequência.
- Então a gente quando tem consciência a gente, a pessoa precisa fazer a mudança.

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Todas as perguntas que a gente fez, se ela não se autorizar parar de ser uma lixeira, se ela não se autorizar parar de ser explorada pelo explorador, ela precisa se autorizar tudo.
- Para isso, você precisa conseguir identificar todos aqueles processos que a gente trouxe na mandala do amor e na mandala da dor e ter habilidade, disponibilidade e autorização para resolver todos eles.
- E aí é que a gente vai pro restante da mandala, que é então, só pra gente fechar que a liberdade consciente acontece quando você reconhece o que carrega com habilidade, se permite ir com a autorização e faz o que precisa ser feito com a disponibilidade.
- Sempre foi com mais habilidade o banho do bebê, lá no comecinho com medo dele escorregar, as crianças vai cair na banheira, você também não v fazer depois de repente você pega, vira assim, vira assim, passa baixo, passa em cima, porque você ganhou habilidade.
- A parte que me chamou atenção foi agora se depois você foi sem as suas cautelas quente entende então o medo não é para parar é para que a gente vá assim com mais cuidado, com mais atenção, com mais presença, mas isso não significa não ir e não fazer o que precisa ser feito.
- Já falei, vou repetir, presta bastante atenção que essa parte teve bastante gente com dúvida, então acho que é válido eu retomar isso.
- Então dependendo do que acontece aqui, consciente, inconsciente, ou está distuando demais, eu vou falar para ela, olha, você precisa falar tudo para ela?
- Então, toda parte desta primeira parte tem a ver com entender o campo energético, entender tudo isso, mas trazer racionalidade pro meu cliente, base racional para ele, para ele entender, para a partir do momento que ele começa a entender o porque aquilo que ele quer não funciona e o que ele precisa fazer para funcionar, ele começa a pôr os pés no chão, ele…
- Se ela não estabelecer amor, equilíbrio no amor, ela nunca vai se autorizar, porque ela tá sempre culpando algo ou alguém.
- Então é também como se a gente só tivesse abrindo fichaz aqui você fazer uma limpeza depois não é você vai dar consciência para ele sobre a questão que ele trouxe a gente sempre precisa se apegar porque ele traz uma frequência e a gente vai acessar essa frequência.

## Conceitos-Chave Extraídos

- Para isso, você precisa conseguir identificar todos aqueles processos que a gente trouxe na mandala do amor e na mandala da dor e ter habilidade, disponibilidade e autorização para resolver todos eles.
- E aí é que a gente vai pro restante da mandala, que é então, só pra gente fechar que a liberdade consciente acontece quando você reconhece o que carrega com habilidade, se permite ir com a autorização e faz o que precisa ser feito com a disponibilidade.
- A parte que me chamou atenção foi agora se depois você foi sem as suas cautelas quente entende então o medo não é para parar é para que a gente vá assim com mais cuidado, com mais atenção, com mais presença, mas isso não significa não ir e não fazer o que precisa ser feito.
- Então quando a gente fala de lugar, função e potência, agora para eu explicar lugar, função e potência, o que que acontece?
- É o mínimo que se você fazer um mau trabalho, você não vai ser receber, você vai ser dispensado, você vai nunca mais vão chamar você para trabalhar, você é simples.
- Então não é que é só um arquétipo, é um campo de energia.
- Então, todo esse conteúdo da primeira parte, gente, ele tem a ver com dar consciência pro meu cliente, dar consciência pro meu assistido, levar ele para um nível racional, onde ele decida fazer a mudança.
- Então a gente precisa ter consciência, clareza, lucidez e parar de ser iludida, certo?
- E aí o inconsciente dela vai responder, o campo inconsciente dela, energético, espiritual.
- Se ela tá, o inconsciente tá três e ela tá cinco, eu preciso aproximar, dar consciência pro inconsciente, trazer luz, colocar luz para o que está no inconsciente, que tá no inconsciente é que tá na nossa sombra, é o que tá reprimido, é o que eu não posso sentir, eu não posso querer isso.
- Então, toda parte desta primeira parte tem a ver com entender o campo energético, entender tudo isso, mas trazer racionalidade pro meu cliente, base racional para ele, para ele entender, para a partir do momento que ele começa a entender o porque aquilo que ele quer não funciona e o que ele precisa fazer para funcionar, ele começa a pôr os pés no chão, ele…
- Ah, então falando dos eixos da liberdade, como você explicou, então como como que a gente faz, né, nesse sentido do eixo da liberdade para para chegar até essa habilidade e autorização e disponibilidade, é a técnica que vai trazer pra gente essa ferramenta para limpar o campo, pra gente conseguir acessar esses eixos com mais, digamos assim, com mais…
- Porque assim, o que que vai fazer a pessoa conseguir fazer isso? tratar os enroscos da mandala da dor e da cura, da mandala da dor e do amor.
- Então a minha dúvida é assim, quando você lá naquelas fichas, eu entendo comência, acho que é uma dúvida mais geral assim sobre qual objetivo final do manência porque entala ali eu teria que dar a consciência pra pessoa sobre todos aqueles pontos ou isso opcional assim tá aberto para receber vou falar.
- Então é também como se a gente só tivesse abrindo fichaz aqui você fazer uma limpeza depois não é você vai dar consciência para ele sobre a questão que ele trouxe a gente sempre precisa se apegar porque ele traz uma frequência e a gente vai acessar essa frequência.
- Então a gente quando tem consciência a gente, a pessoa precisa fazer a mudança.


## Técnicas, Procedimentos e Orientações Práticas

- Eu vou ter que comprar falta pra minha sobrinha, meu irmão para trabalhar, aí eu não me autorizo, aí eu não ganho, porque é para eu não ter, para não ter que dar, entendeu? percebe que vira um bolo e eu preciso pegar o meu meu assistido no pulo.
- Todas as perguntas que a gente fez, se ela não se autorizar parar de ser uma lixeira, se ela não se autorizar parar de ser explorada pelo explorador, ela precisa se autorizar tudo.
- Para isso, você precisa conseguir identificar todos aqueles processos que a gente trouxe na mandala do amor e na mandala da dor e ter habilidade, disponibilidade e autorização para resolver todos eles.
- Então, todo esse conteúdo da primeira parte, gente, ele tem a ver com dar consciência pro meu cliente, dar consciência pro meu assistido, levar ele para um nível racional, onde ele decida fazer a mudança.
- Então você aqui vai fazer as perguntas aqui, você vai perguntar pra pessoa e aí você vai pegar a sua folha, a sua ficha, tá?
- Energia mandada do amor, primeiras perguntas da energia cliente veio e aí tá e aí ela foi falando com você, um monte de coisas, trouxe ali um conteúdo, ai t problema com meu marido, a gente tá se separando, a gente tá com problema, não sabemos ficamos juntos, enfim.
- Então você consegue identificar a frequência da pessoa dentro desse padrão, dentro da dor que ela te traz.
- Então, toda parte desta primeira parte tem a ver com entender o campo energético, entender tudo isso, mas trazer racionalidade pro meu cliente, base racional para ele, para ele entender, para a partir do momento que ele começa a entender o porque aquilo que ele quer não funciona e o que ele precisa fazer para funcionar, ele começa a pôr os pés no chão, ele…
- Esse é o trabalho do terapeuta, principalmente o terapeuta que trabalha com propósito, com energia, não tá nem aí pro cliente, né? uma pessoa que quer ajudar o outro a caminhar com mais alegria, com mais felicidade e muitas vezes sofrimento ele fica, porque tem coisas na nossa cabeça que a gente acredita que esse seria o ideal.
- Aqui na ficha eu já li aqui da parte dos comandos, né, que você falou pra gente colocar o dedo aqui no meio e falar o nome e a data de nascimento do nosso assistido em voz alta, né?
- Então vai ter muitas nuances aí, vão ser muitas, tem muita informação para vocês terem muita base para ir ajudando o cliente de vocês caso a caso, entendeu?
- Eu tô com na primeira pergunta masculina que fala assim: "O quanto você consegue executar suas ideias até o fim sem abandonar no meio do caminho?" Para mim ficou confuso porque a questão do não abandonar para mim parece energia feminina que é a questão da sustentação.
- Então a minha dúvida é assim, quando você lá naquelas fichas, eu entendo comência, acho que é uma dúvida mais geral assim sobre qual objetivo final do manência porque entala ali eu teria que dar a consciência pra pessoa sobre todos aqueles pontos ou isso opcional assim tá aberto para receber vou falar.
- Então é também como se a gente só tivesse abrindo fichaz aqui você fazer uma limpeza depois não é você vai dar consciência para ele sobre a questão que ele trouxe a gente sempre precisa se apegar porque ele traz uma frequência e a gente vai acessar essa frequência.


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- A autorização liberta porque rompe o aprisionamento que te mantinha pequena e abre caminho para que a alma expanda e caminhe inteira.
- Percebe que eu voltei pro padrão, então eu não vou conseguir, porque tem uma parte minha que não quer conseguir para ajudar os outros, quer conseguir para eu ser livre, para eu me autorizar.
- Eu vou ter que comprar falta pra minha sobrinha, meu irmão para trabalhar, aí eu não me autorizo, aí eu não ganho, porque é para eu não ter, para não ter que dar, entendeu? percebe que vira um bolo e eu preciso pegar o meu meu assistido no pulo.
- Todas as perguntas que a gente fez, se ela não se autorizar parar de ser uma lixeira, se ela não se autorizar parar de ser explorada pelo explorador, ela precisa se autorizar tudo.
- Para isso, você precisa conseguir identificar todos aqueles processos que a gente trouxe na mandala do amor e na mandala da dor e ter habilidade, disponibilidade e autorização para resolver todos eles.
- E aí é que a gente vai pro restante da mandala, que é então, só pra gente fechar que a liberdade consciente acontece quando você reconhece o que carrega com habilidade, se permite ir com a autorização e faz o que precisa ser feito com a disponibilidade.
- Sempre foi com mais habilidade o banho do bebê, lá no comecinho com medo dele escorregar, as crianças vai cair na banheira, você também não v fazer depois de repente você pega, vira assim, vira assim, passa baixo, passa em cima, porque você ganhou habilidade.
- A parte que me chamou atenção foi agora se depois você foi sem as suas cautelas quente entende então o medo não é para parar é para que a gente vá assim com mais cuidado, com mais atenção, com mais presença, mas isso não significa não ir e não fazer o que precisa ser feito.
- Já falei, vou repetir, presta bastante atenção que essa parte teve bastante gente com dúvida, então acho que é válido eu retomar isso.
- Então você consegue identificar a frequência da pessoa dentro desse padrão, dentro da dor que ela te traz.
- Porque assim, o que que vai fazer a pessoa conseguir fazer isso? tratar os enroscos da mandala da dor e da cura, da mandala da dor e do amor.
- Se ela não estabelecer amor, equilíbrio no amor, ela nunca vai se autorizar, porque ela tá sempre culpando algo ou alguém.


## Citações e Formulações de Alta Densidade

- “Todas as perguntas que a gente fez, se ela não se autorizar parar de ser uma lixeira, se ela não se autorizar parar de ser explorada pelo explorador, ela precisa se autorizar tudo.”
- “Se você tiver habilidade, disponibilidade e autorização, você consegue tudo, porque você precisa sustentar a frequência.”
- “Para isso, você precisa conseguir identificar todos aqueles processos que a gente trouxe na mandala do amor e na mandala da dor e ter habilidade, disponibilidade e autorização para resolver todos eles.”
- “E aí é que a gente vai pro restante da mandala, que é então, só pra gente fechar que a liberdade consciente acontece quando você reconhece o que carrega com habilidade, se permite ir com a autorização e faz o que precisa ser feito com a disponibilidade.”
- “Sempre foi com mais habilidade o banho do bebê, lá no comecinho com medo dele escorregar, as crianças vai cair na banheira, você também não v fazer depois de repente você pega, vira assim, vira assim, passa baixo, passa em cima, porque você ganhou habilidade.”
- “A parte que me chamou atenção foi agora se depois você foi sem as suas cautelas quente entende então o medo não é para parar é para que a gente vá assim com mais cuidado, com mais atenção, com mais presença, mas isso não significa não ir e não fazer o que precisa ser feito.”
- “Então dependendo do que acontece aqui, consciente, inconsciente, ou está distuando demais, eu vou falar para ela, olha, você precisa falar tudo para ela?”
- “Então, toda parte desta primeira parte tem a ver com entender o campo energético, entender tudo isso, mas trazer racionalidade pro meu cliente, base racional para ele, para ele entender, para a partir do momento que ele começa a entender o porque aquilo que ele quer não funciona e o que ele…”
- “Se ela não estabelecer amor, equilíbrio no amor, ela nunca vai se autorizar, porque ela tá sempre culpando algo ou alguém.”
- “Eu tô com na primeira pergunta masculina que fala assim: "O quanto você consegue executar suas ideias até o fim sem abandonar no meio do caminho?" Para mim ficou confuso porque a questão do não abandonar para mim parece energia feminina que é a questão da sustentação.”
- “Então a minha dúvida é assim, quando você lá naquelas fichas, eu entendo comência, acho que é uma dúvida mais geral assim sobre qual objetivo final do manência porque entala ali eu teria que dar a consciência pra pessoa sobre todos aqueles pontos ou isso opcional assim tá aberto para receber vou…”
- “Então é também como se a gente só tivesse abrindo fichaz aqui você fazer uma limpeza depois não é você vai dar consciência para ele sobre a questão que ele trouxe a gente sempre precisa se apegar porque ele traz uma frequência e a gente vai acessar essa frequência.”

## Conexões com a Wiki

- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio da Liberdade Consciente]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Conceito do Divorcio Energetico]]
- [[Conceito do Parceiro da Missao]]

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## Referência

ANDRESA MOLINA. *Aula 04 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.


## FAQs para NotebookLM (Fase 2)

### Bloco 1: O Eixo da Liberdade e a Manifestação do Dom
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
1. Como Andresa Molina define o "Eixo da Liberdade" e de que maneira a Habilidade, a Autorização e a Disponibilidade interagem para cessar a angústia essencial?
2. Como a "Habilidade" é descrita na aula, e de que forma o treino diário disciplinado substitui o vitimismo e as justificativas de falta de oportunidade?
3. O que significa somaticamente a "Autorização" no Eixo da Liberdade, e de que modo o pânico de desaprovação parental (medo de perder o afeto) aprisiona o assistido em moldes artificiais?
4. Como Andresa conceitua a "Disponibilidade", contrapondo a atitude de fazer "para ver se dá certo" com a de fazer "até dar certo"?

### Bloco 2: A Desconstrução Parental e os Ganhos da Estagnação
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
5. Por que a autora afirma que para conquistar a autorização existencial é obrigatório "desconstruir pai e mãe"?
6. A nível prático, qual é a pergunta investigativa chave que o terapeuta deve propor ao assistido quando a sua prosperidade ou projeto está travado ("a coisa não vai")?
7. Como a mente do assistido sabota as suas conquistas materiais sob o pretexto de "não ganhar para não ter que dar", reativando a lealdade sombria do "lixeiro emocional"?
8. Como Andresa orienta o terapeuta a posicionar-se quando o cliente, após ser confrontado com a verdade de seu bloqueio, decide conscientemente não mudar?

### Bloco 3: A Anatomia do Medo e a Postura de Cautela
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
9. De que modo Andresa Molina define o "Medo" (como sinal de desconhecimento/incompetência provisória) e de que maneira a cautela atenta substitui a lentidão na tomada de ação?
10. Qual é a analogia prática do "aprender a dirigir" ou de "dar banho em um bebê" utilizada pela autora para ilustrar a aquisição progressiva de habilidade a partir do medo inicial?
11. Sob o Princípio da Liberdade Consciente, qual é a relação entre a responsabilidade soberana, a disciplina de autoria e o controle sobre os próprios medos na fase adulta?

### Bloco 4: O Eixo da Realização e a Dinâmica Sistêmica
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
12. O que caracteriza o "Eixo da Realização", e como Andresa conceitua a tríade "Lugar, Função e Potência"?
13. O que acontece com a força vital de um indivíduo quando ele está "fora do seu lugar", e de que modo a adaptação forçada apequena a alma?
14. Como Andresa Molina define a "Função", e por que a excelência técnica na entrega de serviços ("fazer um bom trabalho") é classificada como o mínimo obrigatório de troca?
15. O que é a "Potência" a nível energético, e de que forma a autora relaciona vitalidade ao ectoplasma e ao magnetismo aplicados no projeto?

### Bloco 5: Somatização Física e Condução Clínica na Mesa
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
16. Como a autora explica a nível biológico e somático o ganho de peso (obesidade) sob a ótica da sobrecarga familiar e do acúmulo de tarefas de múltiplas pessoas?
17. Como o terapeuta Humanosense realiza a "Técnica de Ancoragem do Assistido na Mesa" utilizando dados verbais e o selo do espaço sob autorização?
18. Como é executada a "Técnica de Diagnóstico de Alinhamento Consciente-Inconsciente" confrontando a régua da mesa (pêndulo) com os valores lógicos fornecidos pelo cliente?
19. Por que o terapeuta deve emparelhar e perguntar de forma dicotômica (uma pergunta de feminino e uma de masculino correspondentes) ao investigar as pétalas da Mandala do Amor?
20. O que significa somaticamente a orientação da autora de que a "Mandala da Cura" é orientativa, e como o terapeuta deve modular o desfazimento de fractais pela autorresponsabilidade?
