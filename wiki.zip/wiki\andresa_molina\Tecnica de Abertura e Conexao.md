---
type: tecnica
author: Andresa Molina
tags: [comando-abertura, ancoramento, selo-mesa, autorizacao]
sources: ["[[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]]"]
---

# Comando de Abertura e Conexão (Ancoramento no selo da mesa com os dados e autorização do assistido)

- **Objetivo**: Conceder permissão espiritual e física (através do livre-arbítrio) para a egrégora do HumanoSense acessar os registros de DNA e a mente inconsciente do assistido, sintonizando a frequência da pessoa com o selo central da mesa.
- **Pré-requisitos**: Aplicação prévia da [[Tecnica de Enquadramento na Piramide|Prática do Enquadramento em Pirâmide]].
- **Passo a Passo**:
  1. O terapeuta posiciona seu dedo indicador de ancoragem física exatamente no centro da mesa HumanoSense, no local onde está estampado o selo da egrégora do Espaço Humanidade (se for presencial, o próprio assistido coloca o dedo).
  2. O terapeuta solicita que o assistido verbalize, em voz alta, o seu nome completo e a sua data de nascimento.
  3. A emissão sonora desses dados atua como a concessão legal de acesso ao campo bioenergético e akáshico do cliente para que as equipes espirituais iniciem o diagnóstico e a varredura da dor.
- **Duração/Frequência**: Executada uma única vez no início de cada atendimento.
- **Indicadores de Sucesso**: Conexão radiestésica estabelecida no selo, permitindo o movimento fluído do pêndulo e o rastreamento das coordenadas de dor na mesa.
- **Variações**: Condução online (terapeuta coloca o dedo no selo representando o cliente) vs. Condução presencial (o próprio assistido coloca o dedo no selo).
- **Conceitos Envolvidos**: [[Conceito da Mesa HumanoSense]], [[Conceito de Autorizacao (Eixo da Liberdade)]]

## Perguntas Frequentes / Didática de Atendimento

## Perguntas Frequentes / Didática de Atendimento

### 14. Qual o propósito radiestésico e espiritual do "Comando de Abertura e Conexão" ao exigir que o assistido diga seu nome completo e data de nascimento em voz alta?
**Resposta**: O propósito é ancorar a intenção física e obter a permissão espiritual (livre-arbítrio) para intervir na biologia e no campo do paciente. 
A nível radiestésico, a conexão física começa "colocando o dedo no centro da mesma [mesa] humanos onde está o selo". O paciente é exigido a falar seus dados "em voz alta" para que a sua própria frequência sonora libere o acesso da equipe espiritual à sua matriz. A autora é direta sobre esse propósito espiritual: "Sim, em voz alta, porque ele tá dando autorização para você fazer o trabalho. Então ele precisa dar autorização".

## Referencia

ANDRESA MOLINA. *Comando de Abertura e Conexão*. Aula 06 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]].
