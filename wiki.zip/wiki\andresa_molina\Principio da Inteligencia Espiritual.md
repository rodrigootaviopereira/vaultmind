---
type: principio
author: Andresa Molina
tags: [espiritualidade, intuicao, sentimento, bussola-interna]
sources: ["[[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]"]
---
# Princípio da Inteligência Espiritual (A Bússola do "Fazer Sentir" vs. "Fazer Sentido")

- **Definição**: A premissa consciencial de que a verdadeira navegação da alma não obedece à lógica ou ao que compensa materialmente, mas sim a um chamado interno profundo (a intuição) que não precisa fazer sentido lógico, apenas precisa ser sentido.
- **Justificativa**: Seguir apenas a razão social em detrimento do sentir do peito sabota o propósito da alma e causa adoecimento somático.
- **Evidências**: "É ouvir o seu coração, independente do que o outro fala, do que o mundo fala. É sobre, não é sobre fazer sentido, é sobre fazer sentir... Por que que eu quero, não quero mais isso. Eu não sei. Eu sei que eu não quero. Não me move mais. Ah, mas é tão, mas compensa... Não é sobre fazer sentido, é sobre o que pulsa em mim. É uma intuição."
- **Implicações**: O indivíduo deve aprender a ouvir a intuição mesmo quando ela confronta a lógica das conveniências materiais ou opiniões externas.
- **Conexões**: [[Conceito de Influencia vs Intuicao]]
- **Notas Pessoais**: A inteligência espiritual atua como a voz direta da alma comunicando-se através de sensações no peito.

## Perguntas Frequentes / Didática de Atendimento

**Pergunta 20: O que significa "Espiritualidade Livre" na metodologia Humanosense e como a autora desvincula essa percepção dos dogmas religiosos?**

A "Espiritualidade Livre" é conceituada como a soberania do próprio ser em conexão direta com o universo, pautada na união "entre a intuição que sente e a inspiração que move". 

Andresa desvincula radicalmente esse conceito da religião: "não é sobre religiosidade, é sobre uma espiritualidade livre, é sobre eu enquanto espírito, eu respeitando a mim mesmo". Ela reforça que "tem gente que nem acredita em nada e consegue trabalhar muito bem a sua influência e respeita a sua intuição". A espiritualidade livre não depende de dogmas externos, mas do alinhamento energético interno de "confiar no que se percebe e agir em coerência com a alma", pois, nas palavras literais da autora, "Respeito é a resposta do peito".

**Pergunta 22: Como Andresa explica o princípio da Inteligência Espiritual ao contrapor o chamado do coração ("fazer sentir") com as justificativas da mente lógica baseadas no que "compensa"?**

O princípio da Inteligência Espiritual baseia-se na coragem de seguir a intuição sem exigir lógica. A mente racional exige que as escolhas "compensem" ("Ah, mas é tão, mas compensa"). Contudo, Andresa decreta que a bússola da alma não faz conta matemática: "não é sobre fazer sentido, é sobre fazer sentir... Não é sobre fazer sentido, é sobre o que pulsa em mim". 

A nível somático, guiar-se apenas pela conveniência do "compensa" é seguir a "lei da matéria, não lei da espiritualidade". Quando o indivíduo cala o que pulsa no seu corpo para agradar ao mundo, a energia estagna e corrompe o sistema. A autora adverte que "por causa do compenso no compenso a gente ignora, não escuta e continua. E aí a gente vai se matando... adoecendo porque a gente esqueceu essa parte desse desta magia do feminino".

## Referencia

ANDRESA MOLINA. *Princípio da Inteligência Espiritual (A Bússola do "Fazer Sentir" vs. "Fazer Sentido")*. Aula 02 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]].
