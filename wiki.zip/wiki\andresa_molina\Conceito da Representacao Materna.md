---
type: conceito
author: Andresa Molina
tags: [mae, vinculo, interior, retencao]
sources: ["[[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]"]
---
# A Representação Materna (Vínculo, Cuidado e a Retenção de Dinheiro/Relações)

- **Definição Precisa**: O arquétipo e representação energética da figura da mãe, regendo o mundo interno, a nutrição emocional e a retenção sustentada de recursos e vínculos afetivos.
- **Sinônimos/Variações**: Figura Materna, Energia da Mãe, Força Materna, Força do Ficar
- **Contexto de Uso**: Tratamento de vazamento financeiro, autodesvalorização e instabilidade em relacionamentos.
- **Relação com Princípios**: [[Principio da Atracao e Retencao]]
- **Exemplos do Material**: "A mãe simboliza na energia do feminino a sustentação emocional interna... A figura materna representa um espaço interno onde algo cresce com tempo, cuidado e presença... Eu ganho dinheiro, mas eu não não rende, não fica... Porque eu tenho raiva da mãe ou pena da mãe."
- **Aplicação Prática**: Trabalhar a aceitação da mãe para cicatrizar o útero emocional e estancar perdas financeiras ou términos abruptos de relações.
- **Conexões Externas**: [[Conceito da Representacao Paterna]]

## Perguntas Frequentes / Didática de Atendimento

**Pergunta 13: O que a figura materna representa no mundo interno e como a autora correlaciona essa energia ao "espaço onde algo cresce com tempo, cuidado e presença"?**

A figura materna representa a "sustentação emocional interna". A nível somático, ela atua como o recipiente energético responsável pela contenção do que foi atraído. A autora define que essa energia "representa um espaço interno onde algo cresce com tempo, cuidado e presença". Enquanto o pai é o impulso explosivo de começar, a mãe é a estrutura vibracional ("frequência") que suporta o processo de desenvolvimento orgânico de uma criação. É essa força interna profunda que confere ao indivíduo a "paciência para construir algo" a longo prazo, protegendo o projeto ou relacionamento até que ele esteja maduro.

**Pergunta 15: Como o sentimento de ressentimento ou dó da mãe atua provocando o vazamento de recursos e a incapacidade de "retenção"?**

O ressentimento e a pena da figura materna bloqueiam a energia da sustentação, criando a dinâmica onde "tudo o que faz não ficar mãe". Somaticamente, o corpo do indivíduo consegue até dar o impulso para conquistar (usando o masculino), mas o seu "feminino" não tem estrutura para manter. A autora detalha que, ao julgar a mãe com raiva ("lazarenta desgramada") ou dó ("coitada, ela é tão fraca"), a pessoa decreta "eu não reconheço" e "eu não consigo trazer a força dela para mim". O impacto material desse vácuo energético é a perda contínua: "Eu ganho dinheiro, mas eu não não rende, não fica... Eu atraio, mas eu não sustento". Sem essa força de retenção ("frequência"), nada cria raiz na vida do assistido.

**Pergunta 16: Qual é o diagnóstico somático traçado pela autora quando uma pessoa relata que "ganha dinheiro, mas não rende/não fica", citando a dinâmica de transição entre múltiplos parceiros?**

Quando uma pessoa relata esse padrão exato de atrair, mas nunca consolidar (exemplificado na transição de namorar "o João", depois "o Flávio" e agora "o Fernando", onde ela "tá sempre arranjando namorado, mas nada vira"), Andresa diagnostica energeticamente: "Nessa hora eu já sei que ela me sustenta e aqui é o perrengue dela com a mãe". O diagnóstico somático é que a pessoa "não consegue sustentar ou por raiva ou por dó" da figura materna. Vibracionalmente, o indivíduo tem sua energia vital esgotada porque "está vivendo para suprir algo, para que a mãe a veja, a ame, a goste dela". Devido a esse buraco emocional de dependência e expectativa infantil não resolvida, ela é incapaz de nutrir ou reter os próprios relacionamentos e o próprio dinheiro na vida adulta.

## Referencia

ANDRESA MOLINA. *A Representação Materna (Vínculo, Cuidado e a Retenção de Dinheiro/Relações)*. Aula 02 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]].
