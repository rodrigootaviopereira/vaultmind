---
type: tecnica
author: Andresa Molina
tags: [mandala_da_dor, diagnostico, questionario, autoconhecimento]
sources: ["[[raw/archive/transcriptions/03 Código Humanosense  - Andresa Molina.md]]", "[[raw/archive/transcriptions/01 - Aula Inaugural - HumanoSense - Andresa Molina.md]]"]
---

# Técnica de Diagnóstico das Personalidades e Personagens de Dor

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/transcriptions/03 Código Humanosense  - Andresa Molina.md]]
  - [[raw/archive/transcriptions/01 - Aula Inaugural - HumanoSense - Andresa Molina.md]]

## Objetivo

- [INFERÊNCIA] Técnica de Diagnóstico das Personalidades e Personagens de Dor organiza uma prática do sistema de Andresa Molina para transformar leitura da dor em condução, liberação, harmonização ou reorganização do campo.

## Pré-requisitos

- Presença do terapeuta.
- Respeito ao passo a passo, à ficha, ao campo e à autorização do assistido.
- Clareza sobre a questão central antes de aprofundar a técnica.

## Passo a Passo

1. Identificar a queixa, emoção dominante, afeto/desafeto ou ponto de entrada.
2. Relacionar a informação com ficha, corpo, mandala, personagem ou campo energético.
3. Aplicar a condução sem atropelar o assistido, mantendo escuta e conexão.
4. Observar sinais de liberação, resistência, repetição ou necessidade de aprofundamento.
5. Fechar com integração, retorno à consciência ou orientação prática quando aplicável.

## Duração/Frequência

- [INFERÊNCIA] Deve durar o suficiente para esgotar a camada acessada sem forçar uma profundidade que o assistido não sustenta naquele momento.

## Indicadores de Sucesso

- Maior clareza sobre a raiz da dor.
- Redução de confusão, defesa ou carga emocional.
- Sensação de fechamento, harmonização ou novo entendimento corporal/energético.

## Variações

- Pode ser adaptada conforme a mandala, ficha, câmara, mesa, baralho, humanometria ou técnica específica envolvida.

## Conceitos Envolvidos

- [[Camada MasterSense - Personagens da Dor]]
- [[HT - Conceito - Metodo Humanoterapeuta]]
- [[Arquitetura do HumanoSense]]
- [[MasterSense - Mentoria do HumanoSense]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]

## Evidências do Material

- Eles aparecem como movimentos concretos na ficha: espera, dependencia, vergonha, defesa, guerra antiga e dificuldade de sustentar valor proprio. ## Referencia ANDRESA MOLINA. *Camada MasterSense - Personagens da Dor*. (Camada MasterSense - Personagens da Dor)
- Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_03_metodologia_humanoterapeuta.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_04_passo_1_a_consulta_inicial_no_psicogerador_quantionico_o_diagnostico.md]]. (HT - Conceito - Metodo Humanoterapeuta)
- # Camada MasterSense - Personagens da Dor ## Rastreabilidade da Fonte - **Fontes principais no arquivo bruto**: - [[raw/archive/andresa_molina/transcriptions/02 Mastersense - Andresa Molina.md]] ## Segunda Camada O MasterSense mostra que os personagens da dor nao devem ser lidos apenas como tipos psicologicos. (Camada MasterSense - Personagens da Dor)
- Use o método como ligação entre diagnóstico, condução e reintegração. ## Relação com a Série - O `Mapa da Alma` fornece a leitura da origem da dor. - O `Método HumanoSense` organiza a prática. - A `Mesa` e a `Câmara` são os espaços operativos da técnica. - A `Ficha` e a `Anamnese` mantêm a sessão centrada na raiz. ## Referência ANDRESA MOLINA. (Arquitetura do HumanoSense)
- O MasterSense pega essa base e transforma em supervisao viva: o terapeuta aplica, registra, autoriza a analise e aprende a enxergar o que a ficha revela sobre afeto/desafeto, pai, mae, personagens, escassez, valor, fuga e memoria celular. ## Segunda Camada - Leitura de Conjunto - A aula 01 apresenta a moldura espiritual e profissional da mentoria. - A aula 02 confirma o metodo na pratica: a ficha nao e burocracia, e um mapa de fuga, defesa, desejo, dor e incoerencia. - A mentoria insiste que o terapeuta nao precisa sentir tudo mediunicamente para fazer um bom trabalho; primeiro ele deve aprender a ler bem o material que o assistido oferece. - O MasterSense nao substitui o HumanoSense. (MasterSense - Mentoria do HumanoSense)
- Quando a ficha vem vazia ou pouco preenchida, a autora considera que nao ha material suficiente para analisar o caso. - **Fonte relacionada**: [[raw/archive/andresa_molina/transcriptions/02 Mastersense - Andresa Molina.md]] ## Referencia ANDRESA MOLINA. *Conceito da Ficha de Identificação e Síntese da Dor*. (Conceito da Ficha de Identificacao e Sintese da Dor)

## Notas Pessoais

- Reservado para registros de aplicação do usuário.

## Referencia

ANDRESA MOLINA. *Técnica de Diagnóstico das Personalidades e Personagens de Dor*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/transcriptions/03 Código Humanosense  - Andresa Molina.md]], [[raw/archive/transcriptions/01 - Aula Inaugural - HumanoSense - Andresa Molina.md]]. Acesso em: 17 jun. 2026.
