---
type: tecnica
author: Andresa Molina
tags: [tecnica, mandala-suspensa, odus, geometria-sagrada, reconsolidacao, 4a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]]"]
---

# Trabalho Energético da Mandala Suspensa (Odus)

## Objetivo

- Ancorar o mental superior do assistido e isolá-lo de influências e opiniões externas, forçando-o a sustentar o vazio interno (suspensão) até ativar a lembrança inconsciente de seu destino inato (Odu) e iniciar a reconsolidação celular do trauma de anulação pessoal.

## Pré-requisitos

- Identificação da coordenada somática através do [[Tecnica de Mapeamento Somatico da 4a Coordenada|Mapeamento Somático da 4ª Coordenada]].
- Conexão e permissão da equipe de amparadores espirituais do terapeuta e do assistido.

## Passo a Passo

1. **Isolamento de Campo (Círculo Sutil)**:
   - O terapeuta projeta energeticamente um campo isolado de trabalho (círculo mágico ou mandala).
   - O assistido é conduzido mentalmente a entrar nesse espaço completamente só (sem cônjuge, filhos, pais, amigos ou guias projetados).
2. **Conexão com a Linha de Destino (Os 16 Odus)**:
   - Mentalizar a conexão com a sabedoria ancestral que rege os **16 destinos originais (Odus)** e suas mais de 200 combinações possíveis de caminhos.
   - Direcionar a energia do assistido para reconhecer que o seu destino original e seu programa de vida (Saudade do Futuro) estão gravados em seu inconsciente e são invioláveis.
3. **Ancoragem da Mandala com Centro Suspenso (Vazio)**:
   - Apresentar ou projetar visualmente a mandala terapêutica com o seu **centro intencionalmente aberto/suspenso**.
   - Conduzir o assistido a fixar a atenção nessa imagem. O espaço central em aberto serve para forçar o assistido a suspender a busca por validação externa (conselhos de terceiros que invalidam sua dor) e sustentar a angústia até que a saída e a verdade do seu próprio coração emerjam de dentro de si.
4. **Desprogramação Celular**:
   - Conectar os raios periféricos da mandala às coordenadas do corpo do assistido, emitindo o fluxo de transmutação energética necessário para desprogramar os pactos de anulação e reconsolidar o DNA, estendendo a cura para a ancestralidade por entrelaçamento quântico.

## Duração/Frequência

- Executada como intervenção ritualística e energética durante o processo de cura na câmara HumanoSense ou sessões específicas de reconsolidação da 4ª Coordenada.

## Indicadores de Sucesso

- Capacidade de sustentar a visualização da suspensão central sem gerar crises de pânico ou pressa mental.
- Sensação de força interna e clareza sobre o próprio propósito, independentemente da aceitação alheia.

## Conceitos Envolvidos

- [[Conceito da Mulher antes de ser de Todos]]
- [[Conceito de Saudade do Futuro]]
- [[Conceito de Automagia]]
- [[Principio da Gestacao Feminina]]

## Perguntas Frequentes / Didática de Atendimento

### Por que Andresa deixa o centro da Mandala Suspensa (Odus) intencionalmente vazio/suspenso durante o trabalho energético?

O centro da mandala é deixado propositalmente vazio (em suspensão) como uma ferramenta terapêutica para impedir que a pessoa continue fugindo de si mesma. A autora explica que quem passa a vida resolvendo a demanda dos outros perde o contato com a própria voz e está constantemente "esperando que alguém que não te entende diga" o que deve ser feito.

A suspensão no centro obriga a pessoa a sustentar a sua própria dúvida e a permanecer no vazio sem a intervenção de terceiros. O objetivo é forçar a reconexão com o "mental superior" da própria pessoa, pois apenas ela mesma — dentro daquele oráculo isolado — pode encontrar a saída e descobrir qual é o seu verdadeiro caminho e projeto de vida.

## Referência

ANDRESA MOLINA. *Trabalho Energético da Mandala Suspensa (Odus)*. Aula 04 - Coordenada 4 (A Mulher Antes de Ser de Todos). Fontes: [[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]].
