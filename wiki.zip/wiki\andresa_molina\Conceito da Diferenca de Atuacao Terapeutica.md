---
type: conceito
author: Andresa Molina
tags: [metodologias, humanosense, humanoterapia, regressao, egrégora]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# A Diferença de Atuação Terapêutica (Humanosense vs. Humanoterapia vs. Regressão)

- **Definição Precisa**: A distinção operacional das três vias clínicas: a Humanoterapia atua de forma passiva-receptiva limpando o inconsciente profundo celular/epigenético do cliente; o Humanosense atua de dentro para fora exigindo a autoria consciente e o sangramento ativo do assistido; e a Regressão Comum é uma visualização sem desdobramento astral estruturado, sem proteção geométrica e sem egrégora de resgate de fractais.
- **Sinônimos/Variações**: Vias de cura de Andresa Molina, Humanosense vs. outras terapias.
- **Contexto de Uso**: Explicada para desfazer confusões conceituais dos alunos sobre o porquê de cada comando e passo a passo geométrica na mesa serem insubstituíveis no Humanosense.
- **Relação com Princípios**: [[Principio do Respeito a Tecnica e a Equipe Espiritual]], [[Principio da Objetividade Terapeutica]]
- **Exemplos do Material**: "Manoterapeuta de fora para dentro? Porque quem faz é o terapeuta, ele que capta, ele que limpa, ele que chora... manocense é a pessoa que vai... E aí então é o que você fala de dentro para fora, é da pessoa pra expressão para fora... Na regressão a gente não desdobra... A emoção que leva, né? E não o racional. Mas no na regressão é é outra outra proposta. Primeiro que a gente não tá desdobrado, a gente não faz desobsessão. A pessoa vai lá, olha alguma coisa, OK? ...não tem trabalho de agrégor enquadramento... não tem processo de de de recolhimento."
- **Aplicação Prática**: O terapeuta Humanosense estimula o assistido a tomar as rédeas da sessão durante o desdobramento na Câmara, ativando sua força de adulto (autoria), ao invés de deixá-lo relaxado de forma passiva esperando que o terapeuta limpe o campo sozinho.
- **Conexões Externas**: [[Conceito de Complementaridade Metodologica]], [[HT - Conceito - Metodo Humanoterapeuta]]

## Perguntas Frequentes / Didática de Atendimento

### 11. De que forma a mesa Humanosense se diferencia conceitualmente da Humanoterapia e da Regressão Comum?
**Resposta**: A diferença vibracional e somática encontra-se no protagonismo do assistido e na tecnologia magnética aplicada:
*   **Humanoterapia (Limpeza passiva):** Opera "de fora para dentro". Quem absorve a carga celular é o terapeuta: "ele que capta, ele que limpa, ele que chora, ele que vomita... ele que encaminha". Atua "num processo muito mais profundo que o meu assistido ele não é capaz de ir" para desfazer registros ocultos.
*   **Humanosense (Choque ativo):** Opera "de dentro para fora". O processo exige uma postura racional do paciente ("esfrega na cara dele"). É o próprio paciente quem desdobra ("é da pessoa pra expressão para fora"), confrontando a sua dor de forma direta na cena.
*   **Regressão Comum:** Diferencia-se drasticamente porque nela "a gente não desdobra" e "não faz desobsessão". A pessoa é levada apenas pela emoção, sem ancoramento quântico. A autora é categórica sobre a falta de segurança da regressão simples: "Não tem trabalho de agrégor enquadramento, leva, encaminha, trata, não tem processo de de de recolhimento, de arrasto, não tem nada disso. [...] não vem entidade, não vem seres".


## Referencia

ANDRESA MOLINA. *A Diferença de Atuação Terapêutica*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
