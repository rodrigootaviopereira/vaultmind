---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_70_o_que_a_humanometria_trata.md]]"]
---

# Cap 070 - O Que A Humanometria Trata

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_70_o_que_a_humanometria_trata.md]]

## Referencia

ANDRESA MOLINA. *Cap 070 - O Que A Humanometria Trata*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_70_o_que_a_humanometria_trata.md]]. Acesso em: 17 jun. 2026.
