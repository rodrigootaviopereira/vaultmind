---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_56_o_campo_eletromagnetico.md]]"]
---

# Cap 056 - O Campo Eletromagnetico

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_56_o_campo_eletromagnetico.md]]

## Referencia

ANDRESA MOLINA. *Cap 056 - O Campo Eletromagnetico*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_56_o_campo_eletromagnetico.md]]. Acesso em: 17 jun. 2026.
