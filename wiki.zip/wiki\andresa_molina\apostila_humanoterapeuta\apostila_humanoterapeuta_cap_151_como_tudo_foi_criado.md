---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_151_como_tudo_foi_criado.md]]"]
---

# Cap 151 - Como Tudo Foi Criado

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_151_como_tudo_foi_criado.md]]

## Referencia

ANDRESA MOLINA. *Cap 151 - Como Tudo Foi Criado*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_151_como_tudo_foi_criado.md]]. Acesso em: 17 jun. 2026.
