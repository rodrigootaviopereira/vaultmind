---
type: concept
author: Andresa Molina
tags: [entidades-de-resgate, especializacao, pombagira, bombeiro-astral, egrégora]
sources: ["[[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]"]
---

# A Especialização das Entidades de Resgate (O corpo clínico da egrégora)

- **Definição**: O mapeamento hierárquico do "Hospital Astral", que divide os trabalhadores da luz entre consciências que resolvem fardos emocionais severos (entidades de "habilidade/autorização") e as consciências tecnicistas focadas em bloqueios operacionais (os "especialistas").
- **Justificativa**: A egrégora do Humanosense não usa um "clínico geral". A nível vibracional, a dor dita quem é convocado. Se a paciente foi estuprada ou sofre de "dor de amor" visceral, a egrégora projeta os arquétipos perfeitos que conhecem essa dor na pele — "Uma pombogira... é especialista. Ela já viveu isso... Ela que cuida desse tipo de dor". Entretanto, se na visão a pessoa está esmagada física ou mentalmente por escombros, a egrégora das Pombagiras não possui a técnica da engenharia para tirar o bloco. O terapeuta então muda o comando, exigindo "Entidades Especialistas" ("um bombeiro... ou uma pessoa de alta tecnologia" com softwares astrais). O terapeuta rege essa orquestra.
- **Evidências**: "Não é clínico geral... Uma pombogira é clínica geral. Ela é uma especialista extremamente especializada, entende? Em dor de abuso, de estupro, de engano, de traição, de amiga que trafi a faca nas costas... Ela já viveu isso. Ela já foi, ela já ela tá anos luz na frente. Então ela ela que cuida desse tipo de dor... Mas pode ser que às vezes precise vir para tirar um guarda-roupa de cima ou para tirar um carro de cima. Não vai vir um bechu, vai vir um bombeiro. Esse é um especialista excelente... pode ser um uma pessoa de alta tecnologia... ele sabe trabalhar com, sei lá, com um programa específico."
- **Implicações**: O terapeuta deve ter a genialidade clínica para discriminar o tipo de bloqueio e chamar a equipe especializada exata durante a condução.
- **Conexões**: [[Conceito de Entidades de Resgate vs Especialistas]], [[Tecnica do Comando de Intervencao Especializada]]
- **Notas Pessoais**: Chamar bombeiros para tirar escombros e Pombagiras para curar dores de traição reflete a precisão cirúrgica do método.

## Perguntas Frequentes / Didática de Atendimento

### 19. Explique a hierarquia de atuação clínica no Hospital Astral entre as Pombagiras e as equipes especialistas.
**Resposta**: No Hospital Astral do Código Humanosense, as entidades são convocadas de acordo com a patologia ou o obstáculo exato da cena, não havendo "clínico geral" genérico.

*   **Pombagiras (Especialistas em Dor Emocional Visceral):** Elas são chamadas para os resgates emocionais brutais porque são **"especialista extremamente especializada... Em dor de abuso, de estupro, de engano, de traição"**. Elas atuam na dor sentimental porque têm o lastro cármico disso: **"Ela já viveu isso. Ela já foi, ela já ela tá anos luz na frente"**.
*   **Bombeiros Astrais (Equipes e Tecnologias de Remoção):** Se a visão na Câmara não for primariamente sentimental, mas estrutural, a hierarquia muda. **"Só que pode ser que às vezes precise vir para tirar um um um guarda-roupa de cima ou para tirar um carro de cima. Não vai vir um bechu, vai vir um bombeiro"**. O terapeuta pode invocar também **"uma pessoa de alta tecnologia... ele sabe trabalhar com, sei lá, com um programa específico"**.
O terapeuta, como instrumento de comando, rege essa entrada, percebendo as necessidades do campo: **"às vezes vai ser o a entidade especialista que vai vir primeiro para tirar dos escombros para depois vir"** a entidade que vai amparar a dor emocional resgatada.


## Referencia

ANDRESA MOLINA. *A Especialização das Entidades de Resgate*. Aula 10 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]].
