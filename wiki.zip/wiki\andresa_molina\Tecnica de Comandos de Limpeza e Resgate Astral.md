---
type: tecnica
author: Andresa Molina
tags: [comandos-resgate, limpeza-astral, egregora, entidades-especialistas]
sources: ["[[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]"]
---

# Os Comandos de Limpeza e Resgate Astral (A invocação padrão e especializada)

- **Objetivo**: Limpar os detritos vibracionais da cena holográfica e recolher as consciências/fractais de dor liberados na catarse, convocando as equipes de resgate geral ou as equipes especialistas adequadas.
- **Pré-requisitos**: Conclusão da purga emocional do assistido na cena.
- **Passo a Passo**:
  1. **Isolamento**: O terapeuta enquadra a cena mental do trauma em uma pirâmide energética (pulsos magnéticos de 1 a 5) para conter a energia densa e resíduos.
  2. **Invocação de Resgate Geral**: Se a cena envolve apenas dor emocional acumulada, emite o comando exato de invocação padrão convocando a equipe base (*"entidades com habilidade, disponibilidade e autorização"*), encaminhando as almas limpas para a Câmara.
  3. **Invocação Especializada**: Se a contraparte estiver presa fisicamente no cenário (ex: destroços de desabamento, correntes, amarras umbralinas), o terapeuta altera o comando, convocando a equipe especializada (*"entidades especialistas boas e excelentes na execução desta tarefa"*) para desfazer as correntes ou curar os corpos sutis antes do recolhimento.
- **Duração/Frequência**: Praticado na fase de fechamento de cada cena de trauma acessada durante a regressão.
- **Indicadores de Sucesso**: Dissolução completa da imagem holográfica de sofrimento na mente do assistido e sensação de segurança e amparo.
- **Variações**: Convocação de guias terrenos (povos originários, xamãs) vs. guias estelares para reconexões de DNA.
- **Conceitos Envolvidos**: [[Conceito de Entidades de Resgate vs Especialistas]], [[Tecnica do Comando de Encaminhamento Padrao]], [[Tecnica do Comando de Intervencao Especializada]]

## Perguntas Frequentes / Didática de Atendimento

### 17. Qual a diferença de comando e atuação entre a egrégora de resgate padrão e as entidades especialistas?
**Resposta**: Resgate Padrão: O terapeuta comanda "invoca a presença de todas as entidades, com habilidade, disponibilidade e autorização". Essa equipe limpa as toxinas emocionais e recolhe as consciências presas ("Vamos recolhendo tudo... pode ser que venha um caboco... o povo cigano").
Entidades Especialistas: O terapeuta comanda "invoca a presença de todas as entidades especializadas boas e excelentes na execução desta tarefa". Eles são acionados apenas quando há uma armadilha mecânica ou física na cena astral: "precisava de estravar que era a roda da carroça... Pode vir um pedreiro porque a casa caiu. Pode vir um bombeiro para tirar dos resgat... pode ser que venha os médicos, pode ser que venha enfermeiros... antibomba".

## Referencia

ANDRESA MOLINA. *Os Comandos de Limpeza e Resgate Astral*. Aula 07 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]].
