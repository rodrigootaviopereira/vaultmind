---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_119_procedimento_para_reacoplamento.md]]"]
---

# Cap 119 - Procedimento Para Reacoplamento

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_119_procedimento_para_reacoplamento.md]]

## Referencia

ANDRESA MOLINA. *Cap 119 - Procedimento Para Reacoplamento*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_119_procedimento_para_reacoplamento.md]]. Acesso em: 17 jun. 2026.
