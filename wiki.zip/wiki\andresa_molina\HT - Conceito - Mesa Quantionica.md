---
type: conceito
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, mesa_quantionica, radiestesia, diagnostico]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_04_passo_1_a_consulta_inicial_no_psicogerador_quantionico_o_diagnostico.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_62_mesa_quantionica.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_137_mesa_quantionica.md]]"]
---

# HT - Conceito - Mesa Quantionica

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_04_passo_1_a_consulta_inicial_no_psicogerador_quantionico_o_diagnostico.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_62_mesa_quantionica.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_137_mesa_quantionica.md]]

## Definição Precisa

- **Definição**: [INFERÊNCIA] HT - Conceito - Mesa Quantionica nomeia um eixo recorrente da obra de Andresa Molina que deve ser lido dentro do HumanoSense/Humanoterapeuta como categoria de diagnóstico, leitura de campo ou condução terapêutica.
- **Formulação de apoio**: Use o método como ligação entre diagnóstico, condução e reintegração. ## Relação com a Série - O `Mapa da Alma` fornece a leitura da origem da dor. - O `Método HumanoSense` organiza a prática. - A `Mesa` e a `Câmara` são os espaços operativos da técnica. - A `Ficha` e a `Anamnese` mantêm a sessão centrada na raiz. ## Referência ANDRESA MOLINA.

## Sinônimos/Variações

- [INFERÊNCIA] Varia conforme a aula: pode aparecer como campo, código, mandala, personagem, sistema, memória, técnica ou postura terapêutica.

## Contexto de Uso

- Usado para orientar leitura do assistido, organização da sessão, compreensão de padrões emocionais/energéticos e conexão entre método, ficha, mesa, câmara e condução espiritual.

## Relação com Princípios

- [[Arquitetura do HumanoSense]]

## Exemplos do Material

- Use o método como ligação entre diagnóstico, condução e reintegração. ## Relação com a Série - O `Mapa da Alma` fornece a leitura da origem da dor. - O `Método HumanoSense` organiza a prática. - A `Mesa` e a `Câmara` são os espaços operativos da técnica. - A `Ficha` e a `Anamnese` mantêm a sessão centrada na raiz. ## Referência ANDRESA MOLINA. (Arquitetura do HumanoSense)
- Esta nota existe para impedir que esses elementos fiquem soltos em arquivos isolados. ## Eixos - [[Conceito do Mapa da Alma]] - [[Conceito do Metodo HumanoSense]] - [[Conceito da Mesa HumanoSense]] - [[Conceito da Ficha de Identificacao e Sintese da Dor]] - [[Conceito da Camara HumanoSense]] - [[Tecnica de Identificacao da Raiz na Anamnese]] - [[Tecnica de Aplicacao Guiada na Camara HumanoSense]] - [[Mapa Estrutural da Wiki Andresa Molina]] ## Aplicação Prática 1. (Arquitetura do HumanoSense)

## Aplicação Prática

- [INFERÊNCIA] Ao encontrar este tema em atendimento, use-o como pergunta de aprofundamento: onde ele aparece na queixa, no corpo, na ficha, no afeto/desafeto e na relação entre consciência e inconsciente?
- [INFERÊNCIA] Verifique se a pessoa está usando este padrão como defesa, fuga, repetição de dor ou caminho de reorganização.

## Conexões Externas

- [[Arquitetura do HumanoSense]]

## Referencia

ANDRESA MOLINA. *HT - Conceito - Mesa Quantionica*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_04_passo_1_a_consulta_inicial_no_psicogerador_quantionico_o_diagnostico.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_62_mesa_quantionica.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_137_mesa_quantionica.md]]. Acesso em: 17 jun. 2026.
