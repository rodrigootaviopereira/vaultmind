---
type: principio
author: Andresa Molina
tags: [nao-inducao, transe-astral, livre-arbitrio, conducao-empatica, holograma]
sources: ["[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio da Não-Indução no Transe Astral (A condução baseada em confirmar a visão)

- **Definição**: A diretriz intervencionista que proíbe o terapeuta de criar o cenário ou ditar as ações do assistido durante o desdobramento. O terapeuta não insere imagens, ele apenas observa o holograma junto com o paciente e valida as escolhas dele.
- **Justificativa**: A nível espiritual, a Câmara Humanosense é o espelho do próprio inconsciente do paciente. Se a paciente olha para a mãe na cena e diz que não quer ajudá-la, o terapeuta não pode dar um comando moralista: "Você tem que perdoar sua mãe". O terapeuta equaliza a própria frequência com a do paciente ("fico mais muda... eu vou vivendo junto com ela"). Ele atua como um companheiro de exploração, perguntando "o que você quer fazer? Você quer olhar para isso?". Essa não-indução garante que a cura seja uma conquista orgânica do DNA emocional do assistido, e não uma sugestão hipnótica passageira.
- **Evidências**: "Hora que você entra na câmera... você entra numa frequência diferente e aí eu fico, eu vejo o que ela vê, eu consigo conectar, eu vejo no sentido daquela história, eu vou vivendo junto com ela aquele momento, então eu vou ofertando energia e conduzindo o que que você quer fazer, você quer olhar para isso? ...Então eu não induzi o que ela tinha que fazer, eu confirmei com ela o que ela precisaria fazer, certo?"
- **Implicações**: O terapeuta deve usar perguntas abertas de verificação em vez de propor soluções mentais criadas por seu próprio ego.
- **Conexões**: [[Principio da Nao-Manipulacao no Transe]], [[Tecnica da Conducao do Sangramento em Primeira Pessoa]]
- **Notas Pessoais**: Deixar o inconsciente da pessoa se expressar sem julgamentos ou moralismo é a chave para o resgate real.

## Perguntas Frequentes / Didática de Atendimento

### 8. Como a autora estrutura a "Não-Indução" no campo astral e de que forma garante que a cura venha do próprio assistido?
**Resposta**: A autora estrutura a condução abolindo imperativos e assumindo uma postura de empatia visual. Ela equaliza a própria frequência com a do assistido na Câmara: **"eu vejo o que ela vê, eu consigo conectar, eu vejo no sentido daquela história, eu vou vivendo junto com ela aquele momento"**.

Para garantir que a resolução venha legitimamente do assistido (do seu "DNA emocional"), o terapeuta não diz o que deve ser feito na cena holográfica; ele apenas interroga a vontade orgânica do paciente: **"eu vou ofertando energia e conduzindo o que que você quer fazer, você quer olhar para isso? Não quer olhar para isso? ... Então eu não induzi o que ela tinha que fazer, eu confirmei com ela o que ela precisaria fazer"**. A nível somático, a cura acontece porque a própria pessoa escolhe agir e expressar o que estava reprimido nas suas células.


## Referencia

ANDRESA MOLINA. *Princípio da Não-Indução no Transe Astral*. Aula 09 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]].
