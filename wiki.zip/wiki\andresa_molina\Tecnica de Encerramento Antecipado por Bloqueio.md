---
type: technique
author: Andresa Molina
tags: [encerramento-antecipado, resistencia, recuo-amigavel, bloqueio-astral]
sources: ["[[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]"]
---

# Técnica de Encerramento Antecipado por Bloqueio (O desdobramento reverso)

- **Definição**: O protocolo de recuo estruturado e não traumático acionado quando o terapeuta constata que a parede do ego do paciente é intransponível ("Eu não quero falar. Não quero perdoar"), estancando a viagem astral no meio do trajeto.
- **Como praticar e seu Propósito**:
  1. **Aceitar a Recusa**: Se no sangramento o cliente diz "eu não quero falar nada, não consigo", o terapeuta recua sem insistir.
  2. **Comando de Retorno Suave**: Dar o comando reverso: "Então vamos trazer de volta, vamos voltando, vamos vou entregando aí para as entidades, limpando tudo e vamos voltando para cá".
  3. **Ancorar Paz Presente**: "Se você realmente não quer... Se você não gosta agora... Então vamos para um momento de paz, fica em paz, fica calma e vai voltando".
  O propósito é fechar a sessão com segurança neurológica e assepsia astral, ciente de que o livre-arbítrio escolheu reter a raiva para punir o outro, registrando o encerramento como concluído com sucesso.
- **Evidências**: "Então, se ela insistisse, eu teria que assim, então vamos trazer de volta, vamos voltando, então vamos, vamos voltando, vamos vou entregando aí para as entidades, limpando tudo e vamos voltando para cá. Se você realmente não quer, vai voltando, vamos encontrando um momento de passo, fica em paz, tá tranquilo, não precisa. Se você não gosta agora, não consegue, não tem problema, tá tudo bem. Então vamos para um momento de paz, fica em paz, fica calma e vai volando... Ah, só que aí não conclui, né? ...Assim, para mim tá concluídíssimo. Não quer, tá tudo bem para mim."
- **Conexões**: [[Principio do Respeito a Resistencia]], [[Tecnica de Retorno a Consciencia e Harmonizacao]]

## Perguntas Frequentes / Didática de Atendimento

### 17. Descreva o protocolo de recuo e assepsia exigido no encerramento antecipado por bloqueio do assistido?
**Resposta**: Quando o paciente trava diante da cena holográfica do agressor e decreta **"eu não quero falar nada, não, eu não consigo fazer nada"**, o terapeuta deve respeitar o limite psíquico e interromper a sessão através de três passos seguros:

1. **Validação:** O terapeuta desarma o conflito de imediato. **"Se você realmente não quer, vai voltando... Se você não gosta agora, não consegue, não tem problema, tá tudo bem"**.
2. **Assepsia e Retorno:** Comanda-se o recuo astral recolhendo o campo para garantir a segurança magnética. **"Então vamos trazer de volta, vamos voltando, então vamos, vamos voltando, vamos vou entregando aí para as entidades, limpando tudo e vamos voltando para cá"**.
3. **Ancoragem de Paz Somática:** O corpo é estabilizado para despertar sem trauma. **"Então vamos para um momento de paz, fica em paz, fica calma e vai volando"**.
A autora atesta a integridade desse encerramento para a egrégora: **"Assim, para mim tá concluídíssimo. Não quer, tá tudo bem para mim"**.


## Referencia

ANDRESA MOLINA. *Técnica de Encerramento Antecipado por Bloqueio*. Aula 10 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]].
