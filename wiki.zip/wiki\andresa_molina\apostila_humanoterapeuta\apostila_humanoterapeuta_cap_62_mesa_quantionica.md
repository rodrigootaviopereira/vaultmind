---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_62_mesa_quantionica.md]]"]
---

# Cap 062 - Mesa Quantionica

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_62_mesa_quantionica.md]]

## Referencia

ANDRESA MOLINA. *Cap 062 - Mesa Quantionica*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_62_mesa_quantionica.md]]. Acesso em: 17 jun. 2026.
