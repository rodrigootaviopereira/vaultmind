---
type: aula
author: Andresa Molina
tags: [codigo-humanosense, humanosense, aula-02, reingestao-2026-06-19]
sources:
  - "[[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]"
---
# Aula 02 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `02   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 16.926 palavras; 625 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- Resumo Automático: 02 Código Humanosense Transcrição / Texto Completo Olá, boa noite.
- Então, aqui, ó, mandala, como eu falei, perdão, vou abrir de novo, como eu falei, ela tem as três mandalas, a mandala do amor, a mandala da dor e aqui fora a mandala da cura.
- Então eu vou passar com vocês primeiro a o conceito e as perguntas da mandala do amor.
- Então a primeira coisa que nós vamos falar aqui é da eh dentro da mandala do amor, a gente tem um conceito base para terapêutica e a primeira delas que nós vamos falar é sobre energia, certo?
- Então, feminino ferido, ele é ofendido, julgador, magoado.
- Então, essa é a primeira, é o primeiro ponto que a gente precisa sempre identificar.
- Então, cada uma delas foi construída especificamente baseada nesse nesse campo de energia, tá?
- Então aqui a gente vai fazer perguntas pro nosso cliente, pro nosso assistido.
- Então, quando a gente fala em frequência e vibração, a gente precisa entender que tudo está dentro da energia do feminino e masculino.
- Então aqui quando a gente fala da fusão da influência e da intuição, e eu não falei de eu não falei de de espiritualidade aqui, eu não falei de religiosidade, eu não falei de espírito, eu tô falando de outra coisa, tem gente que nem acredita em nada e consegue trabalhar muito bem a sua influência e respeita a sua intuição e não acredita em nada.
- Vocês podem assistir a aula, como vocês podem olhar por aqui, porque tudo que eu falei, a explicação base tá aqui, ó.
- E aí você consegue ter um pensamento mais estruturado do campo energético dele, mas tem didática para falar de uma maneira que ele compreenda que seria uma base um pouco mais terapêutica, mas não uma terapia convencional, porque não é só pai é isso, a mãe é isso, a mãe é isso, pai é isso e a culpa é de quem, quem é culpado que faz só a gente ir de um lado…

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-79
- Resumo Automático: 02 Código Humanosense Transcrição / Texto Completo Olá, boa noite.
- Então, aqui, ó, mandala, como eu falei, perdão, vou abrir de novo, como eu falei, ela tem as três mandalas, a mandala do amor, a mandala da dor e aqui fora a mandala da cura.
- Então a primeira coisa que nós vamos falar aqui é da eh dentro da mandala do amor, a gente tem um conceito base para terapêutica e a primeira delas que nós vamos falar é sobre energia, certo?

### Bloco 2 - frases 80-158
- Então, feminino ferido, ele é ofendido, julgador, magoado.
- Então eu não dou continuidade porque eu tenho dificuldade em sustentar e a minha energia feminina precisa ser trabalhada, tá?
- Então, essa é a primeira, é o primeiro ponto que a gente precisa sempre identificar.

### Bloco 3 - frases 159-237
- Então, cada uma delas foi construída especificamente baseada nesse nesse campo de energia, tá?
- Então aqui a gente vai fazer perguntas pro nosso cliente, pro nosso assistido.
- Então, quando a gente fala em frequência e vibração, a gente precisa entender que tudo está dentro da energia do feminino e masculino.

### Bloco 4 - frases 238-316
- Então precisa fundir esses duas energias também para para nascer qualquer qualquer coisa.
- Então quando a gente fala de pais, a primeira referência simbólica da energia do dar e receber, agir e acolher e e da simbologia da fecundação e da gestação, igual a criação, são os pais.
- Então quando a gente fala que não existe contrrole, é sobre esse desejo.

### Bloco 5 - frases 317-395
- Ao invés de olhar e falar, paizão, segurou a onda, se ferrou, tomou, só se arrebentou, mas segurou era forte porque o que ele passou só sendo muito forte, entende?
- Eu estou dizendo, você precisa curar isso dentro de você de algum jeito, porque senão o dinheiro não vai ficar, o trabalho não vai ficar, o relacionamento não vai ficar.
- Ela não tem autorização para viver a vida dela porque ela precisa. fazer, porque se ela fizer alguma coisa diferente, porque a mãe gosta, a mãe não vai amar.

### Bloco 6 - frases 396-474
- Quando você se posiciona, é porque quando a gente traz algumas expressões, fica muito claro de fica mais fácil de compreender, de assimilar e de não esquecer o que eu falei, né?
- Então essas expressões elas trazem esse conteúdo interno que vem do inconsciente coletivo, por isso fica mais fácil de compreensão.
- Então ela a gente precisa do feminino, que é o sonho, que é o projeto de vida, que é aquilo que movia você, que vai te dar motivação, é mudar o mundo, é encontrar um jeito melhor, é cuidar dos filhos, como eu sempre sonhei, é ter aquela famílhei.

### Bloco 7 - frases 475-553
- Você não vai explicar nada disso que eu expliquei pr pessoas, você vai fazer as perguntas, depois eu vou ensinar como tá e aí ela falou, aí ela vai toda orgulhosa ou ele tod defender o que eu quero é 10 e só fica guerreando uma guerra sem fim porque ela acabada a tô tô cansada, tô doente, não sei por minha cabeça não para ela não para de guerrear dela fica guerreando o tempo inteiro.
- Então aqui quando a gente fala da fusão da influência e da intuição, e eu não falei de eu não falei de de espiritualidade aqui, eu não falei de religiosidade, eu não falei de espírito, eu tô falando de outra coisa, tem gente que nem acredita em nada e consegue trabalhar muito bem a sua influência e respeita a sua intuição e não acredita em nada.
- E aí a gente então tem o que a gente chama de espiritualidade livre, né?

### Bloco 8 - frases 554-625
- Vocês podem assistir a aula, como vocês podem olhar por aqui, porque tudo que eu falei, a explicação base tá aqui, ó.
- Então gente, é isso que queria pedir para vocês se apropriarem disso, refletirem, lê aqui e tenta relembrar o que eu falei, tenta relembrar exemplos, porque com exemplos, né, o poder dessa história, da parábola, da pequena história que me traz a reflexão, eu consigo ajudar o meu cliente a a na hora me lembrar e aí fazer ah isso aqui mais ou menos a mesma coisa que tava falando, uma história diferente, um…
- E aí você consegue ter um pensamento mais estruturado do campo energético dele, mas tem didática para falar de uma maneira que ele compreenda que seria uma base um pouco mais terapêutica, mas não uma terapia convencional, porque não é só pai é isso, a mãe é isso, a mãe é isso, pai é isso e a culpa é de quem, quem é culpado que faz só a gente ir de um lado pro outro e não transcender, transmutar, como eu falei na…

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Então, hoje a gente começa ativamente aqui, mas tudo que eu falei desde a primeira aula, ele vai reverberar no trabalho de vocês, tá?
- Então, aqui, ó, mandala, como eu falei, perdão, vou abrir de novo, como eu falei, ela tem as três mandalas, a mandala do amor, a mandala da dor e aqui fora a mandala da cura.
- Então a primeira coisa que nós vamos falar aqui é da eh dentro da mandala do amor, a gente tem um conceito base para terapêutica e a primeira delas que nós vamos falar é sobre energia, certo?
- Então, essa é a primeira, é o primeiro ponto que a gente precisa sempre identificar.
- Então, cada uma delas foi construída especificamente baseada nesse nesse campo de energia, tá?
- Então, quando a gente fala em frequência e vibração, a gente precisa entender que tudo está dentro da energia do feminino e masculino.
- Então aqui quando a gente fala da fusão da influência e da intuição, e eu não falei de eu não falei de de espiritualidade aqui, eu não falei de religiosidade, eu não falei de espírito, eu tô falando de outra coisa, tem gente que nem acredita em nada e consegue trabalhar muito bem a sua influência e respeita a sua intuição e não acredita em nada.
- Vocês podem assistir a aula, como vocês podem olhar por aqui, porque tudo que eu falei, a explicação base tá aqui, ó.
- Então gente, é isso que queria pedir para vocês se apropriarem disso, refletirem, lê aqui e tenta relembrar o que eu falei, tenta relembrar exemplos, porque com exemplos, né, o poder dessa história, da parábola, da pequena história que me traz a reflexão, eu consigo ajudar o meu cliente a a na hora me lembrar e aí fazer ah isso aqui mais ou menos a mesma…
- E aí você consegue ter um pensamento mais estruturado do campo energético dele, mas tem didática para falar de uma maneira que ele compreenda que seria uma base um pouco mais terapêutica, mas não uma terapia convencional, porque não é só pai é isso, a mãe é isso, a mãe é isso, pai é isso e a culpa é de quem, quem é culpado que faz só a gente ir de um lado…

## Conceitos-Chave Extraídos

- Resumo Automático: 02 Código Humanosense Transcrição / Texto Completo Olá, boa noite.
- Primeiro eu vou explicar alguns conceitos do que é cada uma dessas coisas da mandala para depois vocês entenderem como vocês vão conseguir fazer as perguntas e identificando as respostas, tá?
- Então, aqui, ó, mandala, como eu falei, perdão, vou abrir de novo, como eu falei, ela tem as três mandalas, a mandala do amor, a mandala da dor e aqui fora a mandala da cura.
- Então eu vou passar com vocês primeiro a o conceito e as perguntas da mandala do amor.
- Então a primeira coisa que nós vamos falar aqui é da eh dentro da mandala do amor, a gente tem um conceito base para terapêutica e a primeira delas que nós vamos falar é sobre energia, certo?
- Então, quando a gente fala de energia, toda criação tem duas forças, a energia da expansão e a energia da contenção.
- Então, quando a gente fala de energia masculina, e eu não tô falando de homem e mulher, é natural que a nossa cabeça vá pensar isso para encontrar uma representações simbólicas disso e conseguir então entrar no mundo da energia.
- Então, cada uma delas foi construída especificamente baseada nesse nesse campo de energia, tá?
- Então, quando a gente fala em frequência e vibração, a gente precisa entender que tudo está dentro da energia do feminino e masculino.
- Então quando a gente fala de pais, a primeira referência simbólica da energia do dar e receber, agir e acolher e e da simbologia da fecundação e da gestação, igual a criação, são os pais.
- Então quando a gente fala que não existe contrrole, é sobre esse desejo.
- Então aqui quando a gente fala da fusão da influência e da intuição, e eu não falei de eu não falei de de espiritualidade aqui, eu não falei de religiosidade, eu não falei de espírito, eu tô falando de outra coisa, tem gente que nem acredita em nada e consegue trabalhar muito bem a sua influência e respeita a sua intuição e não acredita em nada.
- E aí a gente então tem o que a gente chama de espiritualidade livre, né?
- E identificar o quanto é verdade, o quanto bate o que ela fala com o que ela tem no campo energético, no campo espiritual dela.
- Então, eu tô dando base terapêutica e aqui eu tô falando só dessa mandala do amor e e você começa a entender coisas quando a pessoa vai fazer, você já vai sabendo onde estão os problemas dela.
- E aí você consegue ter um pensamento mais estruturado do campo energético dele, mas tem didática para falar de uma maneira que ele compreenda que seria uma base um pouco mais terapêutica, mas não uma terapia convencional, porque não é só pai é isso, a mãe é isso, a mãe é isso, pai é isso e a culpa é de quem, quem é culpado que faz só a gente ir de um lado…


## Técnicas, Procedimentos e Orientações Práticas

- Então algumas pessoas ah, não receber meu kit, mas a gente vai identificar que tem pessoas que não preencheram, então não tem como a gente enviar, né?
- O outro recado, a gente tá recebendo no formulário, então lembrando, a gente criou um canal, né, do Telegram, onde a gente coloca alguns comunicados lá e também eu vou responder algumas perguntas.
- Porque algumas pessoas estão mandando perguntas preenchendo lá no formulário e perguntando sobre o kit, sobre questões técnicas, de como que entra, como é que, como é que acessa, como é que assiste a aula que ficou gravada.
- E aí uma coisa que é importante que a gente entenda aqui, eu vou responder perguntas que não são pessoais, então não adianta você falar: "Não é uma terapia, não vou fazer uma consulta com você".
- Então você assiste a aula que foi dada e aí você, se tiver alguma dúvida em relação à aquilo que foi falado naquela aula, você faz a sua pergunta e eu respondo, tá bom?
- Primeiro eu vou explicar alguns conceitos do que é cada uma dessas coisas da mandala para depois vocês entenderem como vocês vão conseguir fazer as perguntas e identificando as respostas, tá?
- Então eu vou passar com vocês primeiro a o conceito e as perguntas da mandala do amor.
- Então esse material vocês já têm com essas perguntas, então vocês podem eh se utilizar deles, enfim, acompanhar por aqui, mas depois vocês tm tudo, tudo que eu vou falar que tá anotado aqui, vocês tm nesse material, tá?
- Gestar é um processo demorado, longo, que precisa de nutrição, que precisa de introspecção, que precisa de espera, que precisa de reflexão, que precisa de estratégia, que precisa sentar e identificar como é que vai fazer.
- Então, essa é a primeira, é o primeiro ponto que a gente precisa sempre identificar.
- Então aqui a gente vai fazer perguntas pro nosso cliente, pro nosso assistido.
- E aí a pessoa vai responder com o racional dela e depois a gente vai conseguir identificar o campo espiritual dela, né?
- E identificar o quanto é verdade, o quanto bate o que ela fala com o que ela tem no campo energético, no campo espiritual dela.
- Então gente, é isso que queria pedir para vocês se apropriarem disso, refletirem, lê aqui e tenta relembrar o que eu falei, tenta relembrar exemplos, porque com exemplos, né, o poder dessa história, da parábola, da pequena história que me traz a reflexão, eu consigo ajudar o meu cliente a a na hora me lembrar e aí fazer ah isso aqui mais ou menos a mesma…


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- Resumo Automático: 02 Código Humanosense Transcrição / Texto Completo Olá, boa noite.
- Não aceitou, tem uma dificuldade de lidar com isso, o que é muito normal, mas não é que você não entendeu, você não consegue lidar com isso porque é uma dor sua.
- Então, aqui, ó, mandala, como eu falei, perdão, vou abrir de novo, como eu falei, ela tem as três mandalas, a mandala do amor, a mandala da dor e aqui fora a mandala da cura.
- Tudo que a gente faz e que a gente não sustenta é porque o nosso feminino está ferido e ele prefere abortar.
- Então, feminino ferido, ele é ofendido, julgador, magoado.
- Mas onde o vai trabalhar nesses abortos, nessas limpezas, aonde esse feminino foi ferido ou ficou ferido porque ele ficou melindroso porque ele não cresceu, ele ficou criança fazendo manha, fazendo birra.
- É para isso vir com o mundo que aí eu estutulei, pensei, aí no dia que eu tinha que começar aquilo, nossa, era uma emoção, ao mesmo tempo era um medo e era um peso, já tava pesado, aquilo tava grande, me angustiava, eu precisava logo trazer pro mundo.
- Então, quando você se profund, nossa, nenhum relacionamento meu dá certo, o quanto você fica só na beira no raso, quanto você se aprofunda nesse universo maior que é cheio de angústias, medos, incertezas, será que vai dar certo?
- Ela não tem autorização para viver a vida dela porque ela precisa. fazer, porque se ela fizer alguma coisa diferente, porque a mãe gosta, a mãe não vai amar.
- A gente não aprende a ouvir a nossa intuição, o nosso sentir e não víceras, desejos, carnais, medos, não ser movido pelo medo ou movido pelos desejos, é ser movido pela vontade divina. que habitam o meu coração e que é mais e que não precisa tudo fazer sentido, mas precisa fazer sentir.
- Então gente, é isso que queria pedir para vocês se apropriarem disso, refletirem, lê aqui e tenta relembrar o que eu falei, tenta relembrar exemplos, porque com exemplos, né, o poder dessa história, da parábola, da pequena história que me traz a reflexão, eu consigo ajudar o meu cliente a a na hora me lembrar e aí fazer ah isso aqui mais ou menos a mesma…
- E aí você consegue ter um pensamento mais estruturado do campo energético dele, mas tem didática para falar de uma maneira que ele compreenda que seria uma base um pouco mais terapêutica, mas não uma terapia convencional, porque não é só pai é isso, a mãe é isso, a mãe é isso, pai é isso e a culpa é de quem, quem é culpado que faz só a gente ir de um lado…


## Citações e Formulações de Alta Densidade

- “Então, quando a gente fala de energia masculina, e eu não tô falando de homem e mulher, é natural que a nossa cabeça vá pensar isso para encontrar uma representações simbólicas disso e conseguir então entrar no mundo da energia.”
- “Então eu não dou continuidade porque eu tenho dificuldade em sustentar e a minha energia feminina precisa ser trabalhada, tá?”
- “Então, essa é a primeira, é o primeiro ponto que a gente precisa sempre identificar.”
- “É para isso vir com o mundo que aí eu estutulei, pensei, aí no dia que eu tinha que começar aquilo, nossa, era uma emoção, ao mesmo tempo era um medo e era um peso, já tava pesado, aquilo tava grande, me angustiava, eu precisava logo trazer pro mundo.”
- “Então, quando a gente fala em frequência e vibração, a gente precisa entender que tudo está dentro da energia do feminino e masculino.”
- “Então quando a gente fala de pais, a primeira referência simbólica da energia do dar e receber, agir e acolher e e da simbologia da fecundação e da gestação, igual a criação, são os pais.”
- “Eu estou dizendo, você precisa curar isso dentro de você de algum jeito, porque senão o dinheiro não vai ficar, o trabalho não vai ficar, o relacionamento não vai ficar.”
- “Ela não tem autorização para viver a vida dela porque ela precisa. fazer, porque se ela fizer alguma coisa diferente, porque a mãe gosta, a mãe não vai amar.”
- “Então ela a gente precisa do feminino, que é o sonho, que é o projeto de vida, que é aquilo que movia você, que vai te dar motivação, é mudar o mundo, é encontrar um jeito melhor, é cuidar dos filhos, como eu sempre sonhei, é ter aquela famílhei.”
- “Então aqui quando a gente fala da fusão da influência e da intuição, e eu não falei de eu não falei de de espiritualidade aqui, eu não falei de religiosidade, eu não falei de espírito, eu tô falando de outra coisa, tem gente que nem acredita em nada e consegue trabalhar muito bem a sua influência…”
- “Então, eu tô dando base terapêutica e aqui eu tô falando só dessa mandala do amor e e você começa a entender coisas quando a pessoa vai fazer, você já vai sabendo onde estão os problemas dela.”
- “E aí você consegue ter um pensamento mais estruturado do campo energético dele, mas tem didática para falar de uma maneira que ele compreenda que seria uma base um pouco mais terapêutica, mas não uma terapia convencional, porque não é só pai é isso, a mãe é isso, a mãe é isso, pai é isso e a culpa…”

## Conexões com a Wiki

- [[Conceito do Metodo HumanoSense]]
- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio da Liberdade Consciente]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Conceito do Divorcio Energetico]]

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## FAQs para NotebookLM (Fase 2)

### Bloco 1: A Mandala do Amor e as Polaridades Masculina e Feminina
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
1. Como Andresa Molina descreve a Mandala do Amor e quais são os seus cinco pilares energéticos de diagnóstico?
2. Qual é o papel biológico e somático da energia masculina (a semeadura, a coragem e o impulso) no Código HumanoSense?
3. De que forma a energia feminina atua no processo de gestação e nutrição de metas, e por que a paciência estratégica é indispensável para a sustentação?
4. Como a união e a fusão criacional entre a energia de expansão (masculino) e de contenção (feminino) gera o magnetismo que traz projetos e realizações à vida?
5. De que maneira a ausência da força de sustentação feminina resulta na superficialidade das relações e na incapacidade de aprofundamento do assistido?

### Bloco 2: O Aborto de Projetos e a Dinâmica de Vibração e Frequência
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
6. O que é o "aborto de projetos" sob a perspectiva do Código HumanoSense, e de que forma o "feminino ferido/melindroso" contribui para esse padrão de desistência?
7. Qual é a diferença técnica e vibracional entre os estados de "Vibração" (regida pelo masculino) e "Frequência" (regida pelo feminino)?
8. Por que a motivação gerada em eventos pontuais ("vibração") não é suficiente para materializar resultados se a pessoa não sustentar a "frequência"?
9. Como a autocrítica ácida e o julgamento interno após o impulso de ação atuam como mecanismos do feminino ferido para abortar desejos?

### Bloco 3: As Representações Ancestrais do Pai e da Mãe na Prosperidade
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
10. Como a aceitação da força arquetípica do pai se conecta com a capacidade de atração e com a postura de segurança e enfrentamento no mundo?
11. De que maneira a representação materna governa o espaço interno de crescimento e a capacidade de retenção de relacionamentos e dinheiro?
12. O que ocorre no sistema financeiro e afetivo do assistido quando há rejeição simultânea à força do pai e da mãe?
13. Como o terapeuta pode realizar o Diagnóstico Somático de Dinheiro e Relacionamentos com base nas queixas de atração (pai) ou retenção (mãe) apresentadas pelo paciente?

### Bloco 4: Os Arquétipos do Protagonismo (Guerreiro, Donzela e Soberanos)
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
14. Qual é a função do "Arquétipo do Guerreiro/Guerreira" no enfrentamento de limites e na defesa de territórios pessoais?
15. De que forma o Guerreiro adoece, entrando em "guerras sem fim" e reações cegas quando se desconecta de uma causa maior?
16. Como o "Arquétipo da Donzela/Príncipe" atua como a faceta visionária do sonho, e quais são os perigos de seu desequilíbrio na fuga da realidade e procrastinação?
17. O que representa o estado de "Rei ou Rainha" no protagonismo, e de que maneira ele funde a espada do Guerreiro com a doçura e a diplomacia da Donzela?

### Bloco 5: A Mediunidade Livre e a Inteligência Espiritual
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
18. Como Andresa Molina define "Mediunidade" e "Inteligência Espiritual" fora das amarras da religiosidade convencional?
19. Qual é a diferença operacional entre "Influência" (polaridade masculina externa) e "Intuição" (polaridade feminina interna) na dinâmica da mediunidade livre?
20. Como o Princípio da Inteligência Espiritual orienta o indivíduo a decidir com base no que "faz sentir" no coração (intuição) em vez do que "faz sentido" lógico (lucro ou opinião alheia)?


## Referência

ANDRESA MOLINA. *Aula 02 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.
