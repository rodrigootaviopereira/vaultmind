---
type: conceito
author: Andresa Molina
tags: [raiva, culpa, autopunicao, 3a-coordenada, somatizacao, infancia, condicionamento]
sources: ["[[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito da Raiva que Virou Culpa (3ª Coordenada)

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: A Raiva que Virou Culpa (3ª Coordenada) define o processo psicossomático de repressão e direcionamento interno da raiva. Ocorre quando o indivíduo suprime sua raiva natural por associá-la imediatamente ao risco iminente de abandono, rejeição ou perda, resultando em extrema culpa subconsciente.
- **Formulação de apoio (Condicionamento Infantil)**: Na primeira infância, a criança não possui capacidade de articulação verbal para comunicar seus desconfortos e incômodos físicos (fome, medo, frio, roupa apertando, nascimento de dente). O único recurso biológico que possui para ser atendida é o choro ou gritos de indignação. Se os cuidadores rejeitam, punem ou ameaçam a criança ("mamãe fica triste e vai embora", "vou te dar para o homem do saco"), a psique infantil, que depende absolutamente dos adultos para sobreviver, estabelece uma trilha neural de sobrevivência: *expressar raiva gera o risco de perder quem me alimenta e me ama (morte)*. Na vida adulta, sempre que a raiva emerge ou o limite é ultrapassado, esse alarme dispara gerando culpa imediata.

## Dinâmica de Autopunição

Como consequência da culpa instalada, o sistema inconsciente executa a diretriz universal de que **todo culpado merece castigo**. Esta dinâmica se manifesta de três formas principais:
1. **Perdas Financeiras**: A pessoa atrai de forma inconsciente boicotes em promoções, perda de empregos e endividamentos (boletos e cobradores) para expiar a culpa de sentir raiva.
2. **Relacionamentos Tóxicos ou Mornos**: Aceitação de parceiros abusivos ou relações vazias devido à crença de que não merece ser feliz ou que expressar insatisfação afastará o outro.
3. **Somatização e Inflamação**: A energia da raiva represada inflama as células físicas, resultando em gastrites, úlceras, dores crônicas na coluna e no pescoço, e dificuldades de emagrecimento.

## Contexto de Uso

- Eixo diagnóstico no HumanoSense usado para identificar a causa de bloqueios financeiros e dores na coluna/estômago. Permite ao terapeuta associar a repressão da raiva ao ciclo de autopunição e desvalor próprio do assistido.

## Relação com Princípios

- [[Principio da Raiva como Potencial de Autonomia]]
- [[Conceito do Ciclo de Autopunicao]]
- [[Principio do Amor Condicionado e Autoabandono]]

## Exemplos do Material

- *"Se eu gritar e ela não vier, eu morro de fome. Eu fico sozinho. Eu fico com frio, eu fico com medo, eu fico com incômodo. Logo, eu não posso incomodar essa pessoa porque senão eu eu posso sofrer. E aí você criou uma trilha neural vindo de uma marca, de um lugar que você entendeu que sentir raiva é ruim."*

## Aplicação Prática

1. **Rastrear o Castigo**: Identificar se o assistido se sabota financeiramente sempre que começa a prosperar, buscando a culpa latente por trás dessa autopunição.
2. **Liberar a Expressão**: Estimular a sangria emocional, permitindo que o assistido admita sentir raiva de eventos passados e de pais/cuidadores sem que isso seja julgado como falta de amor ou desonra.
3. **Mapeamento da Coordenada**: Localizar fisicamente no corpo físico onde a raiva e a culpa estão inflamadas (ombros, estômago, cabeça) para aplicar a reprogramação biológica.

## Referência

ANDRESA MOLINA. *Conceito da Raiva que Virou Culpa (3ª Coordenada)*. Aula 03 - Coordenada 3 (A Raiva que Virou Culpa). Fontes: [[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]].
