---
type: principio
author: Andresa Molina
tags: [terapeuta, preparacao, disciplina, combate-ao-ego, estudo]
sources: ["[[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio da Preparação do Terapeuta (O combate ao ego, à preguiça e à mediocridade no atendimento)

- **Definição**: A exigência moral e técnica de que o terapeuta domine brutalmente os comandos (decorando-os) antes de atender, rompendo com a "preguiça" e o "ego" que transformam profissionais ansiosos e destreinados em massa de manobra de forças umbralinas.
- **Justificativa**: A falta de preparo prático (como ter que ler o papel na hora) divide o foco mental do terapeuta ("o meu foco de atenção, ele tá em dois planos... eu tô mais dividida"), reduzindo drasticamente a potência magnética da invocação espiritual. A autora desconstrói a desculpa de incapacidade intelectual usando a analogia da música "Faroeste Caboclo" (de 12 minutos) para demonstrar que a mente humana decora facilmente longas estruturas se houver interesse e disciplina. Atender sem dominar o protocolo expõe o assistido e desrespeita a sua equipe espiritual de amparo.
- **Evidências**: "Não seja medíocre, mediano, né? Estude e não seja irresponsável com equipe espiritual do outro que trouxe ele até ali... Se você falar para mim que você não consegue, eu acho melhor você fazer outra coisa da sua vida. Porque se você fala para mim, você não consegue decorar isso, eu acho que pode ser que isso não seja para você, porque você tá com preguiça... Percebe que são pessoas que são ansiosas, manipuláveis, facilmente manipuláveis, porque o ego vai lá em cima. É, eu virei ess aqui, eu sei fazer. Massa de manobra fácil para obsessor."
- **Implicações**: O terapeuta é proibido de atender "de qualquer jeito" ou de graça puramente para testar, sob o risco de expor o campo vibracional a obsessores devido à fragilidade de sua segurança técnica e foco disperso.
- **Conexões**: [[Principio do Respeito a Tecnica e a Equipe Espiritual]], [[Conceito de Invasao Energetica ou Obsessao]]
- **Notas Pessoais**: Decorar os comandos liberta a mente do terapeuta para concentrar-se na leitura sutil e somática do assistido.

## Perguntas Frequentes / Didática de Atendimento

## Perguntas Frequentes / Didática de Atendimento

### 2. De que maneira a falta de preparo e estudo prévio do terapeuta divide a sua atenção somática e compromete a potência da egrégora de cura?
**Resposta**: A falta de preparo obriga o terapeuta a ler os comandos no papel durante a sessão, o que fratura o seu campo magnético. A nível somático e vibracional, a autora explica: "Quando eu tô lendo, eu me divido. O meu foco de atenção, ele tá em dois planos... tá no plano material, no plano mental" e tenta estar no plano espiritual simultaneamente. 

Essa divisão drena a energia da invocação. O terapeuta não consegue se "entregar o processo" porque a mente está preocupada com o texto. Em contraste, quando o profissional estuda e decora os comandos, ele consegue "trazer tudo para um foco de energia", o que permite "deixar todo o meu campo mais permeável pro trabalho energético espiritual", garantindo a potência total da egrégora.

### 3. O que Andresa Molina afirma sobre o terapeuta mediano que atende "de qualquer jeito" ou "de graça" para treinar, e como essa atitude impacta a equipe espiritual do assistido?
**Resposta**: A autora é severa com o terapeuta que age com desleixo, pedindo: "Não seja medíocre, mediano, né?". Ela afirma que fazer as coisas "de qualquer jeito é uma lambança. E uma lambança não vai ter equipe espiritual que vai chancelar". Atender de graça apenas para treinar é visto como um ato irresponsável que expõe o campo do paciente ao perigo umbralino: "Vai entregando sua cabeça na mão de qualquer um de graça para você ver".

Essa atitude impacta brutalmente o plano astral porque o encontro terapêutico foi orquestrado pelos guias do paciente. Agir com preguiça significa ser "irresponsável com equipe espiritual do outro que trouxe ele até ali". Se o terapeuta não tiver respeito pelo sagrado, "a equipe espiritual do outro" nunca mais "vai trazer ele até você".

### 4. Qual é a analogia usada por Andresa Molina com a música "Faroeste Caboclo" para rebater terapeutas que dizem ter dificuldade em decorar os comandos da mesa?
**Resposta**: Para rebater a desculpa de que os comandos são difíceis, Andresa utiliza uma "maneira divertida de quebrar o padrão" mental e somático dos alunos: ela cita a música "Faroeste Caboclo", do Legião Urbana. 

Ela confronta o ego e a desculpa do terapeuta lembrando que a música "tem 12 minutos. A música não repete uma frase, não tem refrão", e mesmo assim quase todos sabem cantá-la porque treinaram muito ("Primeiro a gente ficou cantando no rádio para depois cantar lá com os amigos no violão"). A lógica é implacável: os comandos da mesa são curtos, repetitivos e "Tem refrão... que a boca não tem". Portanto, a autora decreta que "se você fala para mim, você não consegue decorar isso... você tá com preguiça. É preguiça que chama", advertindo que quem não se esforça para decorar deveria "fazer outra coisa da sua vida".

## Referencia

ANDRESA MOLINA. *Princípio da Preparação do Terapeuta*. Aula 06 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]].
