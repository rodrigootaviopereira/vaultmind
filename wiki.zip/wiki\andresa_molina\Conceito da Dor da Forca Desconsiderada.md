---
type: concept
author: Andresa Molina
tags: [forca-desconsiderada, protecao-toxica, autoconfianca, exclusao-sistemica]
sources: ["[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"]
---

# A Dor da Força Desconsiderada (A destruição pela superproteção)

- **Definição**: A ferida oculta, instalada na infância, não pelo abandono direto (violência), mas pela negligência do tamanho espiritual da criança. Ocorre quando os pais excluem o filho dos problemas familiares por excesso de proteção, castrando sua autoconfiança sistêmica.
- **Justificativa**: Muitos pais acreditam que poupar a criança de ver a dor (como o luto, lágrimas ou problemas financeiros) é um ato de amor. A nível somático, a criança não se sente amada por isso. Ela é um ser espiritual com potência. Quando a mãe diz "vai para o quarto que a mãe vai chorar sozinha", a biologia da criança absorve a mensagem de que a sua presença, o seu amor e o seu tamanho são inúteis para amparar quem ela ama. A autora elucida que essa desconsideração sistêmica destrói a confiança do adulto, que passa a duvidar da própria capacidade de agir no mundo: "Por que que minha mãe não confiou em mim? ...Eu não sirvo para nada que aquilo que eu tenho é tão pequeno que ela nem precisa."
- **Evidências**: "Se um pai ou uma mãe não confia no filho... ele nunca vai se sentir confiante... A criança não é um espiritinho, ela é capaz de ficar do lado da mãe do pai numa situação difícil. Essa esse lugar de de desconsiderar a força da criança tira dela a confiança... Ela sente fraqueza não sente fraqueza, ela fica com raiva. Por quê? Por que você não enxerga o meu tamanho espiritualmente? O quão grande eu sou? E aí isso mina a confiança da própria criança... a nossa sociedade tá baseada e pautada nisso cada vez mais... Passaram não produzir nada para proteger."
- **Implicações**: O terapeuta deve acolher a raiva da "criança ferida" que foi desconsiderada na sua força e ajudá-la a retomar o próprio tamanho existencial.
- **Conexões**: [[Conceito da Fantasia de Salvamento Infantil]], [[Conceito da Representacao Materna]]
- **Notas Pessoais**: Superproteger é comunicar ao outro que ele é incapaz de suportar a realidade.

## Perguntas Frequentes / Didática de Atendimento

### 12. De que forma a superproteção gera a dor da "força desconsiderada" e como isso reflete na autoconfiança do adulto?
**Resposta**: A superproteção familiar anula o indivíduo quando os pais o poupam de responsabilidades (ex: **"não mexe aí que você não faz, deixa que eu faço"**) ou o blindam dos problemas da casa (**"por proteção não contam, protegem e não deixam ele fazer parte"**).

Somaticamente, o corpo e a psique da criança registram a mensagem de que são incapazes. A autora decreta que **"desconsiderar a força da criança tira dela a confiança"**. Na vida prática do adulto, essa ferida invisível reflete-se na total paralisia diante de desafios (como assumir uma nova profissão), porque a memória celular continua duvidando da própria capacidade vital de suportar a realidade: **"se meu pai, minha mãe não consegue ver e me protege... eu começo a questionar exatamente se eu tenho mesmo essa força e aí a minha confiança mina"**.

### 13. Como o corpo da criança reage à percepção de que seu tamanho espiritual foi desconsiderado e poupado?
**Resposta**: Quando a criança é excluída do amparo emocional aos pais (por exemplo, a mãe que diz **"não vai pro seu quarto e aí eu choro sozinha"**), a criança não se sente protegida, ela se sente inútil. Ela conclui somaticamente: **"Eu não sirvo para nada que aquilo que eu tenho é tão pequeno que ela nem precisa"**.

Em vez de gratidão pela proteção, a reação biológica e energética da criança é a fúria. A autora explica que o corpo repele essa desconsideração: **"Ela sente ela ela ela sente raiva. Ela sente fraqueza não sente fraqueza, ela fica com raiva. Por quê? Porque porque você não enxerga o meu tamanho espiritualmente? O quão grande eu sou?"**. Ao não permitir que a criança se posicione na dor familiar, os pais invalidam a força daquele ser, que no fundo queria ajudar: **"Eu era forte, podia ter ajudado, podia ter falado, podia contar comigo"**.


## Referencia

ANDRESA MOLINA. *A Dor da Força Desconsiderada*. Aula 09 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]].
