---
type: conceito
author: Andresa Molina
tags: [liberdade, autorizacao, desconstrucao-parental, identidade, merecimento]
sources: ["[[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]]"]
---

# Conceito de Autorizacao (Eixo da Liberdade)

- **Definição**: O ato íntimo e soberano de dizer sim para si mesmo, assumindo a autoria das próprias ações e desvinculando-se do pânico inconsciente de desaprovação familiar ou social.
- **Justificativa**: Muitas pessoas possuem [[Conceito de Habilidade (Eixo da Liberdade)|habilidade]], mas sabotam-se porque não têm autorização interna para prosperar ou ser felizes. Para liberar essa permissão, é necessário desconstruir as projeções infantis com [[Principio da Atracao e Retencao|pai e mãe]].
- **Evidências**: "O próximo, autorização. Você precisa se autorizar. [...] é o ato mais íntimo de dizer sim para si mesma. É parar de pedir permissão pro outro, ao passado ou ao medo e decidir ocupar o seu próprio nome e o seu próprio lugar. [...] crescer, aparecer, realizar e prosperar não é egoísmo, é honra ao que te habita. [...] Para isso, você vai precisar desconstruir pai e mãe."
- **Implicações**: O terapeuta deve confrontar o assistido sobre os ganhos de se manter pequeno (como se moldar para ser aceito ou assumir o papel de [[Conceito do Eu Sou Lixeiro|lixeiro]] familiar).
- **Conexões**: [[Conceito do Eixo da Liberdade]], [[Principio da Atracao e Retencao]]
- **Notas Pessoais**: A falta de autorização gera um molde artificial para tentar comprar afeto.

## Referencia

ANDRESA MOLINA. *Conceito de Autorizacao (Eixo da Liberdade)*. Aula 04 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]].
