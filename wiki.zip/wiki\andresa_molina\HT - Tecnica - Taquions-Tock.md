---
type: tecnica
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, tecnica, taquions_tock, quinta_dimensao, essencia]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_05_passo_3_taquions_tock_desconstrucao_da_criacao_dos_campos_mental_e_emocional.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_104_taquions_tock.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_118_a_tecnica_de_taquions_tock.md]]"]
---

# HT - Tecnica - Taquions-Tock

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_05_passo_3_taquions_tock_desconstrucao_da_criacao_dos_campos_mental_e_emocional.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_104_taquions_tock.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_118_a_tecnica_de_taquions_tock.md]]

## Objetivo

- [INFERÊNCIA] HT - Tecnica - Taquions-Tock organiza uma prática do sistema de Andresa Molina para transformar leitura da dor em condução, liberação, harmonização ou reorganização do campo.

## Pré-requisitos

- Presença do terapeuta.
- Respeito ao passo a passo, à ficha, ao campo e à autorização do assistido.
- Clareza sobre a questão central antes de aprofundar a técnica.

## Passo a Passo

1. Identificar a queixa, emoção dominante, afeto/desafeto ou ponto de entrada.
2. Relacionar a informação com ficha, corpo, mandala, personagem ou campo energético.
3. Aplicar a condução sem atropelar o assistido, mantendo escuta e conexão.
4. Observar sinais de liberação, resistência, repetição ou necessidade de aprofundamento.
5. Fechar com integração, retorno à consciência ou orientação prática quando aplicável.

## Duração/Frequência

- [INFERÊNCIA] Deve durar o suficiente para esgotar a camada acessada sem forçar uma profundidade que o assistido não sustenta naquele momento.

## Indicadores de Sucesso

- Maior clareza sobre a raiz da dor.
- Redução de confusão, defesa ou carga emocional.
- Sensação de fechamento, harmonização ou novo entendimento corporal/energético.

## Variações

- Pode ser adaptada conforme a mandala, ficha, câmara, mesa, baralho, humanometria ou técnica específica envolvida.

## Conceitos Envolvidos

- [[Conceito do Metodo HumanoSense]]

## Evidências do Material

- [INFERÊNCIA] Evidência direta não localizada na varredura automática; consultar as fontes indicadas na rastreabilidade.

## Notas Pessoais

- Reservado para registros de aplicação do usuário.

## Referencia

ANDRESA MOLINA. *HT - Tecnica - Taquions-Tock*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_05_passo_3_taquions_tock_desconstrucao_da_criacao_dos_campos_mental_e_emocional.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_104_taquions_tock.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_118_a_tecnica_de_taquions_tock.md]]. Acesso em: 17 jun. 2026.
