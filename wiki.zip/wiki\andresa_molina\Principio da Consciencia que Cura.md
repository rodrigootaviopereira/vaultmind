---
type: principio
author: Andresa Molina
tags: [cura, transmutação, energia, consciência, 6a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]]"]
---

# Princípio da Consciência que Cura

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]]

## Definição

- **Definição**: O Princípio da Consciência que Cura estabelece que a identificação lúcida e a decodificação exata de uma frequência energética ou emoção captada de terceiros/ambientes desarmam instantaneamente o sintoma somático correspondente no corpo do sensitivo, restaurando o seu equilíbrio vibracional e físico.
- **Justificativa**: A energia densa (raiva, medo, nojo, angústia alheia) só consegue gerar desequilíbrio somatizado (enjoo, dor de cabeça, cansaço repentino) enquanto o sensitivo ignorar a sua origem real e cair na ilusão da "Falsa Posse da Dor". Ao tentar encontrar desculpas racionais dentro de si para explicar um sintoma que vem de fora, a mente lógica bloqueia a cura. Quando o indivíduo analisa racionalmente o evento energético, decodifica a frequência captada e a integra de forma consciente, o sistema nervoso desliga o alarme, transmutando a carga acumulada de imediato.

## Evidências

- *"Quando eu consegui decodificar eu consegui integrar. [...] E aí logo, consciência que cura. Quando você ganha consciência disso, você passa a transmutar esta energia. Quando você passa a transmutar essa energia, ela começa a criar um... ela começa a esvaziar esse esse peso e volta o equilíbrio do corpo."*
- *"A gente estava muito bem. Do nada, entre aspas, a gente começou a sentir. E a partir desse sentido, eu falei: 'O que que nós fizemos que mudou essa frequência?' Eu fui analisar e aí quando eu analisei, eu consegui decodificar."*

## Implicações

- **Fim da ilusão da hipocondria e histeria**: O assistido compreende que boa parte de seus distúrbios agudos são captações invisíveis, e não falhas clínicas internas.
- **Autonomia de Higiene Energética**: O terapeuta treina o assistido a ser um agente ativo de transmutação, e não um receptor passivo e doente das cargas ambientais.

## Conexões

- [[Conceito de Clara Evidencia]]
- [[Tecnica de Alinhamento do Chamado]]
- [[Conceito do Bloqueio Sensorial pelo Batismo]]

## Notas Pessoais

- Reservado para observações do usuário.

## Referência

ANDRESA MOLINA. *Princípio da Consciência que Cura*. Aula 06 - Coordenada 6 (O Chamado Ignorado). Fontes: [[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. De que maneira a equipe espiritual de amparo utiliza a sintonia energética para atrair o assistido ao ambiente terapêutico e como o terapeuta pode dar informação lógica ao racional do paciente para que ele permita sua própria cura?
**Resposta**: Embora o termo literal "egrégora espiritual da equipe" não conste no documento, Andresa explica que a equipe espiritual de amparo atrai a pessoa por vibração corporal e somatização: *"Tudo é por sintonia"* e *"É com a sua espiritualidade que te trouxe até aqui, que fez com que você estivesse aqui agora vendo isso e sentindo"*. A atração ocorre porque a pessoa sente *"algo vibrou, algo movimentou"* dentro de si.

Contudo, uma vez que a pessoa é atraída pelo "sentir", ela frequentemente trava o processo de cura devido ao cérebro lógico, porque a racionalidade duvida do invisível e *"fica parado em algum ponto dentro de você [...] não consegue expandir porque não entende"*. 

O terapeuta entra justamente para desarmar essa trava cognitiva. Andresa explica que seu papel é fornecer explicações estruturadas para o cérebro: *"Você só precisa entender para que o seu racional te ajude, para que ele permita. E eu quero te ajudar com isso, a dar informação racional para que você consiga compreender e não tenha mais medo do tamanho do seu amor, do tamanho do seu dom"*. Ao iluminar o *"quarto escuro"* com o conhecimento lógico, o medo racional cessa, permitindo que o corpo e o espírito do paciente aceitem a cura.

