---
type: tecnica
author: Andresa Molina
tags: [tecnica, desidentificacao, meditaÃ§Ã£o, vazio, 4a-coordenada, essencia]
sources: ["[[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]]"]
---

# Prática de Remoção de Papéis Sociais

## Objetivo

- Provocar um curto-circuito na mente lógica e consciente do assistido, expondo a vacuidade de suas máscaras cotidianas e trazendo à tona a âncora do vazio e do silêncio (a coordenada principal do autoabandono).

## Pré-requisitos

- Disposição para encarar o silêncio sem preenchê-lo com explicações ou racionalizações lógicas.

## Passo a Passo

1. **Limpeza do Ambiente Mental**:
   - Fechar os olhos e respirar profundamente três vezes (inspirando pelo nariz e exalando pela boca de forma audível).
   - Visualizar e empurrar para fora do campo pessoal todas as pessoas, problemas, pendências e checklists que exigem atenção (filhos, parceiro, chefe, etc.).
2. **Subtração Identitária (Remover Máscaras)**:
   - Mentalmente, dispa-se de forma intencional de cada papel que você exerce no mundo prático.
   - Afaste o papel de "mãe", depois o de "esposa/parceira", "filha", "amiga que resolve tudo", "profissional", etc.
3. **Sustentação da Pergunta**:
   - Faça a si mesmo a seguinte indagação de olhos fechados: **"Quem sobra?"**.
   - Fique em silêncio absoluto e observe o que preenche o espaço mental imediato.
4. **Acolhimento da Coordenada**:
   - A resposta imediata costuma ser um vazio absoluto ou um silêncio total. Não classifique esse vazio como ruim ou assustador; acolha-o. Ele é a prova somática de que a identidade essencial foi enterrada e precisa ser resgatada.

## Duração/Frequência

- Exercício rápido (5 a 10 minutos) executado no início da intervenção na 4ª Coordenada.

## Indicadores de Sucesso

- Percepção de silêncio interno e interrupção do fluxo de pensamentos de cobrança.
- Contato com a sensação de vazio existencial, permitindo que a essência seja ouvida.

## Conceitos Envolvidos

- [[Conceito da Mulher antes de ser de Todos]]
- [[Conceito do Falso Eu Sou]]
- [[Conceito do Abandono de Si]]

## Referência

ANDRESA MOLINA. *Prática de Remoção de Papéis Sociais*. Aula 04 - Coordenada 4 (A Mulher Antes de Ser de Todos). Fontes: [[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]].
