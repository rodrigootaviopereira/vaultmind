---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_22_atividades_preponderantes_nos_hemisferios_cerebrais.md]]"]
---

# Cap 022 - Atividades Preponderantes Nos Hemisferios Cerebrais

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_22_atividades_preponderantes_nos_hemisferios_cerebrais.md]]

## Referencia

ANDRESA MOLINA. *Cap 022 - Atividades Preponderantes Nos Hemisferios Cerebrais*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_22_atividades_preponderantes_nos_hemisferios_cerebrais.md]]. Acesso em: 17 jun. 2026.
