---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_28_a_energia_de_cura.md]]"]
---

# Cap 028 - A Energia De Cura

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_28_a_energia_de_cura.md]]

## Referencia

ANDRESA MOLINA. *Cap 028 - A Energia De Cura*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_28_a_energia_de_cura.md]]. Acesso em: 17 jun. 2026.
