---
type: conceito
author: Andresa Molina
tags: [personalidade, explorador, ganho-secundario, vitimizacao]
sources: ["[[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]"]
---

# Conceito do Explorador da Dor

- **Definição**: A personalidade defensiva que se alimenta da própria dor e utiliza o sofrimento (como doença ou pobreza) como forma de manipulação para manter vínculos, atrair a atenção alheia e evitar ser excluída ou abandonada.
- **Justificativa**: Enquanto o assistido obtiver um ganho secundário com o seu sofrimento (receber atenção nociva, carinho ou favores), ele boicotará as soluções propostas pelo terapeuta, pois teme perder o vínculo caso melhore.
- **Evidências**: "O explorador, ele se alimenta da própria dor e usa o sofrimento como forma de manter vínculo ou de atrair a atenção. [...] É uma pessoa que explora a própria dor para conseguir alguma coisa. [...] Ela se utiliza daquela dor, explora aquela dor para garantir uma dessas ou as três [não exclusão, amor, não abandono]. [...] E de verdade este processo de explorar esta dor é uma pessoa que esgota a energia, ela esgota, ela coloca para baixo."
- **Implicações**: O terapeuta nunca deve ceder à exploração ou manipulação do assistido (como dar sessões gratuitas por pena), pois isso alimenta a dinâmica estagnada.
- **Conexões**: [[Conceito de Personalidade da Dor]], [[Principio da Mandala da Dor]]
- **Notas Pessoais**: O explorador puxa a energia do ambiente e do terapeuta para baixo.

## Referencia

ANDRESA MOLINA. *Conceito do Explorador da Dor*. Aula 03 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]].
