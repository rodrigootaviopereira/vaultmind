---
type: conceito
author: Hélio Couto
tags: [arquétipos, jung, consciencia, neurotransmissores, biologia, neuroassociacao]
sources: ["[[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_04_parte_i.txt]]", "[[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_08_parte_iii.txt]]"]
---

# Conceito de Arquétipos

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_04_parte_i.txt]]
  - [[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_08_parte_iii.txt]]

## Referencia

HÉLIO COUTO. *Conceito de Arquétipos*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_04_parte_i.txt]], [[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_08_parte_iii.txt]]. Acesso em: 17 jun. 2026.
