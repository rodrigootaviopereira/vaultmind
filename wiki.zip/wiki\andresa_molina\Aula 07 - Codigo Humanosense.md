---
type: aula
author: Andresa Molina
tags: [codigo-humanosense, humanosense, aula-07, reingestao-2026-06-19]
sources:
  - "[[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]"
---
# Aula 07 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `07   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 17.500 palavras; 603 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- Vamos lá, vamos tirar algumas dúvidas, algumas questões que as pessoas estão perguntando, extremamente ansiosas e eu falando: "Calma, gente, a gente vai chegar lá, vocês, a gente ainda vai chegar nessa fase, então tenham calma que a gente tá chegando no finalmente, tá bom?
- Então, a primeira parte do passo a passo é a parte de você se preparar antes do seu cliente, do seu assistido chegar, certo?
- E explica, é uma tecnologia espiritual canalizada que atua em três níveis, no racional, no emocional e no espiritual. e tem como objetivo identificar a raiz de um padrão, limpar o campo, abrir e abrir caminho para uma nova realidade, tá?
- A pastinha lá na dele, tudo que ele fez com você tá dentro da pastinha dele, é seu cliente, se você ti então, mas para facilitar o processo agora, você pode colocar aqui no comecinho o número da pergunta se é uma, dois ou a três para você ter que escrever tudo ali, na vez vai demorar muito e perde um pouco do fluxo.
- Agora eu vou continuo fazendo perguntas, eu quero que você me responda zer na mandala da dor você não precisa seguir a sequência, você vai escolher uma de cada, tá?
- Então, lembrando sempre disso, o cliente chega em dor porque ele está iludido.
- Então essas são as questões que a gente precisa ajudar ele a sair daquele lugar, a perceber e se se acalmando e ter consciência de tudo isso.
- Ó, sinta a dor chegando sem medo, sem fugir, porque só o que é sentido por inteiro pode enem ser curado.
- Então vocês estão desdobrados, o cliente está desdobrado num campo de proteção onde tem uma plasticidade completamente, onde tem códigos completamente diferentes.
- Eh, no momento das perguntas, nas mandalas, eh, a cada investigação de cada pergunta, né, eh, é melhor a gente discutir com ele, com o assistido, eh, o que a gente tá visualizando ali ao fim de cada pergunta ou ao fim de cada pétala?
- Não é para terapeuta ai vou fazer uma não é trabalho, não é trabalho espiritual, não é trabalho de verdade dentro de uma linha de resgate, de uma linha de de cura de verdade, é só o gostosinho." Então, para vocês entenderem isso sim, a gente tá com a equipe, a equipe do código inocência é extremamente potente.
- Então, eh, minha dúvida é a seguinte, como eu também sou humanoterapeuta, né, eu também trabalho com amiza quântica, aí aqui que nos inícios da passo a passo do trabalho, a gente coloca o assistido ou dentro código, né, do situação unidade, coloca ele na mesa.

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-76
- Vamos lá, vamos tirar algumas dúvidas, algumas questões que as pessoas estão perguntando, extremamente ansiosas e eu falando: "Calma, gente, a gente vai chegar lá, vocês, a gente ainda vai chegar nessa fase, então tenham calma que a gente tá chegando no finalmente, tá bom?
- Então, a primeira parte do passo a passo é a parte de você se preparar antes do seu cliente, do seu assistido chegar, certo?
- E explica, é uma tecnologia espiritual canalizada que atua em três níveis, no racional, no emocional e no espiritual. e tem como objetivo identificar a raiz de um padrão, limpar o campo, abrir e abrir caminho para uma nova realidade, tá?

### Bloco 2 - frases 77-152
- Tem que falar, tem em voz alta sim, porque ele precisa autorizar e colocar magneticamente essa autorização no mundo.
- E aí você vai, pede pro assistido se conectar com o que ele precisa resolver, ou seja, a dor ou a questão que ele trouxe.
- E aí, antes disso, desculpa, antes disso que você colocou aqui, você vai fazer as perguntas da mandala do amor, ok?

### Bloco 3 - frases 153-228
- Se você escolher, no caso da Mandala do Amor, uma pergunta, a pergunta número um na energia, você no masculino, você vai escolher a pergunta número um na energia do feminino.
- A pastinha lá na dele, tudo que ele fez com você tá dentro da pastinha dele, é seu cliente, se você ti então, mas para facilitar o processo agora, você pode colocar aqui no comecinho o número da pergunta se é uma, dois ou a três para você ter que escrever tudo ali, na vez vai demorar muito e perde um pouco do fluxo.
- Agora eu vou continuo fazendo perguntas, eu quero que você me responda zer na mandala da dor você não precisa seguir a sequência, você vai escolher uma de cada, tá?

### Bloco 4 - frases 229-304
- Então, lembrando sempre disso, o cliente chega em dor porque ele está iludido.
- Então essas são as questões que a gente precisa ajudar ele a sair daquele lugar, a perceber e se se acalmando e ter consciência de tudo isso.
- Então você vai encontrar de acordo com todos os conceitos que a gente trouxe que estão todos explicadinhos aqui atrás, Andra, mas na hora que eu tiver com meu assistido não vou conseguir estar vendo o vídeo.

### Bloco 5 - frases 305-380
- Siga as orientações do bloco azul, comando de retorno à consciência para harmonizar na mesa, manos lugar, função e potência e encerrar a sessão com assistido.
- Então você vai virar o pêndulo no sentidora, fecha os olhos, relaxa, vou te harmonizar para você ir se acalmando e fica bem.
- Ó, sinta a dor chegando sem medo, sem fugir, porque só o que é sentido por inteiro pode enem ser curado.

### Bloco 6 - frases 381-456
- Então vocês estão desdobrados, o cliente está desdobrado num campo de proteção onde tem uma plasticidade completamente, onde tem códigos completamente diferentes.
- Da câmara humano e por isso funciona só por isso tem pequeno que a gente precisa entender que não somos nós que estamos trabalhando.
- Se lá, vocês vão ver o que vai acontecendo com a mediunidade de vocês, porque estamos na Câmara Humanoscense, desdobrados, você e ele, ancorados por toda a equipe que sustenta o espaço humanidade, espiritualmente falando, OK?

### Bloco 7 - frases 457-532
- Eh, você pode depois de um período, né, manter contato, tem data de nascimento, você pode, eh, mandar parabéns a nos aniversários e manter esse contato com o seu cliente, caso ele não seja um cliente seu já eh sempre.
- Eh, no momento das perguntas, nas mandalas, eh, a cada investigação de cada pergunta, né, eh, é melhor a gente discutir com ele, com o assistido, eh, o que a gente tá visualizando ali ao fim de cada pergunta ou ao fim de cada pétala?
- Não é para terapeuta ai vou fazer uma não é trabalho, não é trabalho espiritual, não é trabalho de verdade dentro de uma linha de resgate, de uma linha de de cura de verdade, é só o gostosinho." Então, para vocês entenderem isso sim, a gente tá com a equipe, a equipe do código inocência é extremamente potente.

### Bloco 8 - frases 533-603
- Então, eh, minha dúvida é a seguinte, como eu também sou humanoterapeuta, né, eu também trabalho com amiza quântica, aí aqui que nos inícios da passo a passo do trabalho, a gente coloca o assistido ou dentro código, né, do situação unidade, coloca ele na mesa.
- Na mesa quântica, quando a gente coloca o assistido, eu já estou acessando o o campo morfogenético dele e o inconsciente.
- Aí eu fiquei meia confusa com isso, porque quando eu coloco assistido na mesa quântica, eu já estou as perguntas que eu faço, ele já está ali no Eu já estou assistando.

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Então, sempre que a gente vai receber, a gente vai trabalhar energeticamente, nós precisamos estar prontos antes dele chegar.
- Então, antes do seu cliente chegar, de seu horário de abrir o zoom com ele à distância ou presencial, você precisa estar pronto, tá?
- E aí você vai, pede pro assistido se conectar com o que ele precisa resolver, ou seja, a dor ou a questão que ele trouxe.
- Consciente primeiro ele vai responder racionalmente, a gente vai fazer a leitura do campo energético, que é o inconsciente, trazer pro consciente uma informação do campo inconsciente energético.
- A pastinha lá na dele, tudo que ele fez com você tá dentro da pastinha dele, é seu cliente, se você ti então, mas para facilitar o processo agora, você pode colocar aqui no comecinho o número da pergunta se é uma, dois ou a três para você ter que escrever tudo ali, na vez vai demorar muito e perde um pouco do fluxo.
- Agora eu vou continuo fazendo perguntas, eu quero que você me responda zer na mandala da dor você não precisa seguir a sequência, você vai escolher uma de cada, tá?
- Então, lembrando sempre disso, o cliente chega em dor porque ele está iludido.
- Então essas são as questões que a gente precisa ajudar ele a sair daquele lugar, a perceber e se se acalmando e ter consciência de tudo isso.
- Então, vá seguindo as orientações sobre sentir, transformar e transmutar, executando atentamente o que ele fala e vá conduzindo o processo, perguntando sempre o que ele sente que deve fazer nessa situação.
- Da câmara humano e por isso funciona só por isso tem pequeno que a gente precisa entender que não somos nós que estamos trabalhando.

## Conceitos-Chave Extraídos

- Então, para facilitar um pouquinho a vida de vocês, embora esteja tudo eh no passo a passo do sistema.
- Ehos o que é comando tá na folha de comando, o que é passo a passo tá no passo a passo no sistema, tá bom?
- Então no passo quatro que tá aqui no sistema, você também tem uma orientação, tem até uma frase pronta para você não esquecer.
- E explica, é uma tecnologia espiritual canalizada que atua em três níveis, no racional, no emocional e no espiritual. e tem como objetivo identificar a raiz de um padrão, limpar o campo, abrir e abrir caminho para uma nova realidade, tá?
- Se você escolher, no caso da Mandala do Amor, uma pergunta, a pergunta número um na energia, você no masculino, você vai escolher a pergunta número um na energia do feminino.
- Consciente primeiro ele vai responder racionalmente, a gente vai fazer a leitura do campo energético, que é o inconsciente, trazer pro consciente uma informação do campo inconsciente energético.
- E aí você vai perguntar do femino, do energia, depois do tempo e você vai fazer todas as perguntas aqui da mandala do amor.
- Agora eu vou continuo fazendo perguntas, eu quero que você me responda zer na mandala da dor você não precisa seguir a sequência, você vai escolher uma de cada, tá?
- Então essas são as questões que a gente precisa ajudar ele a sair daquele lugar, a perceber e se se acalmando e ter consciência de tudo isso.
- Então você vai encontrar de acordo com todos os conceitos que a gente trouxe que estão todos explicadinhos aqui atrás, Andra, mas na hora que eu tiver com meu assistido não vou conseguir estar vendo o vídeo.
- Siga as orientações do bloco azul, comando de retorno à consciência para harmonizar na mesa, manos lugar, função e potência e encerrar a sessão com assistido.
- Então vocês estão desdobrados, o cliente está desdobrado num campo de proteção onde tem uma plasticidade completamente, onde tem códigos completamente diferentes.
- Eh, no momento das perguntas, nas mandalas, eh, a cada investigação de cada pergunta, né, eh, é melhor a gente discutir com ele, com o assistido, eh, o que a gente tá visualizando ali ao fim de cada pergunta ou ao fim de cada pétala?
- Não é para terapeuta ai vou fazer uma não é trabalho, não é trabalho espiritual, não é trabalho de verdade dentro de uma linha de resgate, de uma linha de de cura de verdade, é só o gostosinho." Então, para vocês entenderem isso sim, a gente tá com a equipe, a equipe do código inocência é extremamente potente.
- Então, eh, minha dúvida é a seguinte, como eu também sou humanoterapeuta, né, eu também trabalho com amiza quântica, aí aqui que nos inícios da passo a passo do trabalho, a gente coloca o assistido ou dentro código, né, do situação unidade, coloca ele na mesa.
- Na mesa quântica, quando a gente coloca o assistido, eu já estou acessando o o campo morfogenético dele e o inconsciente.


## Técnicas, Procedimentos e Orientações Práticas

- Vamos lá, vamos tirar algumas dúvidas, algumas questões que as pessoas estão perguntando, extremamente ansiosas e eu falando: "Calma, gente, a gente vai chegar lá, vocês, a gente ainda vai chegar nessa fase, então tenham calma que a gente tá chegando no finalmente, tá bom?
- Então, a primeira parte do passo a passo é a parte de você se preparar antes do seu cliente, do seu assistido chegar, certo?
- Então, antes do seu cliente chegar, de seu horário de abrir o zoom com ele à distância ou presencial, você precisa estar pronto, tá?
- Então, primeira coisa que é essa primeira parte do e do passo a passo, então, agendamento com assistido, preparação do ambiente e preparação do terapeuta, certo?
- Então no passo quatro que tá aqui no sistema, você também tem uma orientação, tem até uma frase pronta para você não esquecer.
- E explica, é uma tecnologia espiritual canalizada que atua em três níveis, no racional, no emocional e no espiritual. e tem como objetivo identificar a raiz de um padrão, limpar o campo, abrir e abrir caminho para uma nova realidade, tá?
- E aí você vai, pede pro assistido se conectar com o que ele precisa resolver, ou seja, a dor ou a questão que ele trouxe.
- Se você escolher, no caso da Mandala do Amor, uma pergunta, a pergunta número um na energia, você no masculino, você vai escolher a pergunta número um na energia do feminino.
- A pastinha lá na dele, tudo que ele fez com você tá dentro da pastinha dele, é seu cliente, se você ti então, mas para facilitar o processo agora, você pode colocar aqui no comecinho o número da pergunta se é uma, dois ou a três para você ter que escrever tudo ali, na vez vai demorar muito e perde um pouco do fluxo.
- Agora eu vou continuo fazendo perguntas, eu quero que você me responda zer na mandala da dor você não precisa seguir a sequência, você vai escolher uma de cada, tá?
- Então, lembrando sempre disso, o cliente chega em dor porque ele está iludido.
- Então vocês estão desdobrados, o cliente está desdobrado num campo de proteção onde tem uma plasticidade completamente, onde tem códigos completamente diferentes.
- Eh, no momento das perguntas, nas mandalas, eh, a cada investigação de cada pergunta, né, eh, é melhor a gente discutir com ele, com o assistido, eh, o que a gente tá visualizando ali ao fim de cada pergunta ou ao fim de cada pétala?
- Então, eh, minha dúvida é a seguinte, como eu também sou humanoterapeuta, né, eu também trabalho com amiza quântica, aí aqui que nos inícios da passo a passo do trabalho, a gente coloca o assistido ou dentro código, né, do situação unidade, coloca ele na mesa.


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- E explica, é uma tecnologia espiritual canalizada que atua em três níveis, no racional, no emocional e no espiritual. e tem como objetivo identificar a raiz de um padrão, limpar o campo, abrir e abrir caminho para uma nova realidade, tá?
- Aí a pessoa vai falando, ai porque lá no meu trabalho, eu tô com muito problema com meu chefe, eu tô com medo, tá correndo risco da semana embora ou na minha casa, eu tô com muito problema na minha casa, meu relacionamento era super bom e agora parece que tá não tá bom, tá esfriando.
- Tem que falar, tem em voz alta sim, porque ele precisa autorizar e colocar magneticamente essa autorização no mundo.
- E aí você vai, pede pro assistido se conectar com o que ele precisa resolver, ou seja, a dor ou a questão que ele trouxe.
- E aí, antes disso, desculpa, antes disso que você colocou aqui, você vai fazer as perguntas da mandala do amor, ok?
- Para algumas pessoas, você relaxa ela primeiro porque ela tá com raiva, ela tá com medo, ela tá angstiada, ela tá com síndrome do pânico, ela tá com cr ansiedade.
- Agora eu vou continuo fazendo perguntas, eu quero que você me responda zer na mandala da dor você não precisa seguir a sequência, você vai escolher uma de cada, tá?
- Femino ferido, não precisa falar para ele que é feminino ferido, porque ele não não necessariamente tem ideia disso.
- Então, lembrando sempre disso, o cliente chega em dor porque ele está iludido.
- Então você vai virar o pêndulo no sentidora, fecha os olhos, relaxa, vou te harmonizar para você ir se acalmando e fica bem.
- Ó, sinta a dor chegando sem medo, sem fugir, porque só o que é sentido por inteiro pode enem ser curado.
- Sem nada que não queira, porque aí eu tô invadindo o campo do outro sem autorização do outro.


## Citações e Formulações de Alta Densidade

- “Então, sempre que a gente vai receber, a gente vai trabalhar energeticamente, nós precisamos estar prontos antes dele chegar.”
- “Então, antes do seu cliente chegar, de seu horário de abrir o zoom com ele à distância ou presencial, você precisa estar pronto, tá?”
- “E aí você vai, pede pro assistido se conectar com o que ele precisa resolver, ou seja, a dor ou a questão que ele trouxe.”
- “Agora eu vou continuo fazendo perguntas, eu quero que você me responda zer na mandala da dor você não precisa seguir a sequência, você vai escolher uma de cada, tá?”
- “Então, lembrando sempre disso, o cliente chega em dor porque ele está iludido.”
- “Então essas são as questões que a gente precisa ajudar ele a sair daquele lugar, a perceber e se se acalmando e ter consciência de tudo isso.”
- “Então, vá seguindo as orientações sobre sentir, transformar e transmutar, executando atentamente o que ele fala e vá conduzindo o processo, perguntando sempre o que ele sente que deve fazer nessa situação.”
- “Ó, sinta a dor chegando sem medo, sem fugir, porque só o que é sentido por inteiro pode enem ser curado.”
- “Da câmara humano e por isso funciona só por isso tem pequeno que a gente precisa entender que não somos nós que estamos trabalhando.”
- “Não é para terapeuta ai vou fazer uma não é trabalho, não é trabalho espiritual, não é trabalho de verdade dentro de uma linha de resgate, de uma linha de de cura de verdade, é só o gostosinho." Então, para vocês entenderem isso sim, a gente tá com a equipe, a equipe do código inocência é…”
- “Na mesa quântica, quando a gente coloca o assistido, eu já estou acessando o o campo morfogenético dele e o inconsciente.”
- “Aí eu fiquei meia confusa com isso, porque quando eu coloco assistido na mesa quântica, eu já estou as perguntas que eu faço, ele já está ali no Eu já estou assistando.”

## Conexões com a Wiki

- [[Conceito do Metodo HumanoSense]]
- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]
- [[Conceito da Camara HumanoSense]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio da Liberdade Consciente]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Enquadramento na Piramide]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Tecnica de Retorno a Consciencia e Harmonizacao]]

## FAQs para NotebookLM (Fase 2)

### Bloco 1: A Ética Clínica e o Choque de Desilusão

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
1. Como Andresa Molina define o "Princípio da Objetividade Terapêutica" e por que "dar aula" de mecânica quântica ou espiritualidade dispersa o campo magnético do assistido?
2. De que maneira a ilusão do paciente atua como o principal fator de adoecimento e por que a "desilusão" promovida pela mesa Humanosense é considerada um processo curativo e libertador?
3. Sob a ótica do "Princípio do Consentimento", quais são as consequências vibracionais e espirituais imediatas para o terapeuta que tenta aplicar a mesa em terceiros (como maridos ou filhos) sem autorização?
4. Como Andresa Molina explica que tentar sintonizar e tratar o campo de um familiar que não pediu ajuda transforma o terapeuta em um "obsessor" e quebra seu próprio escudo magnético?
```

### Bloco 2: O Diagnóstico Radiestésico e a Dissonância do Campo

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
5. O que é o "Princípio do Foco Primordial" e por que desviar do objetivo primário trazido pelo assistido fragmenta e prejudica a energia da sessão?
6. O que Andresa Molina descreve como "Afetos e Desafetos" no diagnóstico clínico e de que maneira um objeto inanimado (como uma empresa, um cargo ou um carro) pode concentrar a mesma dor de perda que uma morte familiar?
7. Como Andresa Molina conceitua a expressão "Gap Vibracional" e de que forma a divergência de três pontos ou mais entre a resposta lógica (consciente) e o pêndulo (inconsciente) sinaliza a autossabotagem do ego?
8. De que forma o Humanosense se diferencia da Humanoterapia no que tange a acessar a biologia profunda, epigenética e registros ancestrais do assistido?
```

### Bloco 3: Os Mecanismos de Fuga e a Condução do Transe

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
9. Como a mente infantil (arquétipo da Donzela e do Príncipe) se protege através da "Fuga para o Universo das Possibilidades" e qual a diferença entre focar no que é "possível" e no que é "provável"?
10. Como o terapeuta deve conduzir a sua própria preparação mental e a entrada em nível "Alfa" muito antes de abrir o atendimento ao assistido, e o que a autora orienta sobre o uso clínico de incensos, velas ou músicas?
11. Qual o propósito diagnóstico de avaliar o signo e os elementos naturais (Fogo, Terra, Água, Ar) na Ficha Cinza, e como a apatia de um paciente regido pelo elemento Fogo indica patologia biológica profunda?
12. Como o terapeuta deve extrair a "síntese" da queixa do assistido durante o preenchimento da Ficha Cinza em vez de se perder no enredo ou na história contada?
```

### Bloco 4: Práticas Operacionais de Choque, Resgate e Harmonização na Mesa

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
13. Como é executado o "Rastreio Duplo" no Bloco Verde e qual a regra para parear perguntas antagônicas entre as polaridades masculina e feminina na Mandala do Amor?
14. Qual a relevância mecânica do enquadramento em Pirâmide e do testemunho vocal em voz alta no momento do ancoramento no selo central da mesa?
15. Como o terapeuta opera a transição de "estado plasmático" do assistido para a Câmara Humanosense e como se dá o comando de desdobramento?
16. De que forma o terapeuta conduz a purgação da dor ("sangramento") durante o transe e por que a autora proíbe acalmar o paciente antes que a emoção seja esgotada por inteiro?
17. Qual a diferença de comando e atuação entre a egrégora de resgate padrão (habilidade, disponibilidade e autorização) e as entidades especialistas (pedreiros, bombeiros, cirurgiões astrais)?
18. Como é aplicada a "Técnica de Avaliação de Estado" e em quais circunstâncias clínicas o terapeuta deve suspender a sessão de transe e optar apenas pela harmonização?
19. Quais são os procedimentos e comandos exatos de encerramento da câmara, incluindo a passagem do solvente cósmico, água crística e o reacoplamento de corpos sutis de 5 a 1?
20. Como o terapeuta opera o pêndulo no sentido horário infundindo a trindade "Harmoniza, Potencializa e Liberta" e como desliza o dedo para desligar o assistido da mesa?
```

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## Referência

ANDRESA MOLINA. *Aula 07 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.
