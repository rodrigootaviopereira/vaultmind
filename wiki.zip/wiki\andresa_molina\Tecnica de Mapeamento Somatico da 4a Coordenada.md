---
type: tecnica
author: Andresa Molina
tags: [tecnica, mapeamento-somatico, somatizacao, rastreamento, 4a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]]"]
---

# Mapeamento Somático da 4ª Coordenada

## Objetivo

- Rastrear e localizar no corpo físico a marca informacional do autoabandono e esvaziamento existencial (4ª Coordenada), condensando o desconforto em uma única frequência (Nome) e associando-o a um ponto somático específico (Local) para desprogramação.

## Pré-requisitos

- Execução prévia da [[Tecnica de Remocao de Papeis Sociais|Prática de Remoção de Papéis Sociais]].

## Passo a Passo

1. **Evocação do Histórico de Autoanulação**:
   - Trazer à lembrança os momentos em que a identidade foi anulada, os desejos esquecidos e as vezes em que os próprios planos foram deixados no fim da fila para servir aos outros.
2. **Identificação do Nome da Emoção**:
   - Condensar essa dor em uma única palavra clara de sentimento (ex: *Medo, Raiva, Tristeza, Ansiedade, Chateação*). Esse "nome" representa a frequência energética do bloqueio.
3. **Rastreamento Físico Imediato**:
   - Sem usar a mente racional, fechar os olhos e perceber instantaneamente onde esse sentimento se localiza fisicamente no corpo (ex: peso nos ombros, aperto no peito, rosto esquentando, frio no estômago, dor na lombar ou pernas dormentes).
4. **Ancoragem da Coordenada**:
   - A união do Nome da Emoção com a localização somática (ex: *"Tristeza no peito"* ou *"Raiva no estômago"*) constitui o "X" ou coordenada exata da 4ª Coordenada no Mapa da Alma do assistido, pronta para receber a curetagem ou sangria energética.

## Duração/Frequência

- Executada como diagnóstico prático e mapeamento durante a sessão terapêutica HumanoSense.

## Indicadores de Sucesso

- Localização instantânea e sem esforço lógico de reações físicas no corpo ao evocar a autoperda.
- Nomeação clara da frequência emocional por trás do sintoma físico.

## Conceitos Envolvidos

- [[Conceito da Mulher antes de ser de Todos]]
- [[Conceito do Mapa da Alma]]
- [[Conceito de Aconteceu vs Acontece]]

## Referência

ANDRESA MOLINA. *Mapeamento Somático da 4ª Coordenada*. Aula 04 - Coordenada 4 (A Mulher Antes de Ser de Todos). Fontes: [[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]].
