---
type: sintese
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, modulo_05, humanometria, apometria, obsessao]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_67_humanometria.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_68_introducao.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_77_hierarquia_espiritual.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_83_parasitismo_x_vampirismo.md]]"]
---

# HT - Modulo 05 - Humanometria

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_67_humanometria.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_68_introducao.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_77_hierarquia_espiritual.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_83_parasitismo_x_vampirismo.md]]


## Nucleos do Modulo

- A Humanometria e apresentada como desdobramento tecnico seguro da apometria.
- O modulo organiza disturbios espirituais por niveis, tipos e leis.
- A hierarquia espiritual e os bloqueios energeticos entram como fundamento de leitura.

## Síntese

- [INFERÊNCIA] HT - Modulo 05 - Humanometria é uma nota de apoio dentro da wiki de Andresa Molina e precisa ser lida em conjunto com as aulas e mapas estruturais já conectados.

## Evidências do Material

- [INFERÊNCIA] Consultar fontes indicadas.

## Conexões

- [[Consolidacao Tematica - Andresa Molina]]

## Referencia

ANDRESA MOLINA. *HT - Modulo 05 - Humanometria*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_67_humanometria.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_68_introducao.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_77_hierarquia_espiritual.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_83_parasitismo_x_vampirismo.md]]. Acesso em: 17 jun. 2026.
