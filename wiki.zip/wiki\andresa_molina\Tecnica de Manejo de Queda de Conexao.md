---
type: technique
author: Andresa Molina
tags: [manejo-de-queda, conexao-online, plano-de-contingencia, resgate-assincrono]
sources: ["[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"]
---

# Técnica de Manejo de Queda de Conexão (O resgate assíncrono)

- **Definição**: O plano de contingência obrigatório de biossegurança usado para evitar que a psique do assistido permaneça desamparada na dimensão de dor caso a rede de internet caia ou a energia elétrica acabe durante o ápice do desdobramento astral.
- **Como praticar e seu Propósito**:
  1. **O Acordo Prévio**: Antes do paciente fechar os olhos, o terapeuta pactua a emergência: "Olha, se cair, a gente não tem como continuar... eu vou pedir que você fique quietinho lá, vá respirando e vai voltando devagar".
  2. **A Mensagem Pronta**: Deixar uma mensagem predefinida via WhatsApp no celular. Se a vídeo-chamada cair, o terapeuta envia na hora: "Olha, se cair, eu vou te mandar uma mensagem... 'Olha, vai respirando, vai voltando devagarzinho, né? Eu vou contar de cinco a um para você ir voltando devagar'".
  O propósito somático é enviar um cordão de ancoramento (mesmo em formato de texto ou áudio assíncrono) para que o paciente consiga sair do transe e da dor da purgação com segurança neurológica ("Ela pode estar num momento de muita dor, onde ela tá sangrando e aí você tem que dar condição para ela ir voltando").
- **Evidências**: "O que eu sugiro... que você antes de começar... avise: 'Olha, se cair, a gente não tem como continuar, a gente vai ter que refazer, mas aí eu vou pedindo >> é só um minuto.' ...Outra coisa que pode ser feito é você já deixar uma mensagem pronta no WhatsApp... que você fale: 'Olha, se cair, eu vou te mandar uma mensagem, você vai pedindo para olha, vai respirando, vai voltando devagarzinho, né? Eu vou contar de cinco a a um para você ir voltando devagar'... Ela pode estar num momento de muita dor, onde ela tá sangrando e aí você tem que dar condição para ela ir voltando."
- **Conexões**: [[Principio da Biosseguranca Online]], [[Tecnica de Retorno a Consciencia e Harmonizacao]]

## Perguntas Frequentes / Didática de Atendimento

### 7. Quais os passos e comandos práticos para gerenciar uma queda repentina de chamada sem deixar a psique do assistido abandonada?
**Resposta**: O terapeuta precisa ter um plano de contingência focado em segurança somática e respiratória, estabelecido em duas etapas:
1. **Aviso Prévio (Ancoragem de Comando):** Antes de iniciar o relaxamento, o terapeuta pactua a emergência: **"Olha, se por acaso cair, eu vou pedir que você fique quietinho lá, vá respirando e vai voltando"**.
2. **Mensagem de Resgate Pré-programada:** O terapeuta deve **"já deixar uma mensagem pronta no WhatsApp"** para disparar imediatamente na queda: **"Olha, se cair, eu vou te mandar uma mensagem, você vai pedindo para olha, vai respirando, vai voltando devagarzinho, né? Eu vou contar de cinco a a um para você ir voltando devagar, vai voltando para cá, né?"**.

A nível somático, o comando para focar na respiração e a contagem devolvem os batimentos cardíacos ao compasso normal, puxando o corpo físico de volta do estado de dor aguda para a vigília.


## Referencia

ANDRESA MOLINA. *Técnica de Manejo de Queda de Conexão*. Aula 09 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]].
