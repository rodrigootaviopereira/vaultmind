---
type: sintese
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, modulo_07, tdr, subpersonalidades, reprogramacao]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_92_terapia_de_desbloqueio_emocional.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_94_subpersonalidade.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_97_reprogramacao_energetica_parte_1.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_103_reprogramacao_energetica.md]]"]
---

# HT - Modulo 07 - TDR e Reprogramacao Energetica

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_92_terapia_de_desbloqueio_emocional.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_94_subpersonalidade.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_97_reprogramacao_energetica_parte_1.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_103_reprogramacao_energetica.md]]


## Nucleos do Modulo

- A dor e traduzida em registro, memoria e configuracao energetica.
- Subpersonalidade vira categoria central do tratamento.
- O modulo tenta aproximar a reprogramacao energetica de linguagem neurofisiologica.

## Síntese

- [INFERÊNCIA] HT - Modulo 07 - TDR e Reprogramacao Energetica é uma nota de apoio dentro da wiki de Andresa Molina e precisa ser lida em conjunto com as aulas e mapas estruturais já conectados.

## Evidências do Material

- Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_84_espiritualidade_avancada.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_85_tecnicas_energeticas_e_espirituais.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_89_principais_tipos_de_implantes.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_91_larvas_astrais_e_miasmas.md]]. (HT - Modulo 06 - Espiritualidade Avancada)

## Conexões

- [[HT - Modulo 06 - Espiritualidade Avancada]]

## Referencia

ANDRESA MOLINA. *HT - Modulo 07 - TDR e Reprogramacao Energetica*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_92_terapia_de_desbloqueio_emocional.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_94_subpersonalidade.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_97_reprogramacao_energetica_parte_1.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_103_reprogramacao_energetica.md]]. Acesso em: 17 jun. 2026.
