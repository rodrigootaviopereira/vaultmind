---
type: principio
author: Andresa Molina
tags: [resistencia, livre-arbitrio, paralisação-terapeutica, bloqueio-consciente]
sources: ["[[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio do Respeito à Resistência (A paralisação clínica sem julgamento)

- **Definição**: A diretriz que obriga o terapeuta a interromper imediatamente o processo de cura na Câmara Astral se o paciente se recusar a liberar a dor ou o agressor, abraçando esse bloqueio como um encerramento legítimo.
- **Justificativa**: A nível somático, a cura forçada é uma agressão. Muitas vezes, a pessoa vê o algoz (ex: o pai abusivo) na cena e o seu corpo trava: "Não, eu não quero falar nada". O terapeuta não deve insistir ou sentir que falhou. A pessoa tem o direito cármico de "continuar com raiva do pai" e castigá-lo internamente. O sucesso da sessão não é forçar um abraço de luz, mas trazer a autorresponsabilidade: ao dar "consciência", a pessoa passa a saber exatamente que a sua vida financeira ou amorosa está travada por uma escolha puramente pessoal de "não largar o osso".
- **Evidências**: "Ela diz: 'não, eu não quero falar nada, não, eu não consigo fazer nada'... A pessoa não quer, não quer. É uma manifestação de que ela realmente não tá querendo, né? ...eu quero continuar com ra do meu pai... a gente respeita. Só que eu dei consciência para ela e a partir do momento que eu dei consciência, ela sabe que a vida dela não anda porque ela não quer liberar essa questão, ela não quer liberar o outro, ela tá com raiva, ela quer continuar castigando. Então tá bom... afinal de contas, é a história, vida, o processo dela."
- **Implicações**: Em caso de resistência severa no transe, o terapeuta deve reverter os comandos e abortar a cena, aplicando a técnica de encerramento amigável.
- **Conexões**: [[Tecnica de Encerramento Antecipado por Bloqueio]], [[Conceito da Falsa Culpa Sistemica]]
- **Notas Pessoais**: Respeitar a dor e a teimosia do cliente é o teste supremo da neutralidade do terapeuta.

## Perguntas Frequentes / Didática de Atendimento

### 3. Como o terapeuta deve agir quando o assistido resiste e se recusa a liberar a dor ou perdoar?
**Resposta**: O terapeuta deve agir recuando imediatamente, sem forçar catarses. A autora decreta a postura de aceitação: "A pessoa não quer, não quer... a gente respeita". Clinicamente e vibracionalmente, o terapeuta interrompe o mergulho na dor e estabiliza o corpo do paciente: "Então vamos trazer de volta, vamos voltando... vamos para um momento de paz, fica em paz, fica calma e vai volando".

A nível somático e psíquico, o tratamento não falha quando isso ocorre. O objetivo da mesa não é forçar o perdão, mas entregar a "consciência". O assistido é devolvido ao seu próprio corpo ciente da responsabilidade pelo seu sofrimento físico e material: "a partir do momento que eu dei consciência, ela sabe que a vida dela não anda porque ela não quer liberar essa questão, ela não quer liberar o outro, ela tá com raiva, ela quer continuar castigando". Diante dessa escolha madura, o terapeuta encerra: "para mim tá concluídíssimo. Não quer, tá tudo bem para mim".


## Referencia

ANDRESA MOLINA. *Princípio do Respeito à Resistência*. Aula 10 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]].
