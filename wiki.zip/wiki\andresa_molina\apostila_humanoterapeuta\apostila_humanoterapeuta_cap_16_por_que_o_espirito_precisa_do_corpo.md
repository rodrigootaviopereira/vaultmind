---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_16_por_que_o_espirito_precisa_do_corpo.md]]"]
---

# Cap 016 - Por Que O Espirito Precisa Do Corpo

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_16_por_que_o_espirito_precisa_do_corpo.md]]

## Referencia

ANDRESA MOLINA. *Cap 016 - Por Que O Espirito Precisa Do Corpo*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_16_por_que_o_espirito_precisa_do_corpo.md]]. Acesso em: 17 jun. 2026.
