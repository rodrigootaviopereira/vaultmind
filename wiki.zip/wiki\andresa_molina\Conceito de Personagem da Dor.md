---
type: conceito
author: Andresa Molina
tags: [personagem, mascara, ego, sobrevivencia, donzela, guerreiro, rainha]
sources: ["[[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]"]
---

# Conceito de Personagem da Dor

- **Definição**: A máscara ou papel comportamental que o indivíduo assume, quase sempre inconscientemente, para proteger a criança ferida e sobreviver emocionalmente, garantindo aceitação e controle.
- **Justificativa**: Enquanto a essência sente e age por escolha, o personagem reage e atua de forma ensaiada baseando-se em dores antigas e ganhos secundários.
- **Evidências**: "O personagem é a máscara que nós aprendemos a vestir para sobreviver emocionalmente. É um papel que assumimos quase sempre de forma inconsciente para proteger a criança ferida que um dia nós fomos. Por trás de cada personagem, que é a donzela guerreira ou a rainha, existe uma dor antiga e também um ganho secundário. [...] Enquanto a essência sente, escolhe e vive, o personagem atua, reage e se defende."
- **Implicações**: Desmontar os personagens exige expô-los à consciência lógica do assistido, desfazendo os fractais de dor no campo energético.
- **Conexões**: [[Principio da Mandala da Dor]], [[Conceito do Arquetipo da Donzela]], [[Conceito do Arquetipo do Guerreiro]], [[Conceito da Soberania do Rei e Rainha]]
- **Notas Pessoais**: O personagem cristalizado aprisiona o indivíduo a repetir histórias do passado.

## Referencia

ANDRESA MOLINA. *Conceito de Personagem da Dor*. Aula 03 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]].
