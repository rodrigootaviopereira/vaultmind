---
type: conceito
author: Andresa Molina
tags: [gap-vibracional, personalidade, sombra, ilusao, autossabotagem]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# A Personalidade Sombra / O Gap (A dissonância do comportamento inconsciente)

- **Definição Precisa**: A faceta oculta e reprimida da personalidade do assistido (Cobrador, Explorador, Limitador ou Lixeiro) que opera à revelia da mente racional, sendo detectada numericamente na mesa através da discrepância profunda ("gap") entre o discurso consciente e o pêndulo.
- **Sinônimos/Variações**: Sombra do ego, dinâmica oculta de dor, comportamento inconsciente discrepante.
- **Contexto de Uso**: Utilizado pelo terapeuta para apontar que o cliente, mesmo declarando-se inocente e proativo, está agindo e atraindo a sua realidade atual por meio de uma frequência agressiva e manipuladora de dor.
- **Relação com Princípios**: [[Principio da Desilusao]], [[Principio da Causa Inconsciente e da Reconsolidacao]]
- **Exemplos do Material**: "E às vezes ela vai dizer no consciente que não, eu sou super forte, não, eu cuido minha vida no inconsciente. Você saca que não é verdade, como ela se manif, ela fala uma coisa, só que na verdade é outra... a gente mente pra gente para caramba... Às vezes é porque ele não percebe que ele tá fazendo aquilo... Quando dá muito discrepante, né, dá uns três pontos aí de diferença, fala: 'Opa, aqui ela tá muito fora da percepção'... ele pensa que é uma coisa, ele diz que é uma coisa, mas inconscientemente ele tá se movendo por outra."
- **Aplicação Prática**: Confrontar a autoilusão do cliente mostrando que a biologia e o magnetismo dele sintonizam sua vida pelas marcas inconscientes, forçando a desilusão terapêutica necessária para a reprogramação.
- **Conexões Externas**: [[Conceito do Gap Vibracional]], [[Conceito de Explorador Limitador e Cobrador]]

## Perguntas Frequentes / Didática de Atendimento

### 8. De que maneira a mesa Humanosense identifica e desfaz os comportamentos de dor ("personalidade") quando o cliente os nega?
**Resposta**: A mesa identifica o personagem através do rastreio de dissonância (o gap) entre o que a mente afirma e o que o corpo físico atrai.

A nível somático, a mente lógica do cliente (o consciente) mente para se defender. Ele pode afirmar categoricamente: **"não, eu sou super forte, não, eu cuido minha vida"**. Contudo, a mesa quântica mede a assinatura vibracional real (o inconsciente). O diagnóstico é revelado quando o pêndulo corta em uma nota oposta, denunciando a falsidade orgânica: **"no inconsciente. Você saca que não é verdade, como ela se manif, ela fala uma coisa, só que na verdade é outra"**. A mesa desfaz a ilusão esfregando essa inconsistência no paciente: **"quando dá muito discrepante, né, dá uns três pontos aí de diferença, fala: 'Opa, aqui ela tá muito fora da percepção'"**. Isso quebra a máscara de autossabotagem, provando que **"em alguns momentos, muitos, ela não tem consciência que ela faz aquilo"**.


## Referencia

ANDRESA MOLINA. *A Personalidade Sombra / O Gap*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
