---
type: tecnica
author: Andresa Molina
tags: [confronto, resgate, viagem-astral, memoria, catarse]
sources: ["[[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]]"]
---

# O Confronto e Resgate da Contraparte (A condução ativa do assistido na cena de dor para liberar a emoção)

- **Objetivo**: Conduzir ativamente a mente inconsciente do assistido para dentro de cenas traumáticas do passado, estimulando a liberação catártica (sangramento emocional) de medos, raivas e dores reprimidas para que o fragmento de alma (contraparte) possa ser resgatado com sucesso.
- **Pré-requisitos**: Indução do assistido ao estado de "Alfa Profundo".
- **Passo a Passo**:
  1. Após o relaxamento profundo, o terapeuta pede para o assistido relatar a imagem ou cenário espiritual que surge em sua tela mental (ex: ver a si mesmo como uma criança chorando ou preso em uma guerra).
  2. O terapeuta estimula o confronto direto com a cena de dor, proibindo defesas racionais ou posturas passivas: *"Olha para ela... Que que você sente? ...Eu quero que você chore toda esta dor"*.
  3. Se o assistido tem medo de deixar a cena ou expressar sua fúria, o terapeuta fornece comandos de empoderamento e incentivo ao desabafo: *"Diz para ele o quanto tá doendo... coloca para fora tudo que você tá sentindo"*.
  4. Uma vez esgotada a carga emocional (ocorre o "sangramento"), o terapeuta orienta o assistido a se despedir daquela cena e inicia o recolhimento do fractal curado.
- **Duração/Frequência**: Praticado durante a fase ativa de desipnose na mesa.
- **Indicadores de Sucesso**: Choro purificador do assistido, mudança de expressão somática (relaxamento do peito e respiração), e desapego voluntário da cena traumática.
- **Variações**: Condução de regressão na infância vs. resgate de contrapartes presas em vidas passadas de guerras ou abandonos.
- **Conceitos Envolvidos**: [[Conceito do Sangramento do Utero da Vida]], [[Conceito de Entidades de Resgate vs Especialistas]]

## Perguntas Frequentes / Didática de Atendimento

## Perguntas Frequentes / Didática de Atendimento

### 12. Por que o terapeuta deve expor o assistido a sentir desconforto, dor ou raiva na cena de transe em vez de tentar acalmar o paciente de imediato?
**Resposta**: O terapeuta não deve acalmar ou apaziguar a dor porque a cura só acontece através da liberação bruta do afeto paralisado. A nível somático, se o paciente for acalmado antes de botar a dor para fora, a energia estagnada voltará a apodrecer no corpo. 

A autora instrui ativamente o confronto: "Yo quero que você chore toda esta dor da sua mãe não ter vindo... Coloca para fora tudo que você tá sentindo... É para sentir. É para sangrar". Durante o esvaziamento, mesmo na fase do Vazio, a ordem é resistir ao impulso de preencher, ordenando: "Sinta o conforto e o desconforto desse vazio... É para ficar no desconforto. Não preencha com nada". Apenas quando o paciente "Sangra, coloca para com raiva... expresse, chore, sangre", ele atinge a exaustão daquela estagnação, promovendo a verdadeira "explosão de consciência e profunda depuração emocional" que limpará o campo vibracional.

### 15. Como o terapeuta deve guiar o assistido no confronto da cena quando ele tem medo de sair ou de agir na cena traumática do passado?
**Resposta**: A nível somático e energético, o terapeuta não acalma passivamente o paciente; ele o empodera a confrontar a cena de dor, incitando-o a falar: "Vai lá agora e fala para esse pai. Você não podia ter feito isso. Você feriu. Conta, diz para ele o quanto tá doendo".

Quando o assistido trava e diz "Mas eu tenho medo", o terapeuta o guia acoplando proteções espirituais para que ele sinta o suporte vibracional. O profissional decreta que o paciente não irá sozinho: "Traz a pessoa que vai junto com você. Não precisa ter medo... 'Tenho uma energia aqui, tem uma energia que me protege.' Ah, ela vai com você. para você poder falar, ninguém vai te bater, guarda". Dessa forma, o assistido sente segurança somática ("tô aqui do lado") para expressar e sangrar a dor represada.

## Referencia

ANDRESA MOLINA. *O Confronto e Resgate da Contraparte*. Aula 06 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]].
