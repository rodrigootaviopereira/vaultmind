---
type: concept
author: Andresa
tags: [coordenadas, rejeicao, vazio, sacrificio]
sources: ["[[raw/archive/transcriptions/02 - O AMOR QUE NUNCA VOLTOU - 2ª Coordenada - O Mapa da Alma.md]]"]
---

# A 2ª Coordenada (O Amor Que Nunca Voltou)

**O padrão sistêmico de sofrimento marcado pelo esgotamento da generosidade unilateral, onde o indivíduo doa afeto, cuidado e sacrifício de forma incondicional nas relações, mas termina sempre sendo preterido, usado ou deixado para trás.**

Esta coordenada mapeia o lugar físico e emocional da frustração amorosa e relacional (não apenas amor íntimo, mas amizades e família). Encontrar a 2ª Coordenada significa identificar no corpo a sensação amarga de ser a pessoa que "sempre cede mais do que os outros".

A pessoa portadora dessa marca age como uma base de apoio para todos. Ela é amorosa, carinhosa e faz tudo "de coração". No entanto, ela nunca recebe o retorno equivalente dessa entrega. A dinâmica acaba sempre do mesmo jeito: os outros sugam a sua energia, resolvem seus problemas, "seguem, vão embora" e o assistido experimenta um profundo sentimento de traição e de "vazio absoluto", acreditando que o erro está em si mesmo por ser "bom demais".

> **Citação Literal:** "...nas suas relações mais importantes, não só afetiva íntima, de amigos, de família, todas as relações, você costuma ser aquela pessoa que sempre fica para trás, que sempre fica esperando, que cede mais do que os outros e acaba sendo deixada para trás. [...] Aquele amor que fica, os outros seguem, vão embora, você sente que você foi usada, que você foi abusada, que você foi traída..."

---

## Perguntas Frequentes / Didática de Atendimento

**1. O que define a "2ª Coordenada" dentro da jornada do "Mapa da Alma" proposta por Andresa Molina?**

**Resposta:** A 2ª Coordenada é intitulada "O amor que nunca voltou". Ela busca identificar no corpo do indivíduo a exata marca física e emocional onde essa dor reside. Trata-se de um guia ou bússola para localizar as impressões celulares causadas por padrões repetitivos de doação excessiva e consequente sentimento de abandono e traição nas relações mais importantes.
