---
type: conceito
author: Andresa Molina
tags: [personagem, donzela, guerreira, rainha, ego, mascaras]
sources: ["[[raw/archive/transcriptions/03 Código Humanosense  - Andresa Molina.md]]"]
---

# Conceito de Personagens da Dor

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/transcriptions/03 Código Humanosense  - Andresa Molina.md]]

## Definição Precisa

- **Definição**: [INFERÊNCIA] Conceito de Personagens da Dor nomeia um eixo recorrente da obra de Andresa Molina que deve ser lido dentro do HumanoSense/Humanoterapeuta como categoria de diagnóstico, leitura de campo ou condução terapêutica.
- **Formulação de apoio**: Eles aparecem como movimentos concretos na ficha: espera, dependencia, vergonha, defesa, guerra antiga e dificuldade de sustentar valor proprio. ## Referencia ANDRESA MOLINA. *Camada MasterSense - Personagens da Dor*.

## Sinônimos/Variações

- [INFERÊNCIA] Varia conforme a aula: pode aparecer como campo, código, mandala, personagem, sistema, memória, técnica ou postura terapêutica.

## Contexto de Uso

- Usado para orientar leitura do assistido, organização da sessão, compreensão de padrões emocionais/energéticos e conexão entre método, ficha, mesa, câmara e condução espiritual.

## Relação com Princípios

- [[Camada MasterSense - Personagens da Dor]]
- [[MasterSense - Mentoria do HumanoSense]]
- [[HT - Conceito - Metodo Humanoterapeuta]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]
- [[Arquitetura do HumanoSense]]

## Exemplos do Material

- Eles aparecem como movimentos concretos na ficha: espera, dependencia, vergonha, defesa, guerra antiga e dificuldade de sustentar valor proprio. ## Referencia ANDRESA MOLINA. *Camada MasterSense - Personagens da Dor*. (Camada MasterSense - Personagens da Dor)
- # Camada MasterSense - Personagens da Dor ## Rastreabilidade da Fonte - **Fontes principais no arquivo bruto**: - [[raw/archive/andresa_molina/transcriptions/02 Mastersense - Andresa Molina.md]] ## Segunda Camada O MasterSense mostra que os personagens da dor nao devem ser lidos apenas como tipos psicologicos. (Camada MasterSense - Personagens da Dor)
- O MasterSense pega essa base e transforma em supervisao viva: o terapeuta aplica, registra, autoriza a analise e aprende a enxergar o que a ficha revela sobre afeto/desafeto, pai, mae, personagens, escassez, valor, fuga e memoria celular. ## Segunda Camada - Leitura de Conjunto - A aula 01 apresenta a moldura espiritual e profissional da mentoria. - A aula 02 confirma o metodo na pratica: a ficha nao e burocracia, e um mapa de fuga, defesa, desejo, dor e incoerencia. - A mentoria insiste que o terapeuta nao precisa sentir tudo mediunicamente para fazer um bom trabalho; primeiro ele deve aprender a ler bem o material que o assistido oferece. - O MasterSense nao substitui o HumanoSense. (MasterSense - Mentoria do HumanoSense)
- Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_03_metodologia_humanoterapeuta.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_04_passo_1_a_consulta_inicial_no_psicogerador_quantionico_o_diagnostico.md]]. (HT - Conceito - Metodo Humanoterapeuta)
- Quando a ficha vem vazia ou pouco preenchida, a autora considera que nao ha material suficiente para analisar o caso. - **Fonte relacionada**: [[raw/archive/andresa_molina/transcriptions/02 Mastersense - Andresa Molina.md]] ## Referencia ANDRESA MOLINA. *Conceito da Ficha de Identificação e Síntese da Dor*. (Conceito da Ficha de Identificacao e Sintese da Dor)
- Use o método como ligação entre diagnóstico, condução e reintegração. ## Relação com a Série - O `Mapa da Alma` fornece a leitura da origem da dor. - O `Método HumanoSense` organiza a prática. - A `Mesa` e a `Câmara` são os espaços operativos da técnica. - A `Ficha` e a `Anamnese` mantêm a sessão centrada na raiz. ## Referência ANDRESA MOLINA. (Arquitetura do HumanoSense)

## Aplicação Prática

- [INFERÊNCIA] Ao encontrar este tema em atendimento, use-o como pergunta de aprofundamento: onde ele aparece na queixa, no corpo, na ficha, no afeto/desafeto e na relação entre consciência e inconsciente?
- [INFERÊNCIA] Verifique se a pessoa está usando este padrão como defesa, fuga, repetição de dor ou caminho de reorganização.

## Conexões Externas

- [[Camada MasterSense - Personagens da Dor]]
- [[MasterSense - Mentoria do HumanoSense]]
- [[HT - Conceito - Metodo Humanoterapeuta]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]
- [[Arquitetura do HumanoSense]]

## Referencia

ANDRESA MOLINA. *Conceito de Personagens da Dor*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/transcriptions/03 Código Humanosense  - Andresa Molina.md]]. Acesso em: 17 jun. 2026.
