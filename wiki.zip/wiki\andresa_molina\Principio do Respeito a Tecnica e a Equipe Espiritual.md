---
type: principio
author: Andresa Molina
tags: [tecnologia-espiritual, egregora, obediencia, respeito, metodo]
sources: ["[[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio do Respeito à Tecnologia Espiritual (A obediência à egrégora e o perigo do "fazer à moda da casa")

- **Definição**: A regra magna de obediência vibracional que proíbe o terapeuta de alterar, pular passos ou inventar procedimentos ("fazer à moda da casa") durante a sessão, sob o risco de quebrar o campo magnético de proteção e abrir brechas para obsessores.
- **Justificativa**: O Código Humanosense não é uma teoria humana maleável, mas uma tecnologia viva canalizada ("orientada por uma equipe espiritual"). A nível energético, cada palavra de comando e cada pulso magnético são senhas que sustentam a câmara astral do atendimento. A autora adverte severamente o terapeuta que se acha superior ao método. Se o profissional decide pular etapas por ego, ele destrói o selo de proteção da Egrégora do Espaço Humanidade. A partir desse momento, a equipe de luz se retira e o terapeuta fica desamparado, conectando-se a forças obscuras ("sabe lá com quem você tá conectando"). O respeito absoluto ao protocolo é o que garante que o terapeuta e o assistido permaneçam imunes às densidades acessadas durante a viagem astral da sessão.
- **Evidências**: "A técnica ela foi trazida e orientada por uma equipe espiritual... quando a gente entra no lugar de desrespeito, de fazer diferente do que foi orientado, de modificar as coisas, de querer recriar... a gente abre brecha para que entrem coisas que não são aquelas que vão fazer o trabalho... Andresa, posso pular um passo? Não. Anda, posso fazer a moda da casa? Eu vou inventar outra coisa? Não... Se você fizer diferente, a equipe espiritual vai falar assim: 'Bom, agora não sei mais quem te guia porque não sou mais eu.' Agora você tá por conta, por conta de quem? Sabe lá com quem você tá conectando."
- **Implicações**: O terapeuta deve manter obediência irrestrita aos protocolos canalizados do [[Conceito do Metodo HumanoSense|Método HumanoSense]], não devendo alterar comandos verbais nem atalhar etapas. A segurança espiritual de toda a sessão reside na integridade da egrégora ativada.
- **Conexões**: [[Conceito da Camara HumanoSense]], [[Tecnica de Enquadramento na Piramide]], [[Tecnica de Abertura e Conexao]]
- **Notas Pessoais**: A obediência à egrégora protege o terapeuta de se sobrecarregar magneticamente com as dores do assistido.

## Perguntas Frequentes / Didática de Atendimento

## Perguntas Frequentes / Didática de Atendimento

### 1. Como Andresa Molina justifica a proibição absoluta de alterar comandos ou pular passos no método Humanosense, explicando a nível energético o risco de abrir brechas para obsessores?
**Resposta**: A autora justifica a proibição afirmando que a técnica não é uma invenção humana, mas "foi trazida e orientada por uma equipe espiritual". A nível energético, os comandos exatos formam o "padrão que nos protege". Se o terapeuta tenta queimar etapas ou inventar algo ("fazer a moda da casa"), ele "abre brecha para que entrem coisas que não são aquelas que vão fazer o trabalho".

O risco de obsessão ocorre porque a quebra do protocolo afasta a egrégora de luz. Andresa alerta: "Se você fizer diferente, a equipe espiritual vai falar assim: 'Bom, agora não sei mais quem te guia porque não sou mais eu'". Sem esse escudo do Espaço Humanidade, o terapeuta fica "por conta" de forças obscuras ("Sabe lá com quem você tá conectando"), tornando-se uma "Massa de manobra fácil para obsessor".

## Referencia

ANDRESA MOLINA. *Princípio do Respeito à Tecnologia Espiritual*. Aula 06 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]].
