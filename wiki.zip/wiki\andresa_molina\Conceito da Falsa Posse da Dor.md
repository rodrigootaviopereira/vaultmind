---
type: conceito
author: Andresa Molina
tags: [somatização, empatia, captação-energética, confusão, 6a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito da Falsa Posse da Dor (Somatização por Captação)

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: A Falsa Posse da Dor é a ilusão cognitiva e frequencial na qual um indivíduo altamente sensível absorve em seu corpo biológico os sintomas físicos, estados de irritação, medos e angústias de terceiros ou de ambientes e, por falta de decodificação energética, assume que essas cargas são suas, buscando justificativas lógicas fictícias para validá-las.
- **Formulação de apoio**: Andresa explica que, quando o sensitivo não sabe que funciona como antena, ele entra em sintonia com a densidade do entorno e sofre dores reflexas (enjoo, dor de estômago, dor de cabeça súbita). Racionalmente, a pessoa tenta justificar o mal-estar dizendo: *"deve ter sido o que comi"*, *"bebi demais ontem"* ou *"eu fiz algo errado e por isso estou triste"*. Essa apropriação indevida da dor impede que a carga seja transmutada, pois a mente lógica passa a lutar contra um sintoma cuja causa é externa e informacional, instalando ciclos crônicos de somatização.

## Contexto de Uso

- Diagnosticado quando o assistido apresenta flutuações rápidas de humor ou mal-estar inexplicável após sair de shoppings, lojas, hospitais ou de diálogos tensos com sócios ou parceiros.

## Relação com Princípios

- [[Principio da Consciencia que Cura]]
- [[Principio do Chamado da Sensibilidade]]
- [[Principio da Memoria Corporal Inconsciente]]

## Exemplos do Material

- *"E aí você acha que é você, você acredita que você aconteceu, comeu alguma coisa que não te fez bem... só que na verdade você está sentindo o ambiente e as pessoas"*
- *"Mas e quando a gente fica triste do nada? [...] Será que essa tristeza é sua ou captou do ambiente das pessoas? [...] Porque não é racional, é uma captação energética"*

## Aplicação Prática

1. **Investigar a Mudança de Frequência**: Ensinar o assistido a notar o instante em que a sua energia oscilou. Perguntar: *"O que fizemos ou de quem falamos antes desse mal-estar aparecer?"*.
2. **Corte da Posse**: Fazer com que o assistido declare verbalmente e sinta no corpo a liberação de que aquela dor pertence ao campo de outro, devolvendo a carga ao fluxo original.
3. **Decodificação e Integração**: Utilizar a clareza intelectual para apontar a egrégora externa de onde a frequência densa (raiva, medo, nojo) foi captada, acionando a transmutação imediata do sintoma físico.

## Conexões Externas

- [[Tecnica de Alinhamento do Chamado]]
- [[Conceito de Clara Evidencia]]
- [[Conceito do Cuidado que Esgota]]

## Referência

ANDRESA MOLINA. *Conceito da Falsa Posse da Dor (Somatização por Captação)*. Aula 06 - Coordenada 6 (O Chamado Ignorado). Fontes: [[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. De que maneira a captação sensorial involuntária de ambientes e pessoas faz com que o indivíduo confunda sintomas alheios com processos emocionais e desequilíbrios próprios?
**Resposta**: A confusão ocorre porque a pessoa capta uma frequência densa que, a nível somático, se materializa imediatamente no próprio corpo como se fosse dela. A autora explica que você entra em um lugar e, **"do nada, entre aspas"**, pode sair de lá **"bocejando ou você tava super bem e aí você saiu de lá com dor de cabeça ou com dor nas costas ou com uma tristeza"**.

Como o cérebro tenta dar lógica a essa mudança física repentina, o indivíduo **"acredita que o que você sentiu é sobre você"**. Em vez de entender que absorveu (captou) a energia de uma conversa ou ambiente, a mente deduz racionalmente que **"comeu alguma coisa que não te fez bem"** ou que **"fez alguma coisa que foi errada"**, internalizando sintomas (como o enjoo ou a raiva) **"só que na verdade você está sentindo o ambiente e as pessoas"**.

