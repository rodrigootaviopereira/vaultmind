---
type: principio
author: Andresa Molina
tags: [criacao, magnetismo, polaridade, feminino-masculino]
sources: ["[[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]"]
---
# Princípio da Fusão Criacional (O Casamento Magnético do Masculino e Feminino)

- **Definição**: A lei universal que dita que nenhuma realities (projetos, relacionamentos, empresas ou dinheiro) pode se materializar no mundo sem o casamento perfeito e a integração entre as energias de expansão (Masculino) e de contenção (Feminino).
- **Justificativa**: A base da criação no Código Humanosense foca na polaridade energética que habita em todos os seres. Sem a fusão dessas duas polaridades internamente, o campo entra em falência magnética e os projetos entram em estagnação crônica.
- **Evidências**: "Toda a criação, toda masculina, feminina, homem, mulher, planta, gato, tudo tem essas duas forças que é a energia da expansão e a energia da contenção, fluxo e refluxo... Não tem como nascer nada. Seja um projeto, seja uma viagem, seja uma empresa, seja um cliente, se não tiver a fusão do feminino e masculino, não tem magnetismo. Se não tem magnetismo, não tem como vir a vida, nascer."
- **Implicações**: Tanto homens quanto mulheres precisam integrar o movimento de fluxo e refluxo em seus projetos para ativar a capacidade de atração e materialização.
- **Conexões**: [[Conceito de Energia Masculina]], [[Conceito de Energia Feminina]]
- **Notas Pessoais**: O equilíbrio das energias internas é o verdadeiro motor do magnetismo pessoal.

## Perguntas Frequentes / Didática de Atendimento

**Pergunta 2: Como a autora define as forces de "expansão" e "contenção" da criação e de que forma a falta de fusão de ambas impede fisicamente a vinda de relacionamentos, projetos ou dinheiro?**

A autora define essas duas forças como as polaridades presentes em absolutamente "toda criação". 
*   A **força de expansão (Energia Masculina)** é "a que inicia, direciona, age, propõe".
*   A **força de contenção (Energia Feminina)** é "a energia que acolhe, que sustenta, que nutre, que transforma".

A nível somático e energético, a vida obedece a um movimento fisiológico de "fluxo e refluxo" entre essas forças, comparado à "batida do coração, ele pulsa e volta... contração, contenção e expansão". 
Quando não há a fusão de ambas no campo vibracional de um indivíduo, a materialização é fisicamente impedida porque "não tem magnetismo". O magnetismo atua como a gravidade que atrai a matéria (dinheiro, projetos, relacionamentos). Andresa decreta a regra invisível: "Se não tiver a fusão do feminino e masculino, não tem magnetismo. Se não tem magnetismo, não tem como vir a vida, nascer. Você não vai atrair nada e você não vai construir nada sem magnetismo."

**Pergunta 3: O que acontece com o magnetismo pessoal de um indivíduo quando ele tenta forçar apenas o movimento masculino de semeadura ou o feminino de gestação no trabalho?**

O magnetismo pessoal da pessoa colapsa e ela vive num estado de estagnação. Andresa alerta: "Se um estiver em desequilíbrio, não tem como fundir".
*   **Forçar apenas o Masculino (Semeadura):** A pessoa tem a ideia, tem coragem e "vai lá e faz", mas a nível somático, falta o útero energético feminino para nutrir o peso desse projeto. Como a pessoa "não sustenta" a pressão contínua do tempo e do esforço, ela cede ao cansaço, seu feminino "dá chilique, um surto" (julga as próprias falhas) e, inevitavelmente, ela promove "abortos de coisas que foram semeadas", largando tudo no meio do caminho.
*   **Forçar apenas o Feminino (Gestação):** A pessoa foca apenas no mundo interno, na imaginação e na espera. Porém, como "se tiver muito mãe e pouco pai, não funde", ela carece do impulso e da "coragem" masculina para expor a ideia ao atrito do mundo real.

A consequência de tentar operar com uma polaridade apenas é o fracasso da criação, pois a autora resume que "Se não tem equilíbrio, não tem fusão. Se não tem fusão, não tem materialização".

## Referencia

ANDRESA MOLINA. *Princípio da Fusão Criacional (O Casamento Magnético do Masculino e Feminino)*. Aula 02 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]].
