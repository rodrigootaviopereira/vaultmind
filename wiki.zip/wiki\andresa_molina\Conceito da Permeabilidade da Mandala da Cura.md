---
type: concept
author: Andresa Molina
tags: [mandala-da-cura, permeabilidade, lugar-função-potência, diagnostico]
sources: ["[[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]"]
---

# A Permeabilidade da Mandala da Cura (O idioma universal do diagnóstico)

- **Definição**: O conceito estrutural que define a "Mandala da Cura" não como uma técnica isolada para o final da sessão, mas como a lente onipresente ("Lugar, Função e Potência" / "Habilidade, Disponibilidade e Autorização") através da qual o terapeuta explica e traduz todas as misérias do cliente do início ao fim.
- **Justificativa**: A autora explica que essa trindade é o "repertório" que dá direção. Somaticamente, a doença se instala porque a energia está distorcida nessas chaves. Se uma paciente deseja arrumar clientes (mas não divulga seu trabalho), a lente revela a falha: ela tem "Habilidade" (é boa terapeuta), mas falta a "Disponibilidade" de fazer o marketing. Se a filha não progride porque cuida do pai viúvo, a lente revela que ela perdeu o "Lugar e Função". O terapeuta desmistifica as histórias superficiais do cliente usando essas 6 âncoras para dar diagnóstico preciso durante a conversa inteira.
- **Evidências**: "A mandala da cura ela é um instrumento para ajudar você a ter repertório e dando direção durante todo o processo, né? Porque tudo que tem o seu lugar, função e potência... Habilidade, disponibilidade e autorização. Então, quando eu falei inclusive com a Patrícia que ela não estava, quando ela trouxe a questão de eh ela ser terapeuta... eu percebo que ela, como terapeuta, ela já tem a habilidade... Então, se falta ela ter clientes, está faltando possivelmente a disponibilidade de fazer o que precisa... Então ele vai permear todas as falas que vocês tiverem."
- **Implicações**: O terapeuta deve costurar a anamnese e a conversa prévia com o cliente sob a luz das 6 âncoras da Mandala da Cura.
- **Conexões**: [[Conceito do Eixo da Liberdade]], [[Conceito do Eixo da Realizacao]]
- **Notas Pessoais**: Enxergar a vida do cliente por Lugar, Função e Potência simplifica a detecção de autoenganos intelectuais.

## Perguntas Frequentes / Didática de Atendimento

### 9. Como a lente da "Mandala da Cura" permeia os diagnósticos na anamnese e na sessão?
**Resposta**: A Mandala da Cura atua como o mapa estrutural (**"um instrumento para ajudar você a ter repertório e dando direção"**) que desvenda as falhas sistêmicas que causam a dor da pessoa.

*   **Lugar, Função e Potência:** A nível somático e magnético, a dor se instala quando a biologia ocupa uma cadeira que não é sua: **"sempre que as coisas estão fora do lugar... a pessoa ela vai ter dificuldade na vida"**. Se uma filha vive **"tentando cuidar do pai... ela está tomando o lugar da mãe"**. O diagnóstico orgânico é fulminante: a pessoa adoece com uma sensação de vazio, e **"tudo isso vai desencadear uma dor"**.
*   **Habilidade, Disponibilidade e Autorização:** O terapeuta usa essa tríade para desmascarar a inércia do cliente. Se a paciente não tem clientes pagantes, a matriz expõe a verdade da estagnação: **"ela, como terapeuta, ela já tem a habilidade... Então, se falta ela ter clientes, está faltando possivelmente a disponibilidade de fazer o que precisa ser feito"**. A autora exige que essas duas tríades passem a **"permear toda narrativa"** e conduzam a investigação clínica da raiz do problema.


## Referencia

ANDRESA MOLINA. *A Permeabilidade da Mandala da Cura*. Aula 10 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]].
