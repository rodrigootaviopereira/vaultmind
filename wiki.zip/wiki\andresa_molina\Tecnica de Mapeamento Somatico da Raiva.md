---
type: tecnica
author: Andresa Molina
tags: [tecnica, 3a-coordenada, meditacao, corporal, raiva, desprogramacao, rastreamento, mapeamento-somatico]
sources: ["[[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]]"]
---

# Prática de Mapeamento Somático da Raiva

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]]

## Objetivo

- Identificar a coordenada ou local físico do corpo físico onde os bloqueios e memórias traumáticas estão armazenados, desviando das racionalizações lógicas para captar os impulsos mais rápidos e intuitivos do sistema nervoso através da memória somática.

## Pré-requisitos

- Disposição para acolher e reconhecer a existência da raiva e da dor sem tentar racionalizá-las ou julgá-las inicialmente.

## Passo a Passo

1. **Desligamento e Conexão**:
   - Respire profunda e lentamente, desconsiderando distrações externas e conectando toda a atenção para dentro de si mesmo.
2. **Evocação do Gatilho 1 (Expressão de Raiva)**:
   - Pergunte a si mesmo: *"Qual foi a última vez que senti raiva e permiti que ela saísse exatamente como raiva (sem tentar transformá-la em choro elegante, silêncio ou desculpas)?"*
3. **Evocação do Gatilho 2 (O Prejuízo/Culpa)**:
   - Traga à memória uma vez em que sua raiva não pôde ser contida, gerando um rompante ou conflito, e você acabou tendo um prejuízo real (uma perda de emprego, briga grave, um parceiro que foi embora, um amigo afastado).
4. **Leitura da Coordenada Somática**:
   - No exato instante da lembrança, não raciocine. Perceba instantaneamente onde essa dor "pesa", "puxa" ou "aperta" a sua atenção no corpo (ombros pesados, nó na garganta, ardência no estômago, dor de cabeça, aperto no peito). Essa região é a coordenada, a marca física que exigirá a reconsolidação energética para deixar de gerar ciclos de dor.

## Duração/Frequência

- Realizado durante o processo de diagnóstico de alinhamento das coordenadas na câmara ou sessão terapêutica HumanoSense.

## Indicadores de Sucesso

- Localização espontânea de desconfortos físicos no corpo associados às lembranças de culpa ou raiva.
- Desprendimento do fluxo mental lógico para uma percepção puramente somática.

## Variações

- O terapeuta pode guiar o assistido verbalmente tocando ou direcionando a atenção para áreas comuns de somatização.

## Conceitos Envolvidos

- [[Principio da Raiva como Potencial de Autonomia]]
- [[Conceito do Sistema RAGE]]
- [[Conceito da Raiva que Virou Culpa]]
- [[Conceito do Ciclo de Autopunicao]]

## Referência

ANDRESA MOLINA. *Prática de Mapeamento Somático da Raiva*. Aula 03 - Coordenada 3 (A Raiva que Virou Culpa). Fontes: [[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]].
