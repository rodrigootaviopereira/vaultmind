---
type: sintese
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, modulo_04, campo_eletromagnetico, radiestesia, mesa_quantionica]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_56_o_campo_eletromagnetico.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_57_o_que_e_radiestesia.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_62_mesa_quantionica.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_66_como_os_bloqueios_sao_formados.md]]"]
---

# HT - Modulo 04 - O Campo Eletromagnetico

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_56_o_campo_eletromagnetico.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_57_o_que_e_radiestesia.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_62_mesa_quantionica.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_66_como_os_bloqueios_sao_formados.md]]


## Nucleos do Modulo

- O pendulo entra como instrumento de convencao e resposta.
- A mesa quantionica ganha densidade teorica antes de virar pratica de consulta.
- Doenca e bloqueio aparecem como derivados de desorganizacao energetica.

## Síntese

- [INFERÊNCIA] HT - Modulo 04 - O Campo Eletromagnetico é uma nota de apoio dentro da wiki de Andresa Molina e precisa ser lida em conjunto com as aulas e mapas estruturais já conectados.

## Evidências do Material

- Ele aprofunda o HumanoSense no campo real dos atendimentos. - A aula 03 reforca que receber sem culpa e reconhecer o que ja chegou sao etapas centrais da maturidade terapeutica e relacional. - A aula 04 mostra que o terapeuta precisa modular linguagem, timing e intensidade para ajudar sem ferir a aliança com o assistido. ## Limite do Sistema - O MasterSense e uma camada de lapidacao do HumanoSense, nao uma tecnica-base separada do nucleo do metodo. - Para nao confundir MasterSense com Humanoterapeuta ou com o proprio HumanoSense, usar [[Mapa dos Sistemas Terapeuticos de Andresa Molina]]. ## Referencia ANDRESA MOLINA. *MasterSense - Mentoria do HumanoSense*. (MasterSense - Mentoria do HumanoSense)

## Conexões

- [[MasterSense - Mentoria do HumanoSense]]

## Referencia

ANDRESA MOLINA. *HT - Modulo 04 - O Campo Eletromagnetico*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_56_o_campo_eletromagnetico.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_57_o_que_e_radiestesia.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_62_mesa_quantionica.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_66_como_os_bloqueios_sao_formados.md]]. Acesso em: 17 jun. 2026.
