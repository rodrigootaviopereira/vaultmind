---
type: conceito
author: Andresa Molina
tags: [emocional, dependente, autonomia, culpa, prosperidade]
sources: ["[[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]"]
---

# Conceito do Dependente Emocional

- **Definição**: O padrão do campo emocional que entrega a própria autonomia em troca de companhia e confunde lealdade sistêmica com aprisionamento, sentindo-se incapaz de prosperar sozinho.
- **Justificativa**: O dependente sabota seu próprio avanço profissional, social ou financeiro por culpa de deixar seus entes queridos para trás ou medo de ser excluído do grupo caso mude de patamar.
- **Evidências**: "A primeira característica é o dependente. Ele entrega autonomia em troca de companhia. Ele tem medo de seguir sozinho. Ele confunde lealdade com prisão. Então o dependente ali é aquela pessoa que ele é tão dependente que ele só vai na vida se o outro for junto. [...] porque se ele for muito para frente, ele vai perder o círculo de amigos."
- **Implicações**: O terapeuta deve tratar a culpa somática do dependente para que ele se autorize a crescer independentemente da situação do seu entorno.
- **Conexões**: [[Principio da Mandala da Dor]]
- **Notas Pessoais**: Manifesta-se frequentemente em demissões abruptas quando a promoção está próxima.

## Referencia

ANDRESA MOLINA. *Conceito do Dependente Emocional*. Aula 03 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]].
