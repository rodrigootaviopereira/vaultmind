---
type: comparacao
tags: [paradigma, mecanicismo, sistêmico, fisica-quantica, materialismo]
sources: ["[[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_04_parte_i.txt]]"]
---

# COMPARAÇÃO: Paradigma Mecanicista vs. Paradigma Sistêmico

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_04_parte_i.txt]]

## Referencia

AUTOR DESCONHECIDO. *COMPARAÇÃO: Paradigma Mecanicista vs. Paradigma Sistêmico*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_04_parte_i.txt]]. Acesso em: 17 jun. 2026.
