---
type: conceito
author: Andresa Molina
tags: [personalidade, cobrador, passado, culpa, divida]
sources: ["[[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]"]
---

# Conceito do Cobrador da Dor

- **Definição**: A personalidade defensiva que utiliza o passado como moeda de troca e a culpa como ferramenta de controle, mantendo os outros em dívida emocional para assegurar o vínculo.
- **Justificativa**: O cobrador não consegue ou não deseja liberar as mágoas do passado, pois se libertar os outros das dívidas, perde o controle sobre eles. Somaticamente, sua energia vibra dívida e cobrança, puxando sua vida para trás.
- **Evidências**: "O cobrador. [...] Ele usa o passado como moeda de troca e culpa como ferramenta de controle. Então o cobrador é aquele que pega alguma coisa que aconteceu e traz sempre pro momento presente. [...] Ele não liberou todo mundo das dívidas. E se ele não libera as pessoas da dívida [...] ele continua vibrando a dívida. Então o que que ele vai ter? Dívida. Dívida cobrança. [...] Puxa a energia para trás."
- **Implicações**: Na clínica, identifica-se o cobrador quando a queixa financeira ou relacional é permeada por mágoas de infância e ressentimento de que o mundo lhe deve algo.
- **Conexões**: [[Conceito de Personalidade da Dor]], [[Principio da Mandala da Dor]]
- **Notas Pessoais**: Enquanto o explorador puxa para baixo, o cobrador puxa para trás.

## Referencia

ANDRESA MOLINA. *Conceito do Cobrador da Dor*. Aula 03 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]].
