---
type: conceito
author: Andresa Molina
tags: [autoesvaziamento, sobrevivencia, cuidado, care, infância, 5a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito do Modo Sobrevivência no Cuidado

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: O Modo Sobrevivência no Cuidado é uma dinâmica inconsciente na qual o sistema CARE (circuito neurobiológico do cuidado) passa a atuar regido pelo medo crônico de rejeição, exclusão ou morte física, em vez de operar por amor livre. O indivíduo associa a sua utilidade e a servidão às necessidades alheias com a garantia de merecimento de proteção e sobrevivência.
- **Formulação de apoio**: Este condicionamento é moldado na infância. A criança percebe que comportar-se bem, ser dócil e não dar trabalho alegra os cuidadores (mãe, pai, avós, professores). O sistema nervoso infantil, que conclui sua formação apenas aos 25 anos, interpreta a felicidade dos cuidadores como garantia de amparo e alimentação. Na vida adulta, o indivíduo automatiza essa trilha neural e assume responsabilidades alheias de forma compulsiva por pânico infantil subconsciente do desamparo.

## Contexto de Uso

- Usado para decodificar e diagnosticar a causa primária do esgotamento em assistidos que são "a âncora de todos" na família ou no ambiente de trabalho.

## Relação com Princípios

- [[Principio da Plenitude Energetica e do Cuidado]]
- [[Principio do Amor Condicionado e Autoabandono]]
- [[Principio da Memoria Corporal Inconsciente]]

## Exemplos do Material

- *"Você começou a cuidar de todo mundo para ser útil pras pessoas, para que elas amassem você. Então esse medo, esse desespero que você criou em você, ele acabou por fazer com que você entrasse no que hoje a neurociência chama de care, que é um sistema automatizado de cuidado. Só que quando a gente entra nesse sistema automático de cuidado por medo e não por amor... você faz porque tem que."*
- *"Mamãe fica tão feliz quando você é bonzinho... O sistema nervoso da criança não consegue entender diferente disso. E aí ele forma toda a estrutura dele baseado nessa utilidade... para poder sobreviver."*

## Aplicação Prática

1. **Rastrear o Gatilho Infantil**: Na anamnese ou regressão, ajudar o assistido a localizar quando seu cérebro de criança criou o pacto de que a sobrevivência dependia de não incomodar.
2. **Reconsolidação da Trilha**: Utilizar o processo de desipnose para reprogramar a memória celular ancestral e infantil, libertando o assistido da compulsão utilitária.
3. **Restabelecer a Plenitude**: Orientar o assistido a abrir a porta para receber cuidado e fechar o ciclo de autossupressão.

## Referência

ANDRESA MOLINA. *Conceito do Modo Sobrevivência no Cuidado*. Aula 05 - Coordenada 5 (O Cuidado que Esgota). Fontes: [[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. Qual é a diferença no nível de desgaste energético entre o "cuidar por amor livre" e o "cuidado automatizado por medo de rejeição" (sistema CARE em sobrevivência)?
**Resposta**: A diferença vital reside na "obrigação" e na "vontade", o que dita se a energia transborda ou seca.
*   **Cuidar por amor livre**: Quando você age de forma autêntica, *"você faz quando você tá com vontade e aí você faz porque você tá com vontade, você quer cuidar e aí você não fica cansado"*. O texto garante que *"quando você se sente feliz porque você faz por amor, você não se sente esgotado"*.
*   **Cuidado automatizado por medo de rejeição (Sistema CARE)**: O texto cita que o indivíduo entra no *"que hoje a neurociência chama de care, que é um sistema automatizado [...] de cuidado"*. A motivação não é o amor, mas um sistema ativado *"por medo de ser abandonado, de não ser amado, de não ser querido, de ser um incômodo"*.

O desgaste energético absurdo neste segundo cenário acontece porque cuidar se tornou uma questão de vida ou morte. O indivíduo deixa de agir com naturalidade e passa a fazer tudo *"porque tem que"*. A autora dita a regra: *"Toda vez que você faz uma coisa obrigado, você se sente esgotado"*. Para sobreviver nesse modo, a pessoa vira uma verdadeira *"âncora para todo mundo, você tá sustentando tudo para todo mundo E ninguém está vendo que você tá se afogando"*.

Como consequência energética prática, esse indivíduo se anula de tal forma que *"não sobrou nada para você, não sobrou energia para você"*, terminando em *"frangalhos"* e completamente *"vazio [...] do seu espírito"*.

### 2. De que maneira frases aparentemente inofensivas dos pais na infância (como "mamãe fica feliz quando você é bonzinho" ou "mamãe fica triste quando você faz malcriação") treinam o sistema nervoso da criança para a utilidade utilitária?
**Resposta**: Essas *"frases muito doces na infância"* atuam como a programação primária que correlaciona obediência à própria sobrevivência física e emocional da criança.

A autora explica que *"o sistema nervoso da criança não consegue entender diferente"* de uma equação muito prática: *"quando você é bonzinho, quando você é útil, quando você ajuda a mamãe [...] vai ficar feliz. Logo, se ela ficar feliz comigo, ela me dá uma recompensa"*.

A recompensa, nesse caso, não é um brinquedo, mas sim o afeto e os suprimentos para que ela continue viva: *"você receberia comida, você receberia afeto, você receberia cuidado"*. Como a mente da criança estava preocupada em evitar a morte e o abandono, ela *"forma toda a estrutura dele baseado nessa utilidade"*. O sistema nervoso é treinado, portanto, a acreditar que a utilidade cega é a única moeda de troca válida pelo amor e pela vida. Isso força o indivíduo, na vida adulta, a entrar no *"lugar automático de que se eu for útil, se eu cuidar, se eu for bonzinho [...] receberei amor"*, gerando a exaustão crônica da 5ª Coordenada.

### 3. Como o sistema CARE (de cuidado) se comporta e se expressa na vida diária quando a memória é reconsolidada com sucesso?
**Resposta**: Quando a memória celular é *"reconsolidada"* com sucesso, o sistema CARE (representado na transcrição foneticamente pela palavra *"quer"*) deixa de operar pelo *"medo de ser abandonado"*. A nível somático, a pessoa recupera a sua *"potência energética"* e o seu *"magnetismo"*.

Na vida diária, esse sistema curado se expressa pela liberdade e pela força vital. A pessoa passa a cuidar porque quer, e não por desespero de utilidade: *"você faz quando você tá com vontade e aí você faz porque você tá com vontade, você quer cuidar e aí você não fica cansado"*. Ao sair da exaustão obrigatória, ela se torna *"plena, preenchida, recheada dessa energia"*.

O transbordamento dessa energia atrai abundância magnética: os relacionamentos saudáveis, os clientes e o dinheiro (que vem atrelado a oportunidades) passam a chegar com força. O comportamento diário muda para gerenciar uma vida próspera, gerando *"outros problemas, entre aspas"*, como ter que escolher entre *"várias propostas de emprego"*, clientes abundantes ou lidar com um parceiro que *"vai exigir presença porque ele quer"* estar com alguém tão preenchido.


