---
type: principio
author: Andresa Molina
tags: [sagrado-feminino, gestacao, criacao, energia, bloqueios, prosperidade, 4a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]]"]
---

# Princípio da Gestação Feminina

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]]

## Definição

- **Definição**: O Princípio da Gestação Feminina postula que a energia feminina presente em cada indivíduo atua como o "útero" metafísico e magnético responsável por nutrir, gestar e sustentar qualquer projeto, sonho, relacionamento ou fluxo de prosperidade no plano físico.
- **Justificativa**: Se esse espaço uterino sutil estiver ocupado, machucado, ferido ou "sujo" com as invasões, problemas e demandas alheias que o indivíduo assumiu devido ao autoabandono, a energia criativa é asfixiada. Isso resulta em pequenos e constantes "abortos" energéticos, impedindo que qualquer nova ideia ou iniciativa dê frutos.

## Evidências

- *"Porque quem sustenta um filho por 9 meses é o feminino. Se você tiver com seu feminino machucado, ferido, abandonado, cheio de de vários projetos, pequenos abortos o tempo inteiro e ele tá cheio, sujo, precisa ser limpo, se você não tiver, você não consegue manifestar nada."*

## Implicações

- **Fracasso das Iniciativas (Masculino Solitário)**: Não importa o quanto o polo masculino do assistido seja forte para agir e ter novas ideias; sem a saúde e o espaço livre do polo feminino para reter e gestar esses projetos, eles falharão ou serão abandonados pela metade.
- **Exigência de Limpeza**: A recuperação da prosperidade exige a "curetagem emocional", limpando o lixo alheio assumido e expulsando as demandas que adoecem o espaço sagrado interno.

## Conexões

- [[Principio do Equilibrio de Forcas Masculino e Feminino]]
- [[Conceito do Abandono de Si]]
- [[Tecnica do Trabalho Energetico de Sangria]]

## Notas Pessoais

- Reservado para observações do usuário.

## Perguntas Frequentes / Didática de Atendimento

### Como a curetagem emocional limpa o útero da vida sagrado?
A curetagem emocional é um processo de limpeza profunda para restaurar a capacidade de criação do indivíduo. No ensinamento de Andresa, o "útero da vida" (ligado à energia do sagrado feminino) é o espaço magnético e energético responsável por gestar e sustentar qualquer projeto, sonho ou abundância na vida real.

Quando uma pessoa se abandona para atender às demandas de todos ao seu redor, ela permite que os outros invadam o seu espaço sagrado e despejem "lixo" emocional e abusos. Consequentemente, esse útero fica "sujo", machucado e preenchido com as exigências alheias, o que leva a pessoa a abortar repetidamente os próprios projetos e ideias no meio do caminho. A "curetagem" emocional atua limpando esse espaço e removendo essas marcas e bloqueios. Ao fazer essa limpeza profunda, o indivíduo se liberta, restaura a saúde do seu espaço de sustentação e volta a ter espaço livre para gestar e manifestar as coisas boas que realmente vêm do seu coração.

## Referência

ANDRESA MOLINA. *Princípio da Gestação Feminina*. Aula 04 - Coordenada 4 (A Mulher Antes de Ser de Todos). Fontes: [[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]].
