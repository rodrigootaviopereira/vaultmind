---
type: conceito
author: Andresa Molina
tags: [autoabandono, autossabotagem, vibracao, escassez, 2a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/02 - O AMOR QUE NUNCA VOLTOU - 2ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito do Abandono de Si (A Frequência do Abandono)

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/02 - O AMOR QUE NUNCA VOLTOU - 2ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: O Abandono de Si (ou Frequência do Abandono) é a dinâmica subconsciente pela qual o indivíduo abdica de sua identidade, necessidades, desejos e autenticidade para se moldar às expectativas e demandas alheias. Este ato de autoanulação emite uma frequência vibracional de abandono no campo energético do assistido, o que, por ressonância magnética, atrai pessoas que o rejeitam, traem ou abandonam no plano físico.
- **Formulação de apoio**: *"A partir do momento que você vira um vendedor para cada cliente, você já não sabe mais quem você é. Em algum lugar você passa a se abandonar. E quando você se abandona, você vai entregar tudo para o outro. E o que você vai ter em algum momento? O abandono do outro. Isso não é porque você é ruim... é porque você tem essa marca."*

## Contexto de Uso

- Aplicado para compreender a raiz das queixas de pessoas que se sentem constantemente "vítimas de ingratidão" ou que "dão tudo de si nas relações e são deixadas para trás". O terapeuta usa este conceito para demonstrar que a rejeição externa sofrida é um reflexo direto do autoabandono interno.

## Relação com Princípios

- [[Principio do Amor Condicionado e Autoabandono]]
- [[Principio da Causa Inconsciente e da Reconsolidacao]]
- [[Conceito das Camadas da Dor]]

## Exemplos do Material

- O assistido que tenta agradar a todos assumindo gostos que não possui (ex: *"dançar rock para um, samba para o outro"*), anulando sua própria personalidade por medo de perder a conexão.
- O outro que trai ou abandona o assistido está, na verdade, respondendo em nível vibracional ao comando de autoabandono que o próprio assistido já vinha executando contra si mesmo.

## Aplicação Prática

1. **Rastrear o Autoabandono**: Questionar o assistido sobre áreas da vida onde ele cede além de seus limites saudáveis para reter a atenção ou aprovação alheia.
2. **Reconhecer a Vibração**: Fazer o assistido compreender que o comportamento de salvador ou de agradador compulsivo emite a frequência de carência e abandono, gerando o efeito reverso nas relações.
3. **Cura pela Autoestima**: O tratamento energético deve focar em recuperar o amor e o cuidado por si mesmo (*"A primeira pessoa que precisa te amar quando você faz tudo errado é você"*), realinhando o campo para parar de emitir a frequência de abandono.

## Perguntas Frequentes / Didática de Atendimento

### O que Andresa ensina sobre a 4ª Coordenada?

Andresa ensina que a 4ª Coordenada se chama **"A mulher que eu era antes de ser de todos"**.

Essa coordenada aborda o processo extremo de autoperda e anulação da própria identidade, associado diretamente ao [[Conceito do Abandono de Si|Abandono de Si]]. Ela mapeia a dor do indivíduo que passou a vida se doando excessivamente para agradar, cuidar e atender às expectativas de todas as pessoas ao seu redor, até o ponto de se perder completamente de quem ele realmente é, caindo na armadilha do [[Principio do Amor Condicionado e Autoabandono|Princípio do Amor Condicionado e Autoabandono]].

O questionamento central dessa marca é o resgate da essência: **"Quem eu era antes de ter feito tudo isso? Sou de todo mundo, mas cadê eu? Quem sou eu?"**.

Como estudado no [[Conceito do Mapa da Alma|Mapa da Alma]], o trabalho nessa quarta etapa consiste em encontrar onde essa ferida de esvaziamento e anulação pessoal repousa fisicamente no corpo, compreendendo as raízes e os motivos inconscientes que forçaram a pessoa a abandonar a si mesma para pertencer aos outros. A desprogramação dessa marca abre espaço para a [[Tecnica de Resgate do Eu Sou Essencial|Técnica de Resgate do Eu Sou Essencial]] e a reintegração da potência pessoal.

## Referência

ANDRESA MOLINA. *Conceito do Abandono de Si (A Frequência do Abandono)*. Aula 02 - Coordenada 2 (O Amor que Nunca Voltou) e Aula 03. Fontes: [[raw/archive/andresa_molina/transcriptions/02 - O AMOR QUE NUNCA VOLTOU - 2ª Coordenada - O Mapa da Alma.md]] e transcrições complementares.
