---
type: conceito
author: Andresa Molina
tags: [pai-biologico, padrasto, transferencia-sistemica, material-genetico]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# A Transferência Sistêmica Biológica (O peso intransferível do Pai Biológico)

- **Definição Precisa**: A lei celular do Humanosense que dita que o elo e a função do pai biológico (responsável por entregar 50% do material genético do corpo físico do assistido) são imutáveis e intransferíveis, não podendo ser substituídos na biologia de defesa do corpo pelo amor do padrasto.
- **Sinônimos/Variações**: Primazia biológica dos pais, força genética sistêmica, elo do pai biológico.
- **Contexto de Uso**: Diagnosticado quando o assistido insiste que "seu padrasto é seu verdadeiro pai" para fugir da dor do abandono paterno biológico, mas continua apresentando severos bloqueios de atração financeira e reações violentas de defesa somática quando regras são impostas pelo padrastinho (*"Você não é meu pai. Você não manda em mim"*).
- **Relação com Princípios**: [[Principio da Aceitacao dos Fatos]], [[Principio da Influencia Parental na Atracao e Retencao]]
- **Exemplos do Material**: "Padrasto é padrasto. Não é pai ponto. Experimenta um padrasto que criou com todo amor. Um dia enfiar o dedo na cara daquela e vai falar: 'Não vai, você não vai fazer porque eu não quero'. Experimento para ver. Acabou. O papaizinho. Acabou. Você não é meu pai. Você não manda em mim. É assim, não existe e por mais afeto e amor que tenha, o padrasto é padraço... A dor que essa pessoa pode ter, ela tá muito relacionada com o pai e mãe, porque pai e mãe são quem entrega material genético pra gente. Não tem como."
- **Aplicação Prática**: Conduzir a investigação na mesa e na mandala focado no pai biológico, pois a liberação de força vital e a cura de traumas celulares de sobrevivência só se conectam à linhagem genética originária.
- **Conexões Externas**: [[Conceito da Representacao Paterna]], [[Conceito de Matar o Pai e a Mae]]

## Perguntas Frequentes / Didática de Atendimento

### 12. Por que Andresa Molina sustenta que o padrasto jamais substitui o elo biológico do pai no assistido?
**Resposta**: A autora destrói a ideia romântica de substituição argumentando através da inegável hierarquia da biologia. A nível somático e celular, "pai e mãe são quem entrega material genético pra gente. Não tem como". Por mais que o padrasto ofereça amor, a nível energético ele "tá cumprindo com uma função", mas "Padrasto é padrasto. Não é pai ponto".

A autora prova que o corpo humano reconhece essa distinção de DNA quando é exposto ao limite. Ela desafia: "Experimenta um padrasto que criou com todo amor. Um dia enfiar o dedo na cara daquela e vai falar: 'Não vai, você não vai fazer porque eu não quero'". A reação instintiva e agressiva de defesa da pessoa será a rejeição absoluta da autoridade não-biológica: "Você não é meu pai. Você não manda em mim". Por essa razão, a dor celular estrutural (abandono/rejeição) deve ser sempre investigada em relação ao pai verdadeiro que forneceu a genética.


## Referencia

ANDRESA MOLINA. *A Transferência Sistêmica Biológica*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
