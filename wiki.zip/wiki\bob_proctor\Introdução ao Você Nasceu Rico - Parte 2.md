---
type: transcricao
author: Bob Proctor
tags: [bob-proctor, introducao, persistencia, metas, riqueza]
sources: ["[[raw/transcriptions/Bob Proctor - Você nasceu rico (Seminário dublado) Introdução parte 2.md]]"]
---

# Introdução ao Você Nasceu Rico - Parte 2

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/transcriptions/Bob Proctor - Você nasceu rico (Seminário dublado) Introdução parte 2.md]]


## Síntese

A segunda parte aprofunda a persistência, a definição de metas e o uso de cartões/declarações como ferramenta de foco mental. O caso de Bob com o cartão de 25 mil dólares vira exemplo de compromisso com a própria visão.

## 80/20

- Persistência diferencia resultados.
- Definir o que quer com clareza muda o rumo.
- Repetição diária instala uma nova crença.

## Leitura Analítica

- O cartão funciona como dispositivo de foco e reprogramação.
- O texto reforça que saber e fazer são coisas diferentes.

## Conexões com a Wiki

- [[wiki/bob_proctor/Técnica da Fórmula de Alinhamento]]
- [[wiki/bob_proctor/Princípio das Cinco Leis da Criação]]

## Referencia

BOB PROCTOR. *Introdução ao Você Nasceu Rico - Parte 2*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/transcriptions/Bob Proctor - Você nasceu rico (Seminário dublado) Introdução parte 2.md]]. Acesso em: 17 jun. 2026.
