---
type: concept
author: Andresa Molina
tags: [dinamica-do-estagiario, transicao-de-carreira, experiencia, orgulho, humildade]
sources: ["[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"]
---

# A Dinâmica do "Estagiário" (O preço somático da inexperiência)

- **Definição**: O conceito orgânico de que toda transição (seja de carreira, país ou projeto) exige o rebaixamento voluntário do ego à condição de vulnerabilidade inicial ("o estagiário"), independentemente da idade biológica ou da senioridade passada do indivíduo.
- **Justificativa**: O paciente em transição frequentemente adoece porque quer os resultados da maestria sem pagar o pedágio do ridículo de quem está começando. A nível vibracional, a autora explica que não importa se a pessoa tem "40 anos de experiência" em outra área; na nova jornada, ela é uma estagiária. A mente tenta pular a fase de errar, cobrar barato, gaguejar ou "engolir água na piscina". O medo de fracassar na prática trava a manifestação do desejo. A cura reside na pessoa aceitar a sua pequenez temporária: "nas primeiras vezes vai ser ruim", abraçando a imperfeição da experiência sem peso ou vaidade.
- **Evidências**: "Quando a gente vai mudar de profissão, a gente é um estagiário, a gente pode ter 40 anos de experiência de uma profissão, na outra eu tô lá lá no comecinho de novo, não mudou nada. Eu posso até ter experiência de vida, mas naquela prática eu sou estagiária... E detalhe, nas primeiras vezes vai ser ruim, eu vou demorar um período para conseguir, vou engolir água, vou ficar desesperada... E aí você está me ajudando e eu te ajudo. Podemos combinar assim? E aí você tira aquele peso, né? E fica mais tranquilo, ele consegue movimentar."
- **Implicações**: O terapeuta deve orientar o cliente em transição a aceitar a vulnerabilidade e os pequenos passos, incluindo permutas ou treinos gratuitos.
- **Conexões**: [[Principio do Posicionamento de Valor]], [[Principio da Logica Invertida do Ego]]
- **Notas Pessoais**: O orgulho de querer começar no topo impede a pessoa de dar o primeiro passo básico na matéria.

## Perguntas Frequentes / Didática de Atendimento

### 3. Como a "Dinâmica do Estagiário" deve ser trabalhada somática e emocionalmente pelo terapeuta em transição de carreira?
**Resposta**: A transição exige que o terapeuta abandone o peso da sua senioridade passada e assuma fisicamente a vulnerabilidade do aprendiz. A autora exemplifica: "a gente pode ter 40 anos de experiência de uma profissão, na outra eu tô lá lá no comecinho de novo... naquela prática eu sou estagiária".

Para lidar com isso emocionalmente, o terapeuta deve aceitar o desconforto visceral dos primeiros passos, sabendo que "nas primeiras vezes vai ser ruim, eu vou demorar um período para conseguir, vou engolir água, vou ficar desesperada". A nível somático, ele precisa forçar o seu corpo a agir, precisando "se colocar no lugar de experiência, de experimentar, de vivenciar". Quando o terapeuta assume com honestidade para o outro que está treinando ("eu tô experimentando, eu quero aprender"), ele "tira aquele peso" da cobrança paralisante e consegue fluir na técnica.

### 5. De que forma o terapeuta deve propor permutas e treinos gratuitos no início do estágio?
**Resposta**: O terapeuta deve propor esses treinos retirando o peso da hierarquia financeira e sendo transparente sobre o seu estágio de aprendizado. Andresa orienta que a pessoa vá a campo para "fazer gratuito, fazer cobrando barato, fazer nas pessoas isso que você tá aprendendo".

A negociação energética é feita através de um acordo sincero de ajuda mútua: "por isso a gente pode falar que é um pouco mais barato, ou eu não quero cobrar nada, ou você me paga quanto você acha que vale... porque eu tô experimentando, eu quero aprender e eu preciso e aí você está me ajudando e eu te ajudo. Podemos combinar assim?". Essa postura limpa o campo magnético das cobranças e expectativas irreais, permitindo que o terapeuta iniciante "tira aquele peso, né? E fica mais tranquilo, ele consegue movimentar".


## Referencia

ANDRESA MOLINA. *A Dinâmica do "Estagiário"*. Aula 09 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]].
