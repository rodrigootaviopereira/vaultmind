---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_78_6a_lei_conducao_do_espirito_desdobrado_do_assistido_encarnado_para_hospital_do_plano_astral.md]]"]
---

# Cap 078 - 6A Lei Conducao Do Espirito Desdobrado Do Assistido Encarnado Para Hospital Do Plano Astral

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_78_6a_lei_conducao_do_espirito_desdobrado_do_assistido_encarnado_para_hospital_do_plano_astral.md]]

## Referencia

ANDRESA MOLINA. *Cap 078 - 6A Lei Conducao Do Espirito Desdobrado Do Assistido Encarnado Para Hospital Do Plano Astral*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_78_6a_lei_conducao_do_espirito_desdobrado_do_assistido_encarnado_para_hospital_do_plano_astral.md]]. Acesso em: 17 jun. 2026.
