---
type: tecnica
author: Andresa Molina
tags: [tecnica, autoanalise, 2a-coordenada, meditacao, conexao-corporal, rastreamento]
sources: ["[[raw/archive/andresa_molina/transcriptions/02 - O AMOR QUE NUNCA VOLTOU - 2ª Coordenada - O Mapa da Alma.md]]"]
---

# Técnica de Mapeamento do Amor Condicionado

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/02 - O AMOR QUE NUNCA VOLTOU - 2ª Coordenada - O Mapa da Alma.md]]

## Objetivo

- Rastrear e localizar no corpo físico a marca emocional gerada por dinâmicas de amor condicionado na infância e autoabandonos repetitivos, permitindo ao assistido identificar a causa raiz de suas frustrações afetivas (sensação de ser usado, traído ou deixado para trás) e traçar a rota para a reprogramação de tais padrões.

## Pré-requisitos

- Disposição para realizar a autoanálise sem autojulgamento, cobrando de si mesma o mesmo amor e cuidado dedicados aos outros.
- Atitude intuitiva (capturar a primeira resposta espontânea que surgir na mente ou no corpo).

## Passo a Passo

1. **Sincronização e Respiração**:
   - Sentar-se confortavelmente e fechar os olhos.
   - Executar a **Respiração em Três Tempos**: Inspirar profundamente pelo nariz, reter o ar nos pulmões por alguns segundos, soltar completamente pela boca e manter os pulmões vazios sem ar por um instante.
   - Repetir este ciclo de respiração **três vezes** consecutivas, retornando depois ao ritmo respiratório normal e relaxado.
2. **Pergunta de Identificação da Posição Relacional**:
   - Faça a seguinte pergunta reflexiva de olhos fechados: *"Nas suas relações mais importantes (afetivas, familiares, amizades, profissionais), você costuma ser aquela pessoa que sempre fica para trás, que sempre fica esperando, que cede mais do que os outros e acaba sendo deixada para trás?"*
   - Apenas observe e acolha a resposta que emergir, sem tentar analisá-la ou se culpar por ela.
3. **Mapeamento Corporal da Marca (Coordenada)**:
   - Investigue as reações físicas à pergunta anterior: *"Onde essa sensação ou memória de ser deixado para trás se concentra fisicamente no seu corpo?"*
   - Sinta onde a marca de dor se ativa (estômago, nó na garganta, olhos, peito, pernas, ombros, etc.). Registre esta coordenada física da memória emocional.
4. **Rastreamento Histórico do Condicionamento Infantil**:
   - Projete a atenção para a infância e responda mentalmente com sinceridade: *"Quando você era criança, você precisou ter algum comportamento específico para ser amada? Você precisou se condicionar a fazer determinadas coisas para não ser abandonada, machucada ou para ser querida?"*
   - Reflita sobre as exigências de conduta da família: *"O amor que te deram tinha condição? Você era amada pelo que você era (mesmo fazendo bagunça) ou apenas quando era boazinha, limpa e obediente?"*
5. **Registro das Coordenadas**:
   - Abra os olhos devagar e anote os dados revelados pelo corpo e pela memória:
     - *Localização corporal da dor* (Ex: aperto no peito, queimação no estômago).
     - *Dinâmica de condicionamento* (Ex: "só recebia elogios quando cuidava da casa ou tirava notas altas", "não podia chorar para não irritar minha mãe").
6. **Preparação para a Reconsolidação**:
   - Use estas coordenadas de dor como guia para o trabalho energético de reprogramação celular, voltando a este registro para alterar a frequência vibracional que emite o padrão de abandono.

## Duração/Frequência

- Executada como técnica diagnóstica e reflexiva na etapa de anamnese do HumanoSense (Coordenada 2).

## Indicadores de Sucesso

- Localização de marcas físicas associadas a dores afetivas.
- Identificação clara do papel de "boazinha" ou "salvadora" como um condicionamento de infância.
- Diminuição da autocobrança e do autojulgamento perante os próprios fracassos relacionais.

## Conceitos Envolvidos

- [[Principio do Amor Condicionado e Autoabandono]]
- [[Conceito do Sistema FER]]
- [[Conceito do Mapa da Alma]]

## Referência

ANDRESA MOLINA. *Técnica de Mapeamento do Amor Condicionado*. Aula 02 - Coordenada 2 (O Amor que Nunca Voltou). Fontes: [[raw/archive/andresa_molina/transcriptions/02 - O AMOR QUE NUNCA VOLTOU - 2ª Coordenada - O Mapa da Alma.md]].
