---
type: transcricao
author: Bob Proctor
tags: [bob-proctor, prosperidade, seminario, mentalidade, paradigmas]
sources: ["[[raw/transcriptions/Bob Proctor - Você nasceu rico (Mensagem sobre o Seminário).md]]"]
---

# Você nasceu rico - mensagem sobre o seminário

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/transcriptions/Bob Proctor - Você nasceu rico (Mensagem sobre o Seminário).md]]


## Síntese

A transcrição é uma peça promocional do seminário e do livro, mas traz a tese central de Bob Proctor: os paradigmas controlam os resultados da vida e mudar paradigmas muda relações, rendimento e prosperidade.

## 80/20

- Paradigmas controlam os resultados da vida.
- A informação precisa ser aplicada, não apenas lida.
- O seminário e o livro existem para ativar mudança de mentalidade.

## Leitura Analítica

- O material mistura divulgação com uma mensagem-chave sobre transformação pessoal.
- A ênfase não é em motivação superficial, mas em reprogramação de padrões mentais.

## Conexões com a Wiki

- [[wiki/bob_proctor/Princípio das Cinco Leis da Criação]]
- [[wiki/bob_proctor/Técnica da Fórmula de Alinhamento]]

## Referencia

BOB PROCTOR. *Você nasceu rico - mensagem sobre o seminário*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/transcriptions/Bob Proctor - Você nasceu rico (Mensagem sobre o Seminário).md]]. Acesso em: 17 jun. 2026.
