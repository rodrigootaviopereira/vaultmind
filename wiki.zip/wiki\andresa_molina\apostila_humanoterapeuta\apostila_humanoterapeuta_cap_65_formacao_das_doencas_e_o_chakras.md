---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_65_formacao_das_doencas_e_o_chakras.md]]"]
---

# Cap 065 - Formacao Das Doencas E O Chakras

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_65_formacao_das_doencas_e_o_chakras.md]]

## Referencia

ANDRESA MOLINA. *Cap 065 - Formacao Das Doencas E O Chakras*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_65_formacao_das_doencas_e_o_chakras.md]]. Acesso em: 17 jun. 2026.
