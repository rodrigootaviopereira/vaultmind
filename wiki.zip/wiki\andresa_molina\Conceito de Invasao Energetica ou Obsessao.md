---
type: conceito
author: Andresa Molina
tags: [espiritualidade, obsessao, livre-arbitrio, energia, campo-energetico, 7a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito de Invasão Energética ou Obsessão

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]]
  - Apoio histórico da trilha: [[HT - Modulo 06 - Espiritualidade Avancada]]

## Definição Precisa

- **Definição**: A Invasão Energética ou Obsessão é o ato de penetração, leitura ou drenagem da carga frequencial de um indivíduo sem o seu consentimento explícito e de forma compulsória. Ela constitui uma violação da barreira energética do livre-arbítrio, realizada tanto por consciências desencarnadas invasoras quanto por pessoas físicas encarnadas (obsessão de encarnado para encarnado, como em relacionamentos de manipulação narcísica).
- **Formulação de apoio**: Andresa Molina diferencia as dinâmicas de obsessão e amparo a partir do princípio da autorização. O obsessor atua como um "ladrão" de energia, invadindo o campo sem pedir licença e drenando a vitalidade, o tempo e os recursos (dinheiro) do indivíduo. Em contrapartida, os amparadores de luz e guias espirituais jamais entram no campo ou realizam intervenções sem que o assistido autorize explicitamente esse acesso e expresse o desejo sincero de cura ("o querer").

## Sinônimos/Variações

- Processo Obsessivo, Invasão de Campo, Vampirismo Energético, Infiltração Frequencial.

## Contexto de Uso

- Usado para identificar relacionamentos abusivos (obsessão narcísica entre encarnados), capturas energéticas que causam perdas financeiras crônicas, e processos de emaranhamento espiritual clássico que drenam a vitalidade do assistido.

## Relação com Princípios

- [[Principio do Consentimento e Invasao de Campo]]
- [[Principio da Responsabilidade Espiritual]]
- [[Principio da Ressonancia da Intencao]]

## Exemplos do Material

- *"quem invade o campo do outro sem autorização é o obsessor. Ele que não pede licença, ele que rouba sua energia sem falar se pode igual o ladrão... Então, ele rouba a sua energia invadindo o seu campo sem a sua autorização. Isso é obsessão, processo obsessivo. O amparador não fez isso..."*
- *"toda a espiritualidade de luz vai te respeitar. Quem não te respeita é obsessor, encarnado ou desencarnado, porque tem um monte de obsessão de encarnado para encarnado, narcísica de que quer que faça o que eu quero. Isso é obsessão."*

## Aplicação Prática

1. **Diagnóstico de Invasão entre Encarnados**: Identificar se o assistido vive sob a hipnose de um obsessor físico (narcisista, familiar cobrador) que tenta impor vontades e invadir o seu campo mental.
2. **Corte e Fechamento de Filtro**: Orientar o assistido highly sensitive a encerrar a ressonância passiva com obsessores, aplicando decretos de divórcio energético e autorizando explicitamente apenas a atuação dos amparadores de luz.
3. **Mapeamento do Consentimento**: Verificar na anamnese se o paciente quer, de fato, curar-se ou se está em conivência subconsciente com a drenagem energética por medo da solidão ou culpa familiar.

## Conexões Externas

- [[Conceito da 7a Coordenada]]
- [[Tecnica de Conexao com a Equipe Espiritual]]

## Referência

ANDRESA MOLINA. *Conceito de Invasão Energética ou Obsessão*. Aula 07 - Coordenada 7 (A Cura Buscada em Todo Lugar). Fontes: [[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. Sob a perspectiva espiritual e terapêutica da aula, qual é a definição dada à figura do "obsessor" e de que forma a obsessão se manifesta de forma análoga a um ladrão?
**Resposta**: Sob a ótica do texto, o "obsessor" é definido pela sua natureza invasora e predatória: "quem invade o campo do outro sem autorização é o obsessor. Ele que não pede licença, ele que rouba sua energia". 

A autora utiliza a metáfora literal do "ladrão" para explicar como essa drenagem somática e energética ocorre na prática. Assim como um ladrão avisa que "vou roubar a sua bolsa" e, mesmo que a vítima negue ("Hoje não, senhor ladrão"), ele "toma", o obsessor espiritual opera ignorando o livre-arbítrio. A nível vibracional, a obsessão acontece quando a entidade ou pessoa "invade o seu campo, pega a sua energia, que o seu dinheiro é energia [...] Ele rouba a sua energia invadindo o seu campo sem a sua autorização. Isso é obsessão, processo obsessivo".

### 2. Como Andresa diferencia o comportamento e o respeito dos amparadores espirituais em relação às dinâmicas obsessivas narcisistas e invasoras cometidas tanto por encarnados quanto por desencarnados?
**Resposta**: A diferenciação reside no limite do respeito e no uso do controle. Sobre as forças benevolentes, Andresa é categórica ao se referir à violação de fronteiras: "O amparador não fez isso". 

Em contrapartida, as dinâmicas invasoras não são exclusividade de espíritos trevosos sem corpo físico. A autora adverte que "Quem não te respeita é obsessor, encarnado ou desencarnado". A nível somático e relacional, essa dinâmica destrutiva entre pessoas vivas (encarnadas) é classificada como uma obsessão "narcísica". Ela se manifesta quando o outro exige dominação física e psicológica sobre o assistido ("quer que faça o que eu quero"). Portanto, o ato de tentar sobrepujar a vontade, o espaço ou o corpo de alguém para benefício próprio é caracterizado como um verdadeiro ato de obsessão diária.

