---
type: tecnica
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, tecnica, baralho_terapeutico, arquetipos, direcionamento]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_07_passo_6_baralho_terapeutico_direcionamento.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_126_baralho_cigano.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_132_as_cartas_do_baralho_terapeutico.md]]"]
---

# HT - Tecnica - Baralho Terapeutico

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_07_passo_6_baralho_terapeutico_direcionamento.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_126_baralho_cigano.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_132_as_cartas_do_baralho_terapeutico.md]]

## Objetivo

- [INFERÊNCIA] HT - Tecnica - Baralho Terapeutico organiza uma prática do sistema de Andresa Molina para transformar leitura da dor em condução, liberação, harmonização ou reorganização do campo.

## Pré-requisitos

- Presença do terapeuta.
- Respeito ao passo a passo, à ficha, ao campo e à autorização do assistido.
- Clareza sobre a questão central antes de aprofundar a técnica.

## Passo a Passo

1. Identificar a queixa, emoção dominante, afeto/desafeto ou ponto de entrada.
2. Relacionar a informação com ficha, corpo, mandala, personagem ou campo energético.
3. Aplicar a condução sem atropelar o assistido, mantendo escuta e conexão.
4. Observar sinais de liberação, resistência, repetição ou necessidade de aprofundamento.
5. Fechar com integração, retorno à consciência ou orientação prática quando aplicável.

## Duração/Frequência

- [INFERÊNCIA] Deve durar o suficiente para esgotar a camada acessada sem forçar uma profundidade que o assistido não sustenta naquele momento.

## Indicadores de Sucesso

- Maior clareza sobre a raiz da dor.
- Redução de confusão, defesa ou carga emocional.
- Sensação de fechamento, harmonização ou novo entendimento corporal/energético.

## Variações

- Pode ser adaptada conforme a mandala, ficha, câmara, mesa, baralho, humanometria ou técnica específica envolvida.

## Conceitos Envolvidos

- [[MasterSense - Mentoria do HumanoSense]]
- [[HT - Apostila Humanoterapeuta - Andresa Molina]]

## Evidências do Material

- Ele aprofunda o HumanoSense no campo real dos atendimentos. - A aula 03 reforca que receber sem culpa e reconhecer o que ja chegou sao etapas centrais da maturidade terapeutica e relacional. - A aula 04 mostra que o terapeuta precisa modular linguagem, timing e intensidade para ajudar sem ferir a aliança com o assistido. ## Limite do Sistema - O MasterSense e uma camada de lapidacao do HumanoSense, nao uma tecnica-base separada do nucleo do metodo. - Para nao confundir MasterSense com Humanoterapeuta ou com o proprio HumanoSense, usar [[Mapa dos Sistemas Terapeuticos de Andresa Molina]]. ## Referencia ANDRESA MOLINA. *MasterSense - Mentoria do HumanoSense*. (MasterSense - Mentoria do HumanoSense)
- Nesta wiki, as notas do Humanoterapeuta ficam nomeadas explicitamente como `Humanoterapeuta`. - Para uma visao integrada sem mistura de sistemas, usar [[Mapa dos Sistemas Terapeuticos de Andresa Molina]]. ## Leitura Integrada - O material sustenta uma visao tripla do ser humano: corpo, mente e espirito. - A cura e descrita como ganho de consciencia, desbloqueio energetico, tratamento espiritual e restabelecimento da informacao original. - A obra insiste na ordem, no metodo e na integridade da aplicacao. - O fechamento em cosmoetica impede que a tecnica seja lida apenas como instrumento de poder. ## Referencia ANDRESA MOLINA. *HT - Apostila Humanoterapeuta - Andresa Molina*. (HT - Apostila Humanoterapeuta - Andresa Molina)

## Notas Pessoais

- Reservado para registros de aplicação do usuário.

## Referencia

ANDRESA MOLINA. *HT - Tecnica - Baralho Terapeutico*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_07_passo_6_baralho_terapeutico_direcionamento.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_126_baralho_cigano.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_132_as_cartas_do_baralho_terapeutico.md]]. Acesso em: 17 jun. 2026.
