---
type: principio
author: Andresa Molina
tags: [posicionamento, valor, devolucao-financeira, energia-de-troca]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio do Posicionamento de Valor (A postura ética perante a fuga do cliente)

- **Definição**: A diretriz financeira e energética que desaconselha a devolução do valor da sessão a assistidos que abandonam o processo no meio por fuga da dor ou recusa em encarar a realidade indicada pelo pêndulo.
- **Justificativa**: O terapeuta reserva seu tempo, foco, egrégora e conhecimento técnico para conduzir a sessão. Se o assistido desiste por não suportar o choque da desilusão ("descobre que é uma mentira sem fim"), essa é uma decisão do livre-arbítrio dele. Tentar "salvá-lo" financeiramente por pena assume a responsabilidade sistêmica do outro, invalidando o aprendizado de sua própria autoria.
- **Evidências**: "Você não quer resolver problema dele. Eu não devolu tô aqui. Eu reservei o meu horário, o meu tempo, a minha disposição, a minha energia, a minha capacidade, a my egregor e você não quer. Isso é uma decisão sua. Eu não devolvo não... Ah, mas ela não vai voltar mais. Tá tudo bem. Não volta. Quem tá com problema, é você, não sou eu... eu não faço porque é o meu meu trabalho, é o meu é o valor de tudo isso que vocês estão... Se a pessoa não sabe o que que é ela que precisa aprender o que ela quer."
- **Implicações**: O terapeuta deve posicionar-se com autoridade material, cobrando antecipadamente e sustentando o valor cobrado mesmo em casos de desistência por orgulho ou medo do assistido.
- **Conexões**: [[Principio da Desilusao]], [[Tecnica de Precificacao e Duracao Teto]]
- **Notas Pessoais**: O dinheiro é o registro material do compromisso do cliente com o seu próprio processo de cura.

## Perguntas Frequentes / Didática de Atendimento

### 6. Por que o terapeuta não deve fazer a devolução financeira para clientes que decidem ir embora no meio da sessão?
**Resposta**: Andresa instrui que não se deve devolver o dinheiro porque o terapeuta já ancorou toda a estrutura física, vibracional e de tempo para a cura, cumprindo o seu papel: **"Eu reservei o meu horário, o meu tempo, a minha disposição, a minha energia, a minha capacidade, a minha egregor e você não quer. Isso é uma decisão sua. Eu não devolvo não"**.

A nível somático e energético, devolver o dinheiro por pena transfere a responsabilidade da fuga (do cliente) para o terapeuta. A postura correta é a ancoragem de quem não se mistura com o problema alheio: **"Quem tá com problema, é você, não sou eu. E quem não sabe resolver você. Eu sei"**. O terapeuta só deve devolver os valores se houver um genuíno e intuitivo incômodo no seu próprio corpo e campo energético rejeitando aquele dinheiro: **"Se você sentir por qualquer razão... meu sentido no meu coração é isso que eu fiz e eu senti de devolver. Ou aquela pessoa... ia mandar tanta energia queira para cima... que eu não quero nem aquela merda daquele dinheiro"**.


## Referencia

ANDRESA MOLINA. *Princípio do Posicionamento de Valor*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
