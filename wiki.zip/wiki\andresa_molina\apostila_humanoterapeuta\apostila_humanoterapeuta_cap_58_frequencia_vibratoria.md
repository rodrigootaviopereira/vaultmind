---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_58_frequencia_vibratoria.md]]"]
---

# Cap 058 - Frequencia Vibratoria

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_58_frequencia_vibratoria.md]]

## Referencia

ANDRESA MOLINA. *Cap 058 - Frequencia Vibratoria*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_58_frequencia_vibratoria.md]]. Acesso em: 17 jun. 2026.
