---
type: sintese
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, modulo_12, etica, moral, cosmoetica, amor]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_147_etica_moral_e_cosmoetica.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_148_a_etica.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_152_o_amor.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_153_conclusao.md]]"]
---

# HT - Modulo 12 - Etica Moral e Cosmoetica

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_147_etica_moral_e_cosmoetica.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_148_a_etica.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_152_o_amor.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_153_conclusao.md]]


## Nucleos do Modulo

- A formacao e encerrada por postura e nao apenas por procedimento.
- O amor aparece como fechamento da cosmologia e da pratica.
- A cosmoetica funciona como criterio superior de aplicacao.

## Síntese

- [INFERÊNCIA] HT - Modulo 12 - Etica Moral e Cosmoetica é uma nota de apoio dentro da wiki de Andresa Molina e precisa ser lida em conjunto com as aulas e mapas estruturais já conectados.

## Evidências do Material

- Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_01_apresentacao.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_03_metodologia_humanoterapeuta.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_147_etica_moral_e_cosmoetica.md]]. (HT - Apostila Humanoterapeuta - Andresa Molina)
- Nesta wiki, as notas do Humanoterapeuta ficam nomeadas explicitamente como `Humanoterapeuta`. - Para uma visao integrada sem mistura de sistemas, usar [[Mapa dos Sistemas Terapeuticos de Andresa Molina]]. ## Leitura Integrada - O material sustenta uma visao tripla do ser humano: corpo, mente e espirito. - A cura e descrita como ganho de consciencia, desbloqueio energetico, tratamento espiritual e restabelecimento da informacao original. - A obra insiste na ordem, no metodo e na integridade da aplicacao. - O fechamento em cosmoetica impede que a tecnica seja lida apenas como instrumento de poder. ## Referencia ANDRESA MOLINA. *HT - Apostila Humanoterapeuta - Andresa Molina*. (HT - Apostila Humanoterapeuta - Andresa Molina)
- Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_84_espiritualidade_avancada.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_85_tecnicas_energeticas_e_espirituais.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_89_principais_tipos_de_implantes.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_91_larvas_astrais_e_miasmas.md]]. (HT - Modulo 06 - Espiritualidade Avancada)

## Conexões

- [[HT - Apostila Humanoterapeuta - Andresa Molina]]
- [[HT - Modulo 06 - Espiritualidade Avancada]]

## Referencia

ANDRESA MOLINA. *HT - Modulo 12 - Etica Moral e Cosmoetica*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_147_etica_moral_e_cosmoetica.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_148_a_etica.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_152_o_amor.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_153_conclusao.md]]. Acesso em: 17 jun. 2026.
