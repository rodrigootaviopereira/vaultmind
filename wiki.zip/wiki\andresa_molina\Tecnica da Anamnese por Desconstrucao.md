---
type: technique
author: Andresa Molina
tags: [anamnese-por-desconstrucao, dor-raiz, sintese-do-sentimento, funil-investigativo]
sources: ["[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"]
---

# Prática da Anamnese por Desconstrução (O funil investigativo da dor raiz)

- **Definição**: O processo ativo de sondagem lógica onde o terapeuta não aceita a queixa superficial e utiliza perguntas sequenciais para espremer a verdade oculta até o paciente tropeçar na própria emoção originária de desamparo ou abandono.
- **Como praticar e seu Propósito**:
  1. **Interromper o Conceito Intelectual**: Quando o paciente diz que quer materializar algo (ex: "Quero materializar ser terapeuta e ter clientes"), o terapeuta desmembra a queixa: "o que que você gostaria de materializar? Viver de terapia ou ser terapeuta?".
  2. **Expor a Inversão**: Provar ao paciente como ele está projetando a segurança no dinheiro ou no cliente, em vez de atuar no seu campo sutil ("você tá querendo ter cliente para ele pagar para que você se sinta segura").
  3. **Identificar a Associação Livre**: Deixar o paciente fazer o link com a dor raiz infantil: "Não sei por que quando eu falo isso eu lembro do meu pai".
  O propósito é poupar a mesa radiestésica de operar numa ilusão periférica, ativando os comandos já com a dor real somática travada na mira da ficha.
- **Evidências**: "O que que é? E eu vou perguntando. Tá, mas como é que é isso? Mas você já é terapeuta? Você não é terapeuta, você queria ser. E aí, claro, conforme eu vou perguntando, eu vou sintetizando com ela aí o que ela o que ela busca... Então não é sobre materializar o ser terapeuta, você se sente terapeuta, você já é terapeuta, você não tem clientes, é sobre viver de terapia... Ah, então faz sentido dizer que é sobre confiança? ...E aí teve uma hora que do nada... ela falou: 'Não sei por quando eu falo isso eu lembro do meu pai'... E aí você vai encontrando um ponto."
- **Conexões**: [[Tecnica de Identificacao da Raiz na Anamnese]], [[Tecnica de Preenchimento da Ficha Cinza]]

## Perguntas Frequentes / Didática de Atendimento

### 16. Como o terapeuta deve guiar as perguntas para afunilar a queixa racional ("sintetizando") até a emoção raiz?
**Resposta**: A desconstrução da queixa ocorre por meio de um interrogatório que recusa a narrativa inicial do paciente. Quando a cliente afirma **"Eu quero materializar ser terapeuta"**, o terapeuta não aceita a afirmação e começa a testar a lógica da paciente: **"Tá, mas como é que é isso? Mas você já é terapeuta?"**.

A nível somático e mental, o terapeuta vai espremendo as defesas intelectuais para desmascarar a ilusão do ego, provando para a paciente que ela invertia a ordem magnética da cura: **"você inverteu o processo, você só vai ter clientes quando se sente segura... E você tá querendo ter cliente para ele pagar para que você se sinta segura"**. Ao continuar **"sintetizando com ela aí o que ela busca"**, o escudo racional cai, e a verdadeira dor visceral emerge espontaneamente: **"ela falou: 'Não sei por quando eu falo isso eu lembro do meu pai da minha ver um sentimento'"**.


## Referencia

ANDRESA MOLINA. *Prática da Anamnese por Desconstrução*. Aula 09 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]].
