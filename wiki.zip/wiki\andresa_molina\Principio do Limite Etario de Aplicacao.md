---
type: principio
author: Andresa Molina
tags: [limite-etario, criancas, consciencia-ativa, maturidade]
sources: ["[[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio do Limite Etário de Aplicacao (A exigência de consciência biológica)

- **Definição**: A regra de seleção de pacientes que desautoriza a aplicação do transe do Código Humanosense em crianças pequenas, reservando a tecnologia apenas para aqueles que possuem a maturidade neurológica e moral para responder pelas próprias escolhas.
- **Justificativa**: O Humanosense não é um passe magnético passivo; ele exige que o paciente observe a própria dor, enfrente o agressor na mente e decida por conta própria perdoar ou agir. A nível de desenvolvimento somático, "não dá para fazer em criança", pois ela não tem os contornos de identidade do ego formados para realizar a "desipnose". A autora define que o limite não é uma idade exata na certidão, mas a emergência da consciência ativa (frequentemente a partir dos 12, 13 ou 14 anos), onde o indivíduo já tem densidade existencial para sustentar o próprio corpo perante as escolhas do destino.
- **Evidências**: "Temos ter algum padrão de idade para começar a fazer esta terapia nas pessoas? ...A partir da data que ela tem a consciência de fazer isso, né? ...não dá para fazer em criança, né? Porque ela não vai eh esse processo é melhor que a gente faça em pessoas que consigam responder por si só, por si mesma. E aí tem crianças de 13, 14 anos que sim conseguem. Eu conseguiria com 13 anos tranquilamente... é mais de conseguir perceber se a adolescente, né, quer e tá disposto a ir nesse lugar e encontrando um caminho com ele."
- **Implicações**: Casos infantis devem ser tratados com outras abordagens, ou tratando-se os pais primeiro para desobstruir o campo.
- **Conexões**: [[Principio do Consentimento e Invasao de Campo]], [[Conceito da Fantasia de Salvamento Infantil]]
- **Notas Pessoais**: Forçar uma mente infantil a responder por escolhas multidimensionais antes da formação do ego pode colapsar sua segurança neurológica.

## Perguntas Frequentes / Didática de Atendimento

### 4. Quais são as limitações de idade impostas à aplicação e o critério para adolescentes?
**Resposta**: A autora impõe que "não dá para fazer em criança". A limitação de idade não está em um número fixo, mas na maturidade biológica e psíquica, "a partir da data que ela tem a consciência de fazer isso".

O critério clínico para avaliar se um adolescente suporta o desdobramento é verificar se ele consegue "responder por si só, por si mesma". A nível somático e mental, a estruturação do ego varia: "tem crianças de 13, 14 anos que sim conseguem... e tem criança de 15, 16 que não consegue". O terapeuta avalia a prontidão percebendo se o adolescente "quer e tá disposto a ir nesse lugar" para sustentar sua própria cura na Câmara.


## Referencia

ANDRESA MOLINA. *Princípio do Limite Etário de Aplicação*. Aula 10 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]].
