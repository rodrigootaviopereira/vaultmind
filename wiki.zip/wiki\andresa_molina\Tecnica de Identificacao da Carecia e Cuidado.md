---
type: tecnica
author: Andresa Molina
tags: [tecnica, autoanalise, 5a-coordenada, conexao-corporal, rastreamento, care]
sources: ["[[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]]"]
---

# Técnica de Identificação da Carência e Cuidado

## Objetivo

- Rastrear e decodificar a coordenada do "Cuidado que Esgota" no Mapa da Alma do assistido, identificando o momento inicial em que seu sistema CARE foi automatizado no medo e mapeando a resistência física a receber nutrição.

## Pré-requisitos

- Um ambiente de escuta compassiva e introspecção.
- Permissão para acessar e acolher sentimentos infantis de medo de rejeição sem julgamento lógico.

## Passo a Passo

1. **Evocação do Registro de Amparo**:
   - Sentar-se de olhos fechados e respirar pausadamente.
   - Formular a seguinte pergunta-gatilho ao subconsciente: *"Qual foi a última vez que alguém cuidou de você da mesma forma que você cuida dos outros?"*.
2. **Leitura e Acolhimento do Bloqueio**:
   - Notar a primeira reação ou resposta imediata (ex: *"faz muito tempo"*, *"nunca aconteceu"*, *"só quando fiquei doente"*).
   - Não tentar justificar ou racionalizar por que as coisas aconteceram assim. Apenas registre a resposta.
3. **Mapeamento do Sistema CARE Automatizado**:
   - Recordar as dinâmicas e frases da infância que instalaram o padrão de utilidade (ex: *"seja bonzinho para a mamãe ficar feliz"*, *"não dê trabalho"*).
   - Identificar onde no corpo físico reside a tensão ou o vazio gerados por estar sempre atuando no automático como a "âncora" dos outros.
4. **Desprogramação do Fluxo de Recebimento**:
   - Conectar-se com a equipe espiritual e de amparo para permitir que o fluxo de amor e cuidado penetre nas barreiras do corpo físico, liberando a resistência e a culpa em ser cuidado.

## Duração/Frequência

- Executada como diagnóstico prático durante a sessão terapêutica HumanoSense ao abordar a 5ª Coordenada.

## Indicadores de Sucesso

- Identificação nítida de emaranhamentos de utilidade infantil ("cuidar para sobreviver").
- Percepção somática e libertação do bloqueio no peito ou estômago ao se dar permissão para ser cuidado.
- Reconexão com a força da alma além das narrativas lógicas criadas pelo ego.

## Conceitos Envolvidos

- [[Conceito do Cuidado que Esgota]]
- [[Conceito do Modo Sobrevivencia no Cuidado]]
- [[Principio da Plenitude Energetica e do Cuidado]]

## Referência

ANDRESA MOLINA. *Técnica de Identificação da Carência e Cuidado*. Aula 05 - Coordenada 5 (O Cuidado que Esgota). Fontes: [[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]].
