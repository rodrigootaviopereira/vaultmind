---
type: conceito
author: Andresa Molina
tags: [mesa, mandalas, radiestesia, ancoragem]
sources: ["[[raw/archive/transcriptions/01 - Aula Inaugural - HumanoSense - Andresa Molina.md]]"]
---

# Conceito da Mesa HumanoSense

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/transcriptions/01 - Aula Inaugural - HumanoSense - Andresa Molina.md]]

## Definição Precisa

- **Definição**: [INFERÊNCIA] Conceito da Mesa HumanoSense nomeia um eixo recorrente da obra de Andresa Molina que deve ser lido dentro do HumanoSense/Humanoterapeuta como categoria de diagnóstico, leitura de campo ou condução terapêutica.
- **Formulação de apoio**: Use o método como ligação entre diagnóstico, condução e reintegração. ## Relação com a Série - O `Mapa da Alma` fornece a leitura da origem da dor. - O `Método HumanoSense` organiza a prática. - A `Mesa` e a `Câmara` são os espaços operativos da técnica. - A `Ficha` e a `Anamnese` mantêm a sessão centrada na raiz. ## Referência ANDRESA MOLINA.

## Sinônimos/Variações

- [INFERÊNCIA] Varia conforme a aula: pode aparecer como campo, código, mandala, personagem, sistema, memória, técnica ou postura terapêutica.

## Contexto de Uso

- Usado para orientar leitura do assistido, organização da sessão, compreensão de padrões emocionais/energéticos e conexão entre método, ficha, mesa, câmara e condução espiritual.

## Relação com Princípios

- [[Arquitetura do HumanoSense]]

## Exemplos do Material

- Use o método como ligação entre diagnóstico, condução e reintegração. ## Relação com a Série - O `Mapa da Alma` fornece a leitura da origem da dor. - O `Método HumanoSense` organiza a prática. - A `Mesa` e a `Câmara` são os espaços operativos da técnica. - A `Ficha` e a `Anamnese` mantêm a sessão centrada na raiz. ## Referência ANDRESA MOLINA. (Arquitetura do HumanoSense)
- Esta nota existe para impedir que esses elementos fiquem soltos em arquivos isolados. ## Eixos - [[Conceito do Mapa da Alma]] - [[Conceito do Metodo HumanoSense]] - [[Conceito da Mesa HumanoSense]] - [[Conceito da Ficha de Identificacao e Sintese da Dor]] - [[Conceito da Camara HumanoSense]] - [[Tecnica de Identificacao da Raiz na Anamnese]] - [[Tecnica de Aplicacao Guiada na Camara HumanoSense]] - [[Mapa Estrutural da Wiki Andresa Molina]] ## Aplicação Prática 1. (Arquitetura do HumanoSense)

## Aplicação Prática

- [INFERÊNCIA] Ao encontrar este tema em atendimento, use-o como pergunta de aprofundamento: onde ele aparece na queixa, no corpo, na ficha, no afeto/desafeto e na relação entre consciência e inconsciente?
- [INFERÊNCIA] Verifique se a pessoa está usando este padrão como defesa, fuga, repetição de dor ou caminho de reorganização.

## Conexões Externas

- [[Arquitetura do HumanoSense]]

## Referencia

ANDRESA MOLINA. *Conceito da Mesa HumanoSense*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/transcriptions/01 - Aula Inaugural - HumanoSense - Andresa Molina.md]]. Acesso em: 17 jun. 2026.
