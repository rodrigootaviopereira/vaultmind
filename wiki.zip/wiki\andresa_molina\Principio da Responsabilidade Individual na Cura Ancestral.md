---
type: principio
author: Andresa Molina
tags: [cura-ancestral, voto-de-pobreza, quebra-de-contrato, isolamento-carmico]
sources: ["[[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio da Responsabilidade Individual na Cura Ancestral

- **Definição**: A premissa espiritual brutal de que quebrar um pacto ou contrato limitante (como um voto de escassez feito por um avô) liberta exclusivamente o indivíduo que pede o tratamento, mantendo o restante da linhagem na mesma vibração se eles assim escolherem.
- **Justificativa**: Muitos pacientes desejam "curar a árvore genealógica inteira". A autora destrói essa invasão de livre-arbítrio. Se uma matriarca fez um pacto de pobreza, o assistido pode desfazer esse laço para si mesmo, quebrando o duto de lealdade. Contudo, a nível energético, "Ancestral vai ficar pobre". O peso psicológico dessa técnica é que o paciente precisará tolerar a culpa biológica de crescer, ficar rico e estruturado, enquanto assiste passivamente a mãe e a família inteira continuarem "na lama", pois o destino deles pertence apenas a eles mesmos.
- **Evidências**: "Ancestral fez o voto de pobreza... Dá para fazer para se? ...Ela vai ter que lidar porque se a ancestral fez e ela não quer mais, não significa que a ancestral vai desfazer. Ela que não quer. Ancestral vai ficar pobre. Então pode ser que a mãe dela fique lá na lama e ela não. Essa é a resposta que ela precisa ter conhecimento... ela vai fazer para ela, só que ela vai ter que lidar com a família pobre e ela ficando melhor. Isso é uma coisa que ela vai ter que lidar, entendeu? Ela vai ter que lidar com isso, trabalhar terapeuticamente."
- **Implicações**: O terapeuta deve preparar emocionalmente o cliente para os choques do seu próprio sucesso isolado da egrégora familiar biológica.
- **Conexões**: [[Principio da Hierarquia dos Papeis]], [[Conceito da Falsa Culpa Sistemica]]
- **Notas Pessoais**: A individuação exige a coragem de ser feliz sozinho quando o clã rejeita a abundância.

## Perguntas Frequentes / Didática de Atendimento

### 12. Por que a quebra de um contrato de pobreza desfaz o voto exclusivamente para o assistido, e como a egrégora lida com a família?
**Resposta**: A quebra atua exclusivamente no assistido porque o livre-arbítrio dos demais membros da linhagem é soberano e inviolável. A autora esclarece que o desfazimento individual não arrasta quem não pediu socorro: **"se a ancestral fez e ela não quer mais, não significa que a ancestral vai desfazer. Ela que não quer. Ancestral vai ficar pobre"**.

A egrégora lida com a família mantendo-a exatamente onde ela escolheu (ou aceitou) vibrar. O terapeuta não salva ninguém à força. A autora é brutalmente franca sobre essa separação cármica: **"pode ser que a mãe dela fique lá na lama e ela não... aquelas que quiserem continuar com esse contrato v e ela vai ter que ter a autorização de seguir e viver"**.

### 13. Qual a carga emocional que o assistido precisa tolerar após quebrar individualmente um pacto de escassez?
**Resposta**: A nível emocional e psíquico, a carga que o indivíduo precisa tolerar é o peso da culpa e a dissonância de assistir aos seus entes queridos sofrerem enquanto ele prospera isoladamente.

A autora decreta que não basta desfazer a magia na mesa; o assistido precisa suportar a nova realidade física na sua biologia: **"ela vai fazer para ela, só que ela vai ter que lidar com a família pobre e ela ficando melhor"**. O trabalho terapêutico contínuo ("daqui para frente") será focado em dar sustentação para que a pessoa suporte essa fratura na lealdade familiar sem voltar a adoecer ou se autossabotar por pena: **"Isso é uma coisa que ela vai ter que lidar, entendeu? Ela vai ter que lidar com isso, trabalhar terapeuticamente, isso que é importante"**.


## Referencia

ANDRESA MOLINA. *Princípio da Responsabilidade Individual na Cura Ancestral*. Aula 10 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]].
