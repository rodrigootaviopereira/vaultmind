---
type: conceito
author: Andresa Molina
tags: [extraterrestres, povos-das-estrelas, consciencia, encarnacao]
sources: ["[[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]]"]
---

# Espíritos Terrestres vs. Extraterrestres (A distinção consciencial baseada na encarnação terrena)

- **Definição Precisa**: A conceituação terapêutica que define "extraterrestres" não como seres físicos alienígenas de ficção, mas estritamente como Consciências ou Espíritos elevados ("povos das estrelas") que auxiliam a egrégora do HumanoSense, cuja única diferença em relação aos espíritos "terrestres" é o fato de nunca terem habitado um corpo biológico de carbono no planeta Terra.
- **Sinônimos/Variações**: Consciências Estelares, Povos das Estrelas vs. Espíritos Terrestres.
- **Contexto de Uso**: Explicado didaticamente para diferenciar o tipo de auxílio vibracional na mesa: espíritos que já encarnaram na Terra (como Orixás e Ancestrais) detêm o comando químico e telúrico sobre os elementos/elementais da natureza (fogo, terra, água), enquanto os extraterrestres dominam as tecnologias dimensionais e magnéticas avançadas baseadas em DNA cósmico.
- **Relação com Princípios**: [[Principio da Inteligencia Espiritual]]
- **Exemplos do Material**: "O que a gente chama de extraterrestres, que são aqueles que nunca encarnaram na terra, são espíritos, OK? Consciência. E qual é a diferença de uma consciência que já encarnou e uma consciência que não encarnou? Nenhuma. A que já encarnou, ela tem conhecimento dos elementos elementais elementares da natureza, que são os orixás... E os que a gente chama de extraterrestres são espíritos que aqui nunca habitaram, nunca encarnaram, mas espíritos, entende?"
- **Aplicação Prática**: Ao sintonizar a mesa, o terapeuta integra ambas as forças: utiliza a alquimia dos espíritos terrenos para manipular a matéria biológica do assistido e as tecnologias estelares das consciências extraterrestres para reconfigurar padrões de DNA multidimensional.
- **Conexões Externas**: [[Conceito de Invasao Energetica ou Obsessao]], [[Conceito da Mesa HumanoSense]]

## Perguntas Frequentes / Didática de Atendimento

## Perguntas Frequentes / Didática de Atendimento

### 8. De que forma Andresa Molina conceitua a distinção entre "Espíritos Terrestres" (como Orixás e Ancestrais) e "Extraterrestres" no que tange ao domínio de elementos naturais e tecnologias de DNA?
**Resposta**: Andresa destrói qualquer mística hierárquica informando que extraterrestres **"são aqueles que nunca encarnaram na terra"**, mas que na base existencial absoluta, ambos **"são espíritos, OK? Consciência"**. Ela questiona: **"E qual é a diferença de uma consciência que já encarnou e uma consciência que não encarnou? Nenhuma"**.

Contudo, a nível de atuação técnica e somática sobre os corpos humanos, há uma vasta especialização:
*   **Espíritos Terrestres (Ancestrais e Orixás):** Por terem vivido na densidade da matéria, a consciência **"que já encarnou, ela tem conhecimento dos elementos elementais elementares da natureza"**. Eles compreendem a biologia bruta do planeta, trazendo o saberes da **"medicina da floresta"** e decodificando **"qual é a flor, qual é a erva"** necessária para o indivíduo.
*   **Extraterrestres (Povos das Estrelas):** Como nunca se limitaram a um corpo de carbono terrestre, eles manipulam as matrizes sutis do corpo, sendo invocados **"para trabalhar nas tecnologias, para trabalhar em base de DNA, para trabalhar e fazer a reconexão com a própria essência"**.

## Referencia

ANDRESA MOLINA. *Espíritos Terrestres vs. Extraterrestres*. Aula 06 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]].
