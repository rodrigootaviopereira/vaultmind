---
type: concept
author: Andresa Molina
tags: [ilusao-do-arquetipo, guerreira, donzela, gap-vibracional, autoengano]
sources: ["[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"]
---

# A Ilusão do Arquétipo (Guerreira vs. Donzela)

- **Definição**: A constatação diagnóstica do "Gap Vibracional" onde o paciente jura conscientemente estar encarnando a força da ação incessante (A Guerreira), enquanto o seu corpo magnético, revelado pelo pêndulo, opera em absoluta estagnação passiva (A Donzela).
- **Justificativa**: Somaticamente, o paciente sofre e relata estar esgotado ("Eu estudo muito, eu luto, não tenho sorte"). A mente lógica dele mascara a paralisação real ("Eu não aplico, não atendo ninguém") com "falso movimento" (estudar excessivamente, fazer teorias). Na mesa, se a pessoa responde nota 8 para "batalhar" e a régua corta no 4, a egrégora expõe o autoengano. A autora desmascara isso: "você acredita que está na guerreira, mas inconscientemente não tá. Você tá aguardando, tá esperando o movimento do nada". A dor da pessoa não nasce de lutar e perder, mas da ilusão de achar que está lutando quando está encolhida no medo de tentar.
- **Evidências**: "Você acredita que tá muito alerta, que você acredita que faz isso, mas na verdade você não faz. Você não, inconscientemente você acredita que você está batalhando, porque esse é o aspect da guerreira... Então você acredita que está na guerreira, mas inconscientemente não tá. Você tá aguardando, tá esperando o movimento do nada. Então isso causa dor... Causa dor porque eu fico imaginando que tá saindo uma coisa, só que na verdade não tá... eu percebo que você não está tão na guerreira, você tá na donzela porque você tá acreditando que tá fazendo uma coisa que não tá."
- **Implicações**: O terapeuta deve usar a testagem do pêndulo para confrontar o cliente com seu real estado de paralisia.
- **Conexões**: [[Conceito do Gap Vibracional]], [[Conceito de Guerreira e Donzela]]
- **Notas Pessoais**: Estudar sem praticar é o refúgio clássico da Donzela disfarçada de Guerreira.

## Perguntas Frequentes / Didática de Atendimento

### 4. Por que o acúmulo de estudos teóricos atua como uma barreira que impede o terapeuta iniciante de ir para a linha de frente do campo prático?
**Resposta**: O excesso de estudos cria uma perigosa ilusão no corpo e na mente (o aspecto do arquétipo da Guerreira). A paciente relata que estuda há mais de um ano, acreditando que está agindo, mas a autora revela pelo pêndulo: "inconscientemente você acredita que você está batalhando, porque esse é o aspecto da guerreira... mas inconscientemente não tá. Você tá aguardando".

A nível somático, a teoria não aciona a memória celular e vibracional necessária para ancorar o método ("se pôr na linha de frente"). A autora usa a metáfora do nadador para provar essa barreira orgânica: "Não adianta eu aprender na teoria como é que bate o braço, como é que respa, como é que vira a cabeça... eu só vou conseguir nadar me jogando na piscina". Estudar sem aplicar aprisiona a pessoa na inércia, o que "causa dor porque eu fico imaginando que tá saindo uma coisa, só que na verdade não tá".

### 11. Como o pêndulo desmascara a "ilusão" da Guerreira em clientes que operam na estagnação da Donzela?
**Resposta**: O pêndulo desmascara essa ilusão expondo o abismo vibracional entre a resposta falada e a medição do inconsciente. O terapeuta lê que, conscientemente, a pessoa dá a nota "oito" e "acredita que tá muito alerta".

Somaticamente e energeticamente, a mente lógica da pessoa tenta convencê-la de que está lutando ("inconscientemente você acredita que você está batalhando, porque esse é o aspecto da guerreira"). Contudo, o pêndulo corta em "quatro", provando que o corpo físico está paralisado na inércia: "Você tá aguardando, tá esperando o movimento do nada". O terapeuta esfregará essa inconsistência na cara do assistido para curá-lo: "você não está tão na guerreira, você tá na donzela porque você tá acreditando que tá fazendo uma coisa que não tá. Então você tá meio iludida sobre a sua própria maneira de viver". A dor orgânica que o cliente sente vem dessa estagnação: "causa dor porque eu fico imaginando que tá saindo uma coisa, só que na verdade não tá".


## Referencia

ANDRESA MOLINA. *A Ilusão do Arquétipo (Guerreira vs. Donzela)*. Aula 09 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]].
