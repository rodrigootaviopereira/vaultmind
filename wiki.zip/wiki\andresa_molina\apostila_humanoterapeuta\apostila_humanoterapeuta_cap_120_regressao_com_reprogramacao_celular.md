---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_120_regressao_com_reprogramacao_celular.md]]"]
---

# Cap 120 - Regressao Com Reprogramacao Celular

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_120_regressao_com_reprogramacao_celular.md]]

## Referencia

ANDRESA MOLINA. *Cap 120 - Regressao Com Reprogramacao Celular*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_120_regressao_com_reprogramacao_celular.md]]. Acesso em: 17 jun. 2026.
