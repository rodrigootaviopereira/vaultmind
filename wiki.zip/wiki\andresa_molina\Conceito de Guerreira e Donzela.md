---
type: conceito
author: Andresa Molina
tags: [polaridades, arqueotipos, guerreira, donzela, rei, rainha]
sources: ["[[raw/archive/transcriptions/Aula 02 - Código Humanosense - Andresa Molina.md]]", "[[raw/archive/transcriptions/03 Código Humanosense  - Andresa Molina.md]]"]
---

# Conceito de Guerreira e Donzela

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/transcriptions/Aula 02 - Código Humanosense - Andresa Molina.md]]
  - [[raw/archive/transcriptions/03 Código Humanosense  - Andresa Molina.md]]

## Definição Precisa

- **Definição**: [INFERÊNCIA] Conceito de Guerreira e Donzela nomeia um eixo recorrente da obra de Andresa Molina que deve ser lido dentro do HumanoSense/Humanoterapeuta como categoria de diagnóstico, leitura de campo ou condução terapêutica.
- **Formulação de apoio**: No caso analisado, escassez e ex-marido aparecem conectados a pai, mae, modelo de casamento, donzela, guerreira, vergonha profissional e valor proprio. - Quanto mais completa a ficha, mais precisa e a supervisao.

## Sinônimos/Variações

- [INFERÊNCIA] Varia conforme a aula: pode aparecer como campo, código, mandala, personagem, sistema, memória, técnica ou postura terapêutica.

## Contexto de Uso

- Usado para orientar leitura do assistido, organização da sessão, compreensão de padrões emocionais/energéticos e conexão entre método, ficha, mesa, câmara e condução espiritual.

## Relação com Princípios

- [[Conceito da Ficha de Identificacao e Sintese da Dor]]

## Exemplos do Material

- No caso analisado, escassez e ex-marido aparecem conectados a pai, mae, modelo de casamento, donzela, guerreira, vergonha profissional e valor proprio. - Quanto mais completa a ficha, mais precisa e a supervisao. (Conceito da Ficha de Identificacao e Sintese da Dor)

## Aplicação Prática

- [INFERÊNCIA] Ao encontrar este tema em atendimento, use-o como pergunta de aprofundamento: onde ele aparece na queixa, no corpo, na ficha, no afeto/desafeto e na relação entre consciência e inconsciente?
- [INFERÊNCIA] Verifique se a pessoa está usando este padrão como defesa, fuga, repetição de dor ou caminho de reorganização.

## Conexões Externas

- [[Conceito da Ficha de Identificacao e Sintese da Dor]]

## Referencia

ANDRESA MOLINA. *Conceito de Guerreira e Donzela*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/transcriptions/Aula 02 - Código Humanosense - Andresa Molina.md]], [[raw/archive/transcriptions/03 Código Humanosense  - Andresa Molina.md]]. Acesso em: 17 jun. 2026.
