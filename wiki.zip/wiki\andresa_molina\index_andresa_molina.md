---
type: indice
author: Andresa Molina
tags: [andresa_molina, indice]
sources: []
---
# Apêndice: Andresa Molina

## Consolidação Tematica
- [[Consolidado - Codigo Humanosense]]
- [[Consolidacao Tematica - Andresa Molina]]
- [[Mapa dos Sistemas Terapeuticos de Andresa Molina]]

## MasterSense
- [[MasterSense - Mentoria do HumanoSense]]
- [[Aula 01 - MasterSense - Andresa Molina]]
- [[Aula 02 - MasterSense - Andresa Molina]]
- [[Aula 03 - MasterSense - Andresa Molina]]
- [[Aula 04 - MasterSense - Andresa Molina]]
- [[Camada MasterSense - Personagens da Dor]]
- [[Camada MasterSense - Memoria Celular]]

## Humanoterapeuta

- [[wiki/andresa_molina/apostila_humanoterapeuta/index_apostila_humanoterapeuta|HT - Fonte da Apostila Humanoterapeuta]]
- [[HT - Apostila Humanoterapeuta - Andresa Molina]]
- [[HT - Conceito - Metodo Humanoterapeuta]]
- [[HT - Tecnica - Psicogerador Quantionico]]
- [[HT - Tecnica - Humanometria]]
- [[HT - Tecnica - TDR]]
- [[HT - Tecnica - Taquions-Tock]]
- [[HT - Tecnica - Regressao com Reprogramacao Celular]]
- [[HT - Tecnica - Baralho Terapeutico]]

Este é o Apêndice de todo o conhecimento estruturado da autora **Andresa Molina**, focado nas **Sete Coordenadas do Mapa da Alma**, no **HumanoSense** e na cura de padrões ancestrais.

---

## Núcleo Estrutural
- [[Mapa Estrutural da Wiki Andresa Molina]]
- [[Arquitetura do HumanoSense]]
- [[Conceito do Metodo HumanoSense]]
- [[Conceito do Mapa da Alma]]
- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]
- [[Conceito da Camara HumanoSense]]

---

## Princí­pios Centrais

* **[[wiki/andresa_molina/Principio da Automagia e Autoabandono Feminino|Princípio da Automagia e Autoabandono Feminino]]** — O autoabandono sob múltiplos papéis sociais é mantido por comandos potentes de autodefesa (automagia) gerados na infí¢ncia/juventude.
* **[[wiki/andresa_molina/Principio da Castracao Parental|Princípio da Castração Parental]]** — A castração simbólica cometida por pais que inibem o espaço de ação ou expressão dos filhos e o impacto disso na vida adulta.
* **[[wiki/andresa_molina/Principio da Causa Inconsciente e da Reconsolidacao|Princípio da Causa Inconsciente e da Reconsolidação]]** — A cura definitiva requer acessar a raiz no inconsciente (95% da mente) e nas memórias celulares, aplicando a transmutação em vez de apenas ressignificar logicamente.
* **[[wiki/andresa_molina/Principio da Hierarquia dos Papeis|Princípio da Hierarquia dos Papéis]]** — O papel de casal (macho e fêmea alfa) deve preceder o papel de pais para manter a estabilidade do sistema familiar.
* **[[wiki/andresa_molina/Principio da Influencia Parental na Atracao e Retencao|Princípio da Influência Parental na Atração e Retenção]]** — O pai rege a atração/conquista e a mãe rege a retenção/permanência de recursos e relacionamentos.
* **[[wiki/andresa_molina/Principio da Mandala da Dor|Princípio da Mandala da Dor]]** — A estrutura de defesa do ego que se manifesta em dores e padrões defensivos para evitar abandono e exclusão.
* **[[wiki/andresa_molina/Principio da Memoria Celular Ancestral|Princípio da Memória Celular Ancestral]]** — O cansaço crí´nico e a impotência são marcas de dores ou traumas herdados dos ancestrais, armazenados nas células.
* **[[wiki/andresa_molina/Principio da Raiva como Potencial de Autonomia|Princípio da Raiva como Potencial de Autonomia]]** — A raiva reprimida gera culpa subconsciente que alimenta um ciclo de autopunição e perdas financeiras/emocionais.
* **[[wiki/andresa_molina/Principio de Lugar Funcao e Potencia|Princípio de Lugar, Função e Potência]]** — Estar fora de seu papel (lugar) desativa a sua função biológica e reduz drasticamente a sua potência de vida.
* **[[wiki/andresa_molina/Principio do Amor Condicionado e Autoabandono|Princípio do Amor Condicionado e Autoabandono]]** — A ferida de ser abandonado ou deixado para trás surge do aprendizado infantil de que o amor depende de agrado e obediência, gerando autoabandono.
* **[[wiki/andresa_molina/Principio da Atracao e Retencao|Princípio da Atração e Retenção (A Aceitação da Força dos Pais)]]** — O pai rege a atração e a mãe rege a retenção de recursos e relacionamentos.
* **[[wiki/andresa_molina/Principio da Doacao Genuina|Princípio da Doação Genuína]]** — Só é possível doar aquilo que possuímos dentro de nós; do contrário, doamos carência.
* **[[wiki/andresa_molina/Principio da Fusao Criacional|Princípio da Fusão Criacional (O Casamento Magnético do Masculino e Feminino)]]** — A lei universal de que nenhuma realidade se materializa sem a união das energias de expansão e contenção.
* **[[wiki/andresa_molina/Principio da Gestacao Cerebral|Princípio da Gestação Cerebral]]** — O cérebro infantil imaturo não racionaliza traumas, exigindo cura na memória celular somática.
* **[[wiki/andresa_molina/Principio da Gestacao Feminina|Princípio da Gestação Feminina]]** — O útero energético feminino como sustentáculo e espaço sagrado de manifestação de projetos.
* **[[wiki/andresa_molina/Principio da Inteligencia Espiritual|Princípio da Inteligência Espiritual (A Bússola do "Fazer Sentir" vs. "Fazer Sentido")]]** — A navegação da alma obedece à intuição do peito e não às conveniências lógicas.
* **[[wiki/andresa_molina/Principio da Liberdade Consciente|Princípio da Liberdade Consciente]]** — A integração da habilidade, autorização e disponibilidade.
* **[[wiki/andresa_molina/Principio da Memoria Celular vs Lembranca|Princípio da Memória Celular vs Lembrança]]** — Traumas e padrões residem na biologia celular e não dependem de lembranças conscientes na mente racional.
* **[[wiki/andresa_molina/Principio da Memoria Corporal Inconsciente|Princípio da Memória Corporal Inconsciente]]** — Nenhuma reação emocional, surto ou autossabotagem surge do nada; tudo está registrado como marca corporal.
* **[[wiki/andresa_molina/Principio da Plenitude Energetica e do Cuidado|Princípio da Plenitude Energética e do Cuidado]]** — Cuidar dos outros por medo ou obrigação esgota o magnetismo pessoal necessário para atrair dinheiro, clientes e relacionamentos abundantes.
* **[[wiki/andresa_molina/Principio da Responsabilidade Espiritual|Princípio da Responsabilidade Espiritual]]** — Os erros e acertos pertencem ao espírito como caminhos precisos de cura.
* **[[wiki/andresa_molina/Principio da Sabedoria Ancestral|Princípio da Sabedoria Ancestral]]** — Os ancestrais estão à nossa frente no tempo e acumulam a sabedoria de caminhada necessária para guiar nossa cura.
* **[[wiki/andresa_molina/Principio da Saudade do Futuro|Princípio da Saudade do Futuro (Saudade da Essência)]]** — O vazio existencial como sinal de desconexão com o programa de vida pré-reencarnatório.
* **[[wiki/andresa_molina/Principio da Vanguarda Ancestral|Princípio da Vanguarda Ancestral]]** — Os antepassados não ficaram no passado, mas estão à nossa frente guiando nossa evolução.
* **[[wiki/andresa_molina/Principio do Chamado da Sensibilidade|Princípio do Chamado da Sensibilidade]]** — A rejeição da alta sensibilidade gera desvalor próprio, esvaziamento existencial e bloqueio da atração financeira.
* **[[wiki/andresa_molina/Principio do Consentimento e Invasao de Campo|Princípio do Consentimento e Invasão de Campo]]** — A atuação da equipe de amparo exige autorização lúcida do assistido; invasões de campo caracterizam processos obsessivos.
* **[[wiki/andresa_molina/Principio do Entrelacamento Quantico Familiar|Princípio do Entrelaçamento Quântico Familiar]]** — A cura efetuada em si reverbera no passado de antepassados e no futuro de descendentes.
* **[[wiki/andresa_molina/Principio do Equilibrio de Forcas Masculino e Feminino|Princípio do Equilíbrio de Forças (Masculino e Feminino)]]** — O fluxo vital de dar e receber regido pelo masculino (ação/coragem) e feminino (sustentação/permanência).
* **[[wiki/andresa_molina/Principio do Vazio como Bussola|Princípio do Vazio como Bússola]]** — O vazio existencial como movimento que direciona a alma a abraçar o seu Dharma em vez de fugir em distrações.

* **[[wiki/andresa_molina/Principio da Preparacao do Terapeuta|Princípio da Preparação do Terapeuta]]** — Exigência de domínio prático e combate ao ego para evitar que o profissional se torne massa de manobra de obsessores.
* **[[wiki/andresa_molina/Principio da Aceitacao dos Fatos|Princípio da Aceitação dos Fatos]]** — Premissa clínica de que a cura exige a aceitação brutal da realidade e a desconstrução das ilusões sobre os outros e o passado.

* **[[wiki/andresa_molina/Principio da Objetividade Terapeutica|Princípio da Objetividade Terapêutica]]** — A regra de condução clínica que proíbe o terapeuta de transformar a sessão em um curso teórico sobre espiritualidade ou física quântica.
* **[[wiki/andresa_molina/Principio da Desilusao|Princípio da Desilusão]]** — A premissa de que toda dor sistêmica nasce de uma ilusão e que a desilusão é o choque libertador.
* **[[wiki/andresa_molina/Principio do Foco Primordial|Princípio do Foco Primordial]]** — A exigência clínica de não desviar da queixa primária trazida pelo assistido.

* **[[wiki/andresa_molina/Principio da Nao-Manipulacao no Transe|Princípio da Não-Manipulação no Transe]]** — A proibição de dar ordens no desdobramento, conduzindo estritamente por convites e perguntas abertas.
* **[[wiki/andresa_molina/Principio da Autossustentacao Fisica|Princípio da Autossustentação Física]]** — A proibição de abraçar ou tocar o paciente durante a catarse para não cortar a purga somática.
* **[[wiki/andresa_molina/Principio da Naturalidade Clinica|Princípio da Naturalidade Clínica]]** — A postura de calma e serenidade perante reações de expurgo fisiológico do assistido.
* **[[wiki/andresa_molina/Principio da Neutralidade Familiar ou Impedimento Clinico|Princípio da Neutralidade Familiar / Impedimento Clínico]]** — Impedimento de tratar familiares devido ao risco de contaminação e falta de neutralidade.
* **[[wiki/andresa_molina/Principio do Posicionamento de Valor|Princípio do Posicionamento de Valor]]** — A diretriz que proíbe devolver o valor da sessão em casos de fuga ou desistência do assistido.
* **[[wiki/andresa_molina/Principio do Fluxo Energetico nas Conexoes|Princípio do Fluxo Energético nas Conexões]]** — A regra de que trocas e parcerias terapêuticas devem ocorrer organicamente por ressonância.

* **[[wiki/andresa_molina/Principio da Musculatura Energetica|Princípio da Musculatura Energética]]** — A prática clínica recorrente como único caminho para o desenvolvimento da musculatura e percepção energética.
* **[[wiki/andresa_molina/Principio da Biosseguranca Online|Princípio da Biossegurança Online]]** — O protocolo espacial livre de interferências e os riscos somáticos e astrais de quedas de rede.
* **[[wiki/andresa_molina/Principio da Logica Invertida do Ego|Princípio da Lógica Invertida do Ego]]** — A desconstrução do uso do cliente como muleta psíquica para a própria autoconfiança do iniciante.
* **[[wiki/andresa_molina/Principio da Nao-Inducao no Transe Astral|Princípio da Não-Indução no Transe Astral]]** — A proibição de moralizar cenários, acompanhando e confirmando de forma neutra a cena.

* **[[wiki/andresa_molina/Principio da Desipnose da Consciencia|Princípio da Desipnose da Consciência]]** — A proibição da sugestão clínica no transe, focando em libertar mentes aprisionadas.
* **[[wiki/andresa_molina/Principio da Inevitabilidade da Troca Magnetica|Princípio da Inevitabilidade da Troca Magnética]]** — A doação inevitável de magnetismo físico do terapeuta para acoplamento e cura na matéria.
* **[[wiki/andresa_molina/Principio do Terapeuta como Instrumento Direcional|Princípio do Terapeuta como Instrumento Direcional]]** — A obrigatoriedade de comandos ativos da matéria para a execução espiritual dos resgates.
* **[[wiki/andresa_molina/Principio do Respeito a Resistencia|Princípio do Respeito à Resistência]]** — A interrupção imediata do transe em caso de recusa consciente do cliente em liberar o algoz.
* **[[wiki/andresa_molina/Principio da Responsabilidade Individual na Cura Ancestral|Princípio da Responsabilidade Individual na Cura Ancestral]]** — A cura ancestral isolada que liberta exclusivamente o assistido, sem alterar o livre-arbítrio familiar.
* **[[wiki/andresa_molina/Principio do Limite Etario de Aplicacao|Princípio do Limite Etário de Aplicação]]** — Limite neurológico e moral para responder pelas próprias escolhas multidimensionais no Humanosense.
* **[[wiki/andresa_molina/Principio da Integridade Magnetica do Codigo|Princípio da Integridade Magnética do Código]]** — O perigo de quebra de proteção e egrégora do terapeuta ao usar material pirata ou cópias.

## Conceitos-Chave

* **[[wiki/andresa_molina/Conceito da Mandala do Amor|A Mandala do Amor (Os 5 Pilares Energéticos)]]** — Estrutura diagnóstica que analisa o equilíbrio das polaridades do assistido.
* **[[wiki/andresa_molina/Conceito da Representacao Materna|A Representação Materna (Vínculo, Cuidado e a Retenção de Dinheiro/Relações)]]** — O arquétipo da nutrição, afeto e retenção.
* **[[wiki/andresa_molina/Conceito da Representacao Paterna|A Representação Paterna (Segurança, Ação e o Ganho de Dinheiro)]]** — O arquétipo da coragem, limites e atração no mundo.
* **[[wiki/andresa_molina/Conceito da Soberania do Rei e Rainha|A Soberania do Rei/Rainha (A Fusão Protagonista)]]** — O estado integrado de protagonismo que une Guerreiro e Donzela.
* **[[wiki/andresa_molina/Conceito da 2a Coordenada|Conceito da 2ª Coordenada (O Amor que Nunca Voltou)]]** — O esgotamento relacional e a dor da doação excessiva unilateral sem retorno.
* **[[wiki/andresa_molina/Conceito da 6a Coordenada|Conceito da 6ª Coordenada (O Chamado Ignorado)]]** — O travamento existencial e cansaço gerado pela recusa de aceitar seu próprio dom.
* **[[wiki/andresa_molina/Conceito da 7a Coordenada|Conceito da 7ª Coordenada (A Cura Buscada em Todo Lugar)]]** — A busca exaustiva por curas externas e racionais sem localizar a marca somática ancestral e celular do problema.
* **[[wiki/andresa_molina/Conceito da Alta Sensibilidade|Conceito da Alta Sensibilidade (Sensibilidade Mediúnica)]]** — A habilidade inata e fisiológica do indivíduo de processar estímulos sutis e captar o campo de terceiros e ambientes.
* **[[wiki/andresa_molina/Conceito da Autoaplicacao do HumanoSense|Conceito da Autoaplicação do HumanoSense]]** — A autoaplicação possível apenas em nível avançado, depois de treino e experiência prática.
* **[[wiki/andresa_molina/Conceito da Camara HumanoSense|Conceito da Cí¢mara HumanoSense]]** — O campo de trabalho vivo onde terapeuta e assistido entram em condução espiritual, energética e inconsciente.
* **[[wiki/andresa_molina/Conceito da Falsa Inteligencia Emocional|Conceito da Falsa Inteligência Emocional]]** — O uso do controle e conveniência social para reprimir as emoções e somatizar dores físicas.
* **[[wiki/andresa_molina/Conceito da Falsa Posse da Dor|Conceito da Falsa Posse da Dor (Somatização por Captação)]]** — A ilusão de apropriar-se de dores, medos e angústias ambientais e de terceiros como se fossem seus.
* **[[wiki/andresa_molina/Conceito da Ficha de Identificacao e Sintese da Dor|Conceito da Ficha de Identificação e Síntese da Dor]]** — O primeiro mapa clínico da sessão com dados, queixa principal, emoção dominante e afeto/desafeto.
* **[[wiki/andresa_molina/Conceito da Geometria Sagrada|Conceito da Geometria Sagrada]]** — A perfeição circular da inteligência celular e como os traumas a bloqueiam.
* **[[wiki/andresa_molina/Conceito da Mesa HumanoSense|Conceito da Mesa HumanoSense]]** — Ferramenta terapêutica que usa arquétipos e espelhamento subconsciente para liberar fractais emaranhados.
* **[[wiki/andresa_molina/Conceito da Mulher antes de ser de Todos|Conceito da Mulher antes de ser de Todos (4ª Coordenada)]]** — O autoabandono existencial e a anulação de identidade em prol dos outros.
* **[[wiki/andresa_molina/Conceito da Raiva que Virou Culpa|Conceito da Raiva que Virou Culpa]]** — A conversão psíquica de raiva em culpa subconsciente que gera ciclos de autopunição e perdas.
* **[[wiki/andresa_molina/Conceito da Sensibilidade como Valor e Dinheiro|Conceito da Sensibilidade como Valor e Dinheiro]]** — A autoaceitação da mediunidade/sensibilidade como ativação do magnetismo financeiro.
* **[[wiki/andresa_molina/Conceito das Camadas da Dor|Conceito das Camadas da Dor]]** — A estrutura de repressão e dor de fora para dentro, desde a máscara social até a identificação com o algoz.
* **[[wiki/andresa_molina/Conceito de Aconteceu vs Acontece|Conceito de Aconteceu vs Acontece]]** — A diferença diagnóstica entre traumas pontuais e repressões diárias naturalizadas.
* **[[wiki/andresa_molina/Conceito de Arrependimento e Perdao|Conceito de Arrependimento e Perdão]]** — A transmutação da culpa pela responsabilidade biológica e a consequente libertação sistêmica.
* **[[wiki/andresa_molina/Conceito de Automagia|Conceito de Automagia]]** — Comandos potentes e decretos de autodefesa criados inconscientemente em momentos de dor.
* **[[wiki/andresa_molina/Conceito de Autorizacao (Eixo da Liberdade)|Conceito de Autorizacao (Eixo da Liberdade)]]** — O sim existencial que desconstrói barreiras de parentes.
* **[[wiki/andresa_molina/Conceito de Campo Emocional e Dependencia|Conceito de Campo Emocional e Dependência]]** — A diní¢mica de autoabandono, codependência e culpa em progredir.
* **[[wiki/andresa_molina/Conceito de Clara Evidencia|Conceito de Clara Evidência]]** — A capacidade espiritual de sentir e decodificar com precisão as energias externas de pessoas e ambientes no peito.
* **[[wiki/andresa_molina/Conceito de Disponibilidade (Eixo da Liberdade)|Conceito de Disponibilidade (Eixo da Liberdade)]]** — A constância e disciplina de fazer até dar certo.
* **[[wiki/andresa_molina/Conceito de Eu Me Sinto Lixo|Conceito de Eu Me Sinto Lixo]]** — Reação externa com mágoa e cobrança de reparação.
* **[[wiki/andresa_molina/Conceito de Eu Sou Lixo|Conceito de Eu Sou Lixo]]** — Crença de identidade somatizada em autoataque celular.
* **[[wiki/andresa_molina/Conceito de Explorador Limitador e Cobrador|Conceito de Explorador, Limitador e Cobrador]]** — As três personalidades defensivas que surgem da aliança do ego com a dor e autoproteção.
* **[[wiki/andresa_molina/Conceito de Funcao (Eixo da Realizacao)|Conceito de Funcao (Eixo da Realizacao)]]** — A expressão prática dos talentos específicos.
* **[[wiki/andresa_molina/Conceito de Guerreira e Donzela|Conceito de Guerreira e Donzela]]** — As forças arquetípicas da guerreira (ação/defesa) e da donzela (magia/idealização) e sua maturidade no Rei/Rainha interno.
* **[[wiki/andresa_molina/Conceito de Habilidade (Eixo da Liberdade)|Conceito de Habilidade (Eixo da Liberdade)]]** — Domínio prático e segurança desenvolvidos por treino.
* **[[wiki/andresa_molina/Conceito de Invasao Energetica ou Obsessao|Conceito de Invasão Energética ou Obsessão]]** — A diferença entre a intrusão sem autorização e a atuação dos guias sob livre-arbítrio.
* **[[wiki/andresa_molina/Conceito de Lixo Emocional|Conceito de Lixo Emocional]]** — A dor adotada como crença profunda de identidade.
* **[[wiki/andresa_molina/Conceito de Lugar (Eixo da Realizacao)|Conceito de Lugar (Eixo da Realizacao)]]** — O ambiente correto sistêmico que nutre a essência.
* **[[wiki/andresa_molina/Conceito de Macho e Femea Alfa|Conceito de Macho e Fêmea Alfa]]** — A atitude biológica de polaridade dominante que ancora a energia e provê o suporte no casal.
* **[[wiki/andresa_molina/Conceito de Magnetismo e Plenitude|Conceito de Magnetismo e Plenitude]]** — A capacidade de atrair prosperidade e recursos de acordo com o preenchimento de energia vital na alma.
* **[[wiki/andresa_molina/Conceito de Meditar como Me-Ditar|Conceito de Meditar ("Me-Ditar")]]** — Escutar ativamente o que o próprio corpo e alma têm a dizer em vez de tentar silenciar a mente.
* **[[wiki/andresa_molina/Conceito de Medo e Cautela|Conceito de Medo e Cautela]]** — A ação com presença atenta diante do desconhecido.
* **[[wiki/andresa_molina/Conceito de Obesidade Somatica por Sobrecarga|Conceito de Obesidade Somatica por Sobrecarga]]** — Expansão física devido à adoção de fardos alheios.
* **[[wiki/andresa_molina/Conceito de Personagem da Dor|Conceito de Personagem da Dor]]** — Máscara de sobrevivência emocional da criança ferida.
* **[[wiki/andresa_molina/Conceito de Personagens da Dor|Conceito de Personagens da Dor]]** — Os arquétipos comportamentais inconscientes de donzela, guerreira e rainha em dor.
* **[[wiki/andresa_molina/Conceito de Personalidade da Dor|Conceito de Personalidade da Dor]]** — Armadura defensiva do ego contra o abandono e exclusão.
* **[[wiki/andresa_molina/Conceito de Potencia (Eixo da Realizacao)|Conceito de Potencia (Eixo da Realizacao)]]** — A energia vital e magnetismo aplicados no papel correto.
* **[[wiki/andresa_molina/Conceito de Relacionamento na Mandala da Dor|Conceito de Relacionamento na Mandala da Dor]]** — Perfis inconstante, perdido e solitário nas relações.
* **[[wiki/andresa_molina/Conceito de Ressignificacao vs Reconsolidacao|Conceito de Ressignificação vs Reconsolidação]]** — A diferença entre o entendimento lógico-mental e a reprogramação celular de traumas somáticos.
* **[[wiki/andresa_molina/Conceito de Saudade do Futuro|Conceito de Saudade do Futuro]]** — A lembrança e nostalgia celular do projeto de vida original da alma que foi engavetado.
* **[[wiki/andresa_molina/Conceito do Abandono de Si|Conceito do Abandono de Si (A Frequência do Abandono)]]** — O processo de anulação pessoal que emite a vibração de rejeição e atrai o abandono do outro.
* **[[wiki/andresa_molina/Conceito do Bloqueio Sensorial pelo Batismo|Conceito do Bloqueio Sensorial pelo Batismo]]** — O fecho sensorial provocado no terceiro olho pelo batismo na infância e a incapacidade resultante de decodificar o entorno.
* **[[wiki/andresa_molina/Conceito do Ciclo Ocupado nao Produtivo|Conceito do Ciclo Ocupado não Produtivo]]** — O mecanismo de defesa da hiperatividade para evitar encarar o vazio essencial.
* **[[wiki/andresa_molina/Conceito do Ciclo de Autopunicao|Conceito do Ciclo de Autopunição]]** — A atração de escassez, sabotagens e dores corporais para expiar a culpa subconsciente.
* **[[wiki/andresa_molina/Conceito do Cobrador da Dor|Conceito do Cobrador da Dor]]** — Controle através de culpa e mágoa do passado.
* **[[wiki/andresa_molina/Conceito do Cuidado que Esgota|Conceito do Cuidado que Esgota (5ª Coordenada)]]** — O autoesvaziamento vital ao cuidar de todos e a consequente perda de magnetismo pessoal.
* **[[wiki/andresa_molina/Conceito do Dependente Emocional|Conceito do Dependente Emocional]]** — Perda da autonomia em troca de companhia e lealdade.
* **[[wiki/andresa_molina/Conceito do Divorcio Energetico|Conceito do Divórcio Energético]]** — O corte e encerramento consciente de vínculos, contratos e padrões que já não devem continuar.
* **[[wiki/andresa_molina/Conceito do Eixo da Liberdade|Conceito do Eixo da Liberdade]]** — Habilidade, autorização e disponibilidade na Mandala.
* **[[wiki/andresa_molina/Conceito do Eixo da Realizacao|Conceito do Eixo da Realizacao]]** — O fluxo de lugar, função e potência na matéria.
* **[[wiki/andresa_molina/Conceito do Equilíbrio do Dar e Receber|Conceito do Equilíbrio do Dar e Receber]]** — O fluxo harmí´nico entre as polaridades masculina (dar/agir) e feminina (receber/sustentar) na alma.
* **[[wiki/andresa_molina/Conceito do Esgotamento Magnetico|Conceito do Esgotamento Magnético]]** — A perda de vitalidade e interrupção do fluxo de atração de prosperidade.
* **[[wiki/andresa_molina/Conceito do Eu Sou Lixeiro|Conceito do Eu Sou Lixeiro]]** — O arquétipo do salvador sobrecarregado.
* **[[wiki/andresa_molina/Conceito do Explorador da Dor|Conceito do Explorador da Dor]]** — Padrão de vitimização e ganho secundário a partir da dor.
* **[[wiki/andresa_molina/Conceito do Falso Eu Sou|Conceito do Falso Eu Sou (Essência vs. Personagem)]]** — A máscara de identidade e os papéis sociais em oposição à essência verdadeira.
* **[[wiki/andresa_molina/Conceito do Limitador da Dor|Conceito do Limitador da Dor]]** — Sabotagem sutil do avanço alheio por medo de solidão.
* **[[wiki/andresa_molina/Conceito do Mapa da Alma|Conceito do Mapa da Alma]]** — O mapa interno composto de coordenadas e marcas emocionais gravadas no corpo.
* **[[wiki/andresa_molina/Conceito do Modo Sobrevivencia no Cuidado|Conceito do Modo Sobrevivência no Cuidado]]** — O agrado compulsivo como mecanismo biológico de sobrevivência para evitar o abandono.
* **[[wiki/andresa_molina/Conceito do Metodo HumanoSense|Conceito do Método HumanoSense]]** — O sistema de reabilitação e decodificação corporal para alinhar o corpo físico í  geometria da alma.
* **[[wiki/andresa_molina/Conceito do Parceiro da Missao|Conceito do Parceiro da Missão]]** — A pessoa que sustenta e propaga a missão sem precisar viver exclusivamente de terapia.
* **[[wiki/andresa_molina/Conceito do Preocupado Emocional|Conceito do Preocupado Emocional]]** — Estado de alerta focado nas demandas externas dos outros.
* **[[wiki/andresa_molina/Conceito do Sistema FER|Conceito do Sistema FER]]** — O sistema biológico de alarme que dispara o medo de separação e pertencimento.
* **[[wiki/andresa_molina/Conceito do Sistema RAGE|Conceito do Sistema RAGE]]** — O sistema biológico de autonomia e proteção de limites físicos/emocionais.
* **[[wiki/andresa_molina/Conceito dos 16 Destinos ou Odus|Conceito dos 16 Destinos ou Odus]]** — Os caminhos ancestrais de destino e aprendizado para o cumprimento da missão de vida.
* **[[wiki/andresa_molina/Conceito dos Tres Estados de Cura|Conceito dos Três Estados de Cura]]** — As fases biológicas necessárias para a depuração de informações celulares traumáticas.
* **[[wiki/andresa_molina/Conceito de Energia Feminina|Energia Feminina (A Gestação, a Nutrição e a Força de Sustentação)]]** — A polaridade arquetípica de recolhimento, gestação e sustentação de projetos.
* **[[wiki/andresa_molina/Conceito de Energia Masculina|Energia Masculina (A Semeadura, a Coragem e o Impulso)]]** — A polaridade arquetípica de impulso, coragem e semeadura.
* **[[wiki/andresa_molina/Conceito de Influencia vs Intuicao|Influência vs. Intuição (A Dinâmica da Mediunidade Livre)]]** — Polaridades da mediunidade: influência (masculino externo) e intuição (feminino interno).
* **[[wiki/andresa_molina/Conceito do Aborto de Projetos|O Aborto de Projetos (A Falência do Feminino Melindroso/Imaturo)]]** — Abandono e paralisação de projetos decorrentes da fragilidade do feminino ferido.
* **[[wiki/andresa_molina/Conceito do Arquetipo da Donzela|O Arquétipo da Donzela/Príncipe (O Sonho, a Fuga e a Ilusão)]]** — A faceta sonhadora e receptiva (polaridade feminina) do protagonismo.
* **[[wiki/andresa_molina/Conceito do Arquetipo do Guerreiro|O Arquétipo do Guerreiro/Guerreira (A Luta, a Espada e a Defesa de Território)]]** — A faceta protetora e ativa (polaridade masculina) do protagonismo.
* **[[wiki/andresa_molina/Conceito de Raiva vs Odio|Raiva vs. Ódio]]** — A diferença entre a emoção motriz saudável e o sentimento rancoroso apodrecido por repressão.
* **[[wiki/andresa_molina/Conceito de Vibracao vs Frequencia|Vibração vs. Frequência (A Motivação e a Manutenção no Tempo)]]** — A vibração é a faísca do impulso (masculino) e a frequência é a manutenção (feminino).

* **[[wiki/andresa_molina/Conceito de Entidades de Resgate vs Especialistas|Entidades de Resgate vs. Entidades Especialistas]]** — Divisão funcional da egrégora entre resgate geral e intervenções cirúrgicas ou mecânicas específicas na cena astral.
* **[[wiki/andresa_molina/Conceito do Sangramento do Utero da Vida|O Sangramento do Útero da Vida]]** — O esvaziamento emocional e catarse somática obrigatórios antes de semear uma nova realidade.
* **[[wiki/andresa_molina/Conceito da Fusao do Masculino e Feminino|A Fusão do Masculino e Feminino]]** — Alquimia de plantio da intenção no solo purificado e ativação somática da Kundalini.
* **[[wiki/andresa_molina/Conceito de Espiritos Terrestres vs Extraterrestres|Espíritos Terrestres vs. Extraterrestres]]** — Distinção consciencial baseada na encarnação terrena e na respectiva manipulação de elementos da natureza ou DNA cósmico.
* **[[wiki/andresa_molina/Conceito da Sustentacao pelos Tres Cerebros|A Sustentação pelos Três Cérebros]]** — Estrutura de contenção somática da intenção que une Mente, Coração e Intestino/Vísceras.

* **[[wiki/andresa_molina/Conceito de Afetos e Desafetos|Afetos e Desafetos]]** — A categoria diagnóstica que mapeia o alvo ou objeto físico que concentra a carga magnética de apego e dor do assistido.
* **[[wiki/andresa_molina/Conceito do Gap Vibracional|O Gap Vibracional]]** — A dissonância numérica entre a nota declarada consciente e a nota real indicada pelo pêndulo no inconsciente.
* **[[wiki/andresa_molina/Conceito da Fuga para o Universo das Possibilidades|A Fuga para o Universo das Possibilidades]]** — Mecanismo de defesa arquetípico da Donzela/Príncipe focado no possível no lugar do provável.
* **[[wiki/andresa_molina/Conceito de Complementaridade Metodologica|A Complementaridade Metodológica (Humanoterapia vs. Humanosense)]]** — Integração entre a atuação celular profunda (Humanoterapia) e a desprogramação mental de ilusões (Humanosense).

* **[[wiki/andresa_molina/Conceito da Fantasia de Salvamento Infantil|A Fantasia de Salvamento Infantil]]** — A ilusão da criança ferida que paralisa o presente esperando um herói resgatador parental.
* **[[wiki/andresa_molina/Conceito do Tratamento do Luto e o Deslocamento de Funcao|O Tratamento do Luto e o Deslocamento de Função]]** — Reconfigurações patológicas onde sobreviventes de mortes ocupam o lugar sistêmico do defunto.
* **[[wiki/andresa_molina/Conceito da Personalidade Sombra|A Personalidade Sombra / O Gap]]** — Comportamento inconsciente discrepante revelado pelo gap na mesa.
* **[[wiki/andresa_molina/Conceito de Afeto e Desafeto Interno ou Externo|Afeto e Desafeto Interno/Externo]]** — Identificação do alvo central da dor, incluindo o auto-ódio (desafeto interno).
* **[[wiki/andresa_molina/Conceito da Diferenca de Atuacao Terapeutica|A Diferença de Atuação Terapêutica (Humanosense vs. Humanoterapia vs. Regressão)]]** — Distinção entre limpeza passiva, catarse ativa de autoria e regressão simples sem egrégora.
* **[[wiki/andresa_molina/Conceito da Transferencia Sistemica Biologica|A Transferência Sistêmica Biológica]]** — A constatação do peso imutável e elo genético celular do Pai Biológico.
* **[[wiki/andresa_molina/Conceito do Bloqueio na Fecundacao ou Ausencia da Kundalini|O Bloqueio na Fecundação / Ausência da Kundalini]]** — Apatia corporal que denuncia inconsistência espiritual no desejo plantado.
* **[[wiki/andresa_molina/Conceito da Ampliacao Mediunica Organica|A Ampliação Mediúnica Orgânica]]** — A aceleração e apuramento intuitivo sem alterar a estrutura cerebral do terapeuta.
* **[[wiki/andresa_molina/Conceito de Magia Pratica e Elementais|Magia Prática e Elementais]]** — Manipulação eletromagnética contínua da matéria por meio dos pensamentos diários.
* **[[wiki/andresa_molina/Conceito do Cerebro Enterico ou Intestino|O Cérebro Entérico / Intestino]]** — Neurônios das vísceras que guardam a depressão e o enfesamento somático.

* **[[wiki/andresa_molina/Conceito do Copo Vazio ou Assistido Leigo|O Copo Vazio / O Assistido Leigo]]** — A vantagem clínica da ausência de jargões e proteções teóricas no transe de leigos.
* **[[wiki/andresa_molina/Conceito da Ilusao do Arquetipo Guerreira vs Donzela|A Ilusão do Arquétipo (Guerreira vs. Donzela)]]** — O autoengano inconsciente de falso movimento prático revelado na testagem da mesa.
* **[[wiki/andresa_molina/Conceito da Dinamica do Estagiario|A Dinâmica do "Estagiário"]]** — A humildade de ego necessária para errar, permutar e aceitar recomeços na transição.
* **[[wiki/andresa_molina/Conceito da Dor da Forca Desconsiderada|A Dor da Força Desconsiderada]]** — A castração da confiança provocada quando pais excluem os filhos da dor por superproteção.
* **[[wiki/andresa_molina/Conceito da Falsa Culpa Sistemica|A Falsa Culpa Sistêmica]]** — A autossabotagem de felicidade filial oriunda do julgamento equivocado de que a vida dos pais é ruim.
* **[[wiki/andresa_molina/Conceito do Arquivamento Longitudinal da Consciencia|O Arquivamento Longitudinal da Consciência]]** — A relevância clínica de manter a ficha cinza como banco de dados psíquico.

* **[[wiki/andresa_molina/Conceito da Permeabilidade da Mandala da Cura|A Permeabilidade da Mandala da Cura]]** — O uso das 6 âncoras da mandala como lentes diagnósticas contínuas na anamnese.
* **[[wiki/andresa_molina/Conceito da Ocupacao de Lugar Sistemico|A Ocupação de Lugar Sistêmico]]** — A lei de exclusão quântica que impede a manifestação de novos desejos se o espaço sutil estiver ocupado.
* **[[wiki/andresa_molina/Conceito da Somatizacao da Mediunidade Reprimida|A Somatização da Mediunidade Reprimida]]** — Processo somático de fibromialgia e dores que andam originadas por captação sensitiva sem descarga.
* **[[wiki/andresa_molina/Conceito da Especializacao das Entidades de Resgate|A Especialização das Entidades de Resgate]]** — O corpo clínico astral dividido por dores sentimentais (Pombagiras) ou operacionais (Especialistas).
* **[[wiki/andresa_molina/Conceito da Validade do Transe sem Choro|A Validade do Transe sem Choro]]** — O reconhecimento da eficácia da cirurgia etérica em perfis defensivos e secos.

## Técnicas e Práticas

* **[[wiki/andresa_molina/Tecnica de Abertura do Circulo Magico|Abertura do Círculo Mágico (Fixação da Coordenada)]]** — Prática energética para corporificar e desenhar as coordenadas celulares na matéria.
* **[[wiki/andresa_molina/Tecnica de Mapeamento Somatico da 4a Coordenada|Mapeamento Somático da 4ª Coordenada]]** — Rastreamento corporal que une a frequência emocional de vazio à coordenada física correspondente.
* **[[wiki/andresa_molina/Tecnica de Mapeamento Somatico da Raiva|Prática de Mapeamento Somático da Raiva]]** — Rastreamento somático para localizar onde os bloqueios e memórias de raiva estão retidos no corpo.
* **[[wiki/andresa_molina/Tecnica de Remocao de Papeis Sociais|Prática de Remoção de Papéis Sociais]]** — Exercício de desidentificação meditativa de papéis para acessar o silêncio da essência.
* **[[wiki/andresa_molina/Tecnica Pratica do Respeito (A Resposta do Peito)|Prática do Respeito (A Resposta do Peito)]]** — Exercício sutil cardíaco para burlar a lógica mental e escutar a orientação sutil do espírito na tomada de decisões.
* **[[wiki/andresa_molina/Tecnica do Trabalho Energetico da Mandala Suspensa (Odus)|Trabalho Energético da Mandala Suspensa (Odus)]]** — Intervenção vibracional com centro suspenso/vazio e sintonia com os 16 destinos/Odus.
* **[[wiki/andresa_molina/Tecnica do Trabalho Energetico de Sangria|Trabalho Energético de "Sangria" (Geometria Sagrada)]]** — Catarse energética em círculo mágico para liberar a raiva reprimida e a culpa.
* **[[wiki/andresa_molina/Tecnica de Alinhamento do Chamado|Técnica de Alinhamento do Chamado]]** — Mapeamento corporal de sintomas de captação externa e consulta da resposta do peito para alinhar-se í  missão de vida.
* **[[wiki/andresa_molina/Tecnica de Aplicacao Guiada na Camara HumanoSense|Técnica de Aplicação Guiada na Cí¢mara HumanoSense]]** — Condução prática ao vivo dentro da Cí¢mara HumanoSense, com presença, treino e escuta atenta.
* **[[wiki/andresa_molina/Tecnica de Depuracao e Desobsessao de Fractais|Técnica de Depuração e Desobsessão de Fractais]]** — Deposição e limpeza somática de memórias parasitárias fixadas no corpo.
* **[[wiki/andresa_molina/Tecnica de Diagnostico das Personalidades e Personagens de Dor|Técnica de Diagnóstico das Personalidades e Personagens de Dor]]** — Questionário diagnóstico de 0 a 10 para mapear mecanismos de dor do assistido.
* **[[wiki/andresa_molina/Tecnica de Enquadramento na Piramide|Técnica de Enquadramento na Pirí¢mide]]** — Criação e isolamento do campo piramidal de proteção e abertura de trabalho.
* **[[wiki/andresa_molina/Tecnica de Espelhamento do Consciente e Inconsciente|Técnica de Espelhamento do Consciente e Inconsciente]]** — O uso de projeções visuais externas para trazer í  tona as diní¢micas bloqueadas do inconsciente.
* **[[wiki/andresa_molina/Tecnica de Fecundacao e Materializacao do Desejo|Técnica de Fecundação e Materialização do Desejo]]** — O alinhamento dos centros biológicos inferiores para criar a energia vital necessária para materializar intenções.
* **[[wiki/andresa_molina/Tecnica de Identificacao da Raiz na Anamnese|Técnica de Identificação da Raiz na Anamnese]]** — Entrevista inicial para localizar a emoção principal, o afeto ou desafeto e a questão central que vai nortear toda a sessão.
* **[[wiki/andresa_molina/Tecnica de Identificacao do Cancaco Ancestral|Técnica de Identificação do Cansaço Ancestral]]** — Meditação e conexão corporal para mapear o peso da ancestralidade no corpo físico.
* **[[wiki/andresa_molina/Tecnica de Mapeamento do Amor Condicionado|Técnica de Mapeamento do Amor Condicionado]]** — Autoanálise e mapeamento corporal do sentimento de rejeição e das regras da infí¢ncia.
* **[[wiki/andresa_molina/Tecnica de Rastreamento da Cura Incompleta|Técnica de Rastreamento da Cura Incompleta]]** — Autoanálise sobre os tratamentos analgésicos malsucedidos da vida e emissão do comando de permissão de cura.
* **[[wiki/andresa_molina/Tecnica de Resgate do Eu Sou Essencial|Técnica de Resgate do Eu Sou Essencial]]** — Exercício mental e de memória de infí¢ncia para despir-se dos papéis sociais e acessar a essência profunda.
* **[[wiki/andresa_molina/Tecnica de Retorno a Consciencia e Harmonizacao|Técnica de Retorno í  Consciência e Harmonização]]** — Fechamento da sessão com ativação da mandala da cura, harmonização do campo e volta estável í  consciência.
* **[[wiki/andresa_molina/Tecnica de Ancoragem do Assistido na Mesa|Técnica de Ancoragem do Assistido na Mesa]]** — Conexão vibracional do assistido por nome e data.
* **[[wiki/andresa_molina/Tecnica de Conexao com a Equipe Espiritual|Técnica de Conexão com a Equipe Espiritual (Sustentação do Sentir)]]** — Meditação e permissão vibracional para ancoragem dos amparadores superiores na câmara.
* **[[wiki/andresa_molina/Tecnica de Conexao e Respiracao das Coordenadas|Técnica de Conexão e Respiração das Coordenadas]]** — Meditação e respiração profunda para sintonizar a equipe espiritual, reconfigurar a frequência mental e recapitular as 7 coordenadas.
* **[[wiki/andresa_molina/Tecnica de Diagnostico de Alinhamento Consciente-Inconsciente|Técnica de Diagnóstico de Alinhamento Consciente-Inconsciente]]** — Cruzamento de respostas lógicas com o pêndulo na mesa.
* **[[wiki/andresa_molina/Tecnica de Identificacao da Carecia e Cuidado|Técnica de Identificação da Carência e Cuidado]]** — Autoanálise e mapeamento da dificuldade física em receber afeto e do modo de utilidade compulsiva.

* **[[wiki/andresa_molina/Tecnica de Abertura e Conexao|Comando de Abertura e Conexão]]** — Ancoramento do assistido no selo central da mesa por nome e data de nascimento em voz alta.
* **[[wiki/andresa_molina/Tecnica do Confronto e Resgate da Contraparte|O Confronto e Resgate da Contraparte]]** — Condução do assistido para reviver e sangrar a carga de dor de memórias passadas antes do resgate.
* **[[wiki/andresa_molina/Tecnica do Comando de Encaminhamento Padrao|Comando de Encaminhamento Padrão]]** — Invocação de entidades com habilidade, disponibilidade e autorização para recolher os fragmentos e encaminhar à Câmara.
* **[[wiki/andresa_molina/Tecnica do Comando de Intervencao Especializada|Comando de Intervenção Especializada]]** — Invocação de cirurgiões ou engenheiros astrais para desfazer amarras ou obstruções físicas na cena.
* **[[wiki/andresa_molina/Tecnica de Esvaziamento e Fecundacao|Prática de Esvaziamento e Fecundação]]** — Indução ao vazio absoluto e plantio consciente da nova semente de intenção no corpo.

* **[[wiki/andresa_molina/Tecnica de Preparacao e Alfa do Terapeuta|Prática de Preparação e Alfa do Terapeuta]]** — Ritual de organização física e mental do terapeuta antes do atendimento.
* **[[wiki/andresa_molina/Tecnica de Preenchimento da Ficha Cinza|Técnica de Preenchimento da Ficha Cinza]]** — Anamnese elemental focado na extração da síntese da dor.
* **[[wiki/andresa_molina/Tecnica de Rastreio Duplo nas Mandalas|Dinâmica de Rastreio Duplo nas Mandalas]]** — Procedimento radiestésico que confronta a resposta do cliente com o pêndulo na mesa.
* **[[wiki/andresa_molina/Tecnica de Enquadramento na Piramide e Conexao|Prática do Enquadramento em Pirâmide e Conexão]]** — Isolamento do campo e testemunho vocal para autorização espiritual.
* **[[wiki/andresa_molina/Tecnica de Desdobramento e Conducao do Sangramento|O Desdobramento e a Condução do Sangramento]]** — Desdobramento à Câmara e catarse emocional na regressão.
* **[[wiki/andresa_molina/Tecnica de Comandos de Limpeza e Resgate Astral|Os Comandos de Limpeza e Resgate Astral]]** — Invocação de equipes de resgate padrão ou especialistas no astral.
* **[[wiki/andresa_molina/Tecnica de Avaliacao de Estado|A Técnica de Avaliação de Estado]]** — Pausa diagnóstica que avalia se a biologia do paciente suporta o transe no mesmo dia.

* **[[wiki/andresa_molina/Tecnica da Posicao Somatica ou Cadeira|Prática da Posição Somática / Cadeira]]** — Posição sentada que simula o feto e facilita a liberação profunda do choro.
* **[[wiki/andresa_molina/Tecnica de Autoaplicacao|Prática de Autoaplicação]]** — Dificuldade e exigência de maturidade clínica para cutucar as próprias feridas em transe.
* **[[wiki/andresa_molina/Tecnica de Ancoramento do Terapeuta na Cena|Técnica de Ancoramento do Terapeuta na Cena]]** — Amparo vocal sutil para dar segurança somática durante a catarse.
* **[[wiki/andresa_molina/Tecnica de Isolamento em Piramide|Prática do Isolamento em Pirâmide]]** — Enquadramento geométrico na mesa para blindar contra vampirismo externo.
* **[[wiki/andresa_molina/Tecnica de Ativacao da Mandala da Cura|Técnica de Ativação da Mandala da Cura]]** — Giro horário do pêndulo infundindo harmonização no encerramento.
* **[[wiki/andresa_molina/Tecnica da Regra de Traducao de Comandos|Regra da Tradução de Comandos]]** — Tradução da semântica dos comandos mantendo senhas nominais em português.
* **[[wiki/andresa_molina/Tecnica de Escolha Radiestesica de Perguntas|Técnica de Escolha Radiestésica de Perguntas]]** — Condução com escolha do pêndulo assumindo a responsabilidade de costura clínica.
* **[[wiki/andresa_molina/Tecnica de Rebaixamento Cerebral ou Alfa|Prática de Rebaixamento Cerebral / Alfa]]** — Respiração e contagem decrescente para reduzir a biologia do assistido.
* **[[wiki/andresa_molina/Tecnica de Precificacao e Duracao Teto|Prática de Precificação e Duração Teto]]** — Honorários elevados e limite de 2 horas de sessão para proteger o campo.

* **[[wiki/andresa_molina/Tecnica de Manejo de Queda de Conexao|Técnica de Manejo de Queda de Conexão]]** — O plano e mensagem de contingência síncrona para guiar o retorno assíncrono do transe.
* **[[wiki/andresa_molina/Tecnica da Anamnese por Desconstrucao|Prática da Anamnese por Desconstrução]]** — O funil investigativo para desmontar a queixa superficial e travar na queixa celular.
* **[[wiki/andresa_molina/Tecnica do Enquadramento Publico vs Privado|Técnica do Enquadramento Público vs. Privado]]** — Ajuste do tempo de isolamento de Pirâmide perante coletivos.
* **[[wiki/andresa_molina/Tecnica de Rebaixamento Cerebral e Respiratorio|Prática de Rebaixamento Cerebral e Respiratório]]** — Varredura topográfica e relaxamento mecânico corporal.
* **[[wiki/andresa_molina/Tecnica do Comando de Abertura da Camara Humanosense|Comando de Abertura da Câmara Humanosense]]** — Evocação das frequências celestes e ancestrais no desdobramento.
* **[[wiki/andresa_molina/Tecnica da Conducao do Sangramento em Primeira Pessoa|A Condução do Sangramento em Primeira Pessoa]]** — A eliminação da triangulação do terapeuta no enfrentamento de matrizes.
* **[[wiki/andresa_molina/Tecnica do Comando de Resgate Emocional Especializado|Comando de Resgate Emocional Especializado]]** — O amolecimento espiritual de corações de pedra na câmara.
* **[[wiki/andresa_molina/Tecnica de Esvaziamento e Ativacao da Kundalini|Prática de Esvaziamento e Ativação da Kundalini]]** — Fecundação no vácuo integrando os três cérebros e faísca vital.
* **[[wiki/andresa_molina/Tecnica de Limpeza e Fechamento do Portal|Procedimento de Limpeza e Fechamento do Portal]]** — Assepsia alquímica e reacoplamento corporal de encerramento.
* **[[wiki/andresa_molina/Tecnica da Mandala da Cura no Encerramento|Técnica da Mandala da Cura no Encerramento]]** O selamento com a trindade e desconexão física do pêndulo.

* **[[wiki/andresa_molina/Tecnica de Diagnostico da Emocao Presente|Prática de Diagnóstico da Emoção Presente]]** — A testagem radiestésica calibrada na emoção ativa do dia de hoje, excluindo apegos extintos.
* **[[wiki/andresa_molina/Tecnica do Dialogo Direto com a Dor Somatica|Prática do Diálogo Direto com a Dor Somática]]** — A personificação de dores musculares agudas como interlocutoras em caso de ausência de visões.
* **[[wiki/andresa_molina/Tecnica de Encerramento Antecipado por Bloqueio|Técnica de Encerramento Antecipado por Bloqueio]]** — Recuo astral seguro e contagem reversa de assepsia perante a recusa de cura do ego.
* **[[wiki/andresa_molina/Tecnica de Mapeamento pela Matriz da Consciencia|O Mapeamento pela Matriz da Consciência]]** — A ferramenta digitalizada para rotular o teatro de sombras (Cobrador, Limitador, Explorador) e capturar a emoção base.

## Fontes Processadas

* `[[raw/archive/transcriptions/01 - O CANSAí‡O QUE NíƒO PARA 1Âª Coordenada - O Mapa da Alma.md]]`
* `[[raw/archive/transcriptions/02 - O AMOR QUE NUNCA VOLTOU - 2Âª Coordenada - O Mapa da Alma.md]]`
* `[[raw/archive/transcriptions/03 - A RAIVA QUE VIROU CULPA 3Âª Coordenada - O Mapa da Alma.md]]`
* `[[raw/archive/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4Âª Coordenada - O Mapa da Alma.md]]`
* `[[raw/archive/transcriptions/05 - O CUIDADO QUE ESGOTA 5Âª Coordenada - O Mapa da Alma.md]]`
* `[[raw/archive/transcriptions/06 - O Chamado Ignorado 6Âª Coordenada - O Mapa da Alma.md]]`
* `[[raw/archive/transcriptions/07 - A Cura Buscada em Todo Lugar 7Âª Coordenada - O Mapa da Alma.md]]`
* `[[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]]`
* `[[raw/archive/transcriptions/Aula 01 - Código Humanosense - Andresa Molina.md]]`
* `[[raw/archive/transcriptions/Aula 02 - Código Humanosense - Andresa Molina.md]]`
* `[[raw/archive/transcriptions/03 Código Humanosense  - Andresa Molina.md]]`
* `[[raw/archive/transcriptions/Aula 04 - Código Humanosense - Andresa Molina.md]]`
* `[[raw/archive/transcriptions/Aula 05 - Código Humanosense - Andresa Molina.md]]`
* `[[raw/archive/transcriptions/Aula 06 - Código Humanosense - Andresa Molina.md]]`
* `[[raw/archive/transcriptions/07 Código Humanosense  - Andresa Molina.md]]`
* `[[raw/archive/transcriptions/08 Código Humanosense - Humanosense.md]]`
* `[[raw/archive/transcriptions/09 Código Humanosense  - Andresa Molina.md]]`
* `[[raw/archive/transcriptions/10 Código Humanosense  - Andresa Molina.md]]`
* `[[raw/archive/andresa_molina/transcriptions/01   Mastersense - Andresa Molina.md]]`
* `[[raw/archive/andresa_molina/transcriptions/02   Mastersense - Andresa Molina.md]]`

---

## Mapa Estrutural

- `Mapa Estrutural da Wiki Andresa Molina`
- `Arquitetura do HumanoSense`
- `Conceito do Metodo HumanoSense`
- `Conceito da Mesa HumanoSense`
- `Conceito da Ficha de Identificacao e Sintese da Dor`
- `Conceito da Camara HumanoSense`
- `Conceito do Divorcio Energetico`

---

## Revisões por Aula

### Aula 01 - Código Humanosense
- `Aula 01 - Código Humanosense`
- `Conceito da Polaridade Masculino e Feminino`
- `Conceito da Mandala do Amor`
- `Conceito do Metodo HumanoSense`
- `Conceito do Equilíbrio do Dar e Receber`
### Aula 02 - Código Humanosense
- `Conceito da Mandala do Amor`
- `Principio da Liberdade Consciente`
- `Conceito do Eixo da Liberdade`

### Aula 04 - Código Humanosense
- `Principio da Liberdade Consciente`
- `Conceito do Eixo da Liberdade`
- `Principio de Lugar Funcao e Potencia`

### Aula 05 - Código Humanosense
- `Conceito de Matar o Pai e a Mae`
- `Conceito de Protagonista e Personagem`
- `Principio da Sustentacao do Que e Seu`

### Aula 06 - Código Humanosense
- `Conceito do Metodo HumanoSense`
- `Principio do Respeito a Tecnica e a Equipe Espiritual`
- `Principio da Disciplina no Passo a Passo`
- `Tecnica de Enquadramento na Piramide`
- `Tecnica de Fecundacao e Materializacao do Desejo`

### Aula 07 - Código Humanosense
- `Conceito do Metodo HumanoSense`
- `Tecnica de Enquadramento na Piramide`
- `Tecnica de Identificacao da Raiz na Anamnese`
- `Conceito da Ficha de Identificacao e Sintese da Dor`

### Aula 08 - Código Humanosense
- `Conceito da Autoaplicacao do HumanoSense`
- `Tecnica de Retorno a Consciencia e Harmonizacao`

### Aula 09 - Código Humanosense
- `Conceito da Camara HumanoSense`
- `Tecnica de Aplicacao Guiada na Camara HumanoSense`

### Aula 10 - Código Humanosense
- `Conceito do Divorcio Energetico`
- `Conceito do Parceiro da Missao`

## Código Humanosense - Reingestão 2026-06-19

- [[Aula 01 - Código Humanosense]] - 17.044 palavras analisadas; 581 frases longas mapeadas.
- [[Aula 02 - Código Humanosense]] - 16.926 palavras analisadas; 625 frases longas mapeadas.
- [[Aula 03 - Código Humanosense]] - 17.335 palavras analisadas; 616 frases longas mapeadas.
- [[Aula 04 - Código Humanosense]] - 16.214 palavras analisadas; 575 frases longas mapeadas.
- [[Aula 05 - Código Humanosense]] - 25.777 palavras analisadas; 876 frases longas mapeadas.
- [[Aula 06 - Código Humanosense]] - 15.298 palavras analisadas; 542 frases longas mapeadas.
- [[Aula 07 - Código Humanosense]] - 17.500 palavras analisadas; 603 frases longas mapeadas.
- [[Aula 08 - Código Humanosense]] - 18.540 palavras analisadas; 603 frases longas mapeadas.
- [[Aula 09 - Código Humanosense]] - 12.797 palavras analisadas; 448 frases longas mapeadas.
- [[Aula 10 - Código Humanosense]] - 18.860 palavras analisadas; 636 frases longas mapeadas.

### Fontes Arquivadas desta Reingestão
- [[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]]
- [[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]
- [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]
- [[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]]
- [[raw/archive/andresa_molina/transcriptions/05   Código Humanosense - Andresa Molina.md]]
- [[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]]
- [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]
- [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]
- [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]
- [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]

## MasterSense - Reingestão 2026-06-19

- [[Aula 01 - MasterSense - Andresa Molina]] - 12.600 palavras analisadas.
- [[Aula 02 - MasterSense - Andresa Molina]] - 17.766 palavras analisadas.
- [[Aula 03 - MasterSense - Andresa Molina]] - 18.500 palavras analisadas.
- [[Aula 04 - MasterSense - Andresa Molina]] - 17.977 palavras analisadas.

### Fontes Arquivadas
- [[raw/archive/andresa_molina/transcriptions/01   Mastersense - Andresa Molina-.md]]
- [[raw/archive/andresa_molina/transcriptions/02   Mastersense - Andresa Molina.md]]
- [[raw/archive/andresa_molina/transcriptions/03   Mastersense - Andresa Molina.md]]
- [[raw/archive/andresa_molina/transcriptions/04   Mastersense - Andresa Molina.md]]
