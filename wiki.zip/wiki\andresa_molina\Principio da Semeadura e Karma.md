---
type: principio
author: Andresa Molina
tags: [karma, semeadura, causa-e-efeito, evolucao]
sources: ["[[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]]"]
---
# Princípio da Semeadura e Karma (A Consequência vs. Castigo)

- **Definição**: A premissa espiritual de que o Karma não é um castigo divino, mas a manifestação da Lei da Semeadura: colhemos exatamente o que plantamos física, emocional e vibracionalmente.
- **Justificativa**: Desmistifica o vitimismo e traz autorresponsabilidade, mostrando que a falta de recursos ou amizades decorre da ausência de plantio ou cultivo anterior.
- **Evidências**: "o karma não é um castigo. O karma não existe. O karma é pura e simplesmente pode ser mudado em um segundo. É lida ação e reação... o karma nada mais é do que a lei da semeadura. A gente colhe o que planta. É só isso. Se eu não tenho nada para colher, porque eu não plantei nada."
- **Implicações**: Ao expandir a consciência e compreender o aprendizado de uma ação, a conta é zerada e equalizada, mudando o karma instantaneamente.
- **Conexões**: [[Conceito do Metodo HumanoSense]], [[Principio de Lugar Funcao e Potencia]]
- **Notas Pessoais**: O sofrimento cede lugar à reparação assim que o indivíduo assume a responsabilidade de suas criações.

## Referencia

ANDRESA MOLINA. *Princípio da Semeadura e Karma (A Consequência vs. Castigo)*. Aula 01 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]].
