---
type: tecnica
author: Andresa Molina
tags: [ancoramento-verbal, presenca-terapeutica, segurança-neurologica]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# Técnica de Ancoramento do Terapeuta na Cena (A sustentação da segurança)

- **Objetivo**: Atuar como um amparo sonoro e cordão umbilical verbal durante a regressão do assistido, fornecendo segurança somática e neurológica para que ele encare cenas traumáticas sem entrar em pânico ou paralisia.
- **Pré-requisitos**: Assistido desdobrado e vivenciando a regressão na Câmara.
- **Passo a Passo**:
  1. Ao perceber que o assistido está se aproximando do núcleo de dor da memória e demonstrando pânico, o terapeuta insere de forma calma e constante a sua própria voz.
  2. Verbaliza frases de segurança temporal, lembrando a pessoa de que o seu corpo adulto está seguro no consultório presente: *"Nós estamos aqui na sala, eu tô aqui com você, pode ir. Lembra que nós estamos dormindo... tô segurando na sua mão, pode ir"*.
  3. Essa sustentação verbal diminui a resposta de alerta da amígdala cerebral, permitindo que o assistido reviva e descarregue a dor ancestral (sangramento).
- **Duração/Frequência**: Aplicada pontualmente durante a catarse na Câmara.
- **Indicadores de Sucesso**: Dissolução do pânico de congelamento da cena e fluidez do assistido para chorar e confrontar o cenário de dor.
- **Variações**: Condução verbal suave vs. comandos firmes de direcionamento espacial na cena.
- **Conceitos Envolvidos**: [[Tecnica do Confronto e Resgate da Contraparte]], [[Tecnica de Desdobramento e Conducao do Sangramento]]

## Perguntas Frequentes / Didática de Atendimento

### 19. Como o terapeuta deve usar a própria voz para dar amparo durante o desdobramento onde há muito medo?
**Resposta**: Quando a pessoa desdobra e "tá com medo" nas cenas profundas ("sonhos tão vividos e tão los"), o terapeuta usa a própria voz para lembrá-la da realidade material: "eu sempre lembro ela vai e não esquece que a gente tá aqui na sala, eu tô aqui com você, pode ir". A nível somático, essa voz serve para a mente acalmar o corpo físico que está em estado de alerta, avisando-o de que ele está seguro: "nós estamos dormindo, ó, lembra disso. Você só tá aqui... tô segurando na sua mão, pode ir". Essa âncora verbal devolve a coragem ao assistido ("Ah, é mesmo, então posso ir").


## Referencia

ANDRESA MOLINA. *Técnica de Ancoramento do Terapeuta na Cena*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
