---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_76_desdobramento_dos_corpus.md]]"]
---

# Cap 076 - Desdobramento Dos Corpus

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_76_desdobramento_dos_corpus.md]]

## Referencia

ANDRESA MOLINA. *Cap 076 - Desdobramento Dos Corpus*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_76_desdobramento_dos_corpus.md]]. Acesso em: 17 jun. 2026.
