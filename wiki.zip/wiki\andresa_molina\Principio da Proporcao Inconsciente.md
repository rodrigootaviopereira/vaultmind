---
type: principio
author: Andresa Molina
tags: [mente-inconsciente, racionalidade, cura, ciência, 7a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]]"]
---

# Princípio da Proporção Inconsciente (A Falha da Cura Racional)

- **Definição**: A premissa neurobiológica de que tentar resolver dores profundas apenas com o intelecto é matematicamente ineficaz, pois a mente racional representa uma fração mínima da estrutura humana em comparação ao subconsciente.
- **Justificativa**: A busca por curas que se apoia exclusivamente no entendimento lógico e racional tende a falhar e gerar frustração. Andresa fundamenta esse princípio em dados científicos que demonstram a desproporção estrutural da mente: "o nosso racional, ele compõe só 5% do nosso todo. 95% é inconsciente". 
- **Evidências**: *"o nosso racional, ele ele é compõe só 5% da nossa do nosso todo. 95% é inconsciente. Isso não é Andresa que tá falando, é a ciência que traz. Então, se você é 100% e você está buscando só com 5% que é racional, você está deixando, desistindo de você nos outros 95%."*
- **Implicações**: Quando um indivíduo resiste a terapias emocionais e ancestrais, exigindo que tudo faça apenas sentido lógico, ele ignora a vasta maioria de sua própria existência. Tentar curar um trauma profundo que está enraizado no corpo utilizando apenas essa pequena fração racional significa que a pessoa está, na prática, ignorando a maior parte de si mesma, pois "você está deixando, desistindo de você nos outros 95%".
- **Conexões**: [[Conceito da 7a Coordenada]], [[Principio da Memoria Celular vs Lembranca]]

## Notas Pessoais

- Reservado para observações do usuário.

## Referência

ANDRESA MOLINA. *Princípio da Proporção Inconsciente (A Falha da Cura Racional)*. Aula 07 - Coordenada 7 (A Cura Buscada em Todo Lugar). Fontes: [[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. Como Andresa Molina justifica cientificamente a limitação do esforço puramente intelectual na cura, citando a proporção de 5% racional e 95% inconsciente na composição do todo humano?
**Resposta**: Andresa justifica a falência da busca puramente intelectual apelando para a matemática do cérebro. Ela cita que "o nosso racional, ele ele é compõe só 5% da nossa do nosso todo. 95% é inconsciente. Isso não é Andresa que tá falando, é a ciência que traz". 

A nível somático, toda a vastidão do corpo físico, das heranças das bisavós e dos "gatilhos que liberam as memórias que estão no corpo" operam fora do radar da lógica consciente, habitando esses gigantescos 95% de sombra sistêmica. A limitação do esforço intelectual ocorre porque tentar curar uma vida inteira usando apenas a lógica significa entrar em uma guerra com uma desvantagem colossal: "se você é 100% e você tá buscando só com 5% que é racional, você está deixando, desistindo de você nos outros 95%". Resistir a acessar o corpo e as emoções profundas é garantir que a maior e mais poderosa parte da sua própria existência permaneça doente e inexplorada.

