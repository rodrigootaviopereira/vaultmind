---
type: principio
author: Andresa Molina
tags: [liberdade, consciencia, disciplina, verdade, autoria]
sources: ["[[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio da Liberdade Consciente

- **Definição**: A integração máxima do ser que ocorre quando o indivíduo une a Habilidade de atuar, a Autorização de ser e a Disponibilidade de fazer até dar certo, assumindo a responsabilidade por sua própria vida.
- **Justificativa**: A liberdade real não é a ausência de amarras externas, mas a disciplina interna e o estado de presença e autoria que impede o medo ou a opinião alheia de ditar as escolhas da alma.
- **Evidências**: "a liberdade consciente acontece quando você reconhece o que carrega com habilidade, se permite ir com a autorização e faz o que precisa ser feito com a disponibilidade. [...] Liberdade não é ausência de responsabilidade, é disciplina, é presença de autoria, é ser autor das suas ações. É quando o medo não some, mas deixa de te comandar, porque quem decide é você."
- **Implicações**: A terapêutica Humanosense visa levar o assistido a este princípio, onde ele sai da ilusão infantil e assume o ônus e o bônus de sua soberania.
- **Conexões**: [[Conceito do Eixo da Liberdade]], [[Conceito da Soberania do Rei e Rainha]]
- **Notas Pessoais**: A liberdade consciente desativa a reatividade robótica dos personagens de dor.

## Referencia

ANDRESA MOLINA. *Princípio da Liberdade Consciente*. Aula 04 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]].
