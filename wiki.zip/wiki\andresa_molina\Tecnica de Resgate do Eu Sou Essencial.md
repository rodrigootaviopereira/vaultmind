---
type: tecnica
author: Andresa Molina
tags: [tecnica, meditacao, desipnose, essencia, autoabandono, 4a-coordenada, resgate]
sources: ["[[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]]"]
---

# Técnica de Resgate do Eu Sou Essencial

## Objetivo

- Romper de forma imediata o fluxo mental racional e a identificação com papéis sociais limitantes, acessando o vazio/silêncio interior e a essência original do assistido (o Eu Sou) para iniciar a desprogramação de bloqueios de autoabandono.

## Pré-requisitos

- Um ambiente calmo e silencioso.
- Abertura para acolher e enfrentar o vazio existencial sem julgamento racional ou necessidade de preenchimento imediato.

## Passo a Passo

1. **Aquietamento e Respiração Consciente**:
   - Sentar-se confortavelmente e fechar os olhos.
   - Realizar 3 respirações profundas coletivas:
     - Inspirar profundamente pelo nariz.
     - Segurar o ar nos pulmões por alguns segundos.
     - Soltar o ar lentamente pela boca com um leve suspiro.
     - Permanecer sem ar por um breve instante antes de respirar normalmente.
2. **Pergunta de Isolamento de Papéis (O Despir das Máscaras)**:
   - Formular mentalmente ou guiar verbalmente a seguinte indagação: *"Se você tirar todos os papéis que você ocupa de mãe, de esposa, de filha, de profissional, de amiga, de salvadora, daquela que resolve tudo e que está sempre disponível... Quem sobra?"*
   - Permanecer em absoluto silêncio de olhos fechados por alguns segundos.
3. **Leitura e Acolhimento do Vazio (A Coordenada de Silêncio)**:
   - Acolher qualquer sensação que surja: seja a conexão com uma identidade profunda ou a percepção de um grande vazio/silêncio.
   - Reconhecer que o silêncio pós-pergunta não é ausência de vida, mas a própria coordenada somática da essência que foi sobreposta pelas demandas cotidianas.
4. **Diálogo de Reconexão e Desnaturalização**:
   - Perguntar a si mesmo de forma neutra: *"Esse vazio é bom ou é ruim?"*
   - Responder sem buscar justificativas intelectuais. 
   - Se for ruim, reconhecer a necessidade de preencher tudo o tempo inteiro e dar permissão para descer até a camada subjacente de dor.
5. **Resgate Histórico da Criança Essencial**:
   - Conectar-se com a memória de como você era na infância antes de aprender a se moldar para ser amado ou aceito: *"Como você era quando criança? Quietinho ou falador? Perguntava os porquês? O que gostava de brincar? Como se sentia?"*
   - Acolher essa criança como a representação do seu espírito sábio e de seu programa de vida, autorizando-a a voltar a habitar o seu presente.
6. **Mapeamento e Retorno à Consciência**:
   - Identificar onde no corpo físico a dor ou saudade de si mesma se manifesta como coordenada (peito, estômago, ombros pesados, etc.).
   - Abrir os olhos gradualmente, registrando as impressões.

## Duração/Frequência

- Executada como técnica de alinhamento e ancoragem na 4ª Coordenada ou no início de sessões de regressão com reprogramação celular.

## Indicadores de Sucesso

- Percepção clara do vazio ou da identidade que reside por trás das obrigações diárias.
- Sensação de presença e desapego momentâneo das exigências sociais (checklists diários).
- Emoção de saudade da própria infância e ativação de sentimentos de merecimento e autovalor.

## Conceitos Envolvidos

- [[Conceito da Mulher antes de ser de Todos]]
- [[Conceito do Abandono de Si]]
- [[Conceito de Saudade do Futuro]]
- [[Conceito de Aconteceu vs Acontece]]

## Perguntas Frequentes / Didática de Atendimento

### Como o temperamento e os comportamentos natos da infância (como "perguntar os porquês") revelam a farsa do personagem utilitário que criamos na vida adulta?

Os comportamentos natos da infância revelam quem nós realmente somos antes da contaminação pelas exigências do mundo. Andresa relata que era uma criança extremamente interessada que "perguntava porquê de tudo", mas que, de repente, parou de perguntar e passou apenas a "obedecer a demanda do mundo" para ser a pessoa "legal da galera".

Essa mudança revela a farsa do personagem utilitário adulto porque evidencia que **a nossa submissão e o ato de dizer "sim" para todos não são a nossa verdadeira personalidade, mas sim uma máscara de sobrevivência**. A criança aprendeu que o seu jeito natural (perguntar demais, falar demais ou cantar) "incomodama" os adultos. Para ser amada e não ser um problema, ela abandonou a si mesma, silenciou seus questionamentos e assumiu um personagem utilitário que apenas obedece e serve aos outros. Portanto, **relembrar a criança é desmascarar o adulto artificial**.

### O que Andresa quer dizer com a expressão "um espírito num corpinho e não um espiritinho"? Como isso muda o olhar sobre a nossa essência?

Com essa expressão, Andresa destrói a visão limitante de que uma criança é um ser imaturo ou vazio. Ela ensina que a criança "não é criança", mas sim **"um espírito sábio" e antigo habitando um corpo físico pequeno**.

Isso muda drasticamente o nosso olhar sobre a essência porque nos obriga a levar a sério os nossos desejos infantis. Aquele comportamento nato e aqueles sonhos puros da infância não eram "fantasias bobas" de um "espiritinho", mas sim **as diretrizes do projeto de vida original** que esse espírito sábio trouxe antes de encarnar. Ao entender isso, percebemos que o abandono da nossa criança interior foi, na verdade, o abandono da nossa sabedoria mais profunda e do nosso verdadeiro destino.

### Qual é o papel da percussão, do samba e dos movimentos de terra como desencadeadores de ancoragem e movimento para a cura da 4ª Coordenada?

No contexto da aula, a percussão, o samba e os "movimentos de terra" (como o toque do pandeiro) são citados por Andresa como as suas âncoras pessoais de alegria, vitalidade e pertencimento às suas raízes (o avô e a história de seus pais na Umbanda).

O papel prático desses elementos é **trazer o "movimento" necessário para uma essência que estava paralisada e anestesiada**. Para quem sofre da 4ª Coordenada — vivendo no ciclo falso de euforia e do "ocupado não produtivo" —, identificar aquilo que genuinamente ativa a sua alegria (que, no caso de Andresa, eram os instrumentos de ataque e de terra) é o primeiro passo para resgatar a vitalidade real e deixar de frequentar lugares ou fazer coisas apenas para agradar aos outros.

## Referência

ANDRESA MOLINA. *Técnica de Resgate do Eu Sou Essencial*. Aula 04 - Coordenada 4 (A Mulher Antes de Ser de Todos). Fontes: [[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]].
