---
type: tecnica
author: Andresa Molina
tags: [mesa-humanosense, ancoragem, campo-vibracional, sintonia]
sources: ["[[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]]"]
---

# Técnica de Ancoragem do Assistido na Mesa

- **Definição**: O procedimento energético inicial de posicionamento que insere e fixa a frequência vibracional e espiritual do assistido no espaço da mesa terapêutica para posterior diagnóstico.
- **Justificativa**: A leitura do pêndulo exige que o campo do cliente esteja conectado à estrutura geométrica da mesa de trabalho, sob a autorização explícita do próprio.
- **Evidências**: "Primeira coisa, você vai, quando o seu cliente chegar aqui no selo do espaço, você vai pôr o seu dedo aqui e vai dizer o nome completo e a data de nascimento do seu cliente. Você só vai fazer isso com quem te autorizar. Só. Você precisa perguntar pra pessoa, conversar com ela, ela fala: 'Claro, vamos fazer'. Aí com ela você põe aqui seu dedo aqui conectado com ela e fala o nome completo e a data de nascimento."
- **Implicações**: Nunca faça leituras sem a concordância lúcida do assistido. Conecte o dedo no local indicado e verbalize os dados com firmeza para abrir o campo.
- **Conexões**: [[Conceito da Mesa HumanoSense]], [[Tecnica de Diagnostico de Alinhamento Consciente-Inconsciente]]
- **Notas Pessoais**: O respeito ao livre-arbítrio é o que garante o suporte da equipe espiritual de amparo.

## Referencia

ANDRESA MOLINA. *Técnica de Ancoragem do Assistido na Mesa*. Aula 04 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]].
