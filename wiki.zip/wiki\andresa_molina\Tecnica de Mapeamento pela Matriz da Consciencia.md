---
type: technique
author: Andresa Molina
tags: [matriz-da-consciencia, mapeamento, cobrador, limitador, explorador]
sources: ["[[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]"]
---

# O Mapeamento pela Matriz da Consciência (A ferramenta estrutural de sombra)

- **Definição**: A utilização da ferramenta estruturada (digitalizada) focada especificamente em catalogar o teatro de sombras dos relacionamentos do paciente, rotulando os familiares e os padrões em três vetores destrutivos: o Cobrador, o Limitador ou o Explorador.
- **Como praticar e seu Propósito**:
  1. **Isolar o Personagem**: Lançar no sistema o afeto/desafeto apontado na Ficha (ex: "chefe Flávio").
  2. **Interrogação Sistemática**: Responder às perguntas automáticas de comportamento ("nunca te deixei na mão...").
  3. **Mapeamento de Emoção Base**: Obter o diagnóstico das sombras: "O Flávio então seria um cobrador... O Flávio é um cobrador na sua vida".
  O propósito psíquico e somático é fornecer "consciência visual" (dar nome ao fantasma do relacionamento), mapeando a emoção correspondente (ex: raiva/decepção) para extrair o assistido da ansiedade genérica.
- **Evidências**: "Essa matriz da consciência, ela vai conseguir identificar na vida do seu cliente quem são os possíveis cobradores, limitadores, exploradores. E ela vai responder algumas perguntas ao tudo automático... E aí ela responde. E aí ele é o quê? O que que ele é seu? O Flávio? Ah, o Flávio é, cadê? É meu conhecido. ...Ah, fala sempre isso para mim. E aí a gente vai perguntando... E qual a cientção que você tem do Flávio? Ah, eu tenho raiva do Flávio e eu tenho uma decepção do Flávio. Legal. ...O Flávio então seria um cobrador. Olha, o Flávio é um cobrador na sua vida... E aí ele sai com o mapa e principalmente identificando qual é a emoção base."
- **Conexões**: [[Conceito da Personalidade Sombra]], [[Conceito de Explorador Limitador e Cobrador]]

## Perguntas Frequentes / Didática de Atendimento

### 18. Qual o propósito psíquico da ferramenta digital da "Matriz da Consciência" no mapeamento das identidades?
**Resposta**: O propósito psíquico da matriz é fornecer um diagnóstico relacional e emocional claro para o paciente, identificando quem são os sugadores ao seu redor através de perguntas direcionadas sobre o convívio (ex: **"nunca te larguei na mão quando você precisou. É uma coisa que o Flávio fala para você?"**).

Ao finalizar a coleta de interações, o sistema cataloga a identidade vibracional nociva. A autora exemplifica: **"O Flávio então seria um cobrador. Olha, o Flávio é um cobrador na sua vida"**. A nível somático e psíquico, isso organiza a mente confusa do assistido, pois **"ele sai com o mapa e principalmente identificando qual é a emoção base... raiva, medo, mágoa, então você consegue ter informações sobre o campo emocional dessa pessoa e as relações que ela tem"**.


## Referencia

ANDRESA MOLINA. *O Mapeamento pela Matriz da Consciência*. Aula 10 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]].
