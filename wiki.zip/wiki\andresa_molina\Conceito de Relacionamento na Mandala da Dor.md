---
type: conceito
author: Andresa Molina
tags: [relacionamento, inconstante, perdido, solitario, masculino-feminino]
sources: ["[[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]"]
---

# Conceito de Relacionamento na Mandala da Dor

- **Definição**: O mapeamento dos padrões profundos de carência, rejeição e atração ferida que sabotam a vida afetiva do assistido, manifestando-se nos perfis Perdido, Inconstante ou Solitário.
- **Justificativa**: A dor no relacionamento expõe a falta de atração (pai/masculino) ou a falta de sustentação (mãe/feminino), mantendo a pessoa na superficialidade ou na solidão acompanhada.
- **Evidências**: "De 0 a 10, o quanto você pula de uma relação para outra, esperando que a próxima funcione melhor. Esse é o inconstante. Então, a gente tem o perdido e o inconstante. E tem o terceiro, que é o solitário. Ele vive relações até que tranquilas, mas porém [...] se sente sozinho ou sozinha."
- **Implicações**: O terapeuta deve decodificar se o assistido pula de parceiro em parceiro (inconstante), se não atrai ninguém (masculino fraco/perdido) ou se permanece numa relação vazia de alma (solitário).
- **Conexões**: [[Principio da Mandala da Dor]], [[Principio da Atracao e Retencao]]
- **Notas Pessoais**: A dor amorosa revela onde a polaridade está bloqueada.

## Referencia

ANDRESA MOLINA. *Conceito de Relacionamento na Mandala da Dor*. Aula 03 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]].
