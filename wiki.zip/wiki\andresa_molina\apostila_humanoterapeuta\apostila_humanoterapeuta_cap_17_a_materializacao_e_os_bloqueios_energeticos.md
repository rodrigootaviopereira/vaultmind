---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_17_a_materializacao_e_os_bloqueios_energeticos.md]]"]
---

# Cap 017 - A Materializacao E Os Bloqueios Energeticos

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_17_a_materializacao_e_os_bloqueios_energeticos.md]]

## Referencia

ANDRESA MOLINA. *Cap 017 - A Materializacao E Os Bloqueios Energeticos*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_17_a_materializacao_e_os_bloqueios_energeticos.md]]. Acesso em: 17 jun. 2026.
