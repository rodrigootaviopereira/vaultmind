---
type: conceito
author: Andresa Molina
tags: [anamnese, identificacao, ficha, sintese, afeto, desafeto, escuta]
sources: ["[[raw/archive/transcriptions/07 Código Humanosense  - Andresa Molina.md]]"]
---

# Conceito da Ficha de Identificação e Síntese da Dor

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/transcriptions/07 Código Humanosense  - Andresa Molina.md]]


## Camada MasterSense

- Na aula 02, a ficha passa a ser ensinada como instrumento de analise fria: o terapeuta deve observar o que foi preenchido, as contradicoes, as lacunas e os desalinhamentos entre consciente e inconsciente.
- A queixa inicial pode nao ser a raiz. No caso analisado, escassez e ex-marido aparecem conectados a pai, mae, modelo de casamento, donzela, guerreira, vergonha profissional e valor proprio.
- Quanto mais completa a ficha, mais precisa e a supervisao. Quando a ficha vem vazia ou pouco preenchida, a autora considera que nao ha material suficiente para analisar o caso.
- **Fonte relacionada**: [[raw/archive/andresa_molina/transcriptions/02   Mastersense - Andresa Molina.md]]

## Referencia

ANDRESA MOLINA. *Conceito da Ficha de Identificação e Síntese da Dor*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/transcriptions/07 Código Humanosense  - Andresa Molina.md]]. Acesso em: 17 jun. 2026.
