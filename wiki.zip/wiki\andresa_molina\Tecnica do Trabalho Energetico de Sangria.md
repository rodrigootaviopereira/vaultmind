---
type: tecnica
author: Andresa Molina
tags: [tecnica, 3a-coordenada, catarse, sangria, geometria-sagrada, trabalho-energetico]
sources: ["[[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]]"]
---

# Trabalho Energético de "Sangria" (Geometria Sagrada)

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]]

## Objetivo

- Drenar a raiva inflamatória reprimida e acumulada no corpo físico e nos fractais de dor através de uma catarse energética guiada, permitindo a liberação da pressão e a dissolução da culpa associada.

## Pré-requisitos

- Identificação prévia da coordenada física do trauma através da [[Prática de Mapeamento Somático da Raiva]].
- Uso de geometrias sagradas, gráficos ou condução energética em círculo mágico para criar um contêiner de segurança biológica e espiritual.

## Passo a Passo

1. **Abertura do Espaço Seguro**:
   - O terapeuta estabelece o círculo mágico ou utiliza um gráfico de geometria sagrada emissor para acolher o assistido e os seus fractais de dor.
2. **Construção do Pico de Pressão**:
   - Conduzir o assistido a lembrar-se de todas as dores, abusos, invasões e injustiças silenciosas que sofreu. Isso cria um atrito intencional entre o impulso original de expressar a raiva (defesa biológica) e a trava subconsciente da culpa (repressão da infância).
3. **Autorização da Existência (A Sangria)**:
   - No pico da tensão, em vez de direcionar a fúria contra uma pessoa do mundo real, o assistido é guiado a expressar, desabafar e descarregar essa energia dentro do espaço geométrico ou gráfico delimitado.
   - O assistido reconhece e aceita a raiva: *"Eu sinto raiva e está tudo bem eu sentir isso, eu aceito que ela existe."*
4. **Drenagem Somática (Limpeza)**:
   - Assim como em uma sangria médica cirúrgica onde o acúmulo infeccioso é drenado para desinflamar o tecido, visualiza-se a raiva e a dor saindo do ponto físico carimbado (ombros, estômago, etc.) e sendo transmutadas pelas geometrias sagradas do gráfico.
5. **Curativo Energético**:
   - Após a vazão total da energia represada, aplicar comandos de pacificação celular e reconsolidação para cicatrizar a marca e restabelecer o equilíbrio biológico do local.

## Duração/Frequência

- Executado em sessões específicas de catarse ou desprogramação celular na câmara/mesa HumanoSense quando identificada a inflamação da 3ª coordenada.

## Indicadores de Sucesso

- Sensação de alívio físico imediato, leveza no corpo e desinflamação das regiões que estavam tensas (como pescoço, estômago ou ombros).
- Aceitação emocional da raiva como força assertiva sem o disparo subsequente de culpa ou autocobrança.

## Conceitos Envolvidos

- [[Principio da Raiva como Potencial de Autonomia]]
- [[Conceito da Raiva que Virou Culpa]]
- [[Conceito do Ciclo de Autopunicao]]
- [[Conceito de Ressignificacao vs Reconsolidacao]]

## Referência

ANDRESA MOLINA. *Trabalho Energético de "Sangria" (Geometria Sagrada)*. Aula 03 - Coordenada 3 (A Raiva que Virou Culpa). Fontes: [[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]].
