---
type: conceito
author: Andresa Molina
tags: [magia-pratica, elementais, materia, eletromagnetismo, triade-espiritual]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# Magia Prática e Elementais (A ciência do pensamento manipulando a matéria)

- **Definição Precisa**: A constatação de que o pensamento persistente (afeto, ódio, reclamações diárias) atua como um comando magnético contínuo que sintoniza e direciona as forças elementais (elementais da natureza - Fogo, Terra, Água, Ar) para plasmar aquela mesma realidade densa na vida física do indivíduo.
- **Sinônimos/Variações**: Magia do pensamento, direcionamento elemental mental, manipulação eletromagnética da matéria.
- **Contexto de Uso**: Explicado para demonstrar que a autossabotagem e a escassez material cronificada do assistido são atos de "magia diária" autoproduzidos pelo mental enfurecido ou lamentoso (*"reclamação o tempo inteiro tem na cabeça, magia e a vida não dá certo? Claro, eu tô reforçando a magia"*).
- **Relação com Princípios**: [[Principio da Ressonancia da Intencao]], [[Principio da Automagia e Autoabandono Feminino]]
- **Exemplos do Material**: "Então tudo tá em três, espírito, alma e corpo. Espírito, alma e matéria. Tudo fogo tem o espírito, alma e matéria... Então tudo o que a gente faz, aglomera, manda, mental, comando, é tudo. A gente tá fazendo magia o tempo inteiro. E a gente tá ativando elemental da natureza. E por isso que e aí é magia pura. Tudo magia. Não tem nada que não seja. Não tem nada que exista sem os elementais... Então, reclamação o tempo inteiro tem na cabeça, magia e a vida não dá certo? Claro, eu tô reforçando a magia dia a dia. Puto da vida... raiva, raiva fogo, elemental fogo."
- **Aplicação Prática**: Identificar qual elemental o cliente está manipulando de forma inconsciente destrutiva (ex: excesso de elemental Fogo alimentado por raiva e ódio crônico) e desarticular essa sintonia por meio de comandos de resgate e reequilíbrio elemental na mesa.
- **Conexões Externas**: [[Conceito de Automagia]], [[Conceito de Espiritos Terrestres vs Extraterrestres]]

## Perguntas Frequentes / Didática de Atendimento

### 15. Como a autora conceitua a magia e de que maneira a raiva e reclamação manipulam os elementais?
**Resposta**: Andresa conceitua que tudo no mundo opera por "magia pura", pois não há materialização no universo sem manipular a energia vital. A estrutura da realidade é composta por "Espírito, alma e matéria", e os "elementais da natureza" (como as energias da terra, água e fogo) não têm racionalidade própria; eles obedecem a comandos magnéticos. A nível vibracional, a pessoa que vive com "reclamação o tempo inteiro tem na cabeça, magia e a vida não dá certo? Claro, eu tô reforçando a magia dia a dia". Somaticamente, ao ficar "Puto da vida... raiva", o corpo emite um pulso magnético que ativa o "elemental fogo", comandando inconscientemente que essas forças ajam (ou destruam) as coisas ao seu redor.


## Referencia

ANDRESA MOLINA. *Magia Prática e Elementais*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
