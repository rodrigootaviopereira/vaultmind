---
type: conceito
author: Hélio Couto
tags: [colapso, onda, escolha, consciencia]
sources: ["[[raw/archive/curso_completo_de_mecânica_quântica_prof_hélio_coutopdf/curso_completo_de_mecânica_quântica_prof_hélio_coutopdf_cap_02_capítulo_2_ª_aula__investigando_seu_sistema_de_crenças.txt]]", "[[raw/archive/curso_completo_de_mecânica_quântica_prof_hélio_coutopdf/curso_completo_de_mecânica_quântica_prof_hélio_coutopdf_cap_03_capítulo_3_ª_aula__basta_um_pensamento.txt]]"]
---

# Conceito de Colapso da Função de Onda

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/curso_completo_de_mecânica_quântica_prof_hélio_coutopdf/curso_completo_de_mecânica_quântica_prof_hélio_coutopdf_cap_02_capítulo_2_ª_aula__investigando_seu_sistema_de_crenças.txt]]
  - [[raw/archive/curso_completo_de_mecânica_quântica_prof_hélio_coutopdf/curso_completo_de_mecânica_quântica_prof_hélio_coutopdf_cap_03_capítulo_3_ª_aula__basta_um_pensamento.txt]]

## Referencia

HÉLIO COUTO. *Conceito de Colapso da Função de Onda*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/curso_completo_de_mecânica_quântica_prof_hélio_coutopdf/curso_completo_de_mecânica_quântica_prof_hélio_coutopdf_cap_02_capítulo_2_ª_aula__investigando_seu_sistema_de_crenças.txt]], [[raw/archive/curso_completo_de_mecânica_quântica_prof_hélio_coutopdf/curso_completo_de_mecânica_quântica_prof_hélio_coutopdf_cap_03_capítulo_3_ª_aula__basta_um_pensamento.txt]]. Acesso em: 17 jun. 2026.
