---
type: principio
author: Andresa Molina
tags: [musculatura-energetica, mediunidade, pratica-clinica, sintonia, camara-humanosense]
sources: ["[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio da Musculatura Energética (A prática clínica como único caminho)

- **Definição**: A premissa vibracional de que a percepção mediúnica e a habilidade de "ver" ou "sentir" o campo do assistido não são dons estáticos, mas músculos orgânicos e espirituais que atrofiam sem uso e só se desenvolvem através da aplicação prática repetitiva.
- **Justificativa**: Muitos terapeutas entram em paralisia clínica achando que "não conseguem sentir" e por isso não devem atender. A autora decreta o oposto: é o ato de atender que ensina o corpo a sentir. A nível energético, cada vez que o terapeuta aciona o comando da Câmara Humanosense, ele expande os próprios dutos neurológicos e sutis. A autora explica que isso é um "desenvolvimento mediúnico" onde o terapeuta começa a antever o que o paciente vai dizer antes mesmo dele abrir a boca. Quanto mais se atende, mais o terapeuta "sintoniza" o Wi-Fi da egrégora. O princípio dita a lei da ação: o transe e a visão interdimensional só se instalam em quem se joga na experiência clínica, abandonando a teoria.
- **Evidências**: "Quanto mais você atende e é dentro desse desse caminho... mais você vai ter habilidade e de percepção ali, isso vai se desenvolvendo. Então é uma capacidade é que a gente vai desenvolvendo uma musculatura energética e espiritual, um campo de atuação que é um desenvolvimento mediúnico também... Eu falo que o única o único jeito de aprender a sentir é sentindo, né? ...Não tem como aprender a sentir se não for sentindo."
- **Implicações**: O terapeuta em formação deve priorizar a prática clínica (estágios ou atendimentos de treinamento) em detrimento do acúmulo de teoria teórica.
- **Conexões**: [[Conceito da Camara HumanoSense]], [[Conceito da Ampliacao Mediunica Organica]]
- **Notas Pessoais**: A insegurança inicial só é vencida na cadeira de atendimento, não lendo manuais.

## Perguntas Frequentes / Didática de Atendimento

### 1. Como Andresa Molina conceitua a "Musculatura Energética", e de que forma a falta de prática clínica afeta a percepção e a mediunidade do terapeuta?
**Resposta**: Andresa conceitua a "Musculatura Energética" como uma capacidade orgânica e espiritual que só cresce com o uso contínuo. Ela afirma que "é uma capacidade é que a gente vai desenvolvendo uma musculatura energética e espiritual, um campo de atuação que é um desenvolvimento mediúnico também".

A nível somático e vibracional, a falta de prática impede o terapeuta de desenvolver o seu canal de percepção (não havendo a palavra "atrofia", mas sim a impossibilidade de aprender). A autora decreta que "o única o único jeito de aprender a sentir é sentindo". Sem se colocar na cadeira para atender, o corpo do terapeuta não equaliza com as forças sutis: "Se você não fizer a aplicação, você nunca vai entender o que é a frequência da Câmara Homense". Apenas a vivência clínica expande os dutos mediúnicos, pois "quanto mais a gente faz, mais a gente conecta, mais fácil vai ficando esse campo de atuação".


## Referencia

ANDRESA MOLINA. *Princípio da Musculatura Energética*. Aula 09 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]].
