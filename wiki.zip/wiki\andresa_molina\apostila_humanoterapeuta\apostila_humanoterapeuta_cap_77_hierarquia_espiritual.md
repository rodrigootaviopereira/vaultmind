---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_77_hierarquia_espiritual.md]]"]
---

# Cap 077 - Hierarquia Espiritual

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_77_hierarquia_espiritual.md]]

## Referencia

ANDRESA MOLINA. *Cap 077 - Hierarquia Espiritual*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_77_hierarquia_espiritual.md]]. Acesso em: 17 jun. 2026.
