---
type: conceito
author: Andresa Molina
tags: [personalidade, ego, defesa, sobrevivencia]
sources: ["[[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]"]
---

# Conceito de Personalidade da Dor

- **Definição**: A armadura do ego aliada ao medo e ao instinto de proteção, moldada de forma defensiva para se proteger da exclusão, garantir afeto e evitar o abandono.
- **Justificativa**: A personalidade em si faz parte do ego saudável que nos ajuda a existir e criar vínculos no mundo. O problema surge quando ela se alia à dor, cristalizando-se em padrões rígidos como o Explorador, o Cobrador ou o Limitador.
- **Evidências**: "Essa ferramenta que usamos para existir no mundo, nos relacionar e criar vínculos. Por si só, ela é necessária, que é esse ego, essa parte individualizada que todos nós temos. [...] Mas quando a personalidade se alia à dor, ao medo e ao instinto de proteção, ela acaba se moldando de forma defensiva. É nesse ponto que surgem as três personalidades, que é o explorador, o limitador e o cobrador."
- **Implicações**: Identificar se a personalidade do assistido está atuando em modo defensivo permite saber por que ele cria barreiras ao tratamento.
- **Conexões**: [[Principio da Mandala da Dor]], [[Conceito de Explorador Limitador e Cobrador]]
- **Notas Pessoais**: O egoísmo (doença do ego) se manifesta quando olhamos apenas para nós mesmos, seja por nos acharmos superiores ou inferiores.

## Referencia

ANDRESA MOLINA. *Conceito de Personalidade da Dor*. Aula 03 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]].
