---
type: principio
author: Andresa Molina
tags: [desipnose, livre-arbitrio, sugestao, automagia, consciencia]
sources: ["[[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio da Desipnose da Consciência (A proibição da sugestão clínica)

- **Definição**: A diretriz ética e magnética que proíbe o terapeuta de usar comandos hipnóticos ou sugestionar as ações do assistido durante o transe, estabelecendo que o propósito da tecnologia não é criar novas crenças, mas desintegrar as antigas.
- **Justificativa**: A nível energético, a humanidade adoece porque cria "automagias" baseadas no medo, aceitando comandos limitantes ao longo da vida. Se o terapeuta conduz a sessão dizendo "vai lá, pensa na sua mãe, fala para ela que você não gosta", ele está utilizando uma "sugestão hipnótica" e implantando uma nova amarra na mente da pessoa. A egrégora do Humanosense recusa sumariamente validar essa prática. A autora é categórica ao decretar a essência do método: não é reprogramar a mente com frases feitas, mas sim "libertar mentes, consciências que estão aprisionadas". A cura é a "desipnose" do ego, forçando o indivíduo a acordar do transe doentio em que vivia.
- **Evidências**: "Esse trabalho é a desipnose, porque a hipnose criou a automagia e nós estão e as pessoas estão presas nos comandos que elas deram para si mesmas... A gente não sugere e não sugestiona nada. A equipe espiritual do código sense não vai apoiar sugestão, não vai apoiar a hipnose, porque o trabalho é desipnar mentes aprisionadas, é libertar... Então, a grande maioria da humanidade tá aprisionada... a gente vai libertar, liberar, né, essa pessoa."
- **Implicações**: O terapeuta deve abster-se de roteiros hipnóticos tradicionais, permitindo que a própria mente do paciente projete o cenário de resgate de forma autêntica.
- **Conexões**: [[Principio da Nao-Manipulacao no Transe]], [[Principio da Nao-Inducao no Transe Astral]]
- **Notas Pessoais**: Desipnotizar significa quebrar a narrativa ilusória em que o paciente se apoia.

## Perguntas Frequentes / Didática de Atendimento

### 1. Como Andresa Molina conceitua a "Desipnose da Consciência", e de que forma a sugestão viola o propósito do método?
**Resposta**: Andresa Molina conceitua a "desipnose" como o desfazimento ativo das crenças limitantes que o próprio assistido implantou em si. Ela afirma: "Esse trabalho é a desipnose, porque a hipnose criou a automagia e nós estão e as pessoas estão presas nos comandos que elas deram para si mesmas".

A sugestão (hipnose) viola o propósito do método porque induzir o paciente a fazer algo (ex: "Vai lá, pensa na sua mãe, fala para ela que você não gosta") é colocar uma nova amarra na psique dele. A nível somático e energético, a egrégora atua para expandir a biologia, não para condicioná-la: "A equipe espiritual do código sense não vai apoiar sugestão, não vai apoiar a hipnose, porque o trabalho é desipnar mentes aprisionadas, é libertar, né, e não aprisionar".


## Referencia

ANDRESA MOLINA. *Princípio da Desipnose da Consciência*. Aula 10 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]].
