---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_87_tecnica_drenagem_energetica.md]]"]
---

# Cap 087 - Tecnica Drenagem Energetica

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_87_tecnica_drenagem_energetica.md]]

## Referencia

ANDRESA MOLINA. *Cap 087 - Tecnica Drenagem Energetica*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_87_tecnica_drenagem_energetica.md]]. Acesso em: 17 jun. 2026.
