---
type: conceito
author: Andresa Molina
tags: [metodologia, identificacao, depuracao, execucao]
sources: ["[[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]]"]
---
# Metodologia Humanosense (Identificação, Depuração e Execução)

- **Definição Precisa**: O protocolo clínico, energético e espiritual estruturado em 3 etapas consecutivas para decodificar, depurar sombras ectoplasmáticas e fecundar novos desejos.
- **Sinônimos/Variações**: Método HumanoSense, Aplicação em Três Etapas, Protocolo HumanoSense
- **Contexto de Uso**: Terapêutica energética-espiritual voltada à liberação de bloqueios somáticos, emocionais e financeiros.
- **Relação com Princípios**: [[Principio de Lugar Funcao e Potencia]], [[Principio do Poder do Tres]]
- **Exemplos do Material**: "como que funciona a aplicação? Ela é dividida em três etapas: identificação, depuração e execução... A identificação é entender a razão racional consciente e inconsciente... Depuração, preparar o espírito, esvaziar, sentir a dor emocional tem a ver com a limpeza espiritual... Execução que é espiritualizar, materialização energética, fusão do masculino e do feminino."
- **Aplicação Prática**: Investigar via radiestesia (Identificação), conduzir o esvaziamento do fractal de dor (Depuração) e direcionar a fusão das polaridades para novos projetos (Execução).
- **Conexões Externas**: [[Conceito da Mesa HumanoSense]], [[Tecnica de Espelhamento do Consciente e Inconsciente]], [[Tecnica de Depuracao e Desobsessao de Fractais]]

## Perguntas Frequentes / Didática de Atendimento

### Como Andresa Molina descreve a divisão metodológica do Código HumanoSense em suas três etapas macro (Identificação, Depuração e Execução)?

A autora descreve essas três etapas como as fases essenciais, onde não há cura ou criação sem que uma anteceda a outra:
*   **Identificação:** É a fase focada em "entender a razão racional consciente e inconsciente". Aqui o terapeuta coleta os relatos do assistido e os compara com a leitura do campo.
*   **Depuração:** É a etapa da faxina energética focada em "preparar o espírito, esvaziar, sentir a dor emocional tem a ver com a limpeza espiritual". A nível somático e vibracional, o terapeuta conecta o assistido aos seus "fractais de dor" e o autoriza a sentir essa emoção reprimida, com o objetivo de "esgotar esse fractal" e esvaziar o terreno para a próxima fase.
*   **Execução:** É a fase da materialização, descrita como "espiritualizar, materialização energética, fusão do feminino e do masculino". Após a limpeza do campo, o terapeuta conduz a "fecundação e materialização do desejo do assistido".


## Referencia

ANDRESA MOLINA. *Metodologia Humanosense (Identificação, Depuração e Execução)*. Aula 01 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]].
