---
type: conceito
author: Andresa Molina
tags: [autoabandono, essencia, personagem, persona, identidade, falso-eu, 4a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito do Falso Eu Sou (Essência vs. Personagem)

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: O Falso Eu Sou é a identidade artificial, rótulos e papéis sociais (a boa mãe, a profissional perfeita, a amiga prestativa, ou mesmo autodepreciações como *"eu sou burra"*, *"sou imbecil"*) que o indivíduo constrói e passa a acreditar ser o seu ser verdadeiro. Ele surge como um mecanismo de sobrevivência e defesa para obter aprovação, segurança e afeto dos outros.
- **Formulação de apoio**: A essência (o Eu Sou verdadeiro) é a identidade primordial da alma encarnada, com seus interesses autênticos e projeto de vida inato. À medida que o indivíduo se desfigura para servir ao mundo, a essência é sufocada pelas camadas de exigência e conveniência, criando a persona do Falso Eu Sou. A cura no HumanoSense requer desmascarar esses papéis para estabelecer um diálogo direto com o Eu Sou verdadeiro.

## Contexto de Uso

- Usado para guiar sessões de desipnose e remoção de máscaras. Permite ao terapeuta confrontar os discursos lógicos e os personagens de dor que o assistido apresenta no consultório.

## Relação com Princípios

- [[Principio da Liberdade Consciente]]
- [[Principio do Amor Condicionado e Autoabandono]]
- [[Conceito do Abandono de Si]]

## Exemplos do Material

- *"E é com esse você que eu quero conversar, é com essa essência... com você de verdade, não com a mãe, a irmã, a profissional competente ou a burra, a imbecil... É com essa parte que eu quero falar, nem com a sua crença sobre identidade, sobre quem você pensa que é e nem sobre o personagem..."*
- O indivíduo que é aplaudido pelo grupo de amigos por organizar todas as festas e dar carona a todos, definindo-se como "a pessoa mais legal", enquanto ignora sua exaustão e depressão interna.

## Aplicação Prática

1. **Desmascarar os Papéis**: Auxiliar o assistido a listar todas as definições que começam com *"Eu sou..."* e identificar quais delas pertencem a personagens utilitários e quais pertencem ao seu sentir original.
2. **Aplicar Desidentificação**: Conduzir técnicas de isolamento de papéis, como a [[Tecnica de Remocao de Papeis Sociais|Prática de Remoção de Papéis Sociais]], para expor a vacuidade das máscaras.
3. **Reconectar com a Origem**: Guiar a energia da sessão diretamente ao centro da coordenada de silêncio para desprogramar os pactos de sobrevivência infantil (Automagia) e dar voz ao Eu Sou essencial.

## Perguntas Frequentes / Didática de Atendimento

### De que maneira o comportamento de ser a "pessoa legal da galera/gente boa do rolê" esconde o medo inconsciente da solidão absoluta?

Andresa explica que assumir o papel da "pessoa super gente boa" que topa tudo é, na verdade, um mecanismo de defesa baseado no medo do abandono. A pessoa anula completamente as suas próprias preferências e essência para se moldar ao que os outros querem, indo a todo tipo de lugar (reggae, samba, sertanejo, rock) e dizendo "sim" para todas as demandas.

O que sustenta essa máscara de pessoa "legal" é a crença inconsciente e aterrorizante de que, se ela dissesse "não" ou impusesse o que realmente gosta, seria rejeitada e ficaria "absolutamente sozinha". Para garantir que não perderá os amigos e que pertencerá a um grupo, ela paga o alto preço de se perder de si mesma, dizendo sim para o mundo enquanto diz um doloroso "não" para os seus próprios limites e vontades.

## Referência

ANDRESA MOLINA. *Conceito do Falso Eu Sou (Essência vs. Personagem)*. Aula 04 - Coordenada 4 (A Mulher Antes de Ser de Todos). Fontes: [[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]].
