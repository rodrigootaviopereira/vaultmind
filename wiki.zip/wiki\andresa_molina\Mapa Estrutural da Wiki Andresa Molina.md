---
type: conceito
author: Andresa Molina
tags: [estrutura, hub, humanosense, mapa-da-alma, cura, protagonismo]
sources: []
---
# Mapa Estrutural da Wiki Andresa Molina

- **Propósito**: Organizar a wiki por camadas de leitura, evitando duplicidade entre método, conceitos, princípios e técnicas.
- **Eixo 1 - Mapa da Alma**: [[wiki/andresa_molina/Conceito do Mapa da Alma]], [[wiki/andresa_molina/Principio da Memoria Celular Ancestral]], [[wiki/andresa_molina/Conceito dos 16 Destinos ou Odus]], [[Arquitetura do HumanoSense]]
- **Eixo 2 - Relações e Papéis**: [[wiki/andresa_molina/Conceito de Protagonista e Personagem]], [[wiki/andresa_molina/Conceito de Matar o Pai e a Mae]], [[wiki/andresa_molina/Principio da Hierarquia dos Papeis]]
- **Eixo 3 - Dor e Reparação**: [[wiki/andresa_molina/Conceito do Ciclo de Autopunicao]], [[wiki/andresa_molina/Conceito de Campo Emocional e Dependencia]], [[wiki/andresa_molina/Conceito de Ressignificacao vs Reconsolidacao]]
- **Eixo 4 - Método HumanoSense**: [[wiki/andresa_molina/Conceito do Metodo HumanoSense]], [[wiki/andresa_molina/Conceito da Mesa HumanoSense]], [[wiki/andresa_molina/Principio do Respeito a Tecnica e a Equipe Espiritual]], [[Arquitetura do HumanoSense]]
- **Eixo 5 - Liberdade e Sustentação**: [[wiki/andresa_molina/Principio da Liberdade Consciente]], [[wiki/andresa_molina/Conceito do Eixo da Liberdade]], [[wiki/andresa_molina/Principio da Sustentacao do Que e Seu]]
- **Uso**: Consulte este hub antes de criar notas novas quando o tema puder ser absorvido por um desses eixos.
- **Nota de Consolidação**: [[Arquitetura do HumanoSense]]
- **Notas Pessoais**:
