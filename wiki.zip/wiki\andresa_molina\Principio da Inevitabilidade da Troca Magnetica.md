---
type: principio
author: Andresa Molina
tags: [troca-magnetica, exaustao, doacao-vital, fisicalidade]
sources: ["[[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio da Inevitabilidade da Troca Magnética (O preço somático da cura)

- **Definição**: A constatação biológica universal de que é absolutamente impossível atuar como terapeuta interdimensional sem doar e transmutar o próprio fluído vital (magnetismo físico) na mesa radiestésica ou durante o atendimento.
- **Justificativa**: Terapeutas frequentemente têm medo de "perder energia" para o paciente e buscam técnicas para se blindar totalmente. A autora destrói essa ilusão: a troca fluídica é a condição primária da existência e do trabalho energético. Quando o profissional acopla na Câmara e comanda as limpezas, a sua biologia atua como um canal condutor elétrico ("cedendo magnetismo"). Não existe assepsia que impeça o desgaste natural da operação mágica, pois a intervenção espiritual usa a densidade da matéria do terapeuta para ancorar a cura no plano físico do assistido.
- **Evidências**: "A gente sempre tá, não tem como a gente tá conectado com alguém para fazer uma coisa boa, ruim, qualquer coisa que a gente não esteja cedendo magnetismo, né? Então isso, isso é uma coisa inerente do ser humano de trocas energéticas, não tem como. Então sim, natural que isso aconteça... é super natural."
- **Implicações**: O terapeuta deve aceitar o cansaço físico pós-sessão como parte da fisiologia do trabalho, investindo em sua própria manutenção energética e repouso.
- **Conexões**: [[Principio da Preparacao do Terapeuta]], [[Tecnica de Retorno a Consciencia e Harmonizacao]]
- **Notas Pessoais**: Blindagem 100% estéril é uma ilusão mental; toda cura exige fusão e entrega material.

## Perguntas Frequentes / Didática de Atendimento

### 6. Por que Andresa Molina sustenta que ceder magnetismo físico é inerente ao ato terapêutico, e como os limites da biossegurança operam?
**Resposta**: A autora sustenta que ceder magnetismo é a base fundamental de qualquer conexão, não havendo barreira que isole totalmente o terapeuta: **"não tem como a gente tá conectado com alguém para fazer uma coisa boa, ruim, qualquer coisa que a gente não esteja cedendo magnetismo, né?"**.

A nível somático e energético, a intervenção na Câmara exige que a biologia do operador sirva de condutor de força vital para efetuar o resgate. Como a autora decreta que isso é **"uma coisa inerente do ser humano de trocas energéticas, não tem como"**, não há menção a "limites de biossegurança" que evitem essa troca específica; ela deve ser aceita e compreendida pelo terapeuta como **"super natural"** no processo clínico.


## Referencia

ANDRESA MOLINA. *Princípio da Inevitabilidade da Troca Magnética*. Aula 10 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]].
