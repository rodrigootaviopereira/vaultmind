---
type: tecnica
author: Andresa Molina
tags: [rastreio-duplo, mandalas, teste-muscular, pendulo, confronto]
sources: ["[[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]"]
---

# Dinâmica de Rastreio Duplo nas Mandalas (A marcação do consciente vs. inconsciente na mesa)

- **Objetivo**: Comparar a nota intelectual consciente dada pelo assistido (de 0 a 10) com a nota eletromagnética inconsciente real indicada pelo pêndulo na régua da mesa, revelando o gap de autoengano e sabotagem do ego.
- **Pré-requisitos**: Ancoragem física e abertura da egrégora do assistido no selo central da mesa.
- **Passo a Passo**:
  1. **Escolha Antagônica**: Na Mandala do Amor, ao escolher uma pergunta diagnóstica na pétala Masculino, o terapeuta deve selecionar a mesma pergunta pareada correspondente na pétala Feminino (calibrando o equilíbrio entre ação e contenção).
  2. **Nota Consciente**: O terapeuta verbaliza a pergunta (ex: *"De 0 a 10, o quanto você se sente pertencente a esse espaço?"*) e o assistido responde de forma rápida e intuitiva. Anotar a nota declarada.
  3. **Nota Inconsciente**: Mantendo a sintonia do pêndulo na régua de numeração da mesa, o terapeuta foca na mesma pergunta mentalmente e anota a nota em que o pêndulo interrompe o balanço ou gira.
- **Duração/Frequência**: Praticado na fase de mapeamento de mandalas com o bloco verde em todas as sessões.
- **Indicadores de Sucesso**: Identificação de gaps de 3 pontos ou mais entre a resposta mental e a realidade do campo bioenergético, permitindo apontar a mentira de autodefesa do ego do assistido.
- **Variações**: Rastreio do consciente/inconsciente na Mandala do Amor vs. Mandala da Dor (onde não é necessário seguir a ordem numérica das perguntas).
- **Conceitos Envolvidos**: [[Conceito do Gap Vibracional]], [[Conceito da Mandala do Amor]], [[Principio da Desilusao]]

## Perguntas Frequentes / Didática de Atendimento

### 13. Como é executada a testagem dupla no Bloco Verde e qual a regra para parear perguntas antagônicas entre as polaridades na Mandala do Amor?
**Resposta**: O processo é executado confrontando a resposta verbal do cliente com a medição radiestésica. O terapeuta lê a pergunta, o cliente responde (o racional/consciente), e então o terapeuta usa o pêndulo na régua da mesa para "ver se no inconsciente quanto que é de verdade".

A regra de pareamento na Mandala do Amor exige que, se o terapeuta escolher "a pergunta número um na energia no masculino, você vai escolher a pergunta número um na energia do feminino". A nível somático e vital, a autora explica que a polaridade masculina e a feminina na mesma numeração "são antagônicas, parece a mesma coisa, mas uma está falando de sustentação e outro está falando de iniciação, de ímpeto". Isso revela se o corpo da pessoa apenas inicia projetos e os abandona, ou se ela apenas executa tarefas alheias sem ter coragem para criar algo próprio.

## Referencia

ANDRESA MOLINA. *Dinâmica de Rastreio Duplo nas Mandalas*. Aula 07 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]].
