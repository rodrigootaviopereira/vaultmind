---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_81_inducao_espiritual_ou_obsessao_simples.md]]"]
---

# Cap 081 - Inducao Espiritual Ou Obsessao Simples

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_81_inducao_espiritual_ou_obsessao_simples.md]]

## Referencia

ANDRESA MOLINA. *Cap 081 - Inducao Espiritual Ou Obsessao Simples*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_81_inducao_espiritual_ou_obsessao_simples.md]]. Acesso em: 17 jun. 2026.
