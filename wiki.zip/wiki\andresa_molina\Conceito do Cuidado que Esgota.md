---
type: conceito
author: Andresa Molina
tags: [autoesvaziamento, esgotamento, cuidado, magnetismo, 5a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito do Cuidado que Esgota (5ª Coordenada)

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: O Cuidado que Esgota (5ª Coordenada) é um padrão comportamental e somático no qual o indivíduo doa compulsivamente sua energia, tempo e atenção para resolver as demandas de todos ao redor, mas é incapaz de abrir a porta para receber nutrição e cuidado. Essa dinâmica gera o esvaziamento de sua força vital ("vazio de espírito"), comprometendo o seu magnetismo de atração para prosperidade, relacionamentos saudáveis e estabilidade física.
- **Formulação de apoio**: Sob o efeito da automação do sistema CARE no modo sobrevivência, o indivíduo acredita que só merece ser amado se for útil. Como resultado, esgota todas as suas reservas energéticas na vida externa. Sem energia vital ("quanto") sobrando, o assistido perde a ressonância para sustentar e manter oportunidades profissionais e relacionamentos abundantes, entrando em colapso físico e financeiro.

## Contexto de Uso

- Usado para diagnosticar assistidos em consultório que reclamam de fadiga crônica, escassez financeira inexplicável, e conflitos familiares recorrentes ("âncoras" de suas famílias que se sentem sós e afogando).

## Relação com Princípios

- [[Principio da Plenitude Energetica e do Cuidado]]
- [[Conceito do Modo Sobrevivencia no Cuidado]]
- [[Principio do Amor Condicionado e Autoabandono]]

## Exemplos do Material

- *"Você cuida de todo mundo, você faz o melhor para todo mundo, você ama todo mundo, mas você sai esgotado. O que que acontece aqui?"*
- *"Você tá sendo âncora para todo mundo, você tá sustentando tudo para todo mundo. E ninguém está vendo que você tá se afogando... E ninguém procura ninguém vazio. Então, o que você precisa é conseguir entrar em plenitude."*

## Aplicação Prática

1. **Rastrear o Registro de Amparo**: Aplicar a [[Tecnica de Identificacao da Carecia e Cuidado|Técnica de Identificação da Carência e Cuidado]] para constatar a incapacidade de aceitar amparo.
2. **Reconsolidação Informacional**: Conduzir o tratamento a nível celular e ancestral para desfazer o pacto infantil de sobrevivência ("se eu não cuidar, serei abandonado e morrerei").
3. **Restaurar o Fluxo Magnético**: Apoiar o assistido na transição de delegar fardos alheios, fortalecendo sua plenitude ("recheio de si") para recuperar a atração financeira e a harmonia nos vínculos afetivos.

## Referência

ANDRESA MOLINA. *Conceito do Cuidado que Esgota (5ª Coordenada)*. Aula 05 - Coordenada 5 (O Cuidado que Esgota). Fontes: [[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. Por que a criança que sente que "dar trabalho é perigoso" acaba invertendo o fluxo e passando a cuidar dos pais, e qual o impacto disso na sua capacidade de receber na vida adulta?
**Resposta**: A autora fundamenta essa dinâmica em um forte instinto biológico e emocional de sobrevivência. Na infância, a criança depende inteiramente de alguém (mamãe, vovó, titia) que seja *"o responsável por te nutrir, por te manter protegido"*. O cérebro primitivo e emocional da criança capta que *"se você desse trabalho, qualquer que fosse, que se você incomodasse alguém, não, a mamãe não vai gostar"*.

Diante do terror biológico de que essa pessoa *"poderia não cuidar de você"* (o que significaria a morte por desamparo), a criança cria uma defesa extrema de autoabandono. Ela decide que precisa parar de ser um peso e, emocionalmente, decreta: *"eu não quero que ela fique cuidando de mim, porque eu dou muito trabalho. Então, deixa eu cuidar. Você registrou invertido"*. Essa inversão forçada de papéis tem raízes profundas na necessidade de pertencer e sobreviver, sendo estruturada em *"bases emocionais, com bases ancestrais"*.

**O impacto na vida adulta**: O impacto direto dessa inversão é que o adulto se torna incapaz de ser cuidado. A autora decreta que *"você está esgotado porque você cuida de todo mundo, mas não aprendeu a receber esse cuidado"*.

Como o sistema nervoso gravou que o afeto e a vida dependem exclusivamente da própria utilidade, o adulto *"não consegue aceitar este cuidado porque você aprendeu que você só vai ser amado, nutrido, protegido se você cuidar"*. Na prática, essa pessoa passa a ser a *"âncora para todo mundo"*, doando tudo o que tem para que ninguém a abandone, até ficar em *"frangalhos"* e *"vazia"*, o que destrói o seu magnetismo de atração, bloqueia a prosperidade e gera falência nos relacionamentos.

### 2. Onde e como a marca do "Cuidado que Esgota" costuma ser somatizada e mapeada no corpo físico (o "X" do mapa na 5ª Coordenada)?
**Resposta**: O texto não aponta um local anatômico exato e predeterminado (como um órgão específico, costas, peito ou garganta) onde fica o "X" dessa somatização para a 5ª Coordenada.

No entanto, a autora detalha *como* essa marca existe e se expressa a nível somático: ela se consolida como um *"registro de memória que ficou no seu corpo, no seu cérebro e criou uma trilha que faz sempre o mesmo caminho"*. Em vez de buscar esse ponto por meio de manuais lógicos ou diagnósticos puramente intelectuais, o terapeuta e o assistido devem mapeá-lo através da permissão sensorial do próprio corpo. O indivíduo deve encontrar as suas *"coordenadas"* internas rastreando o sentir imediato quando contorna a racionalidade: *"Eu quero que você acredite no que você sente, nessa coisa que pode não fazer sentido, mas eu sinto um negócio aqui, parece que tá ahí"*. É esse *"negócio aqui"* sentido fisicamente (um aperto, peso ou desconforto corporal inegável) que indica onde a memória celular da 5ª Coordenada está instalada para ser trabalhada e reconsolidada.


