---
type: concept
author: Andresa Molina
tags: [divorcio-energetico, contratos, pactos, fim-de-ciclo]
sources: ["[[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]"]
---

# O Divórcio Energético / Quebra de Contratos (O desfazimento das alianças invisíveis)

- **Definição**: O conceito somático e vibracional de romper juramentos ("automagias") criados por casamentos, amizades, promessas de pobreza ou laços de emprego, extirpando a massa espiritual que mantinha o paciente vinculado ao passado.
- **Justificativa**: Quando o assistido pronuncia juras de dor ou fidelidade cega ("Vou ser seu para sempre" ou "Minha vida é essa empresa"), ele usa o magnetismo para forjar correntes na dimensão astral que sufocam o seu futuro. O "Divórcio Energético" transcende a assinatura de papéis no cartório. Ele é o desfazer nuclear do elo cósmico. A nível clínico, o terapeuta transporta a pessoa à cena e obriga a consciência dela a desintegrar a intenção: "despede dessa situação, diz tudo o que você tem vontade... e você se despede e encerra". Essa quebra corta o cordão umbilical apodrecido, desidratando o contrato interdimensional.
- **Evidências**: "O que é um divórcio? Um corte. Então a pessoa vai lá e ela vai cortar aquilo que ela não quer mais... É desfazer uma aliança, des fazer um elo, é fim, é corte. É isso que é um divórcio energético de qualquer coisa, para relacionamento, para finalização de trabalho... toda vez que a gente faz qualquer coisa, qualquer contrato, a gente tá fazendo um processo de automagia... a gente cria essa massa e essa massa ela vai atrair energia das mesmas frequências... Então é esse processo é um processo para acontecer a limpeza mesmo... desfazer os contratos é para finalização."
- **Implicações**: O terapeuta deve induzir a quebra ativa de contratos em transe e queimar as pontes de atração de mesma frequência com o passado.
- **Conexões**: [[Tecnica de Comandos de Limpeza e Resgate Astral]], [[Tecnica de Limpeza e Fechamento do Portal]]
- **Notas Pessoais**: Despedir-se verbalmente e aceitar o corte no plano físico é o que sela o divórcio extrafísico.

## Perguntas Frequentes / Didática de Atendimento

### 14. Como Andresa Molina define o "Divórcio Energético", e de que maneira os contratos geram atração?
**Resposta**: Andresa define o "Divórcio Energético" puramente como o encerramento absoluto de um ciclo doentio. Ela afirma: **"O que é um divórcio? Um corte. Então a pessoa vai lá e ela vai cortar aquilo que ela não quer mais... Divórcio é corte, é fim. É desfazer uma aliança, des fazer um elo, é fim, é corte"**. Serve para **"deixar o passado no passado, seguir em frente"**.

Somaticamente e vibracionalmente, qualquer contrato ou jura feita pela boca gera atração porque a mente realiza, mesmo de maneira despretenciosa, **"um processo de automagia"**. Ao firmar um pacto, o corpo e a intenção da pessoa emitem um comando que coagula energia na dimensão invisível: **"com o nosso emocional, um comando mental, a gente cria essa massa"**. Essa massa não fica inerte; ela atua como um ímã constante na vida do indivíduo, pois **"essa massa ela vai atrair energia das mesmas frequências... e vai desencadear um monte de outras coisas"**. O divórcio energético é a ferramenta espiritual que desintegra essa massa e liberta o campo.


## Referencia

ANDRESA MOLINA. *O Divórcio Energético / Quebra de Contratos*. Aula 10 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]].
