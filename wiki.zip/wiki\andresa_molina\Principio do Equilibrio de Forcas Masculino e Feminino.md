---
type: principio
author: Andresa Molina
tags: [polaridades, energia, fluxo, acao, masculino, feminino, 2a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/02 - O AMOR QUE NUNCA VOLTOU - 2ª Coordenada - O Mapa da Alma.md]]"]
---

# Princípio do Equilíbrio de Forças (Masculino e Feminino)

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/02 - O AMOR QUE NUNCA VOLTOU - 2ª Coordenada - O Mapa da Alma.md]]

## Definição

- **Definição**: O Princípio do Equilíbrio de Forças postula que todo ser humano é composto por duas forças arquetípicas complementares que regem a manifestação da vida e dos recursos: a **Força Masculina** (princípio ativo, focado no mundo de fora, na ação, conquista, coragem e capacidade de estabelecer limites) e a **Força Feminina** (princípio receptivo, focado no mundo de dentro, no acolhimento, na intuição e na capacidade de sustentar e manter o que foi criado). A plenitude existencial e material depende do fluxo equilibrado de dar (Masculino) e receber/sustentar (Feminino).
- **Formulação de apoio**: O desequilíbrio dessas forças inviabiliza o sucesso do indivíduo. Se a força masculina estiver enfraquecida por traumas ancestrais, há o medo de desobedecer e a incapacidade de agir rumo aos sonhos. Se a força feminina estiver ferida, a pessoa não consegue reter ou sustentar suas conquistas, abandonando projetos no meio do caminho sob o pretexto de "procrastinação".

## Justificativa

- No HumanoSense, este princípio é crucial para diagnosticar bloqueios de realização e prosperidade. Muitas vezes, a autossabotagem e a procrastinação não são falhas de "caráter" ou preguiça, mas um desalinhamento energético profundo entre a força de iniciar (Masculino) e a força de sustentar (Feminino) decorrente de emaranhamentos com a história dos ancestrais.

## Evidências

- *"Dar e receber... o masculino é o que dá... e o feminino é o interno, é o receber. Se esse equilíbrio entre o dar e o receber... tiver desequilibrado, sendo o seu ou sendo do seu tataravô em você, você nunca vai conseguir ter um fluxo. Você sempre vai olhar a vida do outro e vai falar: 'Eu tenho azar, é karma, é maldição'."*
- *"Com a falta de coragem que vem da linhagem masculina, você não construiu nada... E por isso não é capaz de sustentar, que é a força de dar continuidade. Você abandona tudo no meio do caminho porque você não sustenta... chama isso de procrastinação, mas é a sua fraqueza feminina."*

## Implicações

- **Atração vs. Sustentação**: Conquistar dinheiro ou parceiros depende da ativação do polo masculino (ação/projeção), mas mantê-los e fazê-los prosperar depende da saúde do polo feminino (receptividade/sustentação).
- **Desobediência Saudável**: A força masculina curada concede ao assistido a coragem de desobedecer comandos limitantes herdados dos pais para seguir o próprio propósito, saindo do ciclo do amor condicionado.

## Conexões

- [[Conceito da Polaridade Masculino e Feminino]]
- [[Principio do Amor Condicionado e Autoabandono]]
- [[Conceito do Ciclo de Autopunicao]]

## Notas Pessoais

- Reservado para observações do usuário.

## Perguntas Frequentes / Didática de Atendimento

### O que Andresa ensina sobre equilibrar o masculino e feminino?

Andresa ensina que o **masculino e o feminino não se referem a gênero ou sexo biológico (homem e mulher), mas sim a "cargas" ou forças energéticas presentes dentro de cada indivíduo**, independentemente de quem ele seja.

Os principais pontos de seus ensinamentos sobre esse equilíbrio são:

**1. A Fusão Necessária para a Criação**
Ela enfatiza de forma categórica que, se essas duas cargas estiverem em desequilíbrio, **"não nasce nada"**. A criação, a fluidez e a materialização na vida de uma pessoa só ocorrem na fusão equilibrada dessas duas energias.

**2. A Dinâmica das Forças (Conceito da 2ª Coordenada)**
Essas energias representam o fluxo vital do dar e receber, associadas à [[Conceito da Polaridade Masculino e Feminino|Polaridade Masculina e Feminina]]:
*   **A Carga Masculina:** É o princípio de ação. Representa a força que dá, a energia voltada para o mundo externo, a coragem para o enfrentamento e a capacidade de construir.
*   **A Carga Feminina:** É o princípio de sustentação. Representa a energia que recebe, o ambiente interno e a capacidade de nutrir e dar continuidade ao que foi criado pelo masculino. 

**3. O Impacto na Prosperidade e Relacionamentos**
Andresa explica que ter o masculino e o feminino "bagunçados" internamente afeta diretamente a realidade externa. Esse desequilíbrio é frequentemente alimentado por dores não resolvidas com os pais (como ter raiva ou sentir pena do pai e da mãe) e é o que deixa a pessoa **sem dinheiro, sem amizades, com a saúde fragilizada e atração de relacionamentos amorosos falidos ou mornos**, gerando muitas vezes o [[Conceito do Abandono de Si|Abandono de Si]].

Portanto, equilibrar essas cargas significa limpar os bloqueios com a ancestralidade e permitir que a coragem de iniciar (masculino) e a força para sustentar (feminino) fluam em harmonia, garantindo que a pessoa pare de abandonar projetos ou de ceder aos abusos externos.

## Referência

ANDRESA MOLINA. *Princípio do Equilíbrio de Forças (Masculino e Feminino)*. Aula 02 - Coordenada 2 (O Amor que Nunca Voltou). Fontes: [[raw/archive/andresa_molina/transcriptions/02 - O AMOR QUE NUNCA VOLTOU - 2ª Coordenada - O Mapa da Alma.md]].
