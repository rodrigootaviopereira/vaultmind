---
type: principio
author: Andresa Molina
tags: [ilusao, dor, desilusao, realidade, choque-de-consciencia]
sources: ["[[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio da Desilusão (O adoecimento como sintoma de ilusão)

- **Definição**: A premissa psíquica e vibracional de que toda dor existencial e sistêmica nasce de uma ilusão (o desejo infantil de que a realidade, o passado ou as pessoas fossem diferentes do que são), tornando o choque da "desilusão" o maior vetor de cura terapêutica.
- **Justificativa**: O assistido adoece fisicamente e se sabota na matéria porque está alimentando ilusões subconscientes (como a promessa de amor eterno em troca da automutilação de sua identidade). Desiludir o paciente significa revelar a verdade crua que o pêndulo indica na mesa, desarmando as racionalizações de autodefesa do ego. A desilusão liberta o fluxo de energia porque realinha o indivíduo com a verdade de sua biologia e de seu destino.
- **Evidências**: "Ele tá iludido, acreditando que faz uma coisa no fundo, é um sentimento invertido, tá? Isso é ilusão. E a gente tá trazendo pra racionalidade para desiludir, porque a ilusão é que tá levando ele à dor. Ilusão é sempre o que traz problema, desilusão é boa, tá? Então, lembrando sempre disso, o cliente chega em dor porque ele está iludido. Toda dor é ilusão... E aí então quando tem tá muito distoante... ele tá iludido... trazer, sair, quebrar a ilusão daquela dor."
- **Implicações**: O terapeuta deve usar o diagnóstico de choque da mesa para confrontar de forma lúcida as fantasias do assistido, arrancando-o do papel de vítima indefesa de uma ilusão.
- **Conexões**: [[Principio da Aceitacao dos Fatos]], [[Conceito do Gap Vibracional]], [[Conceito de Aconteceu vs Acontece]]
- **Notas Pessoais**: A verdade desilude a mente, mas cura a alma e o corpo.

## Perguntas Frequentes / Didática de Atendimento

### 2. De que maneira a ilusão do paciente atua como a raiz do adoecimento e por que a "desilusão" é curativa?
**Resposta**: A ilusão atua como a raiz biológica e vibracional do adoecimento porque o paciente passa a operar a sua vida com base em uma mentira energética. A autora decreta: "o cliente chega em dor porque ele está iludido. Toda dor é ilusão". O sofrimento se instala porque "he pensa que é uma coisa, ele diz que é uma coisa, mas inconscientemente ele tá se movendo por outra e os problemas estão exatamente nessa raiz". A dor ocorre porque a pessoa tenta forçar uma realidade interna que "no fundo, é um sentimento invertido".

A desilusão promovida pela mesa é o caminho da cura porque expõe essa mentira. A autora afirma que "Ilusão é sempre o que traz problema, desilusão é boa". Ao usar o pêndulo, o terapeuta confronta a mente consciente com o campo inconsciente, "trazendo pra racionalidade para desiludir". Somaticamente, o choque de realidade serve para "trazer, sair, quebrar a ilusão daquela dor", permitindo que a biologia pare de gastar energia sustentando a mentira.

## Referencia

ANDRESA MOLINA. *Princípio da Desilusão*. Aula 07 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]].
