---
type: conceito
author: Andresa Molina
tags: [autoabandono, 4a-coordenada, essencia, papel-social, anulacao, mapa-da-alma]
sources: ["[[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito da Mulher antes de ser de Todos (4ª Coordenada)

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: O Conceito da Mulher antes de ser de Todos (4ª Coordenada) define o processo psicossomático de autoperda, exaustão e anulação da identidade de um indivíduo em prol do atendimento compulsivo e inconsciente das necessidades, demandas e expectativas alheias (cônjuges, filhos, pais, carreira, amigos). Essa dinâmica resulta no distanciamento severo da essência (o Eu Sou) e na geração de um vazio existencial crônico.
- **Formulação de apoio**: Sob a influência de condicionamentos infantis, o indivíduo aprende que para pertencer e ser amado deve ser útil e dócil. Isso o faz assumir múltiplos papéis sociais (a boa mãe, a esposa dedicada, a profissional competente) e preencher seu tempo com demandas externas ("estar sempre ocupada, mas nunca produtiva"), silenciando seus próprios desejos, projetos e sonhos. A 4ª Coordenada é a marca somática desse autoabandono registrada no corpo físico.

## Dinâmica de Anulação

1. **Atração de Exigências**: Ao se anular, o indivíduo emite a frequência de autoabandono, atraindo cobranças e exigências de todos os lados (inclusive de outras mulheres que também se abandonaram).
2. **Paralisia e Angústia**: A pessoa gasta toda a sua energia solucionando os problemas dos outros enquanto seus próprios projetos pré-encarnatórios (Saudade do Futuro) são deixados "na gaveta" do corpo físico, gerando angústia e looping mental.
3. **Sintomas Físicos**: O esvaziamento e a pressão de anulação são somatizados sob a forma de dor de cabeça, tensões no pescoço/ombros e um cansaço que não passa com o descanso físico simples.

## Contexto de Uso

- Eixo diagnóstico no HumanoSense. Usado para identificar assistidos que reclamam de vazio existencial, depressão sem causa aparente ou que sentem que "vivem para todo mundo, menos para si mesmos".

## Relação com Princípios

- [[Principio do Amor Condicionado e Autoabandono]]
- [[Conceito do Abandono de Si]]
- [[Principio da Liberdade Consciente]]
- [[Principio da Memoria Celular Ancestral]]

## Exemplos do Material

- *"Quando a gente se abandona na vida, a gente começa a atender a demanda de todo mundo... E aí a gente acaba se abandonando, a gente acaba se tornando tantas pessoas que a gente acaba deixando a gente de lado... O problema é quando a gente faz isso de maneira tão inconsciente, tão no automático, que a gente acaba esquecendo quem a gente é..."*
- O indivíduo que tenta corresponder à imagem da "menina legal do rolê", topando programas que não gosta e assumindo preferências que não são suas por medo da solidão.

## Aplicação Prática

1. **Rastrear os Papéis**: Mapear quais papéis o assistido desempenha de forma compulsiva e onde ele está dizendo "sim" para o mundo e "não" para si mesmo.
2. **Mapeamento Somático**: Localizar onde a marca desse autoabandono está registrada no corpo do assistido (ex: peito, garganta ou cabeça).
3. **Resgate do Eu Sou Essencial**: Conduzir o tratamento desfazendo a Automagia autolimitadora e retirando as camadas de exigência social para que o assistido recupere sua soberania pessoal e volte a manifestar o seu propósito de vida.

## Perguntas Frequentes / Didática de Atendimento

### O que Andresa ensina sobre a 'saudade do futuro'?

Andresa ensina que esse sentimento — frequentemente percebido como um vazio absoluto ou a falta de algo que não se sabe o que é — não é apenas uma tristeza comum, mas **a saudade do seu próprio projeto de vida original**, fundamentada no [[Principio da Saudade do Futuro|Princípio da Saudade do Futuro]]. 

É comum que as pessoas transfiram equivocadamente essa angústia para o luto de parentes ou antigos relacionamentos, porém, trata-se do lamento por sonhos e planos que **você mesma estruturou e sonhou antes de encarnar**. Ao passar a vida dizendo "sim" para as demandas de todos ao seu redor e se abandonando, você guardou esse projeto em uma "gaveta" inacessível no seu próprio corpo. 

Portanto, a "saudade do futuro" é **o eco de um propósito e de um destino que a sua essência sabe que veio manifestar, mas que foi deixado de lado** devido aos emaranhamentos somatizados na [[Conceito da Mulher antes de ser de Todos|4ª Coordenada]].

### Como o medo de "incomodar os outros" ou "ser um estorvo" atua como a programação raiz para criar uma máscara de submissão?

A programação raiz inicia-se na infância, quando a essência original da criança (que era questionadora, cantava ou falava muito) é repetidamente reprimida. A pessoa aprende que a sua natureza divina e o seu modo de se divertir "incomodam" os adultos ou o grupo ao seu redor, e entende que "ser você em algum lugar foi um problema".

O medo aterrorizante de "ficar absolutamente sozinha" e perder a aprovação alheia força a pessoa a criar um bloqueio: ela determina que, para ser amada e pertencer, não pode mais incomodar. Esse medo gera a máscara de submissão, transformando-a na pessoa que diz "sim" para tudo e para todos (mesmo para coisas que não gosta) e abandona seus próprios limites. Ao assumir a utilidade cega como forma de garantir afeto, ela sufoca a própria identidade.

### Como a busca por conselhos externos de terceiros acaba por "desconsiderar o feminino" e reativar a hipnose do autoabandono?

Buscar respostas externas é altamente destrutivo nesse processo porque as pessoas ao redor (maridos, amigas, autoridades) estão geralmente operando em uma energia masculina desequilibrada, focada apenas na "ordem, na regra, na competição".

Ao abrir o seu coração e os seus sentimentos de dor para essas pessoas, elas inevitavelmente desconsiderarão o seu lado feminino e intuitivo, tratando os seus questionamentos existenciais como "uma grande bobagem" ou "besteira". Quando você escuta de fora que a sua dor é "besteira", você se sente ainda "mais desconsiderada, mais abandonada". Isso engatilha imediatamente o trauma original: você desconfia da sua própria intuição, desiste de tomar suas decisões, e "de novo vai fazer o que todo mundo te pede, menos o que você quer", reativando o ciclo de autoabandono.

## Referência

ANDRESA MOLINA. *Conceito da Mulher antes de ser de Todos (4ª Coordenada)*. Aula 04 - Coordenada 4 (A Mulher Antes de Ser de Todos). Fontes: [[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]].
