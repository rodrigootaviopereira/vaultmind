---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_49_forca_nuclear_fraca.md]]"]
---

# Cap 049 - Forca Nuclear Fraca

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_49_forca_nuclear_fraca.md]]

## Referencia

ANDRESA MOLINA. *Cap 049 - Forca Nuclear Fraca*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_49_forca_nuclear_fraca.md]]. Acesso em: 17 jun. 2026.
