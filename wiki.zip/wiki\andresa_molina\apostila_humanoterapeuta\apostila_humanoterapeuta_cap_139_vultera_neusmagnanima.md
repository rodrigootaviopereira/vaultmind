---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_139_vultera_neusmagnanima.md]]"]
---

# Cap 139 - Vultera Neusmagnanima

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_139_vultera_neusmagnanima.md]]

## Referencia

ANDRESA MOLINA. *Cap 139 - Vultera Neusmagnanima*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_139_vultera_neusmagnanima.md]]. Acesso em: 17 jun. 2026.
