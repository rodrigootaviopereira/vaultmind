---
type: conceito
author: Hélio Couto
tags: [reptiliano, sobrevivencia, territorio, alimentacao]
sources: ["[[raw/archive/soltar_individuação_e_iluminação_hélio_couto/soltar_individuação_e_iluminação_hélio_couto_cap_06_sociologia_do_soltar.txt]]"]
---

# Conceito de Complexo R

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/soltar_individuação_e_iluminação_hélio_couto/soltar_individuação_e_iluminação_hélio_couto_cap_06_sociologia_do_soltar.txt]]

## Referencia

HÉLIO COUTO. *Conceito de Complexo R*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/soltar_individuação_e_iluminação_hélio_couto/soltar_individuação_e_iluminação_hélio_couto_cap_06_sociologia_do_soltar.txt]]. Acesso em: 17 jun. 2026.
