---
type: principio
author: Andresa Molina
tags: [objetividade, foco-terapeutico, teoria-na-pratica, consciencia]
sources: ["[[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio da Objetividade Terapêutica (A proibição de "dar aula")

- **Definição**: A regra de condução clínica que proíbe o terapeuta de transformar a sessão em um curso teórico sobre espiritualidade ou mecânica quântica, evitando retirar o assistido da frequência magnética e emocional necessária para a cura.
- **Justificativa**: A mente racional do cliente tende a se apegar a explicações teóricas como forma de evitar o contato com a dor real. Quando o terapeuta começa a palestrar ou justificar o método cientificamente, dispersa a energia da sessão. A explicação inicial do método deve ser concisa e focada no objetivo prático: identificar a raiz, limpar o campo e abrir caminho para a manifestação.
- **Evidências**: "explique brevemente, não é uma aula, ele não tá fazendo um curso de terapia, tá? Ele nem quer tudo isso. Quem tá fazendo curso e gosta de explicação, somos nós... não é para entrar nesse contexto. Esse contexto, ele tira o cliente da frequência que ele veio buscar, tá? Então, não é para dar aula... Quem aí já foi no médico que fala pelo cotovelo? muito chato... Então gente que fala demais acaba expando. Ele quer saber a questão dele, não de aula."
- **Implicações**: O terapeuta deve conter o impulso de impressionar o assistido com discussões filosóficas ou ufológicas. As intervenções verbais devem ser curtas e direcionadas para guiar a atenção do assistido de volta ao seu sentir somático.
- **Conexões**: [[Conceito do Metodo HumanoSense]], [[Principio do Foco Primordial]]
- **Notas Pessoais**: Falar menos durante o atendimento mantém o campo de trabalho focado e protege a energia do terapeuta.

## Perguntas Frequentes / Didática de Atendimento

### 1. Como Andresa Molina define a objetividade na sessão e por que "dar aula" dispersa a energia do assistido?
**Resposta**: Andresa Molina define a objetividade terapêutica como a regra de "explique brevemente, não é uma aula, ele não tá fazendo um curso de terapia". O terapeuta não deve focar em teorias longas porque "Quem tá fazendo curso e gosta de explicação, somos nós que somos terapeutas".

A nível somático e vibracional, palestrar sobre o funcionamento do cosmos ou do método "tira o cliente da frequência que ele veio buscar". A mente do assistido se dispersa da sua própria dor (que é o que precisa ser curado) para tentar entender uma aula teórica. A autora ilustra isso comparando com um "médico que fala pelo cotovelo", afirmando que "gente que fala demais acaba expando [espantando]" o paciente, pois a pessoa está ali focada na sua dor orgânica: "Ele quer saber a questão dele, não de aula".

## Referencia

ANDRESA MOLINA. *Princípio da Objetividade Terapêutica*. Aula 07 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]].
