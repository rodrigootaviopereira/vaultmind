---
type: conceito
author: Andresa Molina
tags: [emocional, preocupado, controle, responsabilidade, sobrecarga]
sources: ["[[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]"]
---

# Conceito do Preocupado Emocional

- **Definição**: O padrão do campo emocional que só consegue relaxar ou agir se todos ao redor estiverem em paz, confundindo amor genuíno com responsabilidade emocional sobre o outro.
- **Justificativa**: O preocupado vive em estado de alerta e hiperatividade mental, distraindo-se com as demandas externas dos outros para evitar encarar suas próprias dores e vazio essencial.
- **Evidências**: "O preocupado ele é aquela só consegue relaxar se o outro estiver em paz. Ele confunde amor com responsabilidade emocional. [...] ele se distrai com as demandas do outro para não lidar com a dor dele. [...] De zero a 10, quando você se distrai com demandas dos outros para não lidar realmente com o que é importante para sua vida."
- **Implicações**: Na terapêutica, indica que o assistido gasta toda a sua força na contenção de crises alheias, restando-lhe apenas exaustão corporal.
- **Conexões**: [[Principio da Mandala da Dor]]
- **Notas Pessoais**: O preocupado é presa fácil para os exploradores e limitadores.

## Referencia

ANDRESA MOLINA. *Conceito do Preocupado Emocional*. Aula 03 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]].
