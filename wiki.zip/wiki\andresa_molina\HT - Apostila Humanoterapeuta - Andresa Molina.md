---
type: conceito
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, formacao, metodo, espiritualidade]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_01_apresentacao.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_03_metodologia_humanoterapeuta.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_147_etica_moral_e_cosmoetica.md]]"]
---

# HT - Apostila Humanoterapeuta - Andresa Molina

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_01_apresentacao.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_03_metodologia_humanoterapeuta.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_147_etica_moral_e_cosmoetica.md]]


## Estrutura Geral

- **Preliminares**: apresentacao institucional, missao, valores, metodologia e descricao do fluxo das tecnicas.
- **Modulos 1 a 4**: base mental, energetica, filosofica e de radiestesia.
- **Modulo 5**: Humanometria e seus fundamentos apometricos.
- **Modulo 6**: espiritualidade avancada, tecnicas energeticas, implantes, miasmas e disturbios espirituais.
- **Modulo 7**: TDR, subpersonalidades e reprogramacao energetica.
- **Modulo 8**: Taquions-Tock, energia taquionica e quinta dimensao.
- **Modulo 9**: regressao com reprogramacao celular.
- **Modulo 10**: baralho cigano e baralho terapeutico.
- **Modulo 11**: consulta, mesa quantionica, leitura e tratamento.
- **Modulo 12**: etica, moral, cosmoetica, criacao e amor.

## Distincao em Relacao ao HumanoSense

- O **Humanoterapeuta** aparece nesta apostila como uma formacao mais ampla, com linguagem de energetica, espiritualidade, apometria, radiestesia, mesa quantionica, regressao e baralho terapeutico.
- O **HumanoSense** ja presente na wiki e outro sistema dentro do universo da Andresa Molina, com sua propria arquitetura, ficha, camara, mapa de dor e organizacao de atendimento.
- As duas linhas podem conversar por afinidade, mas **nao devem ser fundidas**. Nesta wiki, as notas do Humanoterapeuta ficam nomeadas explicitamente como `Humanoterapeuta`.
- Para uma visao integrada sem mistura de sistemas, usar [[Mapa dos Sistemas Terapeuticos de Andresa Molina]].

## Leitura Integrada

- O material sustenta uma visao tripla do ser humano: corpo, mente e espirito.
- A cura e descrita como ganho de consciencia, desbloqueio energetico, tratamento espiritual e restabelecimento da informacao original.
- A obra insiste na ordem, no metodo e na integridade da aplicacao.
- O fechamento em cosmoetica impede que a tecnica seja lida apenas como instrumento de poder.

## Referencia

ANDRESA MOLINA. *HT - Apostila Humanoterapeuta - Andresa Molina*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_01_apresentacao.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_03_metodologia_humanoterapeuta.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_147_etica_moral_e_cosmoetica.md]]. Acesso em: 17 jun. 2026.
