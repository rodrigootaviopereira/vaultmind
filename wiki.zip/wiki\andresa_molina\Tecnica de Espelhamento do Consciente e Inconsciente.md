---
type: tecnica
author: Andresa Molina
tags: [identificacao, radiestesia, espelhamento, diagnostico]
sources: ["[[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]]"]
---
# Prática de Espelhamento Consciente/Inconsciente (Fase de Identificação via Radiestesia)

- **Objetivo**: Expor e diagnosticar a contradição ('a mentira') existente entre o relato lógico consciente (5%) do assistido e os registros vibracionais reprimidos (95%) em seu campo celular inconsciente.
- **Pré-requisitos**: Pêndulo, Mesa HumanoSense e fichas de atendimento impressas.
- **Passo a Passo**:
  1. Aplicar o questionário racional da ficha de atendimento coletando as respostas verbais e conscientes do cliente sobre sua vida e dor.
  2. Posicionar o assistido perante a Mesa e, por meio do pêndulo e radiestesia, consultar as mandalas para capturar a ressonância inconsciente profunda das mesmas perguntas.
  3. Comparar ambos os dados para identificar onde o consciente destoa do vibracional inconsciente.
  4. Confrontar respeitosamente a barreira intelectual do assistido mostrando o desalinhamento sutil para quebrar o padrão de negação.
- **Duração/Frequência**: Aplicada na fase inicial de anamnese/diagnóstico de cada atendimento.
- **Indicadores de Sucesso**: O assistido quebra suas defesas e ganha consciência sobre suas dinâmicas de negação/autoengano.
- **Variações**: Pode ser reavaliada ao fim das sessões para medir se a disparidade entre o consciente e inconsciente foi eliminada.
- **Conceitos Envolvidos**: [[Conceito do Metodo HumanoSense]], [[Conceito de Ressignificacao vs Reconsolidacao]]
- **Notas Pessoais**: O pêndulo revela instantaneamente a resistência celular que a mente tenta camuflar por conveniência racional.

## Perguntas Frequentes / Didática de Atendimento

### De que maneira o questionário racional consciente e a investigação do campo energético inconsciente (por meio da radiestesia com pêndulo) se cruzam para evidenciar "a mentira" do assistido?

Eles se cruzam na etapa de Identificação como uma forma de espelhamento. O terapeuta aplica o "questionário racional" e a pessoa responde usando seus 5% de mente consciente. Simultaneamente, o terapeuta faz uma "pesquisa do campo energético vibracional inconsciente do assistido com o uso da radiestesia" usando o pêndulo na mesa. 

A "mentira" é evidenciada a nível somático quando as duas respostas não batem: "Você pergunta como a vida da pessoa tá, ela fala que tá boa, mas o que o inconsciente, o vibracional dela diz é que não tá". A autora explica que o assistido não faz isso por maldade ("Ela não mente porque ela tá mentindo"), mas porque está cego e "não está conseguindo enxergar o que tá por trás do campo racional".


## Referencia

ANDRESA MOLINA. *Prática de Espelhamento Consciente/Inconsciente (Fase de Identificação via Radiestesia)*. Aula 01 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]].
