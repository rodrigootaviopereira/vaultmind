---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_114_1a_premissa_basica_e_fundamental.md]]"]
---

# Cap 114 - 1A Premissa Basica E Fundamental

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_114_1a_premissa_basica_e_fundamental.md]]

## Referencia

ANDRESA MOLINA. *Cap 114 - 1A Premissa Basica E Fundamental*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_114_1a_premissa_basica_e_fundamental.md]]. Acesso em: 17 jun. 2026.
