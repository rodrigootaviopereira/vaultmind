---
type: principio
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, principio, metodo, sequencia]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_04_passo_1_a_consulta_inicial_no_psicogerador_quantionico_o_diagnostico.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_05_passo_3_taquions_tock_desconstrucao_da_criacao_dos_campos_mental_e_emocional.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_06_passo_4_tdr_terapia_de_desbloqueio_emocional_e_reprogramacao_energetica.md]]"]
---

# HT - Principio - Sequencia Terapeutica

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_04_passo_1_a_consulta_inicial_no_psicogerador_quantionico_o_diagnostico.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_05_passo_3_taquions_tock_desconstrucao_da_criacao_dos_campos_mental_e_emocional.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_06_passo_4_tdr_terapia_de_desbloqueio_emocional_e_reprogramacao_energetica.md]]

## Definição

- **Definição**: [INFERÊNCIA] HT - Principio - Sequencia Terapeutica expressa uma regra estrutural do sistema terapêutico de Andresa Molina: sem este princípio, a técnica perde força, segurança ou coerência no atendimento.
- **Formulação de apoio**: Ele aprofunda o HumanoSense no campo real dos atendimentos. - A aula 03 reforca que receber sem culpa e reconhecer o que ja chegou sao etapas centrais da maturidade terapeutica e relacional. - A aula 04 mostra que o terapeuta precisa modular linguagem, timing e intensidade para ajudar sem ferir a aliança com o assistido. ## Limite do Sistema - O MasterSense e uma camada de lapidacao do HumanoSense, nao uma tecnica-base separada do nucleo do metodo. - Para nao confundir MasterSense com Humanoterapeuta ou com o proprio HumanoSense, usar [[Mapa dos Sistemas Terapeuticos de Andresa Molina]]. ## Referencia ANDRESA MOLINA. *MasterSense - Mentoria do HumanoSense*.

## Justificativa

- [INFERÊNCIA] É central porque transforma conteúdo em postura terapêutica: não basta conhecer o método, é preciso aplicá-lo com presença, ordem, respeito ao campo e leitura da raiz da dor.

## Evidências

- Ele aprofunda o HumanoSense no campo real dos atendimentos. - A aula 03 reforca que receber sem culpa e reconhecer o que ja chegou sao etapas centrais da maturidade terapeutica e relacional. - A aula 04 mostra que o terapeuta precisa modular linguagem, timing e intensidade para ajudar sem ferir a aliança com o assistido. ## Limite do Sistema - O MasterSense e uma camada de lapidacao do HumanoSense, nao uma tecnica-base separada do nucleo do metodo. - Para nao confundir MasterSense com Humanoterapeuta ou com o proprio HumanoSense, usar [[Mapa dos Sistemas Terapeuticos de Andresa Molina]]. ## Referencia ANDRESA MOLINA. *MasterSense - Mentoria do HumanoSense*. (MasterSense - Mentoria do HumanoSense)

## Implicações

- [INFERÊNCIA] O terapeuta deve usar este princípio como critério de decisão antes de improvisar, interpretar ou conduzir o assistido.
- [INFERÊNCIA] Quando o princípio é ignorado, a sessão tende a ficar mental, apressada, fragmentada ou desconectada da equipe/campo de trabalho.

## Conexões

- [[MasterSense - Mentoria do HumanoSense]]

## Notas Pessoais

- Reservado para observações do usuário no uso prático da técnica.

## Referencia

ANDRESA MOLINA. *HT - Principio - Sequencia Terapeutica*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_04_passo_1_a_consulta_inicial_no_psicogerador_quantionico_o_diagnostico.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_05_passo_3_taquions_tock_desconstrucao_da_criacao_dos_campos_mental_e_emocional.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_06_passo_4_tdr_terapia_de_desbloqueio_emocional_e_reprogramacao_energetica.md]]. Acesso em: 17 jun. 2026.
