---
type: conceito
author: Andresa Molina
tags: [perdao, soltar, abandono-positivo, ego]
sources: ["[[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]]"]
---
# Princípio da Frequência do Arrependimento e do Abandono Positivo

- **Definição Precisa**: O arrependimento real é a frequência focada em reparar a dor causada ao outro, e não nas perdas pessoais do ego; o perdão é o 'abandono positivo' da teimosia de que a realidade deveria ter sido diferente.
- **Sinônimos/Variações**: Frequência do Arrependimento, Perdão Real, Abandono Positivo, Soltar a Dor
- **Contexto de Uso**: Resolução de vínculos de culpa e reestabelecimento de relacionamentos rompidos ou magiados pelo ego.
- **Relação com Princípios**: [[Principio de Lugar Funcao e Potencia]], [[Principio da Semeadura e Karma]]
- **Exemplos do Material**: "Se ela se arrependeu porque ela ficou sem os netos, isso não é arrependimento, isso é ego... O arrependimento ele vem de quando eu entendi a dor que eu causei em você. E aí eu quero reparar. E aí o pedido de de perdão quando eu falo é real, é verdadeiro... Se não é sobre reparar a dor do outro, não é arrependimento. [...] o soltar, o abandonar é o deixar para lá. É o abandonar a ideia de que o outro tinha que ter feito do jeito que eu quero. Isso é perdão. É um abandono positivo."
- **Aplicação Prática**: Abandonar a exigência infantil de que a história seja reescrita, cessando a cobrança cármica e energética sobre o ofensor.
- **Conexões Externas**: [[Conceito do Metodo HumanoSense]]

## Referencia

ANDRESA MOLINA. *Princípio da Frequência do Arrependimento e do Abandono Positivo*. Aula 01 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]].
