---
type: principio
author: Andresa Molina
tags: [doação, amor-próprio, carência, medo-do-abandono, 5a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]]"]
---

# Princípio da Doação Genuína

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]]

## Definição

- **Definição**: O Princípio da Doação Genuína é a lei espiritual e energética que determina que só podemos entregar ao outro aquilo que já possuímos dentro de nós mesmos. Se não há amor-próprio ou energia vital de sobra, o ato que aparenta ser doação é, na verdade, um mecanismo de sobrevivência baseado no medo e na carência.
- **Justificativa**: Quando uma pessoa se esgota cuidando dos outros por carência e medo de abandono, a doação torna-se uma "moeda de troca" inconsciente para comprar segurança e pertencimento. A verdadeira doação exige estar preenchido de si mesmo para transbordar, impedindo a estafa crônica.

## Evidências

- *"Eu não tenho como dar pro outro aquilo que eu não tenho. Então vamos lá. Se eu não tenho amor para mim, eu não tenho amor para dar. [...] Se eu não tenho amor por mim, o que eu tô dando não é amor, é algo parecido com amor. Pode ser apego, pode ser dor, pode ser tristeza e pode ser, principalmente medo de ser abandonado."*

## Implicações

- **Desnutrição Afetiva Circular**: A pessoa doa carência disfarçada de amor e, consequentemente, atrai mais demandas e exigências que alimentam seu medo crônico de rejeição.
- **Exigência de Autopreenchimento**: Para que a terapia ou a cura familiar funcione, o cuidador deve priorizar o seu preenchimento de si e o desenvolvimento do amor-próprio antes de se doar a novos projetos ou auxílio alheio.

## Conexões

- [[Principio da Plenitude Energetica e do Cuidado]]
- [[Conceito do Cuidado que Esgota]]
- [[Conceito do Modo Sobrevivencia no Cuidado]]

## Referência

ANDRESA MOLINA. *Princípio da Doação Genuína*. Aula 05 - Coordenada 5 (O Cuidado que Esgota). Fontes: [[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]].
