---
type: conceito
author: Andresa Molina
tags: [esgotamento, magnetismo, prosperidade, energia, escassez, 5a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito do Esgotamento Magnético

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: O Esgotamento Magnético é a falência da capacidade vibracional e atrativa do indivíduo decorrente do esvaziamento total de sua energia vital ("vazio de espírito"). Quando a pessoa consome toda a sua força atendendo compulsivamente às demandas dos outros, ela perde o "quanto" energético necessário para atrair e reter oportunidades, dinheiro, clientes abundantes e relacionamentos saudáveis.
- **Formulação de apoio**: Andresa explica que o dinheiro e a prosperidade chegam via oportunidades materiais. Se o indivíduo está vazio e fraco energeticamente, ele carece de magnetismo. Como consequência, as oportunidades "passam reto" ou, caso surjam, ele não tem força vital para mantê-las em sua vida, gerando a ruína financeira e afetiva ("ninguém procura ninguém vazio").

## Contexto de Uso

- Usado para decodificar bloqueios de escassez crônica e incapacidade de reter recursos em assistidos que se anulam para atuar como cuidadores permanentes.

## Relação com Princípios

- [[Principio da Plenitude Energetica e do Cuidado]]
- [[Principio da Doacao Genuina]]
- [[Conceito do Cuidado que Esgota]]

## Exemplos do Material

- *"Se você não tem energia pras oportunidades que chegam, elas não chegam. ou se elas chegam, você não tem força para manter ela na sua vida. [...] O seu dinheiro não fica porque você tá esgotada. Você não tem magnetismo. As oportunidades não chegam... E as pessoas procuram por pessoas que têm alguma coisa para dar."*
- O terapeuta ou profissional que, por estar em frangalhos e cansado, não atrai clientes ou sócios, pois emite a frequência de carência e esvaziamento.

## Aplicação Prática

1. **Avaliar a Carga Magnética**: Analisar o fluxo financeiro e os relacionamentos do assistido para identificar a estagnação típica do esgotamento magnético.
2. **Promover a Desprogramação**: Desarmar o gatilho inconsciente do CARE em modo sobrevivência para estancar a "sangria" de energia para o ambiente.
3. **Preencher a Alma (Recheio de Si)**: Conduzir o assistido a investir em seu próprio preenchimento espiritual e no merecimento de ser cuidado para restabelecer seu campo atrativo.

## Referência

ANDRESA MOLINA. *Conceito do Esgotamento Magnético*. Aula 05 - Coordenada 5 (O Cuidado que Esgota). Fontes: [[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. Por que Andresa afirma que "ninguém procura ninguém vazio" e como esse "vazio de espírito" destrói a atratividade profissional e afetiva do assistido?
**Resposta**: Andresa afirma isso porque, sob a perspectiva vibracional, as relações humanas (profissionais e afetivas) são pautadas na troca de energia e plenitude. Quando o indivíduo doa toda a sua vitalidade cuidando dos outros por medo do abandono, não sobra nada para si mesmo. Ele entra em colapso e fica com um "vazio de espírito".

Esse esvaziamento destrói completamente a atratividade do indivíduo no mundo material porque a lei natural é que *"as pessoas procuram por pessoas que têm alguma coisa para dar"*. Se a pessoa está energeticamente desnutrida, o mercado profissional e os potenciais parceiros a evitam instintivamente. A autora é muito direta ao listar o impacto nas conexões: *"Ninguém procura um sócio ou um funcionário ou um um influencer ou um terapeuta ou um amigo vazio"*. Para ter atratividade e ser desejado, o indivíduo precisa fazer o oposto: estar *"plena, preenchida, recheada de dessa energia"*, pois apenas assim os outros vão *"querer o que você tem"* e disputar a sua presença.

### 2. De que maneira a estafa crônica do cuidador (ser a "âncora" de todos) atua bloqueando fisicamente o magnetismo pessoal necessário para a atração e retenção de dinheiro?
**Resposta**: A estafa crônica age como um bloqueio absoluto porque destrói o que Andresa chama de *"potência energética"*. A autora utiliza a metáfora da "âncora" para ilustrar o peso desproporcional que a pessoa carrega: *"você tá sendo âncora para todo mundo, você tá sustentando tudo para todo mundo E ninguém está vendo que você tá se afogando"*.

Vibracionalmente, esse afogamento e esgotamento afetam a vida financeira em duas etapas destrutivas (atração e retenção):
*   **Falha na Atração**: A autora ensina que *"o dinheiro ele não cai na sua cabeça, ele vem com oportunidades"*. Como a pessoa está em frangalhos servindo como âncora, ela perde o seu "magnetismo". O resultado é que as oportunidades simplesmente fogem do seu campo: *"As oportunidades não chegam. Chega para todo mundo, mas não chega para você"*.
*   **Falha na Retenção**: Mesmo quando uma oportunidade financeira ou um bom cliente consegue perfurar esse bloqueio e chega à vida da pessoa, a estafa física a impede de sustentá-la. Andresa decreta: *"se elas chegam, você não tem força para manter ela na sua vida [...] O seu dinheiro não fica porque você tá esgotada. Você não tem magnetismo"*.

### 3. Por que tratar os efeitos práticos (como a falta de dinheiro ou relacionamentos falidos) falha quando o "gatilho" original da 5ª Coordenada não é desarmado?
**Resposta**: Tratar os resultados externos da vida material falha porque se trata de enxugar gelo. A escassez financeira e a falência afetiva não são a raiz do problema; elas são apenas o *"efeito"*.

O "gatilho" original da 5ª Coordenada é um *"registro de memória que ficou no seu corpo, no seu cérebro e criou uma trilha"*, forjado na infância ou herdado da ancestralidade, que associou obrigatoriamente o ato de cuidar e ser útil à própria sobrevivência. Andresa explica que, enquanto esse sistema automático continuar ativado (o medo oculto de não pertencer e ser abandonado), o cérebro continuará forçando a pessoa a se esgotar para agradar os outros.

Portanto, tentar consertar a conta bancária ou o relacionamento sem "reconsolidar" a memória celular de base é inútil, pois *"não é sobre o efeito, é sobre a causa que gera tudo que gera na sua vida"*. É exatamente a ativação constante desse gatilho traumático interno que, como consequência colateral e vibracional, *"gera a falta de dinheiro, gera a falta de relacionamento, gera o dinheiro que tem"*. Apenas desarmando a causa-raiz (a memória traumática somática) é possível devolver a energia vital para que as áreas externas da vida parem de ruir. *(Nota: Em termos literais, a autora refere-se nas transcrições à incapacidade de manter relacionamentos saudáveis ou à falta de relacionamento em si).*

