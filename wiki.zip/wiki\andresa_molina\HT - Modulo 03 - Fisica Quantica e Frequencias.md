---
type: sintese
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, modulo_03, fisica_quantica, frequencias]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_40_fisica_quantica_e_frequencias.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_41_conceitos_da_fisica_quantica_parte_1.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_50_descricao_da_experiencia_da_fenda_dupla.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_55_frequencias.md]]"]
---

# HT - Modulo 03 - Fisica Quantica e Frequencias

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_40_fisica_quantica_e_frequencias.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_41_conceitos_da_fisica_quantica_parte_1.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_50_descricao_da_experiencia_da_fenda_dupla.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_55_frequencias.md]]


## Nucleos do Modulo

- A apostila usa referencias de fisica para sustentar o vocabulÃ¡rio energetico.
- A fenda dupla e o entrelacamento viram argumentos de nao separacao entre consciencia e realidade.
- Frequencia passa a ser uma categoria-chave para o tratamento.

## Síntese

- [INFERÊNCIA] HT - Modulo 03 - Fisica Quantica e Frequencias é uma nota de apoio dentro da wiki de Andresa Molina e precisa ser lida em conjunto com as aulas e mapas estruturais já conectados.

## Evidências do Material

- Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_40_fisica_quantica_e_frequencias.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_41_conceitos_da_fisica_quantica_parte_1.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_50_descricao_da_experiencia_da_fenda_dupla.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_55_frequencias.md]]. (HT - Modulo 03 - Fisica Quantica e Frequencias)

## Conexões

- [[HT - Modulo 03 - Fisica Quantica e Frequencias]]

## Referencia

ANDRESA MOLINA. *HT - Modulo 03 - Fisica Quantica e Frequencias*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_40_fisica_quantica_e_frequencias.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_41_conceitos_da_fisica_quantica_parte_1.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_50_descricao_da_experiencia_da_fenda_dupla.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_55_frequencias.md]]. Acesso em: 17 jun. 2026.
