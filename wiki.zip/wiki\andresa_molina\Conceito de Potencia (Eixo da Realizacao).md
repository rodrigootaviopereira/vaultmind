---
type: conceito
author: Andresa Molina
tags: [realizacao, potencia, energia-vital, ectoplasma, magnetismo]
sources: ["[[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]]"]
---

# Conceito de Potencia (Eixo da Realizacao)

- **Definição**: A energia vital direcionada pela consciência (magnetismo ou ectoplasma) que se manifesta de forma natural e irresistível quando o indivíduo está no lugar e função corretos.
- **Justificativa**: Não há potência real fora do próprio papel. Tentar salvar pessoas ou resolver problemas alheios drena o quantum energético do corpo, gerando sobrecarga física.
- **Evidências**: "É a energia vital a serviço do propósito. Potência é a energia que nasce quando lugar e função se encontram. É a força viva que te promove com clareza, paixão e verdade. Ou seja, a força direcionada pela consciência. [...] é o seu magnetismo, é o seu ectoplasma. É colocar vida no que você faz. Vitalidade é vida."
- **Implicações**: Se o assistido está sem energia ou apático, indica que ele está desperdiçando sua potência em posições fora de seu lugar sistêmico.
- **Conexões**: [[Conceito do Eixo da Realizacao]], [[Principio de Lugar Funcao e Potencia]]
- **Notas Pessoais**: Potência é a presença da alma em ação contínua.

## Referencia

ANDRESA MOLINA. *Conceito de Potencia (Eixo da Realizacao)*. Aula 04 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]].
