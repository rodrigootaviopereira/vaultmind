---
type: conceito
author: Andresa Molina
tags: [lixo-emocional, identidade, doenca, somatizacao, autopunicao]
sources: ["[[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]"]
---

# Conceito de Eu Sou Lixo

- **Definição**: A crença de identidade profunda e inconsciente em que o indivíduo se autodefine como lixo ou monstro (por culpas do passado), ativando a autodestruição celular e a manifestação de doenças físicas.
- **Justificativa**: Se a identidade profunda é 'eu sou um lixo', o corpo biológico reage fisicamente tentando se decompor, o que resulta em somatizações graves, cânceres ou desordens imunológicas.
- **Evidências**: "E tem gente que carrega que ela é um lixo, porque se eu for e largar a mãe, eu sou um lixo. [...] E todo lixo é natural que ele se decomponha. Então, se eu sou um lixo, eu vou decompor a mim mesmo. E a possibilidade de eu criar uma doença é muito grande, porque eu vou decompor alguma parte minha física [...] se eu sou, eu vou destruir o lixo, vou decompor o lixo."
- **Implicações**: O terapeuta deve investigar de onde veio a autodefinição degradante (bullying, abusos sexuais na infância, abandono de parentes) para transmutar a culpa celular.
- **Conexões**: [[Conceito de Lixo Emocional]], [[Principio da Mandala da Dor]]
- **Notas Pessoais**: A nível terapêutico, o abuso infantil frequentemente deixa a marca do 'eu sou um lixo' na biologia.

## Referencia

ANDRESA MOLINA. *Conceito de Eu Sou Lixo*. Aula 03 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]].
