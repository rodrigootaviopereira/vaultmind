---
type: tecnica
author: Andresa Molina
tags: [escolha-radiestesica, pendulo, diagnostico, amarração-clinica]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# Técnica de Escolha Radiestésica de Perguntas (Os riscos da condução passiva)

- **Objetivo**: Deixar o pêndulo e a egrégora escolherem qual das 3 perguntas da pétala será formulada ao assistido, assumindo a responsabilidade de tecer uma conexão coerente ("dar o nó no pingo d'água") entre esse resultado e a queixa original do cliente.
- **Pré-requisitos**: Mestre ou operador com boa destreza na condução de mandalas.
- **Passo a Passo**:
  1. Ao invés de o terapeuta ler e escolher intuitivamente a pergunta mais contundente da pétala para o drama do cliente, ele gira o pêndulo sobre a régua da mesa para sintonizar o número (1, 2 ou 3).
  2. O pêndulo indica a pergunta de forma quântica (o inconsciente não erra).
  3. O terapeuta lê a pergunta indicada. Se ela soar completamente estranha ao assunto central (ex: falar de solidão quando o cliente quer dinheiro), o terapeuta deve usar seu conhecimento e inteligência para costurar e amarrar clinicamente aquele viés ao nó do cliente.
- **Duração/Frequência**: Utilizada opcionalmente na varredura diagnóstica.
- **Indicadores de Sucesso**: Conexão lógica bem elaborada pelo terapeuta que faça o cliente admitir a relação oculta entre a pergunta aleatória e o seu problema.
- **Variações**: Seleção radiestésica cega de perguntas vs. escolha terapêutica focada.
- **Conceitos Envolvidos**: [[Tecnica de Rastreio Duplo nas Mandalas]], [[Principio do Foco Primordial]]

## Perguntas Frequentes / Didática de Atendimento

### 22. Quais as consequências de permitir que o pêndulo decida a pergunta da mandala e qual a responsabilidade de "dar o nó no pingo d'água"?
**Resposta**: Ao deixar a mesa escolher, a autora adverte que "Errado não vai dar energeticamente", pois o pêndulo nunca erra na captação do inconsciente. No entanto, a consequência clínica é que "pode ser uma pergunta que não tem absolutamente nada a ver com a questão que ele trouxe". A nível somático e mental, se a dor da pessoa for "eu nunca encontro ninguém", e o pêndulo aponta para "Você sente que está acompanhada", o terapeuta assume a árdua responsabilidade psicanalítica de "amarrar" essa contradição e "dar o nó no pingo d'água", provando para o cliente por que aquela resposta oculta trava a vida dele.


## Referencia

ANDRESA MOLINA. *Técnica de Escolha Radiestésica de Perguntas*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
