---
type: conceito
author: Andresa Molina
tags: [liberdade, habilidade, autorizacao, disponibilidade, crescimento]
sources: ["[[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]]"]
---

# Conceito do Eixo da Liberdade

- **Definição**: O conjunto operacional de atitudes e sintonias energéticas na Mandala do Amor (composto por [[Conceito de Habilidade (Eixo da Liberdade)|Habilidade]], [[Conceito de Autorizacao (Eixo da Liberdade)|Autorização]] e [[Conceito de Disponibilidade (Eixo da Liberdade)|Disponibilidade]]) que rompe os medos e permite à alma expandir-se no mundo real.
- **Justificativa**: Ninguém que carece de [[Conceito de Habilidade (Eixo da Liberdade)|habilidade]], [[Conceito de Autorizacao (Eixo da Liberdade)|autorização]] e [[Conceito de Disponibilidade (Eixo da Liberdade)|disponibilidade]] pode acessar a sua liberdade existencial. A ausência de liberdade no campo do assistido gera angústia crônica e estagnação de projetos.
- **Evidências**: "Então, vamos lá pra gente falar todo o eixo de eh de liberdade. [...] Ninguém que não tem habilidade tem liberdade. Ponto. E a angústia vem da sua ausência de liberdade. [...] a liberdade consciente acontece quando você reconhece o que carrega com habilidade, se permite ir com a autorização e faz o que precisa ser feito com a disponibilidade."
- **Implicações**: O terapeuta deve utilizar as três pétalas deste eixo para identificar onde está a trava do assistido em relação à execução de sua missão.
- **Conexões**: [[Conceito de Habilidade (Eixo da Liberdade)]], [[Conceito de Autorizacao (Eixo da Liberdade)]], [[Conceito de Disponibilidade (Eixo da Liberdade)]]
- **Notas Pessoais**: A [[Principio da Liberdade Consciente|liberdade consciente]] exige assumir a autoria das próprias ações e desejos.

## Referencia

ANDRESA MOLINA. *Conceito do Eixo da Liberdade*. Aula 04 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]].
