---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_100_a_hiperpolarizacao.md]]"]
---

# Cap 100 - A Hiperpolarizacao

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_100_a_hiperpolarizacao.md]]

## Referencia

ANDRESA MOLINA. *Cap 100 - A Hiperpolarizacao*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_100_a_hiperpolarizacao.md]]. Acesso em: 17 jun. 2026.
