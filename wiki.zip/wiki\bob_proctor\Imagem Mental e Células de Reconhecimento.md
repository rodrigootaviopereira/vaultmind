---
type: transcricao
author: Bob Proctor
tags: [bob-proctor, imagem-mental, celulas-cerebrais, reconhecimento, prosperidade]
sources: ["[[raw/transcriptions/Bob Proctor - Você nasceu rico - parte 4 (Seminário dublado e legendado).md]]"]
---

# Imagem Mental e Células de Reconhecimento

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/transcriptions/Bob Proctor - Você nasceu rico - parte 4 (Seminário dublado e legendado).md]]


## Síntese

A transcrição mostra que pensar é ativar imagens na mente e que a aprendizagem depende de criar novas células de reconhecimento. A prosperidade começa com a imagem interna correta sobre dinheiro e sobre si mesmo.

## 80/20

- Pensamos em imagens.
- O cérebro reconhece o que já foi treinado.
- Repetição instala novas imagens mentais.
- Carência e prosperidade são imagens concorrentes.

## Leitura Analítica

- O seminário usa demonstrações práticas para mostrar como a mente aprende.
- A atenção é levada da abstração para a visualização concreta.

## Conexões com a Wiki

- [[wiki/bob_proctor/Princípio das Cinco Leis da Criação]]
- [[wiki/bob_proctor/Técnica da Fórmula de Alinhamento]]

## Referencia

BOB PROCTOR. *Imagem Mental e Células de Reconhecimento*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/transcriptions/Bob Proctor - Você nasceu rico - parte 4 (Seminário dublado e legendado).md]]. Acesso em: 17 jun. 2026.
