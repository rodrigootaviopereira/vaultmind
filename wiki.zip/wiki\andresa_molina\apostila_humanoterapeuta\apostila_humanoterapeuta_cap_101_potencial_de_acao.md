---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_101_potencial_de_acao.md]]"]
---

# Cap 101 - Potencial De Acao

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_101_potencial_de_acao.md]]

## Referencia

ANDRESA MOLINA. *Cap 101 - Potencial De Acao*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_101_potencial_de_acao.md]]. Acesso em: 17 jun. 2026.
