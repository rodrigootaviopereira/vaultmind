---
type: principio
author: Andresa Molina
tags: [espiritualidade, paternidade, veiculos, autonomia]
sources: ["[[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]]"]
---
# Princípio da Veiculação Biológica (A Autonomia Espiritual dos Filhos)

- **Definição**: Os pais biológicos são veículos que emprestam material genético para a manifestação física do espírito na Terra, e não criadores ou proprietários de sua alma.
- **Justificativa**: Quebra as prisões de culpa e cobranças excessivas no seio familiar, permitindo o amor maduro sem possessividade ou submissão a abusos.
- **Evidências**: "os seus pais, eles foram veículos para trazer você para o mundo e eles merecem ser agradecidos, honrados por tudo isso, mas eles não são os pais do seu espírito... você não é dona daquele espírito? E aí você consegue enxergar o seu filho, a sua filha ou o seu pai ou a sua mãe como um ser."
- **Implicações**: Honrar pai e mãe significa agradecer pelo corpo físico doado, mas reconhecer a soberania do espírito do filho e do próprio espírito frente às imposições parentais.
- **Conexões**: [[Conceito de Matar o Pai e a Mae]], [[Principio da Castracao Parental]]
- **Notas Pessoais**: Olhar a família como um conjunto de espíritos autônomos reduz a codependência e o peso cármico herdado.

## Perguntas Frequentes / Didática de Atendimento

### Como a autora desconstrói a ideia de posse sobre os espíritos familiares, afirmando que pais e mães são apenas "veículos que emprestaram material genético"?

Andresa desconstrói o senso de propriedade separando a biologia celular da soberania espiritual. Ela explica que os pais devem ser honrados por cederem a matéria física, pois "eles foram veículos para trazer você para o mundo... mas eles não são os pais do seu espírito". 

A nível somático e existencial, a maternidade e a patrimonialidade são tratadas como um acordo biológico de "emprestando material genético para que pudesse criar um outro veículo para que aquele espírito pudesse manifestar". Como "Quem cria espírito é Deus", a autora decreta a lei de autonomia absoluta: "Você não é dono do espírito do outro e o outro não é dono do seu espírito". Isso liberta a família da possessividade, pois cada corpo é apenas um veículo temporário que o espírito utiliza para dirigir no mundo tridimensional.


## Referencia

ANDRESA MOLINA. *Princípio da Veiculação Biológica (A Autonomia Espiritual dos Filhos)*. Aula 01 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]].
