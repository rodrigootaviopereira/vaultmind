---
type: tecnica
author: Andresa Molina
tags: [tecnica, meditacao, ancestralidade, conexao-corporal, rastreamento, cansaco]
sources: ["[[raw/archive/andresa_molina/transcriptions/01 - O CANSAÇO QUE NÃO PARA 1ª Coordenada - O Mapa da Alma.md]]"]
---

# Técnica de Identificação do Cansaço Ancestral

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/01 - O CANSAÇO QUE NÃO PARA 1ª Coordenada - O Mapa da Alma.md]]

## Objetivo

- Conectar o assistido com o seu corpo físico e sua memória emocional profunda para mapear e localizar a origem de um cansaço crônico/sistêmico, identificando se a sua causa é individual ou ancestral, e mapeando de qual linhagem familiar (materna ou paterna) ela se origina.

## Pré-requisitos

- Postura de recepção e presença.
- Disposição para responder às perguntas do rastreamento de forma imediata e intuitiva, usando a primeira resposta que surgir na consciência ou no corpo, sem tentar racionalizar ou analisar logicamente a resposta.

## Passo a Passo

1. **Aquietamento Inicial**: Sente-se de maneira confortável, feche os olhos e relaxe o corpo.
2. **Respiração em Três Tempos (3x)**:
   - Respire profundamente pelo nariz.
   - Segure o ar nos pulmões por alguns segundos.
   - Solte todo o ar suavemente pela boca.
   - Segure os pulmões vazios (sem ar) por alguns instantes.
   - Repita esta sequência exatas **três vezes**. Após a terceira repetição, retorne à respiração normal, leve e tranquila.
3. **Pergunta de Contraste Temporal**: Formule a pergunta interna: *"Qual foi a última vez que você descansou de verdade (não apenas dormiu)?"*. Sinta a resposta intuitiva e corporal que emerge dessa lembrança.
4. **Verificação de Autoria do Sintoma**: Responda mentalmente ou em voz alta com a primeira resposta intuitiva (sim ou não) que surgir para as seguintes perguntas:
   - *"Esse cansaço é seu?"*
   - *"Esse cansaço é só seu?"*
   - *"Esse cansaço você traz dos seus ancestrais?"*
5. **Localização no Corpo Físico**: Escaneie o corpo de forma receptiva e observe onde esse peso ou cansaço se manifesta de forma mais intensa (ombros, peito, cabeça, abdômen, costas, pernas, etc.). Esta localização é a coordenada física da marca no Mapa da Alma.
6. **Determinação da Linhagem Ancestral**: Caso tenha identificado que parte do cansaço é ancestral, faça a seguinte pergunta intuitiva ao corpo: *"Esta marca ancestral vem da linhagem do meu pai ou da linhagem da minha mãe?"*. Anote a primeira percepção que surgir.
7. **Retorno à Consciência**: Abra os olhos lentamente, retornando ao estado de vigília. Anote as respostas obtidas (Localização, Autoria e Linhagem) para utilizá-las como coordenadas iniciais do processo de reconsolidação da dor celular.

## Duração/Frequência

- Executada como uma prática inicial de rastreamento (leva cerca de 3 a 5 minutos) no início da anamnese ou da jornada de cura das dores sistêmicas.

## Indicadores de Sucesso

- Localização exata de um desconforto físico associado à fadiga sistêmica.
- Reconhecimento de que a exaustão física possui raízes emocionais ou sistêmicas.
- Identificação da linhagem familiar responsável pela transmissão epigenética do trauma.

## Conceitos Envolvidos

- [[Conceito do Mapa da Alma]]
- [[Principio da Memoria Celular Ancestral]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]

## Evidências do Material (MasterSense)

- Quando a ficha vem vazia ou pouco preenchida, a autora considera que nao ha material suficiente para analisar o caso. - **Fonte relacionada**: [[raw/archive/andresa_molina/transcriptions/02 Mastersense - Andresa Molina.md]] (Conceito da Ficha de Identificação e Síntese da Dor)
- Na aula 02 do MasterSense, a ficha passa a ser ensinada como instrumento de analise fria: o terapeuta deve observar o que foi preenchido, as contradicoes, as lacunas e os desalinhamentos entre consciente e inconsciente. A queixa inicial pode nao ser a raiz. (Conceito da Ficha de Identificação e Síntese da Dor)

## Referência

ANDRESA MOLINA. *Técnica de Identificação do Cansaço Ancestral*. Aula 01 - Coordenada 1 (Cansaço que não para) e MasterSense. Fontes: [[raw/archive/andresa_molina/transcriptions/01 - O CANSAÇO QUE NÃO PARA 1ª Coordenada - O Mapa da Alma.md]].
