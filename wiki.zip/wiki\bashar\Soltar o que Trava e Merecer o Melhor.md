---
type: transcricao
author: Bashar
tags: [bashar, soltar, merecimento, crenças, estado-positivo]
sources: ["[[raw/transcriptions/Como Soltar O Que Te Trava e ATRAIR O QUE VOCÊ MERECE  com análises críticas  Bashar.md]]"]
---

# Soltar o que Trava e Merecer o Melhor

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/transcriptions/Como Soltar O Que Te Trava e ATRAIR O QUE VOCÊ MERECE  com análises críticas  Bashar.md]]


## Síntese

A transcrição diz que o bloqueio em soltar vem de crenças sobre risco, indignidade e medo do desconhecido. Soltar é revisar a definição do que significa estar em estado positivo.

## 80/20

- O travamento aponta crença de permanência.
- Indignidade bloqueia o recebimento.
- Estado positivo precisa de definição limpa.

## Leitura Analítica

- O tema não é relaxar apenas, mas reprogramar a crença que mantém a pessoa presa.

## Referencia

BASHAR. *Soltar o que Trava e Merecer o Melhor*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/transcriptions/Como Soltar O Que Te Trava e ATRAIR O QUE VOCÊ MERECE  com análises críticas  Bashar.md]]. Acesso em: 17 jun. 2026.
