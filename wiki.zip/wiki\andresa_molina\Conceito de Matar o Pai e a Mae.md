---
type: conceito
author: Andresa Molina
tags: [expectativas, projecao, autonomia, relacionamentos]
sources: ["[[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]]"]
---
# Matar Pais e Mães (A Desconstrução das Frações/Expectativas)

- **Definição Precisa**: O processo de eliminar a fração mental dependente (o fractal da infância) que projetamos sobre os genitores, permitindo enxergar e amar o espírito livre do outro.
- **Sinônimos/Variações**: Matar os pais simbólicos, Eliminar as frações dependentes, Romper a projeção parental
- **Contexto de Uso**: Tratamento de codependências e bloqueios de maturidade emocional.
- **Relação com Princípios**: [[Principio da Veiculacao Biologica]], [[Principio da Castracao Parental]]
- **Exemplos do Material**: "Você precisa matar o pai da criança porque não existe mais criança... Se você não fizer isso, passará a vida esperando que qualquer outro homem ou mulher, real ou simbólico, atendam essas necessidades. Porque aí eu vou querer que meu marido faça igual meu papaizinho fazia... Enquanto eu não matar isso em mim... eu não consigo prosperar."
- **Aplicação Prática**: Conduzir o assistido a cessar a exigência infantil de provisão emocional sobre os pais e assumir a responsabilidade por sua própria vida somática.
- **Conexões Externas**: [[Conceito do Metodo HumanoSense]]

## Perguntas Frequentes / Didática de Atendimento

### O que significa, no contexto espiritual abordado por Andresa Molina, a expressão literal "matar pai e mãe" para poder amar e ser amado de verdade?

No contexto do método, "matar pai e mãe" não é um ato de desamor, mas a destruição da "fração" (ou fractal) mental e somática que criamos sobre eles. Significa "matar a pessoa, é matar essa fração", ou seja, aniquilar a expectativa infantil de que os pais ainda precisam atuar como provedores de uma criança que já não existe ("Você precisa matar o pai da criança porque não existe mais criança"). 

A nível somático, enquanto o indivíduo se relaciona com essa fração ilusória, ele não interage com o ser humano real, mas com uma projeção: "Quando eu olho pra minha mãe e não vejo a pessoa, só vejo a mãe... Eu crio algo entre nós". A consequência física e vibracional disso é que a pessoa ama "aquilo que eu inventei dela e não ela". Matar essa fração é o que permite ao corpo e ao espírito "ver e ser visto de verdade", enxergando a pessoa real "cheia de medos, cheia de dores, cheia de angústias", o que é o único caminho para o amor autêntico.

### Por que a tentativa de ser "esposa do próprio pai" anula a potência de atração de relacionamentos afetivos saudáveis?

Essa tentativa anula a potência porque viola a regra primária do sistema: "eu só posso ter potência quando eu executo a minha função. E eu só sou capaz de executar a minha função quando eu estou no meu lugar". 

A nível somático, a filha que tenta ser a "dona daquela casa" ao lado do pai está ocupando um lugar que a biologia e a energia dela não suportam. A autora é contundente: "você não pode se comportar como esposa do seu pai... porque você não tem a capacidade de dar pro seu pai o que ele quer de uma esposa... Você não tem potência para isso". Ao drenar toda a sua energia vital tentando executar uma função antinatural em casa, o corpo colapsa e não sobra potência, "força" e "coragem" (energia masculina e feminina) para materializar ou atrair um parceiro real para a própria vida, gerando apenas embates e insatisfação contínua.

### De que maneira a culpa infantil por não conseguir curar a infelicidade ou preencher o vazio existencial dos pais aprisiona a energia vital do assistido?

A energia vital é aprisionada porque a criança (ou adulto infantilizado) tenta preencher uma "falta" nos pais que não lhe diz respeito e que o seu corpo jamais poderá suprir. Andresa usa o exemplo de tentar suprir a falta de um parceiro para os pais: "A dor e o vazio dele tá em outro lugar e é só dele... o outro não precisa do que você tem". 

A nível somático, a frustração de tentar o impossível vira um ataque direto ao próprio corpo. A energia que deveria ir para o mundo ("impulso") fica presa numa roda de autodepreciação e inflamação física: "E aí a gente se culpa, se machuca, se fere e o outro reclama, briga com a gente, porque a gente tá nos lugares nas funções completamente erradas". Esse peso de sustentar dores alheias deforma a biologia: "É um corpo para cuidar de uma vida. Aí você agora tem um corpo para cuidar de três vidas... Claro que ele não vai aguentar... vai doer, vai adoecer".

### Como a transição de olhar para os pais não mais como provedores de dívidas emocionais, mas como "espíritos" que fazem parte da jornada, liberta o fluxo da vida?

Ao abandonar o papel de cobrador ("alguém que te deve algo"), o indivíduo quebra os bloqueios do sistema. Andresa explica que, ao "olhar o outro como um espírito", o assistido percebe o familiar apenas como um "ser que faz parte da sua jornada, mas que não é seu e nem você dele". 

A nível somático e vibracional, essa quebra de "dívida" age como a verdadeira cura. Sem a expectativa de posse, o corpo do indivíduo para de operar na frequência do ego e se liberta das amarras adoecedoras: "Sem isso não existe amor. E sem amor não tem cura. Só tem utilidade, dependência, culpa, cobrança, castigo, julgamento e padrão de dor". Ao neutralizar essa dependência e limpar as "alminhas" da cobrança, o fluxo da vida é retomado, permitindo "restabelecer amor profundo na jornada de cada um, no caminhar de cada um".


## Referencia

ANDRESA MOLINA. *Matar Pais e Mães (A Desconstrução das Frações/Expectativas)*. Aula 01 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]].
