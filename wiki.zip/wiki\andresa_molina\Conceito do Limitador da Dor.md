---
type: conceito
author: Andresa Molina
tags: [personalidade, limitador, bloqueio, controle, narcisismo]
sources: ["[[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]"]
---

# Conceito do Limitador da Dor

- **Definição**: A personalidade defensiva que se sente ameaçada pela evolução ou independência do outro e utiliza o falso cuidado ou sabotagem sutil como forma de contenção e barreira.
- **Justificativa**: O limitador impede o crescimento de seus familiares, amigos ou colegas porque teme ser deixado sozinho se eles progredirem. Somaticamente, bloqueia a expansão do sistema.
- **Evidências**: "O limitador. [...] ele limita pela dor. Se sente ameaçado pela evolução do outro e usa o cuidado como forma de contenção. [...] O limitador, a vida não vai porque ele bloqueia. Vai só até aqui. Daqui não passa. [...] Nos dois casos, a vida dele não vai. Se ele é o manipulado ou o manipulador, a vida dele não vai. Não tem como ir porque limita."
- **Implicações**: O terapeuta deve investigar se o assistido é o limitador ou a vítima de uma limitação parental ou conjugal (que exige 'permissão' para prosperar).
- **Conexões**: [[Conceito de Personalidade da Dor]], [[Principio da Mandala da Dor]]
- **Notas Pessoais**: O limitador gera um teto de vidro na prosperidade e na felicidade alheia.

## Referencia

ANDRESA MOLINA. *Conceito do Limitador da Dor*. Aula 03 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]].
