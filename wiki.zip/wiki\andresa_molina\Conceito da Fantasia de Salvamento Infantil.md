---
type: conceito
author: Andresa Molina
tags: [fantasia-infantil, salvamento, criança-ferida, donzela, ilusao]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# A Fantasia de Salvamento Infantil (A ilusão oculta da criança ferida)

- **Definição Precisa**: A ilusão psicológica e somática em que o assistido (por meio de um fractal ferido de sua infância) paralisa a sua vida presente esperando subconscientemente que um salvador (representando a mãe ou o pai ideal) venha resgatá-lo e cuidar das feridas de abandono que sofreu no passado.
- **Sinônimos/Variações**: Fantasia do salvador, síndrome de resgate da criança, idealização infantil de amparo.
- **Contexto de Uso**: Diagnosticado quando o assistido se sabota na matéria e finge autossuficiência racional, mas projeta em chefes, parceiros ou no próprio terapeuta a obrigação infantil de supri-lo ou salvá-lo das consequências da vida real.
- **Relação com Princípios**: [[Principio da Aceitacao dos Fatos]], [[Principio da Desilusao]]
- **Exemplos do Material**: "Eu vou chegar num lugar aonde eu não fui protegida e eu tô esperando alguém me proteger, aonde eu não fui cuidada. Essa é a minha dor. Eu queria que alguém tivesse me cuidado porque aquela minha criança naquele momento precisava. Como ela não teve, ela passou a vida querendo ainda... Então não é você, nem é o seu racional sendo sacana, nem é o seu inconsciente, é um fractal que tá em dor... é uma ilusão, porque no adulto não vai existir isso, mas a criança tá em dor."
- **Aplicação Prática**: Conduzir a regressão para desmantelar essa ilusão, forçando o luto pelo cuidado parental que nunca existiu e incentivando o assistido a assumir o papel de adulto responsável que ampara a si mesmo.
- **Conexões Externas**: [[Conceito do Arquetipo da Donzela]], [[Conceito de Matar o Pai e a Mae]]

## Perguntas Frequentes / Didática de Atendimento

### 9. Como a criança ferida se protege na "fantasia" de salvamento e como essa carência sabota os relacionamentos e a vida profissional do adulto?
**Resposta**: A criança ferida protege-se refugiando-se na ilusão de que um herói virá em seu auxílio: "o quanto você fantasia que alguém venha te salvar ou resolver seus problemas". A nível somático e psíquico, quando a pessoa vive um registro de abandono (ex: "Minha mãe me esqueceu na escola"), o corpo trava nessa carência e a pessoa passa "a vida querendo ainda" que alguém a proteja. O adulto mente para si mesmo "querendo criar e articular racionalmente um jeito de burlar para não parecer infantil".

Essa dor sabota a vida profissional e os relacionamentos porque a pessoa projeta inconscientemente a figura paterna/materna em quem a cerca, punindo essas pessoas quando elas falham em "salvá-la". A autora exemplifica o impacto profissional: "Eu não gosto daquele chefe e aí eu não me dou bem e eu não consigo minha promoção porque em algum ponto ele reconhece naquele chefe um alguém que abandonaria um filho assim como o pai dele abandonou". O adulto paralisa a sua existência porque o seu "fractal que tá em dor" espera algo que nunca virá ("é uma ilusão, porque no adulto não vai existir isso").


## Referencia

ANDRESA MOLINA. *A Fantasia de Salvamento Infantil*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
