---
type: tecnica
author: Andresa Molina
tags: [diagnostico-somatico, pai-e-mae, mapeamento, atracao-retencao]
sources: ["[[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]"]
---
# Diagnóstico Somático de Dinheiro e Relacionamentos (O Mapeamento da Rejeição a Pai e Mãe)

- **Objetivo**: Identificar se a trava do assistido em termos de conquistas e perdas materiais/afetivas está ligada à rejeição da força do pai (atração) ou da mãe (retenção).
- **Pré-requisitos**: Relato detalhado das dores do assistido perante finanças e namoros.
- **Passo a Passo**:
  1. Escutar a queixa principal do paciente sobre seus relacionamentos e finanças.
  2. Se o problem for a falta de atração ('dinheiro não vem', 'não arrumo parceiro'), rastrear julgamentos, pena ou raiva do Pai.
  3. Se o problem for a perda/falha de retenção ('dinheiro vaza rápido', 'namoros duram pouco'), rastrear conflitos e dinâmicas com a Mãe.
  4. Direcionar o foco das sessões de desobsessão de fractais para cicatrizar o vínculo ancestral afetado.
- **Duração/Frequência**: Executada na anamnese inicial.
- **Indicadores de Sucesso**: Mapeamento preciso da raiz sistêmica do fracasso material/afetivo.
- **Variações**: Pode focar nas duas linhas se o assistido apresentar travas simultâneas de atração e retenção.
- **Conceitos Envolvidos**: [[Conceito da Representacao Paterna]], [[Conceito da Representacao Materna]], [[Principio da Atracao e Relencao]]
- **Notas Pessoais**: As queixas financeiras do assistido são bússolas perfeitas para apontar qual genitor está sendo excluído.

## Referencia

ANDRESA MOLINA. *Diagnóstico Somático de Dinheiro e Relacionamentos (O Mapeamento da Rejeição a Pai e Mãe)*. Aula 02 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]].
