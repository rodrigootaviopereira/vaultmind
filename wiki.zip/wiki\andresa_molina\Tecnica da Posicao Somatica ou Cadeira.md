---
type: tecnica
author: Andresa Molina
tags: [posição-somatica, feto, cadeira, catarse-física]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# Prática da Posição Somática / Cadeira (A necessidade de encolhimento na purgação)

- **Objetivo**: Conduzir a sessão terapêutica com o assistido sentado em uma cadeira (e não deitado de barriga para cima numa maca), permitindo que seu corpo físico se recolha em posição fetal para desarmar a sobrevivência e liberar o choro profundo de dor.
- **Pré-requisitos**: Condução clínica no consultório ou espaço online.
- **Passo a Passo**:
  1. O terapeuta posiciona o assistido confortavelmente sentado na cadeira.
  2. Ao ingressar no transe de regressão e aproximar-se da catarse de dor (sangramento), orienta o assistido a inclinar o tronco para a frente.
  3. A posição sentada permite o "embolar" abdominal e o movimento natural de encolhimento que simula a posição fetal, facilitando que o peito se feche de defesas lógicas e a catarse emocional flua.
- **Duração/Frequência**: Adotada durante toda a etapa ativa da mesa e do desdobramento astral.
- **Indicadores de Sucesso**: Liberação fácil e profunda do choro durante o expurgo e sensação corporal de vulnerabilidade segura.
- **Variações**: Condução sentada em sessões online (garantindo que a câmera capte o tronco superior).
- **Conceitos Envolvidos**: [[Conceito do Sangramento do Utero da Vida]], [[Principio da Autossustentacao Fisica]]

## Perguntas Frequentes / Didática de Atendimento

### 17. Por que a autora exige que o paciente fique sentado em uma cadeira, proibindo o deitar de barriga para cima?
**Resposta**: Andresa proíbe o deitar na maca porque a biologia humana não consegue atingir a profunda vulnerabilidade do "sangramento" emocional com o peito aberto. Ela questiona: "Você já viu alguém conseguir chorar e sangrar deitado na maca assim, ó? Não, quando a gente chora, a gente embola assim". A nível somático, "deitado assim, ó, de barriga para cima... Consegue escorrer uma lágrima, mas você não consegue entrar". Estar sentado permite ao paciente fazer o "movimento de feto", projetando o tronco para a frente e encolhendo o abdômen, o que organicamente "traz essa possibilidade" de mergulhar na dor.


## Referencia

ANDRESA MOLINA. *Prática da Posição Somática / Cadeira*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
