---
type: conceito
author: Andresa Molina
tags: [luto, tratamento, deslocamento-de-funcao, familia, constelação]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# O Tratamento do Luto e o Deslocamento de Função (A correção dos papéis sistêmicos após a morte)

- **Definição Precisa**: A dinâmica sistêmica patológica onde os sobreviventes de uma morte na família, por evitarem a catarse do choro (querendo "ser fortes"), deslocam-se de seus papéis biológicos originais para preencher a função e o lugar do defunto na estrutura familiar (ex: a filha que vira esposa energética do pai viúvo).
- **Sinônimos/Variações**: Deslocamento de função no luto, desequilíbrio de papéis por morte.
- **Contexto de Uso**: Diagnosticado quando o assistido apresenta colapsos profissionais ou conjugais graves anos após uma perda familiar devido a inversões inconscientes de hierarquia no sistema.
- **Relação com Princípios**: [[Principio de Lugar Funcao e Potencia]], [[Principio da Aceitacao dos Fatos]]
- **Exemplos do Material**: "Muitas pessoas não tiveram a oportunidade nem o tempo de viver o luto, de chorar... uma coisa que acontece muito quando uma pessoa morre, outra pessoa muda de lugar, lugar, função e potência. E aí ela começa, o casamento fica ruim, porque agora ela virou esposa do pai, entende? No momento que ela virou esposa do pai, ela virou mãe da irmã. Virou o quê? Amante do marido. Inverteu tudo, entendeu? E aí essa conversa alinhando com essa essas informações que é do lugar função e potência... ela ajuda a pessoa."
- **Aplicação Prática**: Conduzir o assistido a vivenciar a catarse represada da perda (sangrar) e realizar o comando verbal e mental de devolução de funções, reassumindo sua real identidade e lugar no sistema.
- **Conexões Externas**: [[Tecnica de Desdobramento e Conducao do Sangramento]], [[Conceito das Camadas da Dor]]

## Perguntas Frequentes / Didática de Atendimento

### 10. Como o luto mal resolvido provoca o "deslocamento de função" no sistema familiar e de que forma a mesa e a câmara corrigem a filha que assume a função do pai viúvo?
**Resposta**: O luto mal resolvido ocorre quando o sobrevivente reprime o choro biológico, assumindo que "precisa ser forte" e esquecendo-se de sentir a dor. A nível somático e sistêmico, essa repressão provoca um "deslocamento de função": "quando uma pessoa morre, outra pessoa muda de lugar, lugar, função e potência". A filha abandona a sua biologia natural e assume a carga do defunto, o que colapsa as suas próprias relações: "o casamento fica ruim, porque agora ela virou esposa do pai... virou mãe da irmã. Virou o quê? Amante do marido. Inverteu tudo".

A mesa e a câmara corrigem essa inversão através da conscientização e do sangramento. Primeiro, a mesa atua no racional, onde as perguntas sobre "lugar função e potência do disponibilidade e autorização, ela ajuda a pessoa a ir percebendo" a sua desordem sistêmica. Depois, o desdobramento na Câmara obriga a pessoa "efetivamente sentir, de se despedir" daquela memória. Somaticamente, o terapeuta vai na câmara astral para "enquadrar, encaminhar aquilo, retirar" a pessoa daquela cena de velório onde ela "ficou lá, tá lá do lado", devolvendo-a ao seu lugar de filha no tempo presente.


## Referencia

ANDRESA MOLINA. *O Tratamento do Luto e o Deslocamento de Função*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
