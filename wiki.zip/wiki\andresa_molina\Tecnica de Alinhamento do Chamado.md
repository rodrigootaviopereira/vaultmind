---
type: tecnica
author: Andresa Molina
tags: [tecnica, autoanalise, 6a-coordenada, conexao-corporal, clareza, rastreamento]
sources: ["[[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]]"]
---

# Técnica de Alinhamento do Chamado

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]]

## Objetivo

- Rastrear a presença de captações energéticas do ambiente e de terceiros que estejam simulando sintomas físicos/emocionais próprios no assistido, utilizando a "resposta do peito" para desativar a hipnose do desvalor próprio e alinhar o sistema à missão essencial de vida.

## Pré-requisitos

- Postura introspectiva e relaxamento do fluxo racional (esvaziamento mental).
- Isolamento de pensamentos de autojulgamento ("estou louca", "sou exagerada").

## Passo a Passo

1. **Estado de Presença**:
   - Sentar-se confortavelmente, fechar os olhos e realizar uma respiração profunda, soltando o ar devagar para reduzir o ruído racional.
2. **Consultar o GPS Corporal**:
   - Diante de uma angústia, tristeza ou medo que surgiram de forma inexplicável ("do nada"), concentrar-se nas sensações físicas do peito e do abdômen.
   - Perguntar internamente ao corpo: *"Essa tristeza (ou medo) é minha ou estou captando de outra pessoa/ambiente?"*.
3. **Decodificação pelo Peito**:
   - Observar a resposta corporal. A resposta não virá como uma lembrança lógica, mas sim como uma reação imediata (um calor, um aperto ou uma intuição súbita no peito).
   - Se o corpo registrar que a emoção não é sua, decodificar a frequência de onde ela veio (raiva, nojo, desespero alheio).
4. **Criação do Oráculo Interno (Resposta do Peito)**:
   - Utilizar a máxima *"Respeito é a resposta do peito"*. 
   - Quando for necessário tomar decisões sobre caminhos profissionais ou afetivos, fechar os olhos e perguntar: *"O que meu peito sente sobre isso? Para onde a minha equipe espiritual me inclina?"*. 
   - Bloquear as desculpas intelectuais do ego e seguir a força desse impulso vibracional primário.
5. **Integração e Transmutação**:
   - Ao tomar consciência de que o sintoma era apenas uma captação sensorial alheia decorrente de sua alta sensibilidade, autorizar a transmutação. A clareza intelectual somada à permissão energética desinflama o sintoma de forma imediata (consciência que cura).

## Duração/Frequência

- Praticada diariamente ao perceber oscilações abruptas de humor ou mal-estar físico sem causa aparente, ou em atendimentos clínicos para treinar a mediunidade sensorial do assistido.

## Indicadores de Sucesso

- Alívio imediato de dores de cabeça, tonturas, bocejos e angústias captadas externamente.
- Dissolução da sensação de "estar ficando louca ou histérica".
- Percepção de um impulso sutil e seguro (impulso de Dharma) no peito direcionando para a ação.

## Conceitos Envolvidos

- [[Principio do Chamado da Sensibilidade]]
- [[Conceito de Clara Evidencia]]
- [[Conceito do Bloqueio Sensorial pelo Batismo]]
- [[Conceito da Sensibilidade como Valor e Dinheiro]]

## Referência

ANDRESA MOLINA. *Técnica de Alinhamento do Chamado*. Aula 06 - Coordenada 6 (O Chamado Ignorado). Fontes: [[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]].
