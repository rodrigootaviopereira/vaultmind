---
type: tecnica
author: Andresa Molina
tags: [esvaziamento, fecundacao, semente, semear, gestacao-interna]
sources: ["[[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]]"]
---

# Prática de Esvaziamento e Fecundação (A sustentação consciente do vazio e o plantio da semente)

- **Objetivo**: Conduzir o assistido a vivenciar e sustentar o silêncio e o vazio absoluto (o útero purificado) e nele fecundar/plantar a semente de sua nova intenção existencial, ativando o fluxo de prazer criativo (Kundalini) no corpo físico.
- **Pré-requisitos**: Conclusão da fase de catarse e encaminhamento de todas as dores associadas ao padrão.
- **Passo a Passo**:
  1. **Indução ao Vazio**: O terapeuta orienta o assistido: *"Sinta o vazio, o nada. Deixe ir tudo o que não te pertence... Sinta o conforto e o desconforto desse vazio"*. O assistido sustenta o estado de pura presença sem preenchê-lo com narrativas ou preocupações.
  2. **Ancoragem nos Três Cérebros**: O terapeuta reforça a contenção do vazio: *"Sustente esse vazio com os três cérebros, que é a mente, o coração e o intestino"*.
  3. **Plantio e Fecundação**: O terapeuta comanda a fusão criacional: *"Fecunde a ideia e penetre a semente. A semente que entra nesse espaço vazio e é fecundada, absorvida... tornando-se um só com a semente e o solo... e ativando a Kundalini"*. O assistido foca na sensação corporal de prazer e calor, permitindo que a nova realidade seja gestada na biologia celular.
- **Duração/Frequência**: Praticada no clímax de cocriação e finalização do transe.
- **Indicadores de Sucesso**: Percepção corporal nítida de prazer, calor ou arrepio subindo pela coluna (ativação da Kundalini) e sensação profunda de paz e preenchimento criativo.
- **Variações**: Fecundação de metas de abundância material vs. fecundação de cura biológica de doenças e dores.
- **Conceitos Envolvidos**: [[Conceito do Sangramento do Utero da Vida]], [[Conceito da Fusao do Masculino e Feminino]], [[Conceito da Sustentacao pelos Tres Cerebros]]

## Perguntas Frequentes / Didática de Atendimento

## Perguntas Frequentes / Didática de Atendimento

### 18. Como é conduzido o passo a passo do esvaziamento e fecundação e qual o papel dos três cérebros na estabilização da semente?
**Resposta**: O processo possui três etapas somáticas rigorosas:
1.  **O Esvaziamento:** O terapeuta induz o vácuo existencial: "Sinta o vazio, o nada... Sinta o conforto e o desconforto desse vazio. É para ficar no desconforto. Não preencha com nada".
2.  **A Sustentação (Os três cérebros):** Para que a semente não se perca, o paciente deve ancorá-la biologicamente "com os três cérebros, que é a mente, o coração e o intestino". O papel desses cérebros é estabilizar a criação combinando as três potências vitais do corpo: "Sustente com inteligência, com amor e com instinto" (onde as vísceras trazem a "Coragem e eliminação do que impede").
3.  **A Fecundação:** O assistido planta a intenção: "fecunde a ideia e penetre a semente... tornando-se um só com a semente e o solo... ativando a cundanaline [kundalini]".

## Referencia

ANDRESA MOLINA. *Prática de Esvaziamento e Fecundação*. Aula 06 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]].
