---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_43_a_palavra__quantica.md]]"]
---

# Cap 043 - A Palavra Quantica

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_43_a_palavra__quantica.md]]

## Referencia

ANDRESA MOLINA. *Cap 043 - A Palavra Quantica*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_43_a_palavra__quantica.md]]. Acesso em: 17 jun. 2026.
