---
type: conceito
author: Hélio Couto
tags: [centelha-divina, ego, self, iluminacao]
sources: ["[[raw/archive/soltar_individuação_e_iluminação_hélio_couto/soltar_individuação_e_iluminação_hélio_couto_cap_03_introdução.txt]]", "[[raw/archive/soltar_individuação_e_iluminação_hélio_couto/soltar_individuação_e_iluminação_hélio_couto_cap_04_o_poder_de_soltar.txt]]"]
---

# Conceito de Centelha Divina e Ego

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/soltar_individuação_e_iluminação_hélio_couto/soltar_individuação_e_iluminação_hélio_couto_cap_03_introdução.txt]]
  - [[raw/archive/soltar_individuação_e_iluminação_hélio_couto/soltar_individuação_e_iluminação_hélio_couto_cap_04_o_poder_de_soltar.txt]]

## Referencia

HÉLIO COUTO. *Conceito de Centelha Divina e Ego*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/soltar_individuação_e_iluminação_hélio_couto/soltar_individuação_e_iluminação_hélio_couto_cap_03_introdução.txt]], [[raw/archive/soltar_individuação_e_iluminação_hélio_couto/soltar_individuação_e_iluminação_hélio_couto_cap_04_o_poder_de_soltar.txt]]. Acesso em: 17 jun. 2026.
