---
type: tecnica
author: Bashar (Darryl Anka)
tags: [bashar, tecnica, meditacao, holotope, frequencia]
sources: ["[[https://www.bashar.org]]"]
---

# TÉCNICA DAS SESSÕES HOLOTOPE

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[https://www.bashar.org]]

## Referencia

BASHAR (DARRYL ANKA). *TÉCNICA DAS SESSÕES HOLOTOPE*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[https://www.bashar.org]]. Acesso em: 17 jun. 2026.
