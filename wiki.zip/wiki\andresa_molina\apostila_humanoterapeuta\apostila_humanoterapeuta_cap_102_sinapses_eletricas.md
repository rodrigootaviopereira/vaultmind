---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_102_sinapses_eletricas.md]]"]
---

# Cap 102 - Sinapses Eletricas

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_102_sinapses_eletricas.md]]

## Referencia

ANDRESA MOLINA. *Cap 102 - Sinapses Eletricas*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_102_sinapses_eletricas.md]]. Acesso em: 17 jun. 2026.
