---
type: principio
author: Andresa Molina
tags: [espiritualidade, livre-arbitrio, karma, dharma, milagres, sogro, sintonia, responsabilidade, 5a-coordenada, 7a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]]", "[[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]]"]
---

# Princípio da Responsabilidade Espiritual

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]]

## Definição

- **Definição**: O Princípio da Responsabilidade Espiritual estabelece que todos os eventos de nossa vida — tanto os grandes acertos quanto os piores erros, assim como a nossa família de nascimento e o acesso a conhecimentos transformadores — não pertencem de forma exclusiva à racionalidade lógica, mas ocorrem como manifestações necessárias de sintonia vibracional e caminhos evolutivos precisos do espírito.
- **Justificativa**: A mente racional tende a buscar culpados, assumir o papel de vítima ou se martirizar. Sob a ótica espiritual e sistêmica, contudo, o espírito encarna e atrai exatamente o que entra em ressonância com o que ele precisa curar ou aprender. Aceitar esse fluxo isenta o indivíduo da culpa, desprograma o ódio e abre as portas do campo sutil para a manifestação de milagres e soluções.
- **Sintonia Vibracional (7ª Coordenada)**: A atração familiar e o próprio acesso a conteúdos de cura no presente ocorrem sob essa lei. O indivíduo só encontra a resposta quando está energeticamente pronto, sendo conduzido por sintonia. Não há acidentes no sistema.

## Evidências

- *"Então, nem o erro, nem o acerto é nosso. Tudo é do nosso espírito. E quando a gente entende isso, a gente pode operar todos os milagres na nossa vida, porque eles estão dentro de nós. [...] O dia que a gente entende isso, a gente entende que tudo que aconteceu na nossa vida foi o que a gente precisava viver. e que tudo aquilo que a gente julga como o que a gente fez errado, a gente fez porque era preciso."*
- *Exemplo Prático (Caso do Sogro)*: O sogro de Andresa ignorou seu "sentir" e fez um procedimento arterial onde houve erro médico grave (perfuração do duodeno) e hemorragia. Racionalmente, pareceria uma má escolha ir ao hospital. Espiritualmente, a hemorragia ocorreria mesmo em casa, e o evento extremo serviu para mobilizar a cura familiar, o perdão ao médico e a ativação de um milagre de ressurreição clínica pela equipe espiritual.

## Implicações

- **Isenção de Culpa**: Compreender que o erro e o acerto pertencem ao espírito dissolve o looping mental de autopunição.
- **Transmutação do Ódio**: A cura sistêmica exige não cultivar "sementes de ódio" diante de injustiças (como erros de terceiros), mas transmutar a dor em amor para ativar a intervenção dos guias.

## Conexões

- [[Principio da Plenitude Energetica e do Cuidado]]
- [[Conceito de Ressignificacao vs Reconsolidacao]]
- [[wiki/andresa_molina/index_andresa_molina|Apêndice de Andresa Molina]]

## Referência

ANDRESA MOLINA. *Princípio da Responsabilidade Espiritual*. Aula 05 - Coordenada 5 (O Cuidado que Esgota) & Aula 07 - Coordenada 7 (A Cura Buscada em Todo Lugar). Fontes: [[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]], [[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. O que é a "dobra do tempo" no processo terapêutico energético e como o ganho de consciência celular encurta processos que levariam anos na terapia convencional?
**Resposta**: A **"dobra do tempo"** é um fenômeno espiritual e energético que acelera drasticamente a cura. A autora explica que esse encurtamento ocorre *"porque espiritualmente o tempo espaço não existe, existe na materialização"*. No mundo físico, um bebê precisa de meses cronológicos para se formar, mas para o espírito e para o campo quântico, a transformação é instantânea.

Quando a pessoa se abre para essa verdade e acessa a raiz espiritual e celular do trauma (em vez de ficar presa apenas na cabeça e na lógica), *"o tempo ele encurta. Então aquilo que pode demorar 10 anos é feito a dobra do tempo. E a dobra do tempo acontece agora"*.

Esse ganho de consciência celular permite esse salto temporal porque atua diretamente na base: a pessoa *"ganhou a consciência, trabalhou na causa, trabalhou no processo ancestral, trabalhou na cura ancestral que lhe habita, porque as células do corpo da sua mãe, ela emprestou células para compor o seu corpo"*. Em vez de passar anos discutindo o "efeito" (como a rejeição ou a falta de dinheiro) racionalmente, a intervenção vai direto na "causa", reconsolidando a trilha neural e operando o que a autora chama de *"milagre"*, encurtando o sofrimento imediato.

### 2. Como os conceitos de "Karma" e "Dharma" se relacionam com a escolha da família e do sistema em que o espírito do indivíduo encarna?
**Resposta**: Para Andresa, nascer em um sistema familiar desestruturado não é um castigo, um acidente ou um mero acaso. Ela questiona: *"se você caiu numa família que tinha esses comportamentos, a pergunta é: por que você caiu nesta família? O que existe em você, no seu espírito que precisou cair aí e que tem competência?"*.

A resposta para essa "queda" na família está fundamentada no *"propósito maior que o seu espírito traz"*, que se divide nos seguintes conceitos:
*   **Karma**: É a via da resolução de pendências que o espírito precisa vivenciar. Andresa explica que nós nascemos naquela família exata porque o nosso espírito traz *"algumas coisas para resolver"*. A vivência no sistema com dores específicas serve para engatilhar as curas que o indivíduo precisa fazer.
*   **Dharma**: É a via da força curadora e da missão. Andresa associa o Dharma à competência espiritual, afirmando que *"você tem o seu espírito e a sua alma é forte o suficiente para corrigir isso nesse sistema como um todo e neste corpo"*.

A relação entre esses conceitos dita que o indivíduo encarna (ou *"encontrou a família que você está"*) justamente porque ele é a peça que possui a grandiosidade, a força e a *"competência"* necessárias para enfrentar as "dores, amores e horrores" ancestrais. Ao fazer a própria cura, a força da sua alma atua de maneira que ele corrige a falha não apenas em si mesmo, mas no *"sistema como um todo"*.

### 3. No relato sobre o grave quadro clínico do sogro de Andresa, como a decisão dele de ignorar seu próprio "sentir" para seguir o protocolo médico e familiar resultou no erro cirúrgico?
**Resposta**: O sogro de Andresa precisava passar por um procedimento aparentemente simples para tratar uma trombose (colocar um stent). A autora relata que, internamente, ele tinha forte resistência e declarou explicitamente: *"Ai, eu não queria, eu não queria fazer isso"*. No entanto, diante da pressão do protocolo médico (*"o médico falou que era importante"*) e da pressão familiar (*"o que todos nós dissemos. Acho que é melhor"*), ele cedeu.

O resultado prático dessa submissão foi que ele acabou indo para a cirurgia *"não respeitando o sentir dele"*. Ao aceitar a imposição externa em detrimento da sua própria intuição, ele *"teve um erro médico"* durante o procedimento, no qual *"perfuraram o do odeno dele"*. Isso desencadeou uma série de complicações severas que culminaram em um quadro onde ele *"começou a ter um sangramento"*, passou a *"vomitar sangue"* e perdeu tanta quantidade de sangue que foi considerado *"praticamente morto"* e *"desenganado"* pela medicina.

Contudo, Andresa faz uma ressalva espiritual profunda sobre essa "escolha": sob a ótica da alma, mesmo se ele tivesse respeitado o seu "sentir" e ficado em casa, o evento traumático o alcançaria. Ela reflete que ele *"não iria pro hospital, mas teria tido uma complicação em casa"* e *"teria tido uma hemorragia em casa"*, indo parar no hospital da mesma maneira, pois o seu espírito *precisava* vivenciar aquela situação.

### 4. Sob a perspectiva do espírito de quem sofre o trauma, por que Andresa argumenta que o erro médico e a hemorragia grave eram eventos que o seu sogro precisava passar para a evolução de sua alma?
**Resposta**: Andresa argumenta que, na visão espiritual, os acidentes e tragédias não são meros acasos ou falhas puramente humanas, pois *"nem o erro é nosso e nem o acerto. Tudo é do nosso espírito"*. Sob essa perspectiva, o sofrimento extremo do seu sogro foi um mecanismo orquestrado pela alma para forçar uma cura que não ocorreria na zona de conforto.

A autora fundamenta essa necessidade de evolução em dois pilares:
*   **A Cura Individual do Espírito**: O evento extremo de ir da saúde quase perfeita para a beira da morte serviu para transmutar dores profundas. Andresa decreta que *"o erro médico foi o que ele precisava viver"*. Aquele choque (estar bem e *"do nada"* ficar ruim, e depois estar *"morto e reviver"*) ocorreu porque *"a espiritualidade dele precisava para curar o que nele precisava ser curado"*. A vivência desse "milagre" permitiu que ele mudasse e aprendesse através desse *"processo espiritual"*.
*   **A Cura Sistêmica e a Transmutação do Ódio**: O trauma não afetou apenas o sogro, mas serviu para a evolução de todo o sistema familiar. Diante do erro médico e da dor de ver um ente querido sangrando até quase morrer, a reação instintiva e racional da família era *"querer culpar alguém"*. No entanto, o evento forçou o sistema a fazer uma escolha de evolução: não deixar *"plantar a semente do ódio no nosso coração"*. Ao invés de processar o médico ou nutrir raiva, a família realizou um trabalho onde *"o objetivo era o amor, inclusive pro médico"*.

Portanto, o erro médico e a hemorragia foram o cenário exato e necessário que a espiritualidade desenhou para que o sogro e a família inteira pudessem *"operar todos os milagres"* e aprender a amar e curar, provando que *"tudo aquilo que a gente julga como o que a gente fez errado, a gente fez porque era preciso"*.

### 5. O que significa a máxima sistêmica "nem o erro é nosso, nem o acerto" no contexto da vida e da morte? Como isso liberta o assistido da culpa?
**Resposta**: No contexto da vida e da morte, a máxima "nem o erro é nosso e nem o acerto" significa que os desfechos das situações extremas e as rotas que tomamos não são determinados ou controlados puramente pela nossa mente humana e lógica, mas sim pelas necessidades evolutivas superiores. A autora esclarece que o desfecho existencial ("todo mundo vai viver ou morrer") foge do nosso controle humano: *"isso não é nosso. O o acerto não é meu, o erro não é meu"*.

Isso liberta o assistido do peso esmagador da culpa porque nós fomos socialmente ensinados a carregar "a culpa do que deu certo e a culpa do que deu errado". Ao absorver a compreensão de que *"Tudo é do nosso espírito"*, a pessoa deixa de se torturar pelas supostas falhas que cometeu no passado. A máxima ensina que *"tudo que aconteceu na nossa vida foi o que a gente precisava viver"* e que até mesmo as decisões que a pessoa julga que *"fez errado, a gente fez porque era preciso"* para a evolução do seu próprio espírito.

### 6. Como a família do sogro de Andresa trabalhou energeticamente para evitar que a "semente do ódio" contra o erro médico fosse plantada em seus corações, e de que forma isso possibilitou o milagre?
**Resposta**: Diante do erro médico grave que perfurou o duodeno do sogro e o fez quase sangrar até a morte, a família enfrentou o instinto humano natural: *"com a dor a gente passa a querer culpar alguém"* e, naturalmente, *"a gente fica com raiva"*.

Para evitar a propagação dessa raiva, a família adotou uma postura espiritual. A autora relata que *"um trabalho muito bom foi feito espiritual"* sustentado na seguinte premissa e escolha: *"o objetivo era o amor, inclusive pro médico"*. *(Nota: O texto relata a intenção e o objetivo desse trabalho espiritual, mas não detalha os passos técnicos ou como exatamente esse trabalho energético foi conduzido na prática).*

A decisão de focar no amor, perdoando a falha de quem executou a cirurgia, foi o que impediu a família de *"deixar plantar a semente do ódio no nosso coração"*. Segundo o texto, foi justamente essa elevação vibracional que pavimentou o caminho para a cura, pois ao escolherem esse amor incondicional como *"o nosso aprendizado na família e o aprendizado dele [...] o milagre aconteceu e o aprendizado também"*.

### 7. Por que o adoecimento repentino e o posterior "milagre" da recuperação do sogro de Andresa serviram para "tirar as certezas racionais" e conectar a família à força pura do espírito?
**Resposta**: Os eventos serviram para destruir as "certezas racionais" porque provaram a impotência absoluta da lógica e da medicina diante dos propósitos da alma. Andresa narra o choque provocado pelos saltos absurdos no quadro do sogro: *"ele tava bem e do nada ele ficou ruim"*, e pouco depois *"do nada ele tava morto. Mas do nada o milagre aconteceu e ele tava vivo"*.

Essa inconstância brutal, em que nem a piora nem a melhora podiam ser justificadas pelo intelecto, *"tirou todas as nossas certezas racionais e nos colocou de frente com o trabalho efetivamente espiritual"*. A família foi forçada a soltar a "racionalidade" e aceitar que o evento os tocava *"num lugar que nenhuma racionalidade é capaz de tocar"*.

Essa quebra da mente lógica os conectou à força pura do espírito ao fazer com que compreendessem que a doença e o milagre não foram meros infortúnios físicos, mas movimentos perfeitamente orquestrados para a evolução: *"A espiritualidade dele precisava para curar o que nele precisava ser curado. E de repente ele tá morto e reviver também foi o que a espiritualidade dele precisava"*.

### 8. Por que a sintonia energética é o fator determinante que atrai um determinado assistido a um terapeuta ou a um conteúdo de cura específico, segundo a perspectiva espiritual descrita?
**Resposta**: A sintonia energética é determinante porque a busca por cura não é um processo aleatório ou governado puramente pelo intelecto, mas sim uma atração magnética gerada por uma necessidade evolutiva. A nível somático, o indivíduo é fisicamente e energeticamente puxado ("sintonizado") para o ambiente terapêutico. 

Andresa explica que "se tudo é por sintonia, você não estaria assistindo esse conteúdo se ele não tivesse sintonia com você". O corpo e o espírito do assistido ressoam na mesma frequência daquele conhecimento porque "o que habita em mi que sintoniza com isso". Portanto, o encontro clínico não é um acidente; é uma orquestração invisível, uma vez que "a sua espiritualidade te conduz para que você encontre aquilo que você precisa. Isso é com você e isso é comigo".

