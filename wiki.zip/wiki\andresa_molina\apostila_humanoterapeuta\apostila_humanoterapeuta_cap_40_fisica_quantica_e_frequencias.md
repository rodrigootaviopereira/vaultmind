---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_40_fisica_quantica_e_frequencias.md]]"]
---

# Cap 040 - Fisica Quantica E Frequencias

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_40_fisica_quantica_e_frequencias.md]]

## Referencia

ANDRESA MOLINA. *Cap 040 - Fisica Quantica E Frequencias*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_40_fisica_quantica_e_frequencias.md]]. Acesso em: 17 jun. 2026.
