---
type: tecnica
author: Andresa Molina
tags: [intuição, alinhamento, coração, decisões, 6a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]]"]
---

# Prática do Respeito (A Resposta do Peito)

## Objetivo

- Burlar a paralisação provocada pelas justificativas e defesas lógicas da mente racional ao consultar diretamente o GPS sensorial e vibracional do tórax (coração/peito) para a tomada de decisões alinhadas ao Dharma e validação imediata de caminhos espirituais.

## Pré-requisitos

- Disposição para silenciar temporariamente o raciocínio analítico.
- Conexão e presença corporal consciente.

## Passo a Passo

1. **Desacelerar o Fluxo Mental**:
   - Diante de uma escolha profissional, financeira ou de relacionamento afetivo íntimo, interrompa a lista lógica de prós e contras.
   - Feche os olhos, respire profundamente e direcione toda a sua consciência para o centro do peito.
2. **Consultar o GPS Cardíaco**:
   - Faça perguntas-âncora a si mesmo: *"O que o meu peito diz sobre isso? Qual é o meu sentir? O que eu sinto agora?"*.
3. **Escutar a Resposta Somática**:
   - Monitore a reação imediata do tórax, ignorando se ela parece absurda racionalmente.
   - Sinta se há uma expansão, calor e um "impulso de vontade" sutil (indicador de alinhamento com a equipe espiritual) ou se há um aperto, desconforto e peso físico inegável (indicador de captação densa ou rota desalinhada).
4. **Respeitar o Sentir (Acolhimento)**:
   - Siga a direção indicada pela vibração do peito, agindo com base nesse sentir. 
   - Quando a mente tentar impor medos ancestrais ou familiares de escassez/julgamento, declare o corte lógico e retorne à segurança da sensação física constatada.

## Duração/Frequência

- Praticada em sessões terapêuticas para ajudar o assistido altamente sensível a desbloquear o canal de recebimento e autodescoberta profissional, ou no dia a dia como bússola de direcionamento existencial.

## Indicadores de Sucesso

- Dissolução imediata da confusão e do looping de indecisão racional.
- Percepção de conforto, leveza física e certeza interior ("fazer sentir" em vez de apenas "fazer sentido").
- Sensação clara de alinhamento com o projeto original da alma.

## Conceitos Envolvidos

- [[Principio do Chamado da Sensibilidade]]
- [[Principio do Vazio como Bussola]]
- [[Conceito de Clara Evidencia]]

## Referência

ANDRESA MOLINA. *Prática do Respeito (A Resposta do Peito)*. Aula 06 - Coordenada 6 (O Chamado Ignorado). Fontes: [[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. Como Andresa Molina decodifica a máxima "Respeito é a resposta do peito" e como a somatização física na região cardíaca ("negócio no peito") atua como bússola energética sutil para tomada de decisões?
**Resposta**: Embora o termo literal "negócio no peito" não conste textualmente no documento, Andresa decodifica a palavra **"Respeito"** como um comando ativo e somático: **"Resposta do peito"**.

Na tomada de decisões, a mente humana tenta governar tudo baseada na lógica, mas a espiritualidade não opera pelo intelecto. A autora instrui a pessoa a ignorar a mente que julga a intuição como *"que coisa louca"* ou diz *"Mas eu não entendo direito"*. Em vez disso, a pessoa deve transferir a atenção para a somatização física na região cardíaca.

Como bússola energética sutil, o corpo responde não com palavras lógicas, mas com sensações físicas e cinéticas: *"o que que mexe no seu coração agora?"* ou *"parece que eu tenho uma vontade me dá um impulso"*. Esse impulso torácico (a "vontade" visceral ou o calor no peito) é o sinal físico de que a equipe espiritual está direcionando o caminho correto, e a pessoa deve *"respeitar o seu sentir"*, pois esse chamado cravado no peito *"é o chamado que você não pode ignorar"*.

