---
type: conceito
author: Bashar (Darryl Anka)
tags: [bashar, conceito, esassani, canalizacao]
sources: ["[[darrylanka.com]]", "[[https://www.bashar.org]]"]
---

# CONCEITO DE ESASSANI

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[darrylanka.com]]
  - [[https://www.bashar.org]]

## Referencia

BASHAR (DARRYL ANKA). *CONCEITO DE ESASSANI*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[darrylanka.com]], [[https://www.bashar.org]]. Acesso em: 17 jun. 2026.
