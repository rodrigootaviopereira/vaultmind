---
type: conceito
author: Hélio Couto
tags: [criancas-indigo, evolucao, salto-quantico, consciencia]
sources: ["[[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_13_introdução.txt]]"]
---

# Conceito de Crianças Índigo

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_13_introdução.txt]]

## Referencia

HÉLIO COUTO. *Conceito de Crianças Índigo*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_13_introdução.txt]]. Acesso em: 17 jun. 2026.
