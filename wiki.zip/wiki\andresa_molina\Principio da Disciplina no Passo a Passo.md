---
type: principio
author: Andresa Molina
tags: [disciplina, passo-a-passo, tecnica, respeito, espaco-sagrado]
sources: ["[[raw/archive/transcriptions/Aula 06 - Código Humanosense - Andresa Molina.md]]", "[[raw/archive/transcriptions/01 - Aula Inaugural - HumanoSense - Andresa Molina.md]]"]
---

# Princípio da Disciplina no Passo a Passo

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/transcriptions/Aula 06 - Código Humanosense - Andresa Molina.md]]
  - [[raw/archive/transcriptions/01 - Aula Inaugural - HumanoSense - Andresa Molina.md]]

## Definição

- **Definição**: [INFERÊNCIA] Princípio da Disciplina no Passo a Passo expressa uma regra estrutural do sistema terapêutico de Andresa Molina: sem este princípio, a técnica perde força, segurança ou coerência no atendimento.
- **Formulação de apoio**: Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_03_metodologia_humanoterapeuta.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_04_passo_1_a_consulta_inicial_no_psicogerador_quantionico_o_diagnostico.md]].

## Justificativa

- [INFERÊNCIA] É central porque transforma conteúdo em postura terapêutica: não basta conhecer o método, é preciso aplicá-lo com presença, ordem, respeito ao campo e leitura da raiz da dor.

## Evidências

- Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_03_metodologia_humanoterapeuta.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_04_passo_1_a_consulta_inicial_no_psicogerador_quantionico_o_diagnostico.md]]. (HT - Conceito - Metodo Humanoterapeuta)

## Implicações

- [INFERÊNCIA] O terapeuta deve usar este princípio como critério de decisão antes de improvisar, interpretar ou conduzir o assistido.
- [INFERÊNCIA] Quando o princípio é ignorado, a sessão tende a ficar mental, apressada, fragmentada ou desconectada da equipe/campo de trabalho.

## Conexões

- [[HT - Conceito - Metodo Humanoterapeuta]]

## Notas Pessoais

- Reservado para observações do usuário no uso prático da técnica.

## Referencia

ANDRESA MOLINA. *Princípio da Disciplina no Passo a Passo*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/transcriptions/Aula 06 - Código Humanosense - Andresa Molina.md]], [[raw/archive/transcriptions/01 - Aula Inaugural - HumanoSense - Andresa Molina.md]]. Acesso em: 17 jun. 2026.
