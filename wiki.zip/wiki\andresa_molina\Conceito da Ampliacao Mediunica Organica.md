---
type: conceito
author: Andresa Molina
tags: [ampliacao-mediunica, organica, racional, sensitivo, clarividencia]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# A Ampliação Mediúnica Orgânica (A aceleração perceptiva sem alteração de natureza)

- **Definição Precisa**: O aprimoramento da via intuitiva do terapeuta decorrente do contato constante com os códigos da mesa, ocorrendo sem alterar a sua configuração neurológica natural (racional ou sensitiva).
- **Sinônimos/Variações**: Aceleração intuitiva, refino de canal mediúnico, apuramento da percepção do terapeuta.
- **Contexto de Uso**: Explicado para acalmar terapeutas lógicos/racionais que se sentem inferiores por não visualizarem cenas astrais cinematográficas. O Humanosense amplia a mediunidade acelerando a captação de pacotes intuitivos de dados rápidos no cérebro.
- **Relação com Princípios**: [[Principio da Preparacao do Terapeuta]], [[Principio da Inteligencia Espiritual]]
- **Exemplos do Material**: "existem os captadores que são mais sensíveis e captam mais pro corpo e tem mais sensibilidade e outros que são mais racionais... não é que vai acontecer uma coisa diferente do que a sua natureza, o seu jeito de ser médium. É ampliar aquilo que já tem... No seu caso que é mais racional, parece que vai ficar cada vez mais ligeiro. Parece que você vai ver uma coisa e a pessoa vai... A informação chega em você com uma rapidez maior e aí você pode até pensar, nossa, será que eu manipulei? ...Não, você só se anteviu. Você tava um segundo, milésimos de segundo antes dela vendo."
- **Aplicação Prática**: O terapeuta racional deve confiar nas intuições e deduções instantâneas que chegam à sua mente durante a varredura da mesa, agindo com a agilidade de quem captou o pacote de informações antes que a boca do cliente formule a história.
- **Conexões Externas**: [[Conceito de Clara Evidencia]], [[Conceito de Influencia vs Intuicao]]

## Perguntas Frequentes / Didática de Atendimento

### 14. Como a tecnologia atua na mediunidade de terapeutas racionais de forma orgânica?
**Resposta**: A autora ensina que a exposição aos códigos não altera a natureza da pessoa: "não é que vai acontecer uma coisa diferente do que a sua natureza, o seu jeito de ser médium. É ampliar aquilo que já tem". A nível somático e neurológico, para um "captador" extremamente racional, a mediunidade acelera o processo cognitivo. A percepção é orgânica e cerebral, chegando como "pacotes de informação" fulminantes: "parece que vai ficar cada vez mais ligeiro... A informação chega em você com uma rapidez maior e aí você pode até pensar, nossa, será que eu manipulei?". A intuição se manifesta na capacidade do cérebro lógico de se antever: "Você tava um segundo, milésimos de segundo antes dela vendo".


## Referencia

ANDRESA MOLINA. *A Ampliação Mediúnica Orgânica*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
