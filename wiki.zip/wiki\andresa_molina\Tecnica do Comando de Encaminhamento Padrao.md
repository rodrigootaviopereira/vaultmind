---
type: tecnica
author: Andresa Molina
tags: [comando-encaminhamento, resgate-padrao, habilidade-disponibilidade, transmutacao]
sources: ["[[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]]"]
---

# Comando de Encaminhamento Padrão (Invocação das entidades com habilidade, disponibilidade e autorização)

- **Objetivo**: Convocar a egrégora base de resgate e limpeza espiritual para acolher a contraparte de dor recém-libertada da cena traumática e encaminhá-la para tratamento na [[Conceito da Camara HumanoSense|Câmara HumanoSense]].
- **Pré-requisitos**: Conclusão da catarse emocional do assistido através da [[Tecnica do Confronto e Resgate da Contraparte|Técnica do Confronto e Resgate da Contraparte]].
- **Passo a Passo**:
  1. O terapeuta realiza o enquadramento (pirâmide de 1 a 5) ao redor do holograma da cena de dor do assistido.
  2. Decreta verbalmente em voz alta o comando estrutural de invocação:
     *"Em nome da minha amada presença de Deus, eu sou em mim e pela chama trina que brilha em meu coração, eu invoco a presença de todas as entidades com habilidade, disponibilidade e autorização que tenham interesse em contribuir com esse processo."*
  3. Comanda o acolhimento do fractal da alma e finaliza com a instrução: *"Encaminho tudo para a câmara humanocense"*.
- **Duração/Frequência**: Utilizada sempre que uma cena de dor ou fractal traumático é desarmado e necessita de recolhimento espiritual.
- **Indicadores de Sucesso**: Sensação imediata de alívio e leveza descrita pelo assistido, e liberação energética da cena na mesa.
- **Variações**: Condução de recolhimento de múltiplos fractais da mesma cena de dor ancestral.
- **Conceitos Envolvidos**: [[Conceito de Entidades de Resgate vs Especialistas]], [[Conceito da Camara HumanoSense]]

## Perguntas Frequentes / Didática de Atendimento

## Perguntas Frequentes / Didática de Atendimento

### 16. Qual a verbalização exata e a funcionalidade do comando no recolhimento das contrapartes de dor?
**Resposta**: A verbalização exata para convocar a equipe padrão de resgate é:
*"Em nome da minha amada presença de Deus, eu sou em mim e pela chamrina [chama trina] que brilha em meu coração, eu invoco a presença de todas as entidades com habilidade, disponibilidade e autorização que tenham interesse em contribuir com esse processo."*

A funcionalidade desse comando é convocar a equipe responsável estritamente pela purificação emocional do cenário. A autora especifica que essas "são as entidades que vão fazer a limpeza e o recolhimento e encaminhamento dessas consciências" que estavam presas na dor.

## Referencia

ANDRESA MOLINA. *Comando de Encaminhamento Padrão*. Aula 06 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]].
