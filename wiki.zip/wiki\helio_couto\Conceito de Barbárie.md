---
type: conceito
author: Hélio Couto
tags: [barbarie, decadencia, civilizacao, colapso]
sources: ["[[raw/hélio_couto_manifesto_quântico/hélio_couto_manifesto_quântico_cap_01_livro_completo.txt]]"]
---

# Conceito de Barbárie

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/hélio_couto_manifesto_quântico/hélio_couto_manifesto_quântico_cap_01_livro_completo.txt]]

## Referencia

HÉLIO COUTO. *Conceito de Barbárie*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/hélio_couto_manifesto_quântico/hélio_couto_manifesto_quântico_cap_01_livro_completo.txt]]. Acesso em: 17 jun. 2026.
