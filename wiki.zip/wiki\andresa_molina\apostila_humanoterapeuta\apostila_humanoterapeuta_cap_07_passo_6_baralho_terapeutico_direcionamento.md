---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_07_passo_6_baralho_terapeutico_direcionamento.md]]"]
---

# Cap 007 - Passo 6 Baralho Terapeutico Direcionamento

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_07_passo_6_baralho_terapeutico_direcionamento.md]]

## Referencia

ANDRESA MOLINA. *Cap 007 - Passo 6 Baralho Terapeutico Direcionamento*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_07_passo_6_baralho_terapeutico_direcionamento.md]]. Acesso em: 17 jun. 2026.
