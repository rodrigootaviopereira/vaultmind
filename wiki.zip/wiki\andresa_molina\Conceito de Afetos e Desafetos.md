---
type: conceito
author: Andresa Molina
tags: [afetos, desafetos, alvo-emocional, materializacao, objeto-de-dor]
sources: ["[[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]"]
---

# Afetos e Desafetos (O alvo sistêmico da dor e do apego)

- **Definição Precisa**: A categoria de diagnóstico somático do Humanosense que identifica a âncora viva ou material onde o assistido projeta a sua carga magnética de dor, amor, raiva ou apego (podendo ser uma pessoa, um carro, uma empresa, um cargo ou um imóvel).
- **Sinônimos/Variações**: Alvos sistêmicos, âncoras emocionais, objetos de dor/apego.
- **Contexto de Uso**: Rastreia-se o afeto/desafeto na anamnese para isolar qual "objeto" do mundo material detém os laços sutis de dor do assistido, orientando a investigação na mandala e o foco do desdobramento.
- **Relação com Princípios**: [[Principio do Foco Primordial]], [[Principio da Aceitacao dos Fatos]]
- **Exemplos do Material**: "Afetos e desafetos. afetos. É porque a pessoa vem, porque ela tá com dor em relação a alguma coisa que ela goste ou alguém que ela goste. Alguém, ah, meu meu marido ou ah, minha mãe... Eu amo o meu trabalho, mas eu não tô conseguindo fazer... Então, a empresa, o trabalho, o cargo é um afeto, entende? ...Ah, eu vou ter que vender o meu carro porque eu tô sem grana e eu não queria. Então, afeto é o carro, entende? Então, afeto pode ser uma pessoa, como pode ser alguma coisa. Ah, a minha mãe faleceu... A casa da mãe é um afeto."
- **Aplicação Prática**: Identificar se a queixa sobre perder um emprego ou vender um imóvel envolve a quebra de um cordão de afeto profundo, tratando a desvinculação desse objeto com a mesma seriedade de um luto de pessoas.
- **Conexões Externas**: [[Tecnica de Preenchimento da Ficha Cinza]], [[Conceito de Campo Emocional e Dependencia]]

## Perguntas Frequentes / Didática de Atendimento

### 6. O que Andresa Molina descreve como "Afetos e Desafetos" no diagnóstico clínico e de que maneira objetos inanimados concentram a dor?
**Resposta**: A autora descreve "Afetos e desafetos" como a origem da dor direcional do cliente: "É porque a pessoa vem, porque ela tá com dor em relação a alguma coisa que ela goste ou alguém que ela goste".

A nível somático, um objeto inanimado gera o mesmo nível de angústia porque ele atua como um elo vibracional e de apego para o paciente. Andresa ilustra que "a empresa, o trabalho, o cargo é um afeto" e que ter que vender um carro sem querer significa que o "afeto é o carro". O sofrimento se consolida porque a energia do indivíduo está aprisionada ao objeto. A autora usa o luto familiar para mostrar essa paralisia na matéria: "A casa da mãe é um afeto, é uma dor vender aquela casa, uma dor vender um carro... Então aquilo é algo que ele gosta, tá? Então não necessariamente pessoas".

## Referencia

ANDRESA MOLINA. *Afetos e Desafetos*. Aula 07 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]].
