---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_04_passo_1_a_consulta_inicial_no_psicogerador_quantionico_o_diagnostico.md]]"]
---

# Cap 004 - Passo 1 A Consulta Inicial No Psicogerador Quantionico O Diagnostico

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_04_passo_1_a_consulta_inicial_no_psicogerador_quantionico_o_diagnostico.md]]

## Referencia

ANDRESA MOLINA. *Cap 004 - Passo 1 A Consulta Inicial No Psicogerador Quantionico O Diagnostico*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_04_passo_1_a_consulta_inicial_no_psicogerador_quantionico_o_diagnostico.md]]. Acesso em: 17 jun. 2026.
