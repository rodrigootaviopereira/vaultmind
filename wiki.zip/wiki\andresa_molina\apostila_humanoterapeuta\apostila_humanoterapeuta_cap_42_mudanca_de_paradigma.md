---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_42_mudanca_de_paradigma.md]]"]
---

# Cap 042 - Mudanca De Paradigma

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_42_mudanca_de_paradigma.md]]

## Referencia

ANDRESA MOLINA. *Cap 042 - Mudanca De Paradigma*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_42_mudanca_de_paradigma.md]]. Acesso em: 17 jun. 2026.
