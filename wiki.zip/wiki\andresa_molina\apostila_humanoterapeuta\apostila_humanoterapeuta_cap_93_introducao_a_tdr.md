---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_93_introducao_a_tdr.md]]"]
---

# Cap 093 - Introducao A Tdr

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_93_introducao_a_tdr.md]]

## Referencia

ANDRESA MOLINA. *Cap 093 - Introducao A Tdr*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_93_introducao_a_tdr.md]]. Acesso em: 17 jun. 2026.
