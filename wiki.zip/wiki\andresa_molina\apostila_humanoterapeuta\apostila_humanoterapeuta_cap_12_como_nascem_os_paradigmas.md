---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_12_como_nascem_os_paradigmas.md]]"]
---

# Cap 012 - Como Nascem Os Paradigmas

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_12_como_nascem_os_paradigmas.md]]

## Referencia

ANDRESA MOLINA. *Cap 012 - Como Nascem Os Paradigmas*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_12_como_nascem_os_paradigmas.md]]. Acesso em: 17 jun. 2026.
