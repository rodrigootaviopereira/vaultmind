---
type: indice
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, indice]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_03_metodologia_humanoterapeuta.md]]"]
---

# HT - Indice Humanoterapeuta

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_03_metodologia_humanoterapeuta.md]]


## Nota-ancora

- [[HT - Apostila Humanoterapeuta - Andresa Molina]]
- [[wiki/andresa_molina/apostila_humanoterapeuta/index_apostila_humanoterapeuta|HT - Fonte da Apostila Humanoterapeuta]]

## Metodo e Tecnicas

- [[HT - Conceito - Metodo Humanoterapeuta]]
- [[HT - Principio - Sequencia Terapeutica]]
- [[HT - Principio - Cosmoetica]]
- [[HT - Tecnica - Psicogerador Quantionico]]
- [[HT - Conceito - Mesa Quantionica]]
- [[HT - Tecnica - Humanometria]]
- [[HT - Tecnica - TDR]]
- [[HT - Tecnica - Taquions-Tock]]
- [[HT - Tecnica - Regressao com Reprogramacao Celular]]
- [[HT - Tecnica - Baralho Terapeutico]]

## Modulos

- [[HT - Modulo 01 - Aprendendo a Voar]]
- [[HT - Modulo 02 - Temperamento e Elementos]]
- [[HT - Modulo 03 - Fisica Quantica e Frequencias]]
- [[HT - Modulo 04 - O Campo Eletromagnetico]]
- [[HT - Modulo 05 - Humanometria]]
- [[HT - Modulo 06 - Espiritualidade Avancada]]
- [[HT - Modulo 07 - TDR e Reprogramacao Energetica]]
- [[HT - Modulo 08 - Taquions-Tock]]
- [[HT - Modulo 09 - Regressao com Reprogramacao Celular]]
- [[HT - Modulo 10 - Baralho Cigano]]
- [[HT - Modulo 11 - A Consulta]]
- [[HT - Modulo 12 - Etica Moral e Cosmoetica]]

## Relacoes com Outras Trilhas da Autora

- [[Mapa dos Sistemas Terapeuticos de Andresa Molina]]
- [[Conceito do Metodo HumanoSense]]
- [[MasterSense - Mentoria do HumanoSense]]

## Observacao de Curadoria

Este indice separa **Humanoterapeuta** de **HumanoSense**. As conexoes entre os dois universos devem ser feitas por comparacao, afinidade de temas ou evolucao de linguagem, sem misturar as arquiteturas.

## Síntese

- [INFERÊNCIA] HT - Indice Humanoterapeuta é uma nota de apoio dentro da wiki de Andresa Molina e precisa ser lida em conjunto com as aulas e mapas estruturais já conectados.

## Evidências do Material

- As conexoes entre os dois universos devem ser feitas por comparacao, afinidade de temas ou evolucao de linguagem, sem misturar as arquiteturas. ## Referencia ANDRESA MOLINA. *HT - Indice Humanoterapeuta*. (HT - Indice Humanoterapeuta)
- Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_03_metodologia_humanoterapeuta.md]]. (HT - Indice Humanoterapeuta)
- Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_01_apresentacao.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_03_metodologia_humanoterapeuta.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_147_etica_moral_e_cosmoetica.md]]. (HT - Apostila Humanoterapeuta - Andresa Molina)
- Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_08_aprendendo_a_voar.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_13_mente_consciente_inconsciente_e_cosmica.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_30_os_chakras.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_34_consciencia_cosmica_parte_2.md]]. (HT - Modulo 01 - Aprendendo a Voar)
- Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_84_espiritualidade_avancada.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_85_tecnicas_energeticas_e_espirituais.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_89_principais_tipos_de_implantes.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_91_larvas_astrais_e_miasmas.md]]. (HT - Modulo 06 - Espiritualidade Avancada)
- Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_40_fisica_quantica_e_frequencias.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_41_conceitos_da_fisica_quantica_parte_1.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_50_descricao_da_experiencia_da_fenda_dupla.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_55_frequencias.md]]. (HT - Modulo 03 - Fisica Quantica e Frequencias)

## Conexões

- [[HT - Indice Humanoterapeuta]]
- [[HT - Apostila Humanoterapeuta - Andresa Molina]]
- [[HT - Modulo 01 - Aprendendo a Voar]]
- [[HT - Modulo 06 - Espiritualidade Avancada]]
- [[HT - Modulo 03 - Fisica Quantica e Frequencias]]

## Referencia

ANDRESA MOLINA. *HT - Indice Humanoterapeuta*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_03_metodologia_humanoterapeuta.md]]. Acesso em: 17 jun. 2026.
