---
type: conceito
author: Hélio Couto
tags: [autoestima, auto-sabotagem, subconsciente, crenças, reprogramação]
sources: ["[[raw/transcriptions/Autoestima - PNL Hélio Couto - Reprogramação Mental.md.md]]"]
---

# Conceito de Autoestima

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/transcriptions/Autoestima - PNL Hélio Couto - Reprogramação Mental.md.md]]

## Referencia

HÉLIO COUTO. *Conceito de Autoestima*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/transcriptions/Autoestima - PNL Hélio Couto - Reprogramação Mental.md.md]]. Acesso em: 17 jun. 2026.
