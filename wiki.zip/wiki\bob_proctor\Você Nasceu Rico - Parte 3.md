---
type: transcricao
author: Bob Proctor
tags: [bob-proctor, mentalidade, metas, persistencia, reprogramacao]
sources: ["[[raw/transcriptions/Bob Proctor e John Kanary - Você nasceu rico - parte 3 (dublado).md]]"]
---

# Você Nasceu Rico - Parte 3

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/transcriptions/Bob Proctor e John Kanary - Você nasceu rico - parte 3 (dublado).md]]


## Síntese

A parte 3 retoma a história de Bob e aprofunda o uso de metas, repetição e autoeducação. O seminário é apresentado como um processo de crescimento contínuo que altera a percepção de si e os resultados externos.

## 80/20

- Você se torna aquilo que pensa repetidamente.
- O resultado revela o nível de consciência.
- Crescimento exige autoobservação e persistência.

## Leitura Analítica

- A entrevista com John Kanary reforça a importância do ambiente e do estudo direcionado.
- O conteúdo insiste na aprendizagem emocional, não só intelectual.

## Conexões com a Wiki

- [[wiki/bob_proctor/Introdução ao Você Nasceu Rico]]
- [[wiki/bob_proctor/Técnica da Fórmula de Alinhamento]]

## Referencia

BOB PROCTOR. *Você Nasceu Rico - Parte 3*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/transcriptions/Bob Proctor e John Kanary - Você nasceu rico - parte 3 (dublado).md]]. Acesso em: 17 jun. 2026.
