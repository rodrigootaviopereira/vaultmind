---
type: consolidacao
author: Andresa Molina
tags: [andresa_molina, consolidacao, codigo-humanosense, humanosense]
sources:
  - "[[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]]"
  - "[[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]"
  - "[[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]"
  - "[[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]]"
  - "[[raw/archive/andresa_molina/transcriptions/05   Código Humanosense - Andresa Molina.md]]"
  - "[[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]]"
  - "[[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]"
  - "[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"
  - "[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"
  - "[[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]"
---

# Consolidado de Aulas: Código Humanosense (Aulas 01 a 10)

Este documento reúne de forma integrada e integral todas as notas das aulas **Aula 01** a **Aula 10** do Código Humanosense por Andresa Molina. Todos os detalhes foram preservados, e os termos identificados como não literais ou estranhos às transcrições originais foram marcados com tachado (`~~termo~~`) acompanhados das devidas notas de fidelidade textual.

## Aula 01 - Codigo Humanosense

# Aula 01 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `01   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 17.044 palavras; 581 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- Então, nesse primeiro momento, eu trago mais conteúdo que precisa dessas bases para vocês conseguirem fazer a aplicação, as perguntas depois e aí mais para frente eu abro com um embasamento maior e até as perguntas de vocês vão ficar mais embasadas, conseguir entender melhor e formular um pouco melhor e o raciocínio para executar essas perguntas, tá bom?
- Então, primeiro eu vou trazer informações conceituais extremamente importantes para que vocês tenham capacidade de executar o atendimento, conversar com o seu cliente, identificar os processos dele, identificar onde estão os problemas, os nós, os entraves, conseguir ter material intelectual para conversar com ele, para mostrar para ele onde tá o problema,…
- E aí depois dessa segunda parte a gente vai pra parte da técnica energética espiritual, dos comandos que a gente precisa, do como a gente vai fazer a parte onde a gente mergulha num padrão do do espírito da espiritualidade, no padrão energético, no padrão inconsciente da pessoa.
- O humanocense não é apenas um protocolo, é um caminho vivo, sensível que conduz o assistido da dor à consciência, da consciência à liberação e da liberação à criação de novas possibilidades.
- Aqui no portal humanoense você vai encontrar o passo a passo completo do método, as videoaulas comigo, explicando os conceitos e a terapêutica, as instruções práticas de aplicação e as fichas para download que irão guiar os seus atendimentos com clareza, leveza e profundidade.
- Então lá você tem o passo a passo, lá você vai ter as videoaulas, você vai ter as instruções práticas e você vai ter as fichas de atendimento para você poder as fichas de atendimento imprimir quantas vocês quiserem para você poder, eu espero que você tenha muito cliente, que você precise de muitas fichas de atendimento.
- Então você vai ter em mãos ferramentas como a mesa humanocense e as suas variações específicas que tem nela na mesa a mandala do amor, mandala da dor e a mandala da cura.
- Então quando a gente diz que o portal orienta, é porque aqui você encontra o que você tem que fazer, o passo a passo, os estudos e a ficha para download com tudo que precisa preencher.
- O kit físico teancora porque você tem em mãos, você terá o que perguntar e o que dizer com comandos espirituais energéticos do código manocência, perguntas estruturadas e condução prática. e a sua presença que conduz, porque é o sentir, a sua escuta e a sua entrega que complementam o processo.
- E somente com trabalho espiritual, energético, consciencial, profundo e tecnológico, é que se pode acabar com a autoobsessão, que muitos chamam de autossabotagem.
- Se você quer entender racionalmente o que te trava, aprender a tratar energeticamente, espiritualmente o que te bloqueia e criar um campo fértil para plantar suas novas criações e possibilidades, eu te convido a acessar o código inocência, que é uma energia viva, uma entidade organizada, inteligente que atua junto com o terapeuta e o assistido para…
- Então esse é o grande objetivo do humanos curar esse feminino, né, essas frações que estejam desequilibradas, como com esse ganho de consciência e com essas técnicas pra gente trabalhar essas sombras que não são só são só ideias e que são facilmente manipuladas pela espiritualidade e por nós também quando sabemos usar isso, né? que o que eu manipulo na…

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-73
- Então, nesse primeiro momento, eu trago mais conteúdo que precisa dessas bases para vocês conseguirem fazer a aplicação, as perguntas depois e aí mais para frente eu abro com um embasamento maior e até as perguntas de vocês vão ficar mais embasadas, conseguir entender melhor e formular um pouco melhor e o raciocínio para executar essas perguntas, tá bom?
- Então, primeiro eu vou trazer informações conceituais extremamente importantes para que vocês tenham capacidade de executar o atendimento, conversar com o seu cliente, identificar os processos dele, identificar onde estão os problemas, os nós, os entraves, conseguir ter material intelectual para conversar com ele, para mostrar para ele onde tá o problema, poder também ter entendimento para fazer as perguntas e…
- E aí depois dessa segunda parte a gente vai pra parte da técnica energética espiritual, dos comandos que a gente precisa, do como a gente vai fazer a parte onde a gente mergulha num padrão do do espírito da espiritualidade, no padrão energético, no padrão inconsciente da pessoa.

### Bloco 2 - frases 74-146
- Aqui no portal humanoense você vai encontrar o passo a passo completo do método, as videoaulas comigo, explicando os conceitos e a terapêutica, as instruções práticas de aplicação e as fichas para download que irão guiar os seus atendimentos com clareza, leveza e profundidade.
- Então lá você tem o passo a passo, lá você vai ter as videoaulas, você vai ter as instruções práticas e você vai ter as fichas de atendimento para você poder as fichas de atendimento imprimir quantas vocês quiserem para você poder, eu espero que você tenha muito cliente, que você precise de muitas fichas de atendimento.
- O kit físico teancora porque você tem em mãos, você terá o que perguntar e o que dizer com comandos espirituais energéticos do código manocência, perguntas estruturadas e condução prática. e a sua presença que conduz, porque é o sentir, a sua escuta e a sua entrega que complementam o processo.

### Bloco 3 - frases 147-219
- Nessa fase, após a limpeza emocional e espiritual e definição responsável do que se quer manifestar, partimos para a fecundação e materialização do desejo do assistido, facilitando a fusão entre o masculino e o feminino.
- Uma fase racional em que a pessoa vai entender o problema dela, compreender, identificar o problema. uma fase de limpeza onde essa pessoa vai conseguir chorar essa dor, limpar esse terreno fétil, essas sementes que foram plantadas, esses abortos que aconteceram de coisas que não vingaram e que estão sobrecarregando o sistema dela, fazer toda essa limpeza.
- Então o trabalho aqui, ele tem consciência, ele tem limpeza energética espiritual, tudo consciente, tudo consciente e ele tem o processo de manifestação e materialização a partir de um solo limpo, sagrado.

### Bloco 4 - frases 220-292
- E aí você se sente culpada porque você tenta, você faz tudo e o outro ainda tá infeliz porque o outro não precisa do que você tem.
- Não, dito isso, isso é uma coisa que vai, por isso que eu falei, vai embasar todo o trabalho sempre, porque muitas vezes as pessoas chegam para conversar com a gente, para trazer uma questão e tá tudo isso nesse balaio.
- Então, de maneira simbólica ou real, essa castração precisa acontecer ou pelo pai, ou ela vai acontecer pela vida, ou ela vai acontecer pelo pelo chefe, ou ela ela sempre vai, alguém vai precisar frustrar e dizer não.

### Bloco 5 - frases 293-365
- Não, eu ganho consciência ao ponto de querer reparar, de querer, de entender a dor que eu causei no outro, de entender que se eu não estou, porque o karma nada mais é do que a lei da semeadura.
- Mas o que o que a espiritualidade explica sempre é que não existe este pecado no sentido que tem que pagar, que tem que sofrer, não.
- Quando eu entendo que foi a dor no outro, eu quero reparar porque eu falo, gente, eu fui o mago desta magia, eu criei aquela dor.

### Bloco 6 - frases 366-438
- Você precisa matar o pai da criança porque não existe mais criança.
- E aí você vai ver, eu tô falando isso porque eu tô falando com muita gente, gente que teve pais e mães que foram malvados, violentos, abusivos e que ficou essa história de que tem que honrar pai e mãe e tem que tem honrar uma coisa, mas ele não é seu dono que você deva tudo, você deve sim o a honra, o agradecimento pelo ve que você não precisa se humilhar, rebaixar, se penci abusado, invadido, ferido por essa…
- Não significa que a gente não tenha que tratar energeticamente, que é o que propõe o código mas para eu ter o entendimento de tudo isso, para eu conseguir fazer o meu assistido tratar isso, eu preciso ter essa frequência em mim habitando.

### Bloco 7 - frases 439-511
- E somente com trabalho espiritual, energético, consciencial, profundo e tecnológico, é que se pode acabar com a autoobsessão, que muitos chamam de autossabotagem.
- Então, ah, o Código Humanocia, ele vai trabalhar dentro de tudo isso, de encontrar essas alminhas que a gente chama de fractal, de como transmutar isso, de como trabalhar isso, de quais as equipes espirituais, quais são os códigos pra gente se reconectar com as nossas essências.
- Se você quer entender racionalmente o que te trava, aprender a tratar energeticamente, espiritualmente o que te bloqueia e criar um campo fértil para plantar suas novas criações e possibilidades, eu te convido a acessar o código inocência, que é uma energia viva, uma entidade organizada, inteligente que atua junto com o terapeuta e o assistido para solucionar os entraves e abrir as portas pro novo.

### Bloco 8 - frases 512-581
- E aí se a gente dá o nome de obsessão lá fora chamando de autossabotagem e aí acham que só por ressignificar aí vai resolver.
- É o que então quando o meu feminino está magoado, com medo, melindroso, mimimi, chiliquento, é tudo o feminino ferido.
- Então esse é o grande objetivo do humanos curar esse feminino, né, essas frações que estejam desequilibradas, como com esse ganho de consciência e com essas técnicas pra gente trabalhar essas sombras que não são só são só ideias e que são facilmente manipuladas pela espiritualidade e por nós também quando sabemos usar isso, né? que o que eu manipulo na pessoa é a sombra dela.

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Então, nesse primeiro momento, eu trago mais conteúdo que precisa dessas bases para vocês conseguirem fazer a aplicação, as perguntas depois e aí mais para frente eu abro com um embasamento maior e até as perguntas de vocês vão ficar mais embasadas, conseguir entender melhor e formular um pouco melhor e o raciocínio para executar essas perguntas, tá bom?
- Esse código Manocense ele veio baseado em alguns pilares estruturais, né, onde vocês precisam compreender esses pilares para que depois na parte de execução vocês consigam executar o que vocês aprenderam desses pilares, tá?
- E aí depois dessa segunda parte a gente vai pra parte da técnica energética espiritual, dos comandos que a gente precisa, do como a gente vai fazer a parte onde a gente mergulha num padrão do do espírito da espiritualidade, no padrão energético, no padrão inconsciente da pessoa.
- Nessa primeira aula, que é uma aula que eu chamo de eh uma aula inaugural, eu vou trazer alguns conceitos que são extremamente importantes e que no decorrer do processo como um todo eles vão sempre estar ali num lugar bastante significativo de toda a técnica, de todo o caminho, tanto do curso quanto do seu cliente.
- Então esse isso você vai precisar sempre, muitos, se Deus quiser, você vai ter um monte de cliente vai ser um monte, tá bom?
- Então quando a gente diz que o portal orienta, é porque aqui você encontra o que você tem que fazer, o passo a passo, os estudos e a ficha para download com tudo que precisa preencher.
- Não, eu ganho consciência ao ponto de querer reparar, de querer, de entender a dor que eu causei no outro, de entender que se eu não estou, porque o karma nada mais é do que a lei da semeadura.
- E somente com trabalho espiritual, energético, consciencial, profundo e tecnológico, é que se pode acabar com a autoobsessão, que muitos chamam de autossabotagem.
- Então, o que mais a gente precisa, a gente vai falar muito disso, do masculino e do feminino ainda, mas a gente precisa entender que o que a gente julga, o que a gente toda vez que tem algum problema, é o nosso feminino que está ferido, sejamos nós homens ou mulheres, porque o nosso masculino vai lá e faz, ele é o que põe para fora, ele é o que impulsiona,…
- Então, para que a gente materialize qualquer coisa, a gente não precisa ter essas essas consciências, porque senão eu sou sempre a vítima.

## Conceitos-Chave Extraídos

- Esse código Manocense ele veio baseado em alguns pilares estruturais, né, onde vocês precisam compreender esses pilares para que depois na parte de execução vocês consigam executar o que vocês aprenderam desses pilares, tá?
- Nessa primeira aula, que é uma aula que eu chamo de eh uma aula inaugural, eu vou trazer alguns conceitos que são extremamente importantes e que no decorrer do processo como um todo eles vão sempre estar ali num lugar bastante significativo de toda a técnica, de todo o caminho, tanto do curso quanto do seu cliente.
- Então você acaba de acessar um código, uma tecnologia espiritual de cura que tem o poder de transformar vidas e também a forma como você atua como terapeuta.
- O humanocense não é apenas um protocolo, é um caminho vivo, sensível que conduz o assistido da dor à consciência, da consciência à liberação e da liberação à criação de novas possibilidades.
- Aqui no portal humanoense você vai encontrar o passo a passo completo do método, as videoaulas comigo, explicando os conceitos e a terapêutica, as instruções práticas de aplicação e as fichas para download que irão guiar os seus atendimentos com clareza, leveza e profundidade.
- Então você vai ter em mãos ferramentas como a mesa humanocense e as suas variações específicas que tem nela na mesa a mandala do amor, mandala da dor e a mandala da cura.
- O kit físico teancora porque você tem em mãos, você terá o que perguntar e o que dizer com comandos espirituais energéticos do código manocência, perguntas estruturadas e condução prática. e a sua presença que conduz, porque é o sentir, a sua escuta e a sua entrega que complementam o processo.
- Então o trabalho aqui, ele tem consciência, ele tem limpeza energética espiritual, tudo consciente, tudo consciente e ele tem o processo de manifestação e materialização a partir de um solo limpo, sagrado.
- Não, eu ganho consciência ao ponto de querer reparar, de querer, de entender a dor que eu causei no outro, de entender que se eu não estou, porque o karma nada mais é do que a lei da semeadura.
- Não significa que a gente não tenha que tratar energeticamente, que é o que propõe o código mas para eu ter o entendimento de tudo isso, para eu conseguir fazer o meu assistido tratar isso, eu preciso ter essa frequência em mim habitando.
- E somente com trabalho espiritual, energético, consciencial, profundo e tecnológico, é que se pode acabar com a autoobsessão, que muitos chamam de autossabotagem.
- Então, ah, o Código Humanocia, ele vai trabalhar dentro de tudo isso, de encontrar essas alminhas que a gente chama de fractal, de como transmutar isso, de como trabalhar isso, de quais as equipes espirituais, quais são os códigos pra gente se reconectar com as nossas essências.
- Se você quer entender racionalmente o que te trava, aprender a tratar energeticamente, espiritualmente o que te bloqueia e criar um campo fértil para plantar suas novas criações e possibilidades, eu te convido a acessar o código inocência, que é uma energia viva, uma entidade organizada, inteligente que atua junto com o terapeuta e o assistido para…
- E aí se a gente dá o nome de obsessão lá fora chamando de autossabotagem e aí acham que só por ressignificar aí vai resolver.
- É o que então quando o meu feminino está magoado, com medo, melindroso, mimimi, chiliquento, é tudo o feminino ferido.
- Então esse é o grande objetivo do humanos curar esse feminino, né, essas frações que estejam desequilibradas, como com esse ganho de consciência e com essas técnicas pra gente trabalhar essas sombras que não são só são só ideias e que são facilmente manipuladas pela espiritualidade e por nós também quando sabemos usar isso, né? que o que eu manipulo na…


## Técnicas, Procedimentos e Orientações Práticas

- Então, nesse primeiro momento, eu trago mais conteúdo que precisa dessas bases para vocês conseguirem fazer a aplicação, as perguntas depois e aí mais para frente eu abro com um embasamento maior e até as perguntas de vocês vão ficar mais embasadas, conseguir entender melhor e formular um pouco melhor e o raciocínio para executar essas perguntas, tá bom?
- Então, primeiro eu vou trazer informações conceituais extremamente importantes para que vocês tenham capacidade de executar o atendimento, conversar com o seu cliente, identificar os processos dele, identificar onde estão os problemas, os nós, os entraves, conseguir ter material intelectual para conversar com ele, para mostrar para ele onde tá o problema,…
- Depois a gente tem uma parte efetivamente prática onde você tem as perguntas para fazer e essas perguntas você vai identificar padrões conscientes e inconscientes.
- E aí depois dessa segunda parte a gente vai pra parte da técnica energética espiritual, dos comandos que a gente precisa, do como a gente vai fazer a parte onde a gente mergulha num padrão do do espírito da espiritualidade, no padrão energético, no padrão inconsciente da pessoa.
- Nessa primeira aula, que é uma aula que eu chamo de eh uma aula inaugural, eu vou trazer alguns conceitos que são extremamente importantes e que no decorrer do processo como um todo eles vão sempre estar ali num lugar bastante significativo de toda a técnica, de todo o caminho, tanto do curso quanto do seu cliente.
- O humanocense não é apenas um protocolo, é um caminho vivo, sensível que conduz o assistido da dor à consciência, da consciência à liberação e da liberação à criação de novas possibilidades.
- Aqui no portal humanoense você vai encontrar o passo a passo completo do método, as videoaulas comigo, explicando os conceitos e a terapêutica, as instruções práticas de aplicação e as fichas para download que irão guiar os seus atendimentos com clareza, leveza e profundidade.
- Então lá você tem o passo a passo, lá você vai ter as videoaulas, você vai ter as instruções práticas e você vai ter as fichas de atendimento para você poder as fichas de atendimento imprimir quantas vocês quiserem para você poder, eu espero que você tenha muito cliente, que você precise de muitas fichas de atendimento.
- Essas, o passo a passo vai estar no portal e as fichas de atendimento vai estar no portal para você imprimir quantas, 10, 20, 50, 200, 400, 1 milhão, quantas clientes você tiver.
- Então esse isso você vai precisar sempre, muitos, se Deus quiser, você vai ter um monte de cliente vai ser um monte, tá bom?
- Então quando a gente diz que o portal orienta, é porque aqui você encontra o que você tem que fazer, o passo a passo, os estudos e a ficha para download com tudo que precisa preencher.
- O kit físico teancora porque você tem em mãos, você terá o que perguntar e o que dizer com comandos espirituais energéticos do código manocência, perguntas estruturadas e condução prática. e a sua presença que conduz, porque é o sentir, a sua escuta e a sua entrega que complementam o processo.
- Então tem perguntas em que eu vou ter racionalmente saber o que fazer, vou perguntar, a pessoa vai me responder o racional dela, mas eu vou conseguir investigar o que está no padrão inconsciente dela.
- Se você quer entender racionalmente o que te trava, aprender a tratar energeticamente, espiritualmente o que te bloqueia e criar um campo fértil para plantar suas novas criações e possibilidades, eu te convido a acessar o código inocência, que é uma energia viva, uma entidade organizada, inteligente que atua junto com o terapeuta e o assistido para…


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- Então, primeiro eu vou trazer informações conceituais extremamente importantes para que vocês tenham capacidade de executar o atendimento, conversar com o seu cliente, identificar os processos dele, identificar onde estão os problemas, os nós, os entraves, conseguir ter material intelectual para conversar com ele, para mostrar para ele onde tá o problema,…
- E aí depois dessa segunda parte a gente vai pra parte da técnica energética espiritual, dos comandos que a gente precisa, do como a gente vai fazer a parte onde a gente mergulha num padrão do do espírito da espiritualidade, no padrão energético, no padrão inconsciente da pessoa.
- O humanocense não é apenas um protocolo, é um caminho vivo, sensível que conduz o assistido da dor à consciência, da consciência à liberação e da liberação à criação de novas possibilidades.
- Então você vai ter em mãos ferramentas como a mesa humanocense e as suas variações específicas que tem nela na mesa a mandala do amor, mandala da dor e a mandala da cura.
- Então tem perguntas em que eu vou ter racionalmente saber o que fazer, vou perguntar, a pessoa vai me responder o racional dela, mas eu vou conseguir investigar o que está no padrão inconsciente dela.
- Nessa fase, nós iremos conectar o assistido aos fractais de dor que ele carrega e fazê-lo sentir essa dor, autorizando as suas emoções reprimidas para que possamos esgotar esse fractal que foi magnetizado por anos e consecutivamente faremos a limpeza espiritual desse fractal que por ter sido alimentado por muito tempo com o ectoplasma já se torna um…
- Não, eu ganho consciência ao ponto de querer reparar, de querer, de entender a dor que eu causei no outro, de entender que se eu não estou, porque o karma nada mais é do que a lei da semeadura.
- E somente com trabalho espiritual, energético, consciencial, profundo e tecnológico, é que se pode acabar com a autoobsessão, que muitos chamam de autossabotagem.
- Se você quer entender racionalmente o que te trava, aprender a tratar energeticamente, espiritualmente o que te bloqueia e criar um campo fértil para plantar suas novas criações e possibilidades, eu te convido a acessar o código inocência, que é uma energia viva, uma entidade organizada, inteligente que atua junto com o terapeuta e o assistido para…
- E aí se a gente dá o nome de obsessão lá fora chamando de autossabotagem e aí acham que só por ressignificar aí vai resolver.
- Então, o que mais a gente precisa, a gente vai falar muito disso, do masculino e do feminino ainda, mas a gente precisa entender que o que a gente julga, o que a gente toda vez que tem algum problema, é o nosso feminino que está ferido, sejamos nós homens ou mulheres, porque o nosso masculino vai lá e faz, ele é o que põe para fora, ele é o que impulsiona,…
- É o que então quando o meu feminino está magoado, com medo, melindroso, mimimi, chiliquento, é tudo o feminino ferido.


## Citações e Formulações de Alta Densidade

- “Então, nesse primeiro momento, eu trago mais conteúdo que precisa dessas bases para vocês conseguirem fazer a aplicação, as perguntas depois e aí mais para frente eu abro com um embasamento maior e até as perguntas de vocês vão ficar mais embasadas, conseguir entender melhor e formular um pouco…”
- “Esse código Manocense ele veio baseado em alguns pilares estruturais, né, onde vocês precisam compreender esses pilares para que depois na parte de execução vocês consigam executar o que vocês aprenderam desses pilares, tá?”
- “E aí depois dessa segunda parte a gente vai pra parte da técnica energética espiritual, dos comandos que a gente precisa, do como a gente vai fazer a parte onde a gente mergulha num padrão do do espírito da espiritualidade, no padrão energético, no padrão inconsciente da pessoa.”
- “Nessa primeira aula, que é uma aula que eu chamo de eh uma aula inaugural, eu vou trazer alguns conceitos que são extremamente importantes e que no decorrer do processo como um todo eles vão sempre estar ali num lugar bastante significativo de toda a técnica, de todo o caminho, tanto do curso…”
- “O humanocense não é apenas um protocolo, é um caminho vivo, sensível que conduz o assistido da dor à consciência, da consciência à liberação e da liberação à criação de novas possibilidades.”
- “Então esse isso você vai precisar sempre, muitos, se Deus quiser, você vai ter um monte de cliente vai ser um monte, tá bom?”
- “Então quando a gente diz que o portal orienta, é porque aqui você encontra o que você tem que fazer, o passo a passo, os estudos e a ficha para download com tudo que precisa preencher.”
- “Não, eu ganho consciência ao ponto de querer reparar, de querer, de entender a dor que eu causei no outro, de entender que se eu não estou, porque o karma nada mais é do que a lei da semeadura.”
- “E somente com trabalho espiritual, energético, consciencial, profundo e tecnológico, é que se pode acabar com a autoobsessão, que muitos chamam de autossabotagem.”
- “Então, o que mais a gente precisa, a gente vai falar muito disso, do masculino e do feminino ainda, mas a gente precisa entender que o que a gente julga, o que a gente toda vez que tem algum problema, é o nosso feminino que está ferido, sejamos nós homens ou mulheres, porque o nosso masculino vai…”
- “É o que então quando o meu feminino está magoado, com medo, melindroso, mimimi, chiliquento, é tudo o feminino ferido.”
- “Então esse é o grande objetivo do humanos curar esse feminino, né, essas frações que estejam desequilibradas, como com esse ganho de consciência e com essas técnicas pra gente trabalhar essas sombras que não são só são só ideias e que são facilmente manipuladas pela espiritualidade e por nós…”

## Conexões com a Wiki

- [[Conceito do Metodo HumanoSense]]
- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]
- [[Conceito da Camara HumanoSense]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio da Liberdade Consciente]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Conceito do Divorcio Energetico]]
- [[Conceito do Parceiro da Missao]]

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. 
### Bloco 1: A Estrutura do Método HumanoSense e as Fases de Cura
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
1. Como Andresa Molina descreve a divisão metodológica do Código HumanoSense em suas três etapas macro (Identificação, Depuração e Execução)?
2. Qual é a diferença prática entre "ressignificar racionalmente" e a real "transmutação/mudança de estado" na resolução de um entrave de vida?
3. De que maneira o questionário racional consciente e a investigação do campo energético inconsciente (por meio da radiestesia com pêndulo) se cruzam para evidenciar "a mentira" do assistido?
4. Como Andresa Molina diferencia somática e energeticamente os três estados fundamentais da cura: "sentir", "transformar" e "transmutar"?
5. De que forma o "esvaziamento e limpeza do terreno fértil" na fase de depuração prepara o útero/sistema do assistido para uma manifestação ou cocriação responsável?





### Bloco 2: A Biologia Oculta dos Papéis e a Dinâmica de Lugar, Função e Potência
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
6. Como o conceito biológico/instintivo de "macho alfa e fêmea alfa" regula as lideranças e responsabilidades dentro de um sistema de relacionamentos de acordo com Andresa?
7. Qual é a regra hierárquica estabelecida pela autora quando os pais visitam a casa dos filhos e vice-versa, e quais são os impactos somáticos de desrespeitar esse fluxo natural?
8. De que forma a divisão societária e de relacionamento íntimo entre Andresa e Rodrigo exemplifica a alternância de polaridades alfa e beta nos níveis administrativo e terapêutico?
9. Como a autora conecta a perda de potência pessoal e profissional diretamente ao desalinhamento de um indivíduo em relação ao seu "lugar" e "função" no sistema?
10. Por que a tentativa de "competir com o parceiro" ou "metralhar ordens na casa dos pais" ativa reações instintivas de defesa e embate no nível mais primário do cérebro?

### Bloco 3: A Castração Psíquica, Frustração e Conflitos de Autoridade
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
11. Sob a ótica do Código HumanoSense, por que o pai é o responsável por "castrar o menino" e a mãe por "castrar a menina", e o que isso significa em termos práticos de limite?
12. Quais são as consequências na vida adulta (especialmente nas relações com chefes ou no mercado de trabalho) de uma criança que não passou pela castração parental na infância?
13. Como Andresa Molina explica que a frustração gerada pelo "não" parental auxilia o desenvolvimento somático do indivíduo para lidar com os embates e limites da vida?
14. Por que a ausência de posicionamento e imposição de limites pelos pais gera o comportamento de projetar neles (ou nos parceiros/chefes) a satisfação de todas as necessidades infantis?
15. De que maneira a egrégora do trabalho ou da empresa reage quando um profissional tenta se comportar fora do seu lugar por não ter resolvido a castração com seus pais?

### Bloco 4: Rompimento de Vínculos Infantis e "Matar Pai e Mãe"
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
16. O que significa, no contexto espiritual abordado por Andresa Molina, a expressão literal "matar pai e mãe" para poder amar e ser amado de verdade?
17. Como a autora desconstrói a ideia de posse sobre os espíritos familiares, afirmando que pais e mães são apenas "veículos que emprestaram material genético"?
18. Por que a tentativa de ser "esposa do próprio pai" ou "marido da própria mãe" anula a potência de atração de relacionamentos afetivos saudáveis?
19. De que maneira a culpa infantil por não conseguir curar a infelicidade ou preencher o vazio existencial dos pais aprisiona a energia vital do assistido?
20. Como a transição de olhar para os pais não mais como provedores de dívidas emocionais, mas como "espíritos iguais" que fazem parte da jornada, liberta o fluxo da vida?

### Bloco 5: Formas-Pensamento, Abortos de Criação e Autoobsessão
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
21. O que são os "pequenos abortos" mencionados por Andresa Molina no contexto de projetos e objetivos iniciados e não sustentados, e como eles afetam a fertilidade do "solo"?
22. Como o ectoplasma humano alimenta o que a autora chama de "alminhas" ou "fractais de dor", gerando a dinâmica de autoobsessão comumente rotulada de autossabotagem?
23. De que maneira a incapacidade do feminino em "sangrar" (chorar os lutos, sentir a dor e a falta) impede a capacidade masculina de "dar o sangue" e realizar a materialização?
24. Por que o trabalho tecnológico, energético e consciencial do Código HumanoSense é necessário para dissolver a "magia" que o próprio assistido fez em si mesmo e que amarra o outro?
25. Como o restabelecimento da harmonia entre o sentir feminino e o fazer masculino permite a fecundação responsável de novos desejos e criações?

## Referência

ANDRESA MOLINA. *Aula 01 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.

---

## Aula 02 - Codigo Humanosense

# Aula 02 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `02   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 16.926 palavras; 625 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- Resumo Automático: 02 Código Humanosense Transcrição / Texto Completo Olá, boa noite.
- Então, aqui, ó, mandala, como eu falei, perdão, vou abrir de novo, como eu falei, ela tem as três mandalas, a mandala do amor, a mandala da dor e aqui fora a mandala da cura.
- Então eu vou passar com vocês primeiro a o conceito e as perguntas da mandala do amor.
- Então a primeira coisa que nós vamos falar aqui é da eh dentro da mandala do amor, a gente tem um conceito base para terapêutica e a primeira delas que nós vamos falar é sobre energia, certo?
- Então, feminino ferido, ele é ofendido, julgador, magoado.
- Então, essa é a primeira, é o primeiro ponto que a gente precisa sempre identificar.
- Então, cada uma delas foi construída especificamente baseada nesse nesse campo de energia, tá?
- Então aqui a gente vai fazer perguntas pro nosso cliente, pro nosso assistido.
- Então, quando a gente fala em frequência e vibração, a gente precisa entender que tudo está dentro da energia do feminino e masculino.
- Então aqui quando a gente fala da fusão da influência e da intuição, e eu não falei de eu não falei de de espiritualidade aqui, eu não falei de religiosidade, eu não falei de espírito, eu tô falando de outra coisa, tem gente que nem acredita em nada e consegue trabalhar muito bem a sua influência e respeita a sua intuição e não acredita em nada.
- Vocês podem assistir a aula, como vocês podem olhar por aqui, porque tudo que eu falei, a explicação base tá aqui, ó.
- E aí você consegue ter um pensamento mais estruturado do campo energético dele, mas tem didática para falar de uma maneira que ele compreenda que seria uma base um pouco mais terapêutica, mas não uma terapia convencional, porque não é só pai é isso, a mãe é isso, a mãe é isso, pai é isso e a culpa é de quem, quem é culpado que faz só a gente ir de um lado…

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-79
- Resumo Automático: 02 Código Humanosense Transcrição / Texto Completo Olá, boa noite.
- Então, aqui, ó, mandala, como eu falei, perdão, vou abrir de novo, como eu falei, ela tem as três mandalas, a mandala do amor, a mandala da dor e aqui fora a mandala da cura.
- Então a primeira coisa que nós vamos falar aqui é da eh dentro da mandala do amor, a gente tem um conceito base para terapêutica e a primeira delas que nós vamos falar é sobre energia, certo?

### Bloco 2 - frases 80-158
- Então, feminino ferido, ele é ofendido, julgador, magoado.
- Então eu não dou continuidade porque eu tenho dificuldade em sustentar e a minha energia feminina precisa ser trabalhada, tá?
- Então, essa é a primeira, é o primeiro ponto que a gente precisa sempre identificar.

### Bloco 3 - frases 159-237
- Então, cada uma delas foi construída especificamente baseada nesse nesse campo de energia, tá?
- Então aqui a gente vai fazer perguntas pro nosso cliente, pro nosso assistido.
- Então, quando a gente fala em frequência e vibração, a gente precisa entender que tudo está dentro da energia do feminino e masculino.

### Bloco 4 - frases 238-316
- Então precisa fundir esses duas energias também para para nascer qualquer qualquer coisa.
- Então quando a gente fala de pais, a primeira referência simbólica da energia do dar e receber, agir e acolher e e da simbologia da fecundação e da gestação, igual a criação, são os pais.
- Então quando a gente fala que não existe contrrole, é sobre esse desejo.

### Bloco 5 - frases 317-395
- Ao invés de olhar e falar, paizão, segurou a onda, se ferrou, tomou, só se arrebentou, mas segurou era forte porque o que ele passou só sendo muito forte, entende?
- Eu estou dizendo, você precisa curar isso dentro de você de algum jeito, porque senão o dinheiro não vai ficar, o trabalho não vai ficar, o relacionamento não vai ficar.
- Ela não tem autorização para viver a vida dela porque ela precisa. fazer, porque se ela fizer alguma coisa diferente, porque a mãe gosta, a mãe não vai amar.

### Bloco 6 - frases 396-474
- Quando você se posiciona, é porque quando a gente traz algumas expressões, fica muito claro de fica mais fácil de compreender, de assimilar e de não esquecer o que eu falei, né?
- Então essas expressões elas trazem esse conteúdo interno que vem do inconsciente coletivo, por isso fica mais fácil de compreensão.
- Então ela a gente precisa do feminino, que é o sonho, que é o projeto de vida, que é aquilo que movia você, que vai te dar motivação, é mudar o mundo, é encontrar um jeito melhor, é cuidar dos filhos, como eu sempre sonhei, é ter aquela famílhei.

### Bloco 7 - frases 475-553
- Você não vai explicar nada disso que eu expliquei pr pessoas, você vai fazer as perguntas, depois eu vou ensinar como tá e aí ela falou, aí ela vai toda orgulhosa ou ele tod defender o que eu quero é 10 e só fica guerreando uma guerra sem fim porque ela acabada a tô tô cansada, tô doente, não sei por minha cabeça não para ela não para de guerrear dela fica guerreando o tempo inteiro.
- Então aqui quando a gente fala da fusão da influência e da intuição, e eu não falei de eu não falei de de espiritualidade aqui, eu não falei de religiosidade, eu não falei de espírito, eu tô falando de outra coisa, tem gente que nem acredita em nada e consegue trabalhar muito bem a sua influência e respeita a sua intuição e não acredita em nada.
- E aí a gente então tem o que a gente chama de espiritualidade livre, né?

### Bloco 8 - frases 554-625
- Vocês podem assistir a aula, como vocês podem olhar por aqui, porque tudo que eu falei, a explicação base tá aqui, ó.
- Então gente, é isso que queria pedir para vocês se apropriarem disso, refletirem, lê aqui e tenta relembrar o que eu falei, tenta relembrar exemplos, porque com exemplos, né, o poder dessa história, da parábola, da pequena história que me traz a reflexão, eu consigo ajudar o meu cliente a a na hora me lembrar e aí fazer ah isso aqui mais ou menos a mesma coisa que tava falando, uma história diferente, um…
- E aí você consegue ter um pensamento mais estruturado do campo energético dele, mas tem didática para falar de uma maneira que ele compreenda que seria uma base um pouco mais terapêutica, mas não uma terapia convencional, porque não é só pai é isso, a mãe é isso, a mãe é isso, pai é isso e a culpa é de quem, quem é culpado que faz só a gente ir de um lado pro outro e não transcender, transmutar, como eu falei na…

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Então, hoje a gente começa ativamente aqui, mas tudo que eu falei desde a primeira aula, ele vai reverberar no trabalho de vocês, tá?
- Então, aqui, ó, mandala, como eu falei, perdão, vou abrir de novo, como eu falei, ela tem as três mandalas, a mandala do amor, a mandala da dor e aqui fora a mandala da cura.
- Então a primeira coisa que nós vamos falar aqui é da eh dentro da mandala do amor, a gente tem um conceito base para terapêutica e a primeira delas que nós vamos falar é sobre energia, certo?
- Então, essa é a primeira, é o primeiro ponto que a gente precisa sempre identificar.
- Então, cada uma delas foi construída especificamente baseada nesse nesse campo de energia, tá?
- Então, quando a gente fala em frequência e vibração, a gente precisa entender que tudo está dentro da energia do feminino e masculino.
- Então aqui quando a gente fala da fusão da influência e da intuição, e eu não falei de eu não falei de de espiritualidade aqui, eu não falei de religiosidade, eu não falei de espírito, eu tô falando de outra coisa, tem gente que nem acredita em nada e consegue trabalhar muito bem a sua influência e respeita a sua intuição e não acredita em nada.
- Vocês podem assistir a aula, como vocês podem olhar por aqui, porque tudo que eu falei, a explicação base tá aqui, ó.
- Então gente, é isso que queria pedir para vocês se apropriarem disso, refletirem, lê aqui e tenta relembrar o que eu falei, tenta relembrar exemplos, porque com exemplos, né, o poder dessa história, da parábola, da pequena história que me traz a reflexão, eu consigo ajudar o meu cliente a a na hora me lembrar e aí fazer ah isso aqui mais ou menos a mesma…
- E aí você consegue ter um pensamento mais estruturado do campo energético dele, mas tem didática para falar de uma maneira que ele compreenda que seria uma base um pouco mais terapêutica, mas não uma terapia convencional, porque não é só pai é isso, a mãe é isso, a mãe é isso, pai é isso e a culpa é de quem, quem é culpado que faz só a gente ir de um lado…

## Conceitos-Chave Extraídos

- Resumo Automático: 02 Código Humanosense Transcrição / Texto Completo Olá, boa noite.
- Primeiro eu vou explicar alguns conceitos do que é cada uma dessas coisas da mandala para depois vocês entenderem como vocês vão conseguir fazer as perguntas e identificando as respostas, tá?
- Então, aqui, ó, mandala, como eu falei, perdão, vou abrir de novo, como eu falei, ela tem as três mandalas, a mandala do amor, a mandala da dor e aqui fora a mandala da cura.
- Então eu vou passar com vocês primeiro a o conceito e as perguntas da mandala do amor.
- Então a primeira coisa que nós vamos falar aqui é da eh dentro da mandala do amor, a gente tem um conceito base para terapêutica e a primeira delas que nós vamos falar é sobre energia, certo?
- Então, quando a gente fala de energia, toda criação tem duas forças, a energia da expansão e a energia da contenção.
- Então, quando a gente fala de energia masculina, e eu não tô falando de homem e mulher, é natural que a nossa cabeça vá pensar isso para encontrar uma representações simbólicas disso e conseguir então entrar no mundo da energia.
- Então, cada uma delas foi construída especificamente baseada nesse nesse campo de energia, tá?
- Então, quando a gente fala em frequência e vibração, a gente precisa entender que tudo está dentro da energia do feminino e masculino.
- Então quando a gente fala de pais, a primeira referência simbólica da energia do dar e receber, agir e acolher e e da simbologia da fecundação e da gestação, igual a criação, são os pais.
- Então quando a gente fala que não existe contrrole, é sobre esse desejo.
- Então aqui quando a gente fala da fusão da influência e da intuição, e eu não falei de eu não falei de de espiritualidade aqui, eu não falei de religiosidade, eu não falei de espírito, eu tô falando de outra coisa, tem gente que nem acredita em nada e consegue trabalhar muito bem a sua influência e respeita a sua intuição e não acredita em nada.
- E aí a gente então tem o que a gente chama de espiritualidade livre, né?
- E identificar o quanto é verdade, o quanto bate o que ela fala com o que ela tem no campo energético, no campo espiritual dela.
- Então, eu tô dando base terapêutica e aqui eu tô falando só dessa mandala do amor e e você começa a entender coisas quando a pessoa vai fazer, você já vai sabendo onde estão os problemas dela.
- E aí você consegue ter um pensamento mais estruturado do campo energético dele, mas tem didática para falar de uma maneira que ele compreenda que seria uma base um pouco mais terapêutica, mas não uma terapia convencional, porque não é só pai é isso, a mãe é isso, a mãe é isso, pai é isso e a culpa é de quem, quem é culpado que faz só a gente ir de um lado…


## Técnicas, Procedimentos e Orientações Práticas

- Então algumas pessoas ah, não receber meu kit, mas a gente vai identificar que tem pessoas que não preencheram, então não tem como a gente enviar, né?
- O outro recado, a gente tá recebendo no formulário, então lembrando, a gente criou um canal, né, do Telegram, onde a gente coloca alguns comunicados lá e também eu vou responder algumas perguntas.
- Porque algumas pessoas estão mandando perguntas preenchendo lá no formulário e perguntando sobre o kit, sobre questões técnicas, de como que entra, como é que, como é que acessa, como é que assiste a aula que ficou gravada.
- E aí uma coisa que é importante que a gente entenda aqui, eu vou responder perguntas que não são pessoais, então não adianta você falar: "Não é uma terapia, não vou fazer uma consulta com você".
- Então você assiste a aula que foi dada e aí você, se tiver alguma dúvida em relação à aquilo que foi falado naquela aula, você faz a sua pergunta e eu respondo, tá bom?
- Primeiro eu vou explicar alguns conceitos do que é cada uma dessas coisas da mandala para depois vocês entenderem como vocês vão conseguir fazer as perguntas e identificando as respostas, tá?
- Então eu vou passar com vocês primeiro a o conceito e as perguntas da mandala do amor.
- Então esse material vocês já têm com essas perguntas, então vocês podem eh se utilizar deles, enfim, acompanhar por aqui, mas depois vocês tm tudo, tudo que eu vou falar que tá anotado aqui, vocês tm nesse material, tá?
- Gestar é um processo demorado, longo, que precisa de nutrição, que precisa de introspecção, que precisa de espera, que precisa de reflexão, que precisa de estratégia, que precisa sentar e identificar como é que vai fazer.
- Então, essa é a primeira, é o primeiro ponto que a gente precisa sempre identificar.
- Então aqui a gente vai fazer perguntas pro nosso cliente, pro nosso assistido.
- E aí a pessoa vai responder com o racional dela e depois a gente vai conseguir identificar o campo espiritual dela, né?
- E identificar o quanto é verdade, o quanto bate o que ela fala com o que ela tem no campo energético, no campo espiritual dela.
- Então gente, é isso que queria pedir para vocês se apropriarem disso, refletirem, lê aqui e tenta relembrar o que eu falei, tenta relembrar exemplos, porque com exemplos, né, o poder dessa história, da parábola, da pequena história que me traz a reflexão, eu consigo ajudar o meu cliente a a na hora me lembrar e aí fazer ah isso aqui mais ou menos a mesma…


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- Resumo Automático: 02 Código Humanosense Transcrição / Texto Completo Olá, boa noite.
- Não aceitou, tem uma dificuldade de lidar com isso, o que é muito normal, mas não é que você não entendeu, você não consegue lidar com isso porque é uma dor sua.
- Então, aqui, ó, mandala, como eu falei, perdão, vou abrir de novo, como eu falei, ela tem as três mandalas, a mandala do amor, a mandala da dor e aqui fora a mandala da cura.
- Tudo que a gente faz e que a gente não sustenta é porque o nosso feminino está ferido e ele prefere abortar.
- Então, feminino ferido, ele é ofendido, julgador, magoado.
- Mas onde o vai trabalhar nesses abortos, nessas limpezas, aonde esse feminino foi ferido ou ficou ferido porque ele ficou melindroso porque ele não cresceu, ele ficou criança fazendo manha, fazendo birra.
- É para isso vir com o mundo que aí eu estutulei, pensei, aí no dia que eu tinha que começar aquilo, nossa, era uma emoção, ao mesmo tempo era um medo e era um peso, já tava pesado, aquilo tava grande, me angustiava, eu precisava logo trazer pro mundo.
- Então, quando você se profund, nossa, nenhum relacionamento meu dá certo, o quanto você fica só na beira no raso, quanto você se aprofunda nesse universo maior que é cheio de angústias, medos, incertezas, será que vai dar certo?
- Ela não tem autorização para viver a vida dela porque ela precisa. fazer, porque se ela fizer alguma coisa diferente, porque a mãe gosta, a mãe não vai amar.
- A gente não aprende a ouvir a nossa intuição, o nosso sentir e não víceras, desejos, carnais, medos, não ser movido pelo medo ou movido pelos desejos, é ser movido pela vontade divina. que habitam o meu coração e que é mais e que não precisa tudo fazer sentido, mas precisa fazer sentir.
- Então gente, é isso que queria pedir para vocês se apropriarem disso, refletirem, lê aqui e tenta relembrar o que eu falei, tenta relembrar exemplos, porque com exemplos, né, o poder dessa história, da parábola, da pequena história que me traz a reflexão, eu consigo ajudar o meu cliente a a na hora me lembrar e aí fazer ah isso aqui mais ou menos a mesma…
- E aí você consegue ter um pensamento mais estruturado do campo energético dele, mas tem didática para falar de uma maneira que ele compreenda que seria uma base um pouco mais terapêutica, mas não uma terapia convencional, porque não é só pai é isso, a mãe é isso, a mãe é isso, pai é isso e a culpa é de quem, quem é culpado que faz só a gente ir de um lado…


## Citações e Formulações de Alta Densidade

- “Então, quando a gente fala de energia masculina, e eu não tô falando de homem e mulher, é natural que a nossa cabeça vá pensar isso para encontrar uma representações simbólicas disso e conseguir então entrar no mundo da energia.”
- “Então eu não dou continuidade porque eu tenho dificuldade em sustentar e a minha energia feminina precisa ser trabalhada, tá?”
- “Então, essa é a primeira, é o primeiro ponto que a gente precisa sempre identificar.”
- “É para isso vir com o mundo que aí eu estutulei, pensei, aí no dia que eu tinha que começar aquilo, nossa, era uma emoção, ao mesmo tempo era um medo e era um peso, já tava pesado, aquilo tava grande, me angustiava, eu precisava logo trazer pro mundo.”
- “Então, quando a gente fala em frequência e vibração, a gente precisa entender que tudo está dentro da energia do feminino e masculino.”
- “Então quando a gente fala de pais, a primeira referência simbólica da energia do dar e receber, agir e acolher e e da simbologia da fecundação e da gestação, igual a criação, são os pais.”
- “Eu estou dizendo, você precisa curar isso dentro de você de algum jeito, porque senão o dinheiro não vai ficar, o trabalho não vai ficar, o relacionamento não vai ficar.”
- “Ela não tem autorização para viver a vida dela porque ela precisa. fazer, porque se ela fizer alguma coisa diferente, porque a mãe gosta, a mãe não vai amar.”
- “Então ela a gente precisa do feminino, que é o sonho, que é o projeto de vida, que é aquilo que movia você, que vai te dar motivação, é mudar o mundo, é encontrar um jeito melhor, é cuidar dos filhos, como eu sempre sonhei, é ter aquela famílhei.”
- “Então aqui quando a gente fala da fusão da influência e da intuição, e eu não falei de eu não falei de de espiritualidade aqui, eu não falei de religiosidade, eu não falei de espírito, eu tô falando de outra coisa, tem gente que nem acredita em nada e consegue trabalhar muito bem a sua influência…”
- “Então, eu tô dando base terapêutica e aqui eu tô falando só dessa mandala do amor e e você começa a entender coisas quando a pessoa vai fazer, você já vai sabendo onde estão os problemas dela.”
- “E aí você consegue ter um pensamento mais estruturado do campo energético dele, mas tem didática para falar de uma maneira que ele compreenda que seria uma base um pouco mais terapêutica, mas não uma terapia convencional, porque não é só pai é isso, a mãe é isso, a mãe é isso, pai é isso e a culpa…”

## Conexões com a Wiki

- [[Conceito do Metodo HumanoSense]]
- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio da Liberdade Consciente]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Conceito do Divorcio Energetico]]

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## FAQs para NotebookLM (Fase 2)

### Bloco 1: A Mandala do Amor e as Polaridades Masculina e Feminina
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
1. Como Andresa Molina descreve a Mandala do Amor e quais são os seus cinco pilares energéticos de diagnóstico?
2. Qual é o papel biológico e somático da energia masculina (a semeadura, a coragem e o impulso) no Código HumanoSense?
3. De que forma a energia feminina atua no processo de gestação e nutrição de metas, e por que a paciência estratégica é indispensável para a sustentação?
4. Como a união e a fusão criacional entre a energia de expansão (masculino) e de contenção (feminino) gera o magnetismo que traz projetos e realizações à vida?
5. De que maneira a ausência da força de sustentação feminina resulta na superficialidade das relações e na incapacidade de aprofundamento do assistido?

### Bloco 2: O Aborto de Projetos e a Dinâmica de Vibração e Frequência
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
6. O que é o "aborto de projetos" sob a perspectiva do Código HumanoSense, e de que forma o "feminino ferido/melindroso" contribui para esse padrão de desistência?
7. Qual é a diferença técnica e vibracional entre os estados de "Vibração" (regida pelo masculino) e "Frequência" (regida pelo feminino)?
8. Por que a motivação gerada em eventos pontuais ("vibração") não é suficiente para materializar resultados se a pessoa não sustentar a "frequência"?
9. Como a autocrítica ácida e o julgamento interno após o impulso de ação atuam como mecanismos do feminino ferido para abortar desejos?

### Bloco 3: As Representações Ancestrais do Pai e da Mãe na Prosperidade
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
10. Como a aceitação da força arquetípica do pai se conecta com a capacidade de atração e com a postura de segurança e enfrentamento no mundo?
11. De que maneira a representação materna governa o espaço interno de crescimento e a capacidade de retenção de relacionamentos e dinheiro?
12. O que ocorre no sistema financeiro e afetivo do assistido quando há rejeição simultânea à força do pai e da mãe?
13. Como o terapeuta pode realizar o Diagnóstico Somático de Dinheiro e Relacionamentos com base nas queixas de atração (pai) ou retenção (mãe) apresentadas pelo paciente?

### Bloco 4: Os Arquétipos do Protagonismo (Guerreiro, Donzela e Soberanos)
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
14. Qual é a função do "Arquétipo do Guerreiro/Guerreira" no enfrentamento de limites e na defesa de territórios pessoais?
15. De que forma o Guerreiro adoece, entrando em "guerras sem fim" e reações cegas quando se desconecta de uma causa maior?
16. Como o "Arquétipo da Donzela/Príncipe" atua como a faceta visionária do sonho, e quais são os perigos de seu desequilíbrio na fuga da realidade e procrastinação?
17. O que representa o estado de "Rei ou Rainha" no protagonismo, e de que maneira ele funde a espada do Guerreiro com a doçura e a diplomacia da Donzela?

### Bloco 5: A Mediunidade Livre e a Inteligência Espiritual
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
18. Como Andresa Molina define "Mediunidade" e "Inteligência Espiritual" fora das amarras da religiosidade convencional?
19. Qual é a diferença operacional entre "Influência" (polaridade masculina externa) e "Intuição" (polaridade feminina interna) na dinâmica da mediunidade livre?
20. Como o Princípio da Inteligência Espiritual orienta o indivíduo a decidir com base no que "faz sentir" no coração (intuição) em vez do que "faz sentido" lógico (lucro ou opinião alheia)?


## Referência

ANDRESA MOLINA. *Aula 02 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.

---

## Aula 03 - Codigo Humanosense

# Aula 03 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `03   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 17.335 palavras; 616 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- Então, tô bem feliz com as que estão chegando, com aquelas que eu consigo identificar e responder, claro, de uma maneira de uma maneira simples, porque é um um espaço pequeno paraa elaboração, então não tem como fazer uma elaboração profunda, mas a gente vai ter aqui também espaços para vocês perguntarem, não vai ser ainda, tá?
- Então, vai ter uma grande união, um grande processamento de informação para você poder identificar e ajudar ainda mais o seu assistido, né?
- Então já pra gente ir quebrando o processo, eu quero que você esteja atento aos seus clientes, aos seus assistidos, né, como a gente chama aqui, aqueles que você vai atender, aqueles que você já atende em casos específicos, tá?
- Então, mandalador é um campo invisível que ancora medos, memórias e crenças, um círculo de repetições internas que paralisa, sabota e pesa a vida.
- Então sempre de entender que existe uma dor, ninguém procura terapia se não tivesse dor.
- Então essa pessoa, ela normalmente está para baixo, está nada anda na vida dela, não anda mesmo, porque conforme ela explora dor, ela precisa ficar nesse lugar, esse lugar não tem energia, a energia fica parada, ela fica estagnada, realmente nada tá dando certo na vida dela, é bem possível, tá?
- E aí de repente você identifica que ele tem um padrão cobrador muito grande, porque tudo ele vai lá para trás, tudo ele vai lá para trás, tudo ele conta uma coisa lá atrás, porque o meu e sempre a culpa é o de alguém, nunca dele, entende?
- Então a vida dele não anda, não destrava, porque ele tem esse processo de dependência, não consegue liberar, ele não consegue se autorizar fazer porque ele se vai sentir culpa ou ele não vai se sentir mais amado e aí é possível que as pessoas falam: "Nossa, enricou agora ficou metido".
- No trabalho terapêutico, o dinheiro deixa de ser só matéria e passa a ser um espelho que mostra onde a energia do assistido precisa ser liberada, curada ou fortalecida.
- As pessoas que apanham e assumem para si, porque é tão enlouquecedor que assumem para si que é culpa delas. e que se elas não tivessem feito, não tivessem saído com aquela roupa, ela não teria apanhado, ele não precisaria bater.
- É naquela situação, naquela dor específica, naquele momento específico, ele tá carregado naquela personagem, porque ele está cheio de fractais, ele está cheio de criações, que é o que a gente vai trabalhar no desfazimento no campo energético.
- Pr as próximas, porque a gente vai aprender a usar mesa, fazer as perguntas e identificar também coisas no inconsciente e aí vocês vão entender bastante coisa, tá bom, gente?

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-77
- Então, tô bem feliz com as que estão chegando, com aquelas que eu consigo identificar e responder, claro, de uma maneira de uma maneira simples, porque é um um espaço pequeno paraa elaboração, então não tem como fazer uma elaboração profunda, mas a gente vai ter aqui também espaços para vocês perguntarem, não vai ser ainda, tá?
- Então já pra gente ir quebrando o processo, eu quero que você esteja atento aos seus clientes, aos seus assistidos, né, como a gente chama aqui, aqueles que você vai atender, aqueles que você já atende em casos específicos, tá?
- Então, mandalador é um campo invisível que ancora medos, memórias e crenças, um círculo de repetições internas que paralisa, sabota e pesa a vida.

### Bloco 2 - frases 78-154
- Então sempre de entender que existe uma dor, ninguém procura terapia se não tivesse dor.
- Então essa pessoa, ela normalmente está para baixo, está nada anda na vida dela, não anda mesmo, porque conforme ela explora dor, ela precisa ficar nesse lugar, esse lugar não tem energia, a energia fica parada, ela fica estagnada, realmente nada tá dando certo na vida dela, é bem possível, tá?
- E aí de repente você identifica que ele tem um padrão cobrador muito grande, porque tudo ele vai lá para trás, tudo ele vai lá para trás, tudo ele conta uma coisa lá atrás, porque o meu e sempre a culpa é o de alguém, nunca dele, entende?

### Bloco 3 - frases 155-231
- Ou ele é o que precisa carbar, não deixa o filho ir, não deixa o relacionamento terminar, não deixa, porque ele fica conduzindo e manipulando tudo aquilo.
- É um campo invisível que encara medos, memórias e crenças, um círculo de repetição interna que paralisa, sabota e pesa a vida.
- Ninguém tem que perceber porque cada um tá cuidando da sua vida e a pessoa chega em terapia com essa dor e a gente precisa ajudando a desconstruir isso, tá?

### Bloco 4 - frases 232-308
- Então assim, é uma pessoa reativa, julga e entra em confronto o tempo inteiro, cria lutas onde não há nenhuma batalha, usa o julgamento como defesa contra a dor.
- Então, zer 10, quando você sente que precisa estar sempre certa, em alerta e pronta para se defender.
- Aqui em alguns momentos tem algumas pessoas, né, aqui na dor, tá? quando quando tá na mandala da dor e quando a pessoa traz isso, que são as pessoas extremamente quando ela tá em dor manipuladoras, elas ela quer mexer as peças taboleira xadrez do jeito que ela quer, do jeito que ele quer.

### Bloco 5 - frases 309-385
- Então a vida dele não anda, não destrava, porque ele tem esse processo de dependência, não consegue liberar, ele não consegue se autorizar fazer porque ele se vai sentir culpa ou ele não vai se sentir mais amado e aí é possível que as pessoas falam: "Nossa, enricou agora ficou metido".
- Isso vai ser terapeuta trazendo pro consciente e ajudando a atravessar, fazer essa travessia nesse processo que é difícil, porque ela sente que não vai ser amada, sente que naquilo vai existir um abandono, que em alguns momentos não existe, é ilusório, em alguns momentos é real, porque o outro tá ali só porque tá tendo um ganho também, né?
- Então ó lá de 0 a 10, o quanto você sente que nunca tem tempo para si porque sempre está resolvendo o problema de alguém.

### Bloco 6 - frases 386-462
- Então a gente vai perguntar para essa pessoa: 0 a 10: quanto você sente que nunca viveu um relacionamento verdadeiro ou duradouro?
- Então o dinheiro é fluxo, é a energia que revela merecimento, autorresponsabilidade, confiança e limites.
- No trabalho terapêutico, o dinheiro deixa de ser só matéria e passa a ser um espelho que mostra onde a energia do assistido precisa ser liberada, curada ou fortalecida.

### Bloco 7 - frases 463-539
- Então você tem dinheiro para pagar conta, nunca sofre, sempre fica naquele limite, nunca sustenta mais.
- As pessoas que apanham e assumem para si, porque é tão enlouquecedor que assumem para si que é culpa delas. e que se elas não tivessem feito, não tivessem saído com aquela roupa, ela não teria apanhado, ele não precisaria bater.
- Quando você acredita que só poderá ter paz se todos ao seu redor estiverem curados, porque você é o lixo, você é o causador da dor de todo mundo.

### Bloco 8 - frases 540-616
- E tome isso para você como um uma jornada interior mesmo, um lugar de mais do que de chegar em algum lugar, mas um retorno pr pra casa, pra sua essência, para esse lugar incrível que é você que é o seu assistido, que é a pessoa que tá em dor, que é a pessoa que tá enfermizando, mas a pessoa precisa querer, né?
- É naquela situação, naquela dor específica, naquele momento específico, ele tá carregado naquela personagem, porque ele está cheio de fractais, ele está cheio de criações, que é o que a gente vai trabalhar no desfazimento no campo energético.
- Pr as próximas, porque a gente vai aprender a usar mesa, fazer as perguntas e identificar também coisas no inconsciente e aí vocês vão entender bastante coisa, tá bom, gente?

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Não importa qual é o problema que ele trouxe, ele traz aquela dor e ele fala da dor dele e tudo que você fala nada resolve porque ele quer ficar, ele tem um ganho secundário, ele ganha com aquilo.
- Então sempre de entender que existe uma dor, ninguém procura terapia se não tivesse dor.
- Então essa pessoa, ela normalmente está para baixo, está nada anda na vida dela, não anda mesmo, porque conforme ela explora dor, ela precisa ficar nesse lugar, esse lugar não tem energia, a energia fica parada, ela fica estagnada, realmente nada tá dando certo na vida dela, é bem possível, tá?
- E aí de repente você identifica que ele tem um padrão cobrador muito grande, porque tudo ele vai lá para trás, tudo ele vai lá para trás, tudo ele conta uma coisa lá atrás, porque o meu e sempre a culpa é o de alguém, nunca dele, entende?
- Ou ele é o que precisa carbar, não deixa o filho ir, não deixa o relacionamento terminar, não deixa, porque ele fica conduzindo e manipulando tudo aquilo.
- Ninguém tem que perceber porque cada um tá cuidando da sua vida e a pessoa chega em terapia com essa dor e a gente precisa ajudando a desconstruir isso, tá?
- Aqui em alguns momentos tem algumas pessoas, né, aqui na dor, tá? quando quando tá na mandala da dor e quando a pessoa traz isso, que são as pessoas extremamente quando ela tá em dor manipuladoras, elas ela quer mexer as peças taboleira xadrez do jeito que ela quer, do jeito que ele quer.
- Isso vai ser terapeuta trazendo pro consciente e ajudando a atravessar, fazer essa travessia nesse processo que é difícil, porque ela sente que não vai ser amada, sente que naquilo vai existir um abandono, que em alguns momentos não existe, é ilusório, em alguns momentos é real, porque o outro tá ali só porque tá tendo um ganho também, né?
- No trabalho terapêutico, o dinheiro deixa de ser só matéria e passa a ser um espelho que mostra onde a energia do assistido precisa ser liberada, curada ou fortalecida.
- As pessoas que apanham e assumem para si, porque é tão enlouquecedor que assumem para si que é culpa delas. e que se elas não tivessem feito, não tivessem saído com aquela roupa, ela não teria apanhado, ele não precisaria bater.

## Conceitos-Chave Extraídos

- Então trouxe o conceito de todas as as variações do masculino e feminino e de todas as etapas da mandala do amor.
- Esse processo de resistência que vocês imprimem no campo energético, ele é cansado de iso ficar derrubando essas barreiras que vocês mesmos criam por conta da dor, tá?
- Então por isso eu vou começar na mandala da dor falando de eh da personalidade de dor.
- Então já pra gente ir quebrando o processo, eu quero que você esteja atento aos seus clientes, aos seus assistidos, né, como a gente chama aqui, aqueles que você vai atender, aqueles que você já atende em casos específicos, tá?
- Eu vou compartilhar com vocês aqui a minha tela pra gente então seguir na mandala da dor.
- Então tentem prestar atenção aqui, depois vocês tm esse material todo para para consultar e tem até mais do que o que eu vou trazer aqui, que é o que tá na parte de trás como orientação, como explicação, como apoio para você terapeuta na hora que você estiver atendendo o seu assistido.
- Então, primeiro conceito, depois a gente vai partir, vai pra parte prática no próximo momento.
- Então, a primeira, a mandalador, ela é dividida em algumas eh em algumas faixas.
- Então, mandalador é um campo invisível que ancora medos, memórias e crenças, um círculo de repetições internas que paralisa, sabota e pesa a vida.
- E aí de repente você identifica que ele tem um padrão cobrador muito grande, porque tudo ele vai lá para trás, tudo ele vai lá para trás, tudo ele conta uma coisa lá atrás, porque o meu e sempre a culpa é o de alguém, nunca dele, entende?
- Então, primeiro conce entende o conceito do cobrador, tá?
- Ou ele é o que precisa carbar, não deixa o filho ir, não deixa o relacionamento terminar, não deixa, porque ele fica conduzindo e manipulando tudo aquilo.
- É um campo invisível que encara medos, memórias e crenças, um círculo de repetição interna que paralisa, sabota e pesa a vida.
- Aqui em alguns momentos tem algumas pessoas, né, aqui na dor, tá? quando quando tá na mandala da dor e quando a pessoa traz isso, que são as pessoas extremamente quando ela tá em dor manipuladoras, elas ela quer mexer as peças taboleira xadrez do jeito que ela quer, do jeito que ele quer.
- É naquela situação, naquela dor específica, naquele momento específico, ele tá carregado naquela personagem, porque ele está cheio de fractais, ele está cheio de criações, que é o que a gente vai trabalhar no desfazimento no campo energético.
- Então, quantas vezes a pessoa precisa passar por por pela pelo pelo código?


## Técnicas, Procedimentos e Orientações Práticas

- Então, aquelas que não foram respondidas, até porque eu me comprometi em responder três, né? e também das perguntas que fazem sentido nesse momento em que a gente tá.
- Então, tô bem feliz com as que estão chegando, com aquelas que eu consigo identificar e responder, claro, de uma maneira de uma maneira simples, porque é um um espaço pequeno paraa elaboração, então não tem como fazer uma elaboração profunda, mas a gente vai ter aqui também espaços para vocês perguntarem, não vai ser ainda, tá?
- Então, vai ter uma grande união, um grande processamento de informação para você poder identificar e ajudar ainda mais o seu assistido, né?
- Então já pra gente ir quebrando o processo, eu quero que você esteja atento aos seus clientes, aos seus assistidos, né, como a gente chama aqui, aqueles que você vai atender, aqueles que você já atende em casos específicos, tá?
- Então, esse é um material para você terapeuta conseguir elaborar com os seus clientes, com seus assistidos, tá bom?
- Então tentem prestar atenção aqui, depois vocês tm esse material todo para para consultar e tem até mais do que o que eu vou trazer aqui, que é o que tá na parte de trás como orientação, como explicação, como apoio para você terapeuta na hora que você estiver atendendo o seu assistido.
- Então, primeiro conceito, depois a gente vai partir, vai pra parte prática no próximo momento.
- Então ele usa daquela dor, ele explora aquilo, ou uma doença física, ou a pobreza, ou ai como eu sofro com o seu pai, você não sabe o que eu passo, o meu trabalho é muito difícil, você não sabe o que eu vivo.
- Então a pergunta é de 0 a 10: o quanto você sente que precisa sofrer ou se diminuir para que a sua mãe fique por perto?
- Então a gente vai perguntar para essa pessoa: 0 a 10: quanto você sente que nunca viveu um relacionamento verdadeiro ou duradouro?
- No trabalho terapêutico, o dinheiro deixa de ser só matéria e passa a ser um espelho que mostra onde a energia do assistido precisa ser liberada, curada ou fortalecida.
- E tome isso para você como um uma jornada interior mesmo, um lugar de mais do que de chegar em algum lugar, mas um retorno pr pra casa, pra sua essência, para esse lugar incrível que é você que é o seu assistido, que é a pessoa que tá em dor, que é a pessoa que tá enfermizando, mas a pessoa precisa querer, né?
- Então depois eu assisti a aula com essas pinceladas que a gente colocou aqui, porque às vezes tá atendendo cliente, depois a gente vai ver como faz atendimento, tá atendendo o cliente, nossa, o que que era isso mesmo?
- Pr as próximas, porque a gente vai aprender a usar mesa, fazer as perguntas e identificar também coisas no inconsciente e aí vocês vão entender bastante coisa, tá bom, gente?


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- Então, mandalador é um campo invisível que ancora medos, memórias e crenças, um círculo de repetições internas que paralisa, sabota e pesa a vida.
- Eh, cada uma delas revela não só um padrão de comportamento, mas também o tipo de dor que está sendo carregada e o motivo pelo qual essa armadura foi construída, que é proteger-se da exclusão, garantir o amor e evitar o abandono.
- Não importa qual é o problema que ele trouxe, ele traz aquela dor e ele fala da dor dele e tudo que você fala nada resolve porque ele quer ficar, ele tem um ganho secundário, ele ganha com aquilo.
- Então ele usa daquela dor, ele explora aquilo, ou uma doença física, ou a pobreza, ou ai como eu sofro com o seu pai, você não sabe o que eu passo, o meu trabalho é muito difícil, você não sabe o que eu vivo.
- Então sempre de entender que existe uma dor, ninguém procura terapia se não tivesse dor.
- Então essa pessoa, ela normalmente está para baixo, está nada anda na vida dela, não anda mesmo, porque conforme ela explora dor, ela precisa ficar nesse lugar, esse lugar não tem energia, a energia fica parada, ela fica estagnada, realmente nada tá dando certo na vida dela, é bem possível, tá?
- E aí de repente você identifica que ele tem um padrão cobrador muito grande, porque tudo ele vai lá para trás, tudo ele vai lá para trás, tudo ele conta uma coisa lá atrás, porque o meu e sempre a culpa é o de alguém, nunca dele, entende?
- É um campo invisível que encara medos, memórias e crenças, um círculo de repetição interna que paralisa, sabota e pesa a vida.
- Ninguém tem que perceber porque cada um tá cuidando da sua vida e a pessoa chega em terapia com essa dor e a gente precisa ajudando a desconstruir isso, tá?
- Então a vida dele não anda, não destrava, porque ele tem esse processo de dependência, não consegue liberar, ele não consegue se autorizar fazer porque ele se vai sentir culpa ou ele não vai se sentir mais amado e aí é possível que as pessoas falam: "Nossa, enricou agora ficou metido".
- As pessoas que apanham e assumem para si, porque é tão enlouquecedor que assumem para si que é culpa delas. e que se elas não tivessem feito, não tivessem saído com aquela roupa, ela não teria apanhado, ele não precisaria bater.
- É naquela situação, naquela dor específica, naquele momento específico, ele tá carregado naquela personagem, porque ele está cheio de fractais, ele está cheio de criações, que é o que a gente vai trabalhar no desfazimento no campo energético.


## Citações e Formulações de Alta Densidade

- “Então a pergunta é de 0 a 10: o quanto você sente que precisa sofrer ou se diminuir para que a sua mãe fique por perto?”
- “Então sempre de entender que existe uma dor, ninguém procura terapia se não tivesse dor.”
- “Então essa pessoa, ela normalmente está para baixo, está nada anda na vida dela, não anda mesmo, porque conforme ela explora dor, ela precisa ficar nesse lugar, esse lugar não tem energia, a energia fica parada, ela fica estagnada, realmente nada tá dando certo na vida dela, é bem possível, tá?”
- “E aí de repente você identifica que ele tem um padrão cobrador muito grande, porque tudo ele vai lá para trás, tudo ele vai lá para trás, tudo ele conta uma coisa lá atrás, porque o meu e sempre a culpa é o de alguém, nunca dele, entende?”
- “Ou ele é o que precisa carbar, não deixa o filho ir, não deixa o relacionamento terminar, não deixa, porque ele fica conduzindo e manipulando tudo aquilo.”
- “Ninguém tem que perceber porque cada um tá cuidando da sua vida e a pessoa chega em terapia com essa dor e a gente precisa ajudando a desconstruir isso, tá?”
- “Aqui em alguns momentos tem algumas pessoas, né, aqui na dor, tá? quando quando tá na mandala da dor e quando a pessoa traz isso, que são as pessoas extremamente quando ela tá em dor manipuladoras, elas ela quer mexer as peças taboleira xadrez do jeito que ela quer, do jeito que ele quer.”
- “Então ó lá de 0 a 10, o quanto você sente que nunca tem tempo para si porque sempre está resolvendo o problema de alguém.”
- “No trabalho terapêutico, o dinheiro deixa de ser só matéria e passa a ser um espelho que mostra onde a energia do assistido precisa ser liberada, curada ou fortalecida.”
- “As pessoas que apanham e assumem para si, porque é tão enlouquecedor que assumem para si que é culpa delas. e que se elas não tivessem feito, não tivessem saído com aquela roupa, ela não teria apanhado, ele não precisaria bater.”
- “Quando você acredita que só poderá ter paz se todos ao seu redor estiverem curados, porque você é o lixo, você é o causador da dor de todo mundo.”
- “E tome isso para você como um uma jornada interior mesmo, um lugar de mais do que de chegar em algum lugar, mas um retorno pr pra casa, pra sua essência, para esse lugar incrível que é você que é o seu assistido, que é a pessoa que tá em dor, que é a pessoa que tá enfermizando, mas a pessoa…”

## Conexões com a Wiki

- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio da Liberdade Consciente]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Conceito do Divorcio Energetico]]
- [[Conceito do Parceiro da Missao]]

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## Referência

ANDRESA MOLINA. *Aula 03 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.


## FAQs para NotebookLM (Fase 2)

### Bloco 1: A Estrutura da Mandala da Dor e o Ego Defensivo
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
1. Como Andresa Molina descreve a "Mandala da Dor" e quais são as seis faixas ou divisões que a compõem graficamente?
2. Qual é a função biológica e social do ego na formação da identidade e de que forma o egoísmo atua como sua doença?
3. Como a personalidade do assistido se molda de maneira defensiva quando aliada à dor, ao medo e ao instinto de proteção?
4. Quais são as três necessidades humanas básicas no inconsciente que motivam a construção das armaduras de defesa (personalidades de dor)?

### Bloco 2: As Personalidades de Dor: Explorador, Cobrador e Limitador
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
5. O que caracteriza a personalidade do "Explorador da Dor" e como ele utiliza doenças físicas ou pobreza para obter ganhos secundários?
6. Por que Andresa Molina afirma que o Explorador é um sugador de energia que puxa a vibração do ambiente "para baixo"? Como o terapeuta deve agir?
7. Como a personalidade do "Cobrador da Dor" mantém as pessoas presas ao passado? De que maneira vibrar em dívida afeta a prosperidade material?
8. De que forma o "Limitador da Dor" utiliza o pretexto do cuidado como contenção para bloquear a evolução de seus familiares e amigos?

### Bloco 3: Personagens em Dor e o Mecanismo de Fuga
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
9. Qual é a diferença na atuação somática e psíquica entre a essência e o personagem quando cristalizado como armadura de sobrevivência?
10. O que caracteriza o "Príncipe ou Donzela" na Mandala da Dor e qual é o erro ilusório em acreditar que "aquele que feriu será quem irá curar"?
11. De que maneira o "Guerreiro ou Guerreira" adoece ao lutar em confrontos cegos sem saber qual é a causa ou a batalha real a ser travada?
12. O que caracteriza a "Rainha Má ou Rei Governador Corrupto" e qual é a diferença entre manipular pelo bem do reino do lar ou pelo egoísmo?

### Bloco 4: O Campo Emocional e a Dinâmica do Relacionamento
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
13. O que caracteriza o "Dependente Emocional" e por que ele se sabota para não deixar amigos ou familiares para trás em sua ascensão?
14. Como o perfil do "Preocupado Emocional" sabota o seu próprio progresso usando demandas e problemas de terceiros para não encarar sua própria dor?
15. Como a autora classifica os três perfis de travamento nos relacionamentos amorosos (Perdido, Inconstante, Solitário) e de que forma eles refletem a biologia das polaridades?

### Bloco 5: Lixo Emocional e Identidade: Eu Sou vs. Eu Me Sinto Lixo
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
16. De que forma a crença de identidade profunda "Eu Sou um Lixo" somatiza-se fisicamente no corpo do assistido, levando-o a se decompor e gerar doenças graves?
17. Qual é a diferença somática e financeira entre a crença interna "Eu Sou um Lixo" e a reação externa "Eu Me Sinto um Lixo"?
18. Como Andresa Molina descreve o perfil do "Salvador Lixeiro" e por que ele confunde a própria exaustão corporal severa com amor?
19. Por que o tratamento terapêutico eficiente exige desarmar as lealdades do lixeiro, deixando-o temporariamente "sem nenhum problema" alheio para que ele encare sua essência?
20. Como o terapeuta Humanosense pode utilizar o pêndulo e as perguntas de 0 a 10 para identificar as contradições entre a narrativa do assistido e a verdade de seu campo inconsciente?

---

## Aula 04 - Codigo Humanosense

# Aula 04 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `04   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 16.214 palavras; 575 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- A autorização liberta porque rompe o aprisionamento que te mantinha pequena e abre caminho para que a alma expanda e caminhe inteira.
- Percebe que eu voltei pro padrão, então eu não vou conseguir, porque tem uma parte minha que não quer conseguir para ajudar os outros, quer conseguir para eu ser livre, para eu me autorizar.
- Todas as perguntas que a gente fez, se ela não se autorizar parar de ser uma lixeira, se ela não se autorizar parar de ser explorada pelo explorador, ela precisa se autorizar tudo.
- Para isso, você precisa conseguir identificar todos aqueles processos que a gente trouxe na mandala do amor e na mandala da dor e ter habilidade, disponibilidade e autorização para resolver todos eles.
- E aí é que a gente vai pro restante da mandala, que é então, só pra gente fechar que a liberdade consciente acontece quando você reconhece o que carrega com habilidade, se permite ir com a autorização e faz o que precisa ser feito com a disponibilidade.
- A parte que me chamou atenção foi agora se depois você foi sem as suas cautelas quente entende então o medo não é para parar é para que a gente vá assim com mais cuidado, com mais atenção, com mais presença, mas isso não significa não ir e não fazer o que precisa ser feito.
- Então, todo esse conteúdo da primeira parte, gente, ele tem a ver com dar consciência pro meu cliente, dar consciência pro meu assistido, levar ele para um nível racional, onde ele decida fazer a mudança.
- Então você consegue identificar a frequência da pessoa dentro desse padrão, dentro da dor que ela te traz.
- Então, toda parte desta primeira parte tem a ver com entender o campo energético, entender tudo isso, mas trazer racionalidade pro meu cliente, base racional para ele, para ele entender, para a partir do momento que ele começa a entender o porque aquilo que ele quer não funciona e o que ele precisa fazer para funcionar, ele começa a pôr os pés no chão, ele…
- Porque assim, o que que vai fazer a pessoa conseguir fazer isso? tratar os enroscos da mandala da dor e da cura, da mandala da dor e do amor.
- Se ela não estabelecer amor, equilíbrio no amor, ela nunca vai se autorizar, porque ela tá sempre culpando algo ou alguém.
- Então é também como se a gente só tivesse abrindo fichaz aqui você fazer uma limpeza depois não é você vai dar consciência para ele sobre a questão que ele trouxe a gente sempre precisa se apegar porque ele traz uma frequência e a gente vai acessar essa frequência.

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-72
- Todas as perguntas que a gente fez, se ela não se autorizar parar de ser uma lixeira, se ela não se autorizar parar de ser explorada pelo explorador, ela precisa se autorizar tudo.
- Para isso, você precisa conseguir identificar todos aqueles processos que a gente trouxe na mandala do amor e na mandala da dor e ter habilidade, disponibilidade e autorização para resolver todos eles.
- E aí é que a gente vai pro restante da mandala, que é então, só pra gente fechar que a liberdade consciente acontece quando você reconhece o que carrega com habilidade, se permite ir com a autorização e faz o que precisa ser feito com a disponibilidade.

### Bloco 2 - frases 73-144
- Sempre foi com mais habilidade o banho do bebê, lá no comecinho com medo dele escorregar, as crianças vai cair na banheira, você também não v fazer depois de repente você pega, vira assim, vira assim, passa baixo, passa em cima, porque você ganhou habilidade.
- A parte que me chamou atenção foi agora se depois você foi sem as suas cautelas quente entende então o medo não é para parar é para que a gente vá assim com mais cuidado, com mais atenção, com mais presença, mas isso não significa não ir e não fazer o que precisa ser feito.
- A prosperidade flui como consequência natural, porque você está no espaço certo, fazendo o que você nasceu para fazer, com a energia viva que transforma, não só a sua história, mas também a de quem você toca.

### Bloco 3 - frases 145-216
- Então não é que é só um arquétipo, é um campo de energia.
- Então, todo esse conteúdo da primeira parte, gente, ele tem a ver com dar consciência pro meu cliente, dar consciência pro meu assistido, levar ele para um nível racional, onde ele decida fazer a mudança.
- Já falei, vou repetir, presta bastante atenção que essa parte teve bastante gente com dúvida, então acho que é válido eu retomar isso.

### Bloco 4 - frases 217-288
- Então você aqui vai fazer as perguntas aqui, você vai perguntar pra pessoa e aí você vai pegar a sua folha, a sua ficha, tá?
- Energia mandada do amor, primeiras perguntas da energia cliente veio e aí tá e aí ela foi falando com você, um monte de coisas, trouxe ali um conteúdo, ai t problema com meu marido, a gente tá se separando, a gente tá com problema, não sabemos ficamos juntos, enfim.
- E aí o inconsciente dela vai responder, o campo inconsciente dela, energético, espiritual.

### Bloco 5 - frases 289-360
- Então dependendo do que acontece aqui, consciente, inconsciente, ou está distuando demais, eu vou falar para ela, olha, você precisa falar tudo para ela?
- Então você consegue identificar a frequência da pessoa dentro desse padrão, dentro da dor que ela te traz.
- Então, toda parte desta primeira parte tem a ver com entender o campo energético, entender tudo isso, mas trazer racionalidade pro meu cliente, base racional para ele, para ele entender, para a partir do momento que ele começa a entender o porque aquilo que ele quer não funciona e o que ele precisa fazer para funcionar, ele começa a pôr os pés no chão, ele começa a sair da ilusão, ele começa a entender porque não…

### Bloco 6 - frases 361-432
- Esse é o trabalho do terapeuta, principalmente o terapeuta que trabalha com propósito, com energia, não tá nem aí pro cliente, né? uma pessoa que quer ajudar o outro a caminhar com mais alegria, com mais felicidade e muitas vezes sofrimento ele fica, porque tem coisas na nossa cabeça que a gente acredita que esse seria o ideal.
- Porque assim, o que que vai fazer a pessoa conseguir fazer isso? tratar os enroscos da mandala da dor e da cura, da mandala da dor e do amor.
- Se ela não estabelecer amor, equilíbrio no amor, ela nunca vai se autorizar, porque ela tá sempre culpando algo ou alguém.

### Bloco 7 - frases 433-504
- Então vai ter muitas nuances aí, vão ser muitas, tem muita informação para vocês terem muita base para ir ajudando o cliente de vocês caso a caso, entendeu?
- Eu tô com na primeira pergunta masculina que fala assim: "O quanto você consegue executar suas ideias até o fim sem abandonar no meio do caminho?" Para mim ficou confuso porque a questão do não abandonar para mim parece energia feminina que é a questão da sustentação.
- Então eu ter essa ideia e começar a executar essa ideia é uma energia masculina, porque eu não estou abandonando a minha ideia, mas o fato de eu ir lá fazer, por exemplo, ah, tem contar essa pessoa, tem que pegar o fornecedor, daí isso da energia feminina, porque eu tô sustentando isso.

### Bloco 8 - frases 505-575
- Então a minha dúvida é assim, quando você lá naquelas fichas, eu entendo comência, acho que é uma dúvida mais geral assim sobre qual objetivo final do manência porque entala ali eu teria que dar a consciência pra pessoa sobre todos aqueles pontos ou isso opcional assim tá aberto para receber vou falar.
- Então é também como se a gente só tivesse abrindo fichaz aqui você fazer uma limpeza depois não é você vai dar consciência para ele sobre a questão que ele trouxe a gente sempre precisa se apegar porque ele traz uma frequência e a gente vai acessar essa frequência.
- Então a gente quando tem consciência a gente, a pessoa precisa fazer a mudança.

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Todas as perguntas que a gente fez, se ela não se autorizar parar de ser uma lixeira, se ela não se autorizar parar de ser explorada pelo explorador, ela precisa se autorizar tudo.
- Para isso, você precisa conseguir identificar todos aqueles processos que a gente trouxe na mandala do amor e na mandala da dor e ter habilidade, disponibilidade e autorização para resolver todos eles.
- E aí é que a gente vai pro restante da mandala, que é então, só pra gente fechar que a liberdade consciente acontece quando você reconhece o que carrega com habilidade, se permite ir com a autorização e faz o que precisa ser feito com a disponibilidade.
- Sempre foi com mais habilidade o banho do bebê, lá no comecinho com medo dele escorregar, as crianças vai cair na banheira, você também não v fazer depois de repente você pega, vira assim, vira assim, passa baixo, passa em cima, porque você ganhou habilidade.
- A parte que me chamou atenção foi agora se depois você foi sem as suas cautelas quente entende então o medo não é para parar é para que a gente vá assim com mais cuidado, com mais atenção, com mais presença, mas isso não significa não ir e não fazer o que precisa ser feito.
- Já falei, vou repetir, presta bastante atenção que essa parte teve bastante gente com dúvida, então acho que é válido eu retomar isso.
- Então dependendo do que acontece aqui, consciente, inconsciente, ou está distuando demais, eu vou falar para ela, olha, você precisa falar tudo para ela?
- Então, toda parte desta primeira parte tem a ver com entender o campo energético, entender tudo isso, mas trazer racionalidade pro meu cliente, base racional para ele, para ele entender, para a partir do momento que ele começa a entender o porque aquilo que ele quer não funciona e o que ele precisa fazer para funcionar, ele começa a pôr os pés no chão, ele…
- Se ela não estabelecer amor, equilíbrio no amor, ela nunca vai se autorizar, porque ela tá sempre culpando algo ou alguém.
- Então é também como se a gente só tivesse abrindo fichaz aqui você fazer uma limpeza depois não é você vai dar consciência para ele sobre a questão que ele trouxe a gente sempre precisa se apegar porque ele traz uma frequência e a gente vai acessar essa frequência.

## Conceitos-Chave Extraídos

- Para isso, você precisa conseguir identificar todos aqueles processos que a gente trouxe na mandala do amor e na mandala da dor e ter habilidade, disponibilidade e autorização para resolver todos eles.
- E aí é que a gente vai pro restante da mandala, que é então, só pra gente fechar que a liberdade consciente acontece quando você reconhece o que carrega com habilidade, se permite ir com a autorização e faz o que precisa ser feito com a disponibilidade.
- A parte que me chamou atenção foi agora se depois você foi sem as suas cautelas quente entende então o medo não é para parar é para que a gente vá assim com mais cuidado, com mais atenção, com mais presença, mas isso não significa não ir e não fazer o que precisa ser feito.
- Então quando a gente fala de lugar, função e potência, agora para eu explicar lugar, função e potência, o que que acontece?
- É o mínimo que se você fazer um mau trabalho, você não vai ser receber, você vai ser dispensado, você vai nunca mais vão chamar você para trabalhar, você é simples.
- Então não é que é só um arquétipo, é um campo de energia.
- Então, todo esse conteúdo da primeira parte, gente, ele tem a ver com dar consciência pro meu cliente, dar consciência pro meu assistido, levar ele para um nível racional, onde ele decida fazer a mudança.
- Então a gente precisa ter consciência, clareza, lucidez e parar de ser iludida, certo?
- E aí o inconsciente dela vai responder, o campo inconsciente dela, energético, espiritual.
- Se ela tá, o inconsciente tá três e ela tá cinco, eu preciso aproximar, dar consciência pro inconsciente, trazer luz, colocar luz para o que está no inconsciente, que tá no inconsciente é que tá na nossa sombra, é o que tá reprimido, é o que eu não posso sentir, eu não posso querer isso.
- Então, toda parte desta primeira parte tem a ver com entender o campo energético, entender tudo isso, mas trazer racionalidade pro meu cliente, base racional para ele, para ele entender, para a partir do momento que ele começa a entender o porque aquilo que ele quer não funciona e o que ele precisa fazer para funcionar, ele começa a pôr os pés no chão, ele…
- Ah, então falando dos eixos da liberdade, como você explicou, então como como que a gente faz, né, nesse sentido do eixo da liberdade para para chegar até essa habilidade e autorização e disponibilidade, é a técnica que vai trazer pra gente essa ferramenta para limpar o campo, pra gente conseguir acessar esses eixos com mais, digamos assim, com mais…
- Porque assim, o que que vai fazer a pessoa conseguir fazer isso? tratar os enroscos da mandala da dor e da cura, da mandala da dor e do amor.
- Então a minha dúvida é assim, quando você lá naquelas fichas, eu entendo comência, acho que é uma dúvida mais geral assim sobre qual objetivo final do manência porque entala ali eu teria que dar a consciência pra pessoa sobre todos aqueles pontos ou isso opcional assim tá aberto para receber vou falar.
- Então é também como se a gente só tivesse abrindo fichaz aqui você fazer uma limpeza depois não é você vai dar consciência para ele sobre a questão que ele trouxe a gente sempre precisa se apegar porque ele traz uma frequência e a gente vai acessar essa frequência.
- Então a gente quando tem consciência a gente, a pessoa precisa fazer a mudança.


## Técnicas, Procedimentos e Orientações Práticas

- Eu vou ter que comprar falta pra minha sobrinha, meu irmão para trabalhar, aí eu não me autorizo, aí eu não ganho, porque é para eu não ter, para não ter que dar, entendeu? percebe que vira um bolo e eu preciso pegar o meu meu assistido no pulo.
- Todas as perguntas que a gente fez, se ela não se autorizar parar de ser uma lixeira, se ela não se autorizar parar de ser explorada pelo explorador, ela precisa se autorizar tudo.
- Para isso, você precisa conseguir identificar todos aqueles processos que a gente trouxe na mandala do amor e na mandala da dor e ter habilidade, disponibilidade e autorização para resolver todos eles.
- Então, todo esse conteúdo da primeira parte, gente, ele tem a ver com dar consciência pro meu cliente, dar consciência pro meu assistido, levar ele para um nível racional, onde ele decida fazer a mudança.
- Então você aqui vai fazer as perguntas aqui, você vai perguntar pra pessoa e aí você vai pegar a sua folha, a sua ficha, tá?
- Energia mandada do amor, primeiras perguntas da energia cliente veio e aí tá e aí ela foi falando com você, um monte de coisas, trouxe ali um conteúdo, ai t problema com meu marido, a gente tá se separando, a gente tá com problema, não sabemos ficamos juntos, enfim.
- Então você consegue identificar a frequência da pessoa dentro desse padrão, dentro da dor que ela te traz.
- Então, toda parte desta primeira parte tem a ver com entender o campo energético, entender tudo isso, mas trazer racionalidade pro meu cliente, base racional para ele, para ele entender, para a partir do momento que ele começa a entender o porque aquilo que ele quer não funciona e o que ele precisa fazer para funcionar, ele começa a pôr os pés no chão, ele…
- Esse é o trabalho do terapeuta, principalmente o terapeuta que trabalha com propósito, com energia, não tá nem aí pro cliente, né? uma pessoa que quer ajudar o outro a caminhar com mais alegria, com mais felicidade e muitas vezes sofrimento ele fica, porque tem coisas na nossa cabeça que a gente acredita que esse seria o ideal.
- Aqui na ficha eu já li aqui da parte dos comandos, né, que você falou pra gente colocar o dedo aqui no meio e falar o nome e a data de nascimento do nosso assistido em voz alta, né?
- Então vai ter muitas nuances aí, vão ser muitas, tem muita informação para vocês terem muita base para ir ajudando o cliente de vocês caso a caso, entendeu?
- Eu tô com na primeira pergunta masculina que fala assim: "O quanto você consegue executar suas ideias até o fim sem abandonar no meio do caminho?" Para mim ficou confuso porque a questão do não abandonar para mim parece energia feminina que é a questão da sustentação.
- Então a minha dúvida é assim, quando você lá naquelas fichas, eu entendo comência, acho que é uma dúvida mais geral assim sobre qual objetivo final do manência porque entala ali eu teria que dar a consciência pra pessoa sobre todos aqueles pontos ou isso opcional assim tá aberto para receber vou falar.
- Então é também como se a gente só tivesse abrindo fichaz aqui você fazer uma limpeza depois não é você vai dar consciência para ele sobre a questão que ele trouxe a gente sempre precisa se apegar porque ele traz uma frequência e a gente vai acessar essa frequência.


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- A autorização liberta porque rompe o aprisionamento que te mantinha pequena e abre caminho para que a alma expanda e caminhe inteira.
- Percebe que eu voltei pro padrão, então eu não vou conseguir, porque tem uma parte minha que não quer conseguir para ajudar os outros, quer conseguir para eu ser livre, para eu me autorizar.
- Eu vou ter que comprar falta pra minha sobrinha, meu irmão para trabalhar, aí eu não me autorizo, aí eu não ganho, porque é para eu não ter, para não ter que dar, entendeu? percebe que vira um bolo e eu preciso pegar o meu meu assistido no pulo.
- Todas as perguntas que a gente fez, se ela não se autorizar parar de ser uma lixeira, se ela não se autorizar parar de ser explorada pelo explorador, ela precisa se autorizar tudo.
- Para isso, você precisa conseguir identificar todos aqueles processos que a gente trouxe na mandala do amor e na mandala da dor e ter habilidade, disponibilidade e autorização para resolver todos eles.
- E aí é que a gente vai pro restante da mandala, que é então, só pra gente fechar que a liberdade consciente acontece quando você reconhece o que carrega com habilidade, se permite ir com a autorização e faz o que precisa ser feito com a disponibilidade.
- Sempre foi com mais habilidade o banho do bebê, lá no comecinho com medo dele escorregar, as crianças vai cair na banheira, você também não v fazer depois de repente você pega, vira assim, vira assim, passa baixo, passa em cima, porque você ganhou habilidade.
- A parte que me chamou atenção foi agora se depois você foi sem as suas cautelas quente entende então o medo não é para parar é para que a gente vá assim com mais cuidado, com mais atenção, com mais presença, mas isso não significa não ir e não fazer o que precisa ser feito.
- Já falei, vou repetir, presta bastante atenção que essa parte teve bastante gente com dúvida, então acho que é válido eu retomar isso.
- Então você consegue identificar a frequência da pessoa dentro desse padrão, dentro da dor que ela te traz.
- Porque assim, o que que vai fazer a pessoa conseguir fazer isso? tratar os enroscos da mandala da dor e da cura, da mandala da dor e do amor.
- Se ela não estabelecer amor, equilíbrio no amor, ela nunca vai se autorizar, porque ela tá sempre culpando algo ou alguém.


## Citações e Formulações de Alta Densidade

- “Todas as perguntas que a gente fez, se ela não se autorizar parar de ser uma lixeira, se ela não se autorizar parar de ser explorada pelo explorador, ela precisa se autorizar tudo.”
- “Se você tiver habilidade, disponibilidade e autorização, você consegue tudo, porque você precisa sustentar a frequência.”
- “Para isso, você precisa conseguir identificar todos aqueles processos que a gente trouxe na mandala do amor e na mandala da dor e ter habilidade, disponibilidade e autorização para resolver todos eles.”
- “E aí é que a gente vai pro restante da mandala, que é então, só pra gente fechar que a liberdade consciente acontece quando você reconhece o que carrega com habilidade, se permite ir com a autorização e faz o que precisa ser feito com a disponibilidade.”
- “Sempre foi com mais habilidade o banho do bebê, lá no comecinho com medo dele escorregar, as crianças vai cair na banheira, você também não v fazer depois de repente você pega, vira assim, vira assim, passa baixo, passa em cima, porque você ganhou habilidade.”
- “A parte que me chamou atenção foi agora se depois você foi sem as suas cautelas quente entende então o medo não é para parar é para que a gente vá assim com mais cuidado, com mais atenção, com mais presença, mas isso não significa não ir e não fazer o que precisa ser feito.”
- “Então dependendo do que acontece aqui, consciente, inconsciente, ou está distuando demais, eu vou falar para ela, olha, você precisa falar tudo para ela?”
- “Então, toda parte desta primeira parte tem a ver com entender o campo energético, entender tudo isso, mas trazer racionalidade pro meu cliente, base racional para ele, para ele entender, para a partir do momento que ele começa a entender o porque aquilo que ele quer não funciona e o que ele…”
- “Se ela não estabelecer amor, equilíbrio no amor, ela nunca vai se autorizar, porque ela tá sempre culpando algo ou alguém.”
- “Eu tô com na primeira pergunta masculina que fala assim: "O quanto você consegue executar suas ideias até o fim sem abandonar no meio do caminho?" Para mim ficou confuso porque a questão do não abandonar para mim parece energia feminina que é a questão da sustentação.”
- “Então a minha dúvida é assim, quando você lá naquelas fichas, eu entendo comência, acho que é uma dúvida mais geral assim sobre qual objetivo final do manência porque entala ali eu teria que dar a consciência pra pessoa sobre todos aqueles pontos ou isso opcional assim tá aberto para receber vou…”
- “Então é também como se a gente só tivesse abrindo fichaz aqui você fazer uma limpeza depois não é você vai dar consciência para ele sobre a questão que ele trouxe a gente sempre precisa se apegar porque ele traz uma frequência e a gente vai acessar essa frequência.”

## Conexões com a Wiki

- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio da Liberdade Consciente]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Conceito do Divorcio Energetico]]
- [[Conceito do Parceiro da Missao]]

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## Referência

ANDRESA MOLINA. *Aula 04 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.


## FAQs para NotebookLM (Fase 2)

### Bloco 1: O Eixo da Liberdade e a Manifestação do Dom
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
1. Como Andresa Molina define o "Eixo da Liberdade" e de que maneira a Habilidade, a Autorização e a Disponibilidade interagem para cessar a angústia essencial?
2. Como a "Habilidade" é descrita na aula, e de que forma o treino diário disciplinado substitui o vitimismo e as justificativas de falta de oportunidade?
3. O que significa somaticamente a "Autorização" no Eixo da Liberdade, e de que modo o pânico de desaprovação parental (medo de perder o afeto) aprisiona o assistido em moldes artificiais?
4. Como Andresa conceitua a "Disponibilidade", contrapondo a atitude de fazer "para ver se dá certo" com a de fazer "até dar certo"?

### Bloco 2: A Desconstrução Parental e os Ganhos da Estagnação
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
5. Por que a autora afirma que para conquistar a autorização existencial é obrigatório "desconstruir pai e mãe"?
6. A nível prático, qual é a pergunta investigativa chave que o terapeuta deve propor ao assistido quando a sua prosperidade ou projeto está travado ("a coisa não vai")?
7. Como a mente do assistido sabota as suas conquistas materiais sob o pretexto de "não ganhar para não ter que dar", reativando a lealdade sombria do "lixeiro emocional"?
8. Como Andresa orienta o terapeuta a posicionar-se quando o cliente, após ser confrontado com a verdade de seu bloqueio, decide conscientemente não mudar?

### Bloco 3: A Anatomia do Medo e a Postura de Cautela
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
9. De que modo Andresa Molina define o "Medo" (como sinal de desconhecimento/incompetência provisória) e de que maneira a cautela atenta substitui a lentidão na tomada de ação?
10. Qual é a analogia prática do "aprender a dirigir" ou de "dar banho em um bebê" utilizada pela autora para ilustrar a aquisição progressiva de habilidade a partir do medo inicial?
11. Sob o Princípio da Liberdade Consciente, qual é a relação entre a responsabilidade soberana, a disciplina de autoria e o controle sobre os próprios medos na fase adulta?

### Bloco 4: O Eixo da Realização e a Dinâmica Sistêmica
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
12. O que caracteriza o "Eixo da Realização", e como Andresa conceitua a tríade "Lugar, Função e Potência"?
13. O que acontece com a força vital de um indivíduo quando ele está "fora do seu lugar", e de que modo a adaptação forçada apequena a alma?
14. Como Andresa Molina define a "Função", e por que a excelência técnica na entrega de serviços ("fazer um bom trabalho") é classificada como o mínimo obrigatório de troca?
15. O que é a "Potência" a nível energético, e de que forma a autora relaciona vitalidade ao ectoplasma e ao magnetismo aplicados no projeto?

### Bloco 5: Somatização Física e Condução Clínica na Mesa
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
16. Como a autora explica a nível biológico e somático o ganho de peso (obesidade) sob a ótica da sobrecarga familiar e do acúmulo de tarefas de múltiplas pessoas?
17. Como o terapeuta Humanosense realiza a "Técnica de Ancoragem do Assistido na Mesa" utilizando dados verbais e o selo do espaço sob autorização?
18. Como é executada a "Técnica de Diagnóstico de Alinhamento Consciente-Inconsciente" confrontando a régua da mesa (pêndulo) com os valores lógicos fornecidos pelo cliente?
19. Por que o terapeuta deve emparelhar e perguntar de forma dicotômica (uma pergunta de feminino e uma de masculino correspondentes) ao investigar as pétalas da Mandala do Amor?
20. O que significa somaticamente a orientação da autora de que a "Mandala da Cura" é orientativa, e como o terapeuta deve modular o desfazimento de fractais pela autorresponsabilidade?

---

## Aula 05 - Codigo Humanosense

# Aula 05 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/05   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `05   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 25.777 palavras; 876 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- Então, eh, o que você precisa fazer precisa ser feito, o que você traz na alma, porque você tá falando de expansão de consciência, certo?
- E aqui quando a gente coloca o consciente e o inconsciente, né, na folhinha de decuração, eh, já tava até conversando com um colega que tá aqui também e e aí aqui a gente vai tá perguntando, né, sobre todas as pétalas e fazendo as perguntas e tendo consciente, neconsciente, só que a gente vai tá sempre dando foco naquela questão que deu, no caso, né, um…
- Eu vou, então eu coloquei três, só que quando eu fui lá e na na energia deu nove, falei na verdade não é o que eu tenho parece uma questão que vai dando visualização para visualização.
- É mais essa visualização tanto pra gente poder ir decurando no decorrer no final e pro cliente ele não vai precisar explicar esse ponto, né? a gente vai pegar o o assunto geral do que tirar um denominador comum e falar: "Olha, por esse caminho, é depende, depende, depende do cliente, depende da necessidade dele, depende da gente estar super presente pro…
- Aí fui, eu mostrei para ela e fiz uma pergunta, um exemplo, ela pegou assim: "Ah, eu nem sei como responder essa pergunta, porque muita gente nem tem consciência das perguntas dela parar de pensar." É, mas é porque assim, ó, a gente precisa entender que a gente tá sobre um campo de energia.
- Código humanosense não é um código à toa, ele é um campo, tem uma egrégora, tem um campo de força, não tem essa simulação.
- Eh, a minha questão, né, eu acho que tem a ver também com com isso, porque tá nas perguntas, eh, que eu entendi isso, que a gente vai seguir sempre o mesmo número de perguntas e aí na mandala do amor a gente tem femino masculino.
- É, por exemplo, no caso, mas uma coisa é fato, é um feminino extremamente ferido, mas ele não fica sempre num único comportamento, ele vai ser não, porque ele joga, ele é um bom jogador, na verdade é uma é uma manipuladora, é uma rainha manipulando.
- Então essas dores profundas que eles têm, mas nesses corpos, essas mentes, essas almas que estão ali se cortando para caber nessa nossa sociedade, sabe?
- Uma outra pergunta que eu tenho, que é uma coisa que me angustia um pouco, eh, por exemplo, a gente, eu fiz o humanoterapeuta, né, e a gente viu que tudo tá no energético, tá no espiritual e quando ele se manifesta no corpo, ele já tava lá se manifestando, né?
- Mas depende, ele é super meu cliente de terapia, eu sou psicólogo, eu sou psicanalista, ele é super meu cliente e tá tranquilo a gente mexer nessa dor de novo, porque quando eu mexo numa dor, automaticamente todo o meu mecanismo de defesa vai subir, aí eu tenho uma semana para me calçar, entende?
- Então fique em paz que vocês vão conseguir absorver bastante coisa e entender aí por uma outra via também que é a via dos códigos, a via do campo energético e espiritual.

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-88
- Então, eh, o que você precisa fazer precisa ser feito, o que você traz na alma, porque você tá falando de expansão de consciência, certo?
- Então, esses você vai ter que lidar com eles e fazer nascer aquilo, parar de fugir daquilo que você precisa colocar no mundo, que você trouxe como missão na sua alma.
- Você não falou de uma pergunta, de uma questão onde o seu assistido está com problema, é isso e ele não tá conseguindo identificar isso.

### Bloco 2 - frases 89-176
- Então a gente tem essas frentes para ele, ganhando consciência e também se permitindo ser tratado, percebendo que é mais difícil do que ele imaginava, percebendo que muitas coisas não dão certo, porque ele no fundo quer querer aquilo, quanto ele quer sustentar, suportar tudo que vem com aquilo, né?
- Você perguntou uma coisa, responde um monte de outra, não sei se respondeu, tava perguntando, não faz sentido com que acontece no entendimento, mas então ficou claro que no eu vou sempre voltar para aquela questão que ele trouxe para conseguir esvaziar aquela questão e aí depois se de repente ele perceber que não faz mais sentido ou não, aí a gente pode dar um suporte para ele de uma outra forma.
- Então a gente como tem um potencial, um estudo, um aprofundamento maior, a gente consegue buscar coisas muito mais profundas e memórias muito enraizadas que ele nem tem consciência que isso fica no seu campo, é nas suas células, isso fica na Então se você acabou de estudar oaputa, o homoterapeuta você estudou epigenética, você entendeu que aquilo que você traz que ele não tem consciência de tudo isso.

### Bloco 3 - frases 177-264
- Então aí sempre ficou uma dúvida muito grande na minha cabeça de qual é que você tem você, não tem como, porque se eu rejeito o pai de um ou o meu mesmo ou o biológico, o biológico ou o adutivo, mas principalmente o biológico, eu rejeito metade de mim.
- A gente pode eh ferida, a gente pode ter essas duas energias eh feridas, mas assim intercaladas eh por exemplo, em situações diferentes, né?
- E no mesmo instante o meu feminino, que é melindroso, ofendido, magoado, eh, enfim, dolorido, ele quentra em dor na dor dele.

### Bloco 4 - frases 265-352
- Então a gente tá caminhando num campo energético, espiritual, então vamos ter pra gente ter um pouquinho de cuidado e aí conforme a coisa for acontecendo a gente vai entendendo melhor como vai sendo essas respostas, tá bom?
- Então se eu tiver a força, eu tenho força para fazer, eu tenho força para sustentar morar fora do país, mas aí a minha mãe que é uma exploradora não me autoriza aí e eu não consigo me autorizar.
- E aí tentar explicar de um jeito algum exemplo que fica mais fácil, porque desse voltar pro útero é desafio do eu tenho que nascer, eu tenho que sair da origem e ir pro destino e ir embora e deixar essa mãe seguir, entendendo que essa consciência ela não é a criadora do meu espírito.

### Bloco 5 - frases 353-440
- E aqui quando a gente coloca o consciente e o inconsciente, né, na folhinha de decuração, eh, já tava até conversando com um colega que tá aqui também e e aí aqui a gente vai tá perguntando, né, sobre todas as pétalas e fazendo as perguntas e tendo consciente, neconsciente, só que a gente vai tá sempre dando foco naquela questão que deu, no caso, né, um desequilíbrio ali da questão que ela trouxe pra gente, né,…
- Então eu sou aquela pessoa que nunca tem dinheiro, que não tem cliente, porque não cobra, porque tá salvador.
- O Salvador é o que não tem cliente, porque ele acredita que ele é o Salvador.

### Bloco 6 - frases 441-528
- Eu vou, então eu coloquei três, só que quando eu fui lá e na na energia deu nove, falei na verdade não é o que eu tenho parece uma questão que vai dando visualização para visualização.
- É mais essa visualização tanto pra gente poder ir decurando no decorrer no final e pro cliente ele não vai precisar explicar esse ponto, né? a gente vai pegar o o assunto geral do que tirar um denominador comum e falar: "Olha, por esse caminho, é depende, depende, depende do cliente, depende da necessidade dele, depende da gente estar super presente pro que ele precisa." Depende.
- Aí fui, eu mostrei para ela e fiz uma pergunta, um exemplo, ela pegou assim: "Ah, eu nem sei como responder essa pergunta, porque muita gente nem tem consciência das perguntas dela parar de pensar." É, mas é porque assim, ó, a gente precisa entender que a gente tá sobre um campo de energia.

### Bloco 7 - frases 529-616
- Então é foi mais nesse sentido porque parou e aí dá para trabalhar no manocência e buscar mais dentro do racional dela para ela ir em busca desse movimento racionalmente ela ir em busca ela porque aí a gente vai tá trabalhando nesse porque a ciclino é aquele que ia lá e traía ela tinha essa ela tinha esse ímp e acabava fazendo, mas ela tava eu não sei até trabalhar tá cortando muito je tô conseguindo escut mas é um…
- Aí faz todo aquele link com tudo que você apresentou e aí você começa a fazer porque que ela tá usando aquilo, a dor que ela traz.
- Sim, porque senão a gente precisa entender que no mesmo pai da mesma mãe nascem consciências completamente distintas, com potências e comportamentos completamente e às vezes com índoles e caráter completamente distinto.

### Bloco 8 - frases 617-704
- Então aí nesse caso de fazer pergunta, eu teria que perguntar, por exemplo, se tá mais a ver com o biológico, não para ajudar a consciência, tipo, ah, é mais a esse lado ou eu acho que eu perguntaria, nesse caso que é uma um eu perguntaria dos dois, perguntaria dos dois.
- Tem muita coisa que tá no nosso inconsciente, mas que não é verdade no sentido de não ter acontecido efetivamente, mas que a gente carrega como verdade, que é tipo o sentimento de abandono da mãe que nunca nos abandonou.
- Só que o sentimento é esse, porque o campo de energia se esva de tal maneira, porque algo muito mais potente, não, Deus foi o macho alfa da história, ele foi lá, não é Deus, entende?

### Bloco 9 - frases 705-792
- É, por exemplo, no caso, mas uma coisa é fato, é um feminino extremamente ferido, mas ele não fica sempre num único comportamento, ele vai ser não, porque ele joga, ele é um bom jogador, na verdade é uma é uma manipuladora, é uma rainha manipulando.
- Então essas dores profundas que eles têm, mas nesses corpos, essas mentes, essas almas que estão ali se cortando para caber nessa nossa sociedade, sabe?
- Uma outra pergunta que eu tenho, que é uma coisa que me angustia um pouco, eh, por exemplo, a gente, eu fiz o humanoterapeuta, né, e a gente viu que tudo tá no energético, tá no espiritual e quando ele se manifesta no corpo, ele já tava lá se manifestando, né?

### Bloco 10 - frases 793-876
- Ah, então é como no na mandala da dor eu tenho que identificar mais aonde eu tô e pot aonde isso está em dores.
- Mas depende, ele é super meu cliente de terapia, eu sou psicólogo, eu sou psicanalista, ele é super meu cliente e tá tranquilo a gente mexer nessa dor de novo, porque quando eu mexo numa dor, automaticamente todo o meu mecanismo de defesa vai subir, aí eu tenho uma semana para me calçar, entende?
- Então fique em paz que vocês vão conseguir absorver bastante coisa e entender aí por uma outra via também que é a via dos códigos, a via do campo energético e espiritual.

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Então, eh, o que você precisa fazer precisa ser feito, o que você traz na alma, porque você tá falando de expansão de consciência, certo?
- E aqui quando a gente coloca o consciente e o inconsciente, né, na folhinha de decuração, eh, já tava até conversando com um colega que tá aqui também e e aí aqui a gente vai tá perguntando, né, sobre todas as pétalas e fazendo as perguntas e tendo consciente, neconsciente, só que a gente vai tá sempre dando foco naquela questão que deu, no caso, né, um…
- Então eu sou aquela pessoa que nunca tem dinheiro, que não tem cliente, porque não cobra, porque tá salvador.
- Mas nessas perguntas, então assim, eh, na questão da pessoa nunca vai, sempre vai ter que dar de um a 10.
- Eu vou, então eu coloquei três, só que quando eu fui lá e na na energia deu nove, falei na verdade não é o que eu tenho parece uma questão que vai dando visualização para visualização.
- É mais essa visualização tanto pra gente poder ir decurando no decorrer no final e pro cliente ele não vai precisar explicar esse ponto, né? a gente vai pegar o o assunto geral do que tirar um denominador comum e falar: "Olha, por esse caminho, é depende, depende, depende do cliente, depende da necessidade dele, depende da gente estar super presente pro…
- Aí fui, eu mostrei para ela e fiz uma pergunta, um exemplo, ela pegou assim: "Ah, eu nem sei como responder essa pergunta, porque muita gente nem tem consciência das perguntas dela parar de pensar." É, mas é porque assim, ó, a gente precisa entender que a gente tá sobre um campo de energia.
- Eh, a minha questão, né, eu acho que tem a ver também com com isso, porque tá nas perguntas, eh, que eu entendi isso, que a gente vai seguir sempre o mesmo número de perguntas e aí na mandala do amor a gente tem femino masculino.
- Aqui não tem como porque base a base é consciência, então teria que fazer a aplicação do manoterapeuta, entendeu?
- É, por exemplo, no caso, mas uma coisa é fato, é um feminino extremamente ferido, mas ele não fica sempre num único comportamento, ele vai ser não, porque ele joga, ele é um bom jogador, na verdade é uma é uma manipuladora, é uma rainha manipulando.

## Conceitos-Chave Extraídos

- Então, eh, o que você precisa fazer precisa ser feito, o que você traz na alma, porque você tá falando de expansão de consciência, certo?
- Então sim, ele é um contexto, é um trabalho para fazer materialização, só que ninguém materializa, ninguém planta nada se não tiver consciência e não limpar aquilo, porque por isso que as coisas não acontecem, não acontecem porque a pessoa ela só quer, mas no fundo ela não quer, porque o que ela quer vem com um monte de coisa, então por isso que não dá…
- Então a gente tem essas frentes para ele, ganhando consciência e também se permitindo ser tratado, percebendo que é mais difícil do que ele imaginava, percebendo que muitas coisas não dão certo, porque ele no fundo quer querer aquilo, quanto ele quer sustentar, suportar tudo que vem com aquilo, né?
- Então a gente como tem um potencial, um estudo, um aprofundamento maior, a gente consegue buscar coisas muito mais profundas e memórias muito enraizadas que ele nem tem consciência que isso fica no seu campo, é nas suas células, isso fica na Então se você acabou de estudar oaputa, o homoterapeuta você estudou epigenética, você entendeu que aquilo que você…
- Então a gente tá caminhando num campo energético, espiritual, então vamos ter pra gente ter um pouquinho de cuidado e aí conforme a coisa for acontecendo a gente vai entendendo melhor como vai sendo essas respostas, tá bom?
- E aí tentar explicar de um jeito algum exemplo que fica mais fácil, porque desse voltar pro útero é desafio do eu tenho que nascer, eu tenho que sair da origem e ir pro destino e ir embora e deixar essa mãe seguir, entendendo que essa consciência ela não é a criadora do meu espírito.
- Ela tem cois, então precisamos trabalhar isso, só que a força você não tá conseguindo e aí vamos trabalhando masculino e vamos mudando consciência para ela.
- E aí lá a gente vai ter, mas vamos e aí a gente muda de jogo porque quando você fechou o olho, muda é outra coisa quando a gente vai entrar no campo, vão ter comandos energéticos, espirituais, vai ter gregra domand cuidando, vai acontecer mon coisa tá essa é uma outra outra isso.
- O Salvador é o que não tem cliente, porque ele acredita que ele é o Salvador.
- Eu vou, então eu coloquei três, só que quando eu fui lá e na na energia deu nove, falei na verdade não é o que eu tenho parece uma questão que vai dando visualização para visualização.
- Aí fui, eu mostrei para ela e fiz uma pergunta, um exemplo, ela pegou assim: "Ah, eu nem sei como responder essa pergunta, porque muita gente nem tem consciência das perguntas dela parar de pensar." É, mas é porque assim, ó, a gente precisa entender que a gente tá sobre um campo de energia.
- Código humanosense não é um código à toa, ele é um campo, tem uma egrégora, tem um campo de força, não tem essa simulação.
- Eh, a minha questão, né, eu acho que tem a ver também com com isso, porque tá nas perguntas, eh, que eu entendi isso, que a gente vai seguir sempre o mesmo número de perguntas e aí na mandala do amor a gente tem femino masculino.
- Aqui não tem como porque base a base é consciência, então teria que fazer a aplicação do manoterapeuta, entendeu?
- Ah, então é como no na mandala da dor eu tenho que identificar mais aonde eu tô e pot aonde isso está em dores.
- Então fique em paz que vocês vão conseguir absorver bastante coisa e entender aí por uma outra via também que é a via dos códigos, a via do campo energético e espiritual.


## Técnicas, Procedimentos e Orientações Práticas

- Você não falou de uma pergunta, de uma questão onde o seu assistido está com problema, é isso e ele não tá conseguindo identificar isso.
- A minha pergunta é o seguinte, a gente sempre vai se atendendo processo naquela questão que o assistido trouxer ou pode desobrar em outras questões que nem por exemplo acontece no mano terapeuta, pessoas à vezes vai tratar relacionamento, mas ao longo do processo é a vida financeira que deslancha ou vai tratar uma questão familiar relacionamento que…
- E aqui quando a gente coloca o consciente e o inconsciente, né, na folhinha de decuração, eh, já tava até conversando com um colega que tá aqui também e e aí aqui a gente vai tá perguntando, né, sobre todas as pétalas e fazendo as perguntas e tendo consciente, neconsciente, só que a gente vai tá sempre dando foco naquela questão que deu, no caso, né, um…
- Então eu sou aquela pessoa que nunca tem dinheiro, que não tem cliente, porque não cobra, porque tá salvador.
- O Salvador é o que não tem cliente, porque ele acredita que ele é o Salvador.
- Mas nessas perguntas, então assim, eh, na questão da pessoa nunca vai, sempre vai ter que dar de um a 10.
- Eu vou, então eu coloquei três, só que quando eu fui lá e na na energia deu nove, falei na verdade não é o que eu tenho parece uma questão que vai dando visualização para visualização.
- É mais essa visualização tanto pra gente poder ir decurando no decorrer no final e pro cliente ele não vai precisar explicar esse ponto, né? a gente vai pegar o o assunto geral do que tirar um denominador comum e falar: "Olha, por esse caminho, é depende, depende, depende do cliente, depende da necessidade dele, depende da gente estar super presente pro…
- Aí fui, eu mostrei para ela e fiz uma pergunta, um exemplo, ela pegou assim: "Ah, eu nem sei como responder essa pergunta, porque muita gente nem tem consciência das perguntas dela parar de pensar." É, mas é porque assim, ó, a gente precisa entender que a gente tá sobre um campo de energia.
- Eh, a minha questão, né, eu acho que tem a ver também com com isso, porque tá nas perguntas, eh, que eu entendi isso, que a gente vai seguir sempre o mesmo número de perguntas e aí na mandala do amor a gente tem femino masculino.
- Aqui não tem como porque base a base é consciência, então teria que fazer a aplicação do manoterapeuta, entendeu?
- Uma outra pergunta que eu tenho, que é uma coisa que me angustia um pouco, eh, por exemplo, a gente, eu fiz o humanoterapeuta, né, e a gente viu que tudo tá no energético, tá no espiritual e quando ele se manifesta no corpo, ele já tava lá se manifestando, né?
- Ah, então é como no na mandala da dor eu tenho que identificar mais aonde eu tô e pot aonde isso está em dores.
- Mas depende, ele é super meu cliente de terapia, eu sou psicólogo, eu sou psicanalista, ele é super meu cliente e tá tranquilo a gente mexer nessa dor de novo, porque quando eu mexo numa dor, automaticamente todo o meu mecanismo de defesa vai subir, aí eu tenho uma semana para me calçar, entende?


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- Então se eu tiver a força, eu tenho força para fazer, eu tenho força para sustentar morar fora do país, mas aí a minha mãe que é uma exploradora não me autoriza aí e eu não consigo me autorizar.
- E aí tentar explicar de um jeito algum exemplo que fica mais fácil, porque desse voltar pro útero é desafio do eu tenho que nascer, eu tenho que sair da origem e ir pro destino e ir embora e deixar essa mãe seguir, entendendo que essa consciência ela não é a criadora do meu espírito.
- Então eu sou aquela pessoa que nunca tem dinheiro, que não tem cliente, porque não cobra, porque tá salvador.
- O Salvador é o que não tem cliente, porque ele acredita que ele é o Salvador.
- Então a gente precisa amadurecer isso, mas sim, isso é algo que é possível de acontecer e é vaidade, porque o salvador é vaidoso, de todo mundo.
- Então para eu identificar, por exemplo, ou para qualquer outra terapeuta identificar se ela está nesse papel de salvadora e não na missão, ela teria que estar nessas condições.
- É mais essa visualização tanto pra gente poder ir decurando no decorrer no final e pro cliente ele não vai precisar explicar esse ponto, né? a gente vai pegar o o assunto geral do que tirar um denominador comum e falar: "Olha, por esse caminho, é depende, depende, depende do cliente, depende da necessidade dele, depende da gente estar super presente pro…
- Então, uma coisa é a distância e outra coisa é com a pessoa que aqui não tem como a gente fazer a distância eh com a pessoa dormindo, por exemplo, como a gente consegue com a metodologia com a pessoa no hospital ou com a pessoa quetinha lá que me autorizou e eu ponho aqui, ok, mas ela tá no hospital.
- É, por exemplo, no caso, mas uma coisa é fato, é um feminino extremamente ferido, mas ele não fica sempre num único comportamento, ele vai ser não, porque ele joga, ele é um bom jogador, na verdade é uma é uma manipuladora, é uma rainha manipulando.
- Então essas dores profundas que eles têm, mas nesses corpos, essas mentes, essas almas que estão ali se cortando para caber nessa nossa sociedade, sabe?
- Ah, então é como no na mandala da dor eu tenho que identificar mais aonde eu tô e pot aonde isso está em dores.
- Mas depende, ele é super meu cliente de terapia, eu sou psicólogo, eu sou psicanalista, ele é super meu cliente e tá tranquilo a gente mexer nessa dor de novo, porque quando eu mexo numa dor, automaticamente todo o meu mecanismo de defesa vai subir, aí eu tenho uma semana para me calçar, entende?


## Citações e Formulações de Alta Densidade

- “Então, eh, o que você precisa fazer precisa ser feito, o que você traz na alma, porque você tá falando de expansão de consciência, certo?”
- “Então, esses você vai ter que lidar com eles e fazer nascer aquilo, parar de fugir daquilo que você precisa colocar no mundo, que você trouxe como missão na sua alma.”
- “E aqui quando a gente coloca o consciente e o inconsciente, né, na folhinha de decuração, eh, já tava até conversando com um colega que tá aqui também e e aí aqui a gente vai tá perguntando, né, sobre todas as pétalas e fazendo as perguntas e tendo consciente, neconsciente, só que a gente vai tá…”
- “Mas nessas perguntas, então assim, eh, na questão da pessoa nunca vai, sempre vai ter que dar de um a 10.”
- “Eu vou, então eu coloquei três, só que quando eu fui lá e na na energia deu nove, falei na verdade não é o que eu tenho parece uma questão que vai dando visualização para visualização.”
- “É mais essa visualização tanto pra gente poder ir decurando no decorrer no final e pro cliente ele não vai precisar explicar esse ponto, né? a gente vai pegar o o assunto geral do que tirar um denominador comum e falar: "Olha, por esse caminho, é depende, depende, depende do cliente, depende da…”
- “Aí fui, eu mostrei para ela e fiz uma pergunta, um exemplo, ela pegou assim: "Ah, eu nem sei como responder essa pergunta, porque muita gente nem tem consciência das perguntas dela parar de pensar." É, mas é porque assim, ó, a gente precisa entender que a gente tá sobre um campo de energia.”
- “Código humanosense não é um código à toa, ele é um campo, tem uma egrégora, tem um campo de força, não tem essa simulação.”
- “Eh, a minha questão, né, eu acho que tem a ver também com com isso, porque tá nas perguntas, eh, que eu entendi isso, que a gente vai seguir sempre o mesmo número de perguntas e aí na mandala do amor a gente tem femino masculino.”
- “É, por exemplo, no caso, mas uma coisa é fato, é um feminino extremamente ferido, mas ele não fica sempre num único comportamento, ele vai ser não, porque ele joga, ele é um bom jogador, na verdade é uma é uma manipuladora, é uma rainha manipulando.”
- “Uma outra pergunta que eu tenho, que é uma coisa que me angustia um pouco, eh, por exemplo, a gente, eu fiz o humanoterapeuta, né, e a gente viu que tudo tá no energético, tá no espiritual e quando ele se manifesta no corpo, ele já tava lá se manifestando, né?”
- “Mas depende, ele é super meu cliente de terapia, eu sou psicólogo, eu sou psicanalista, ele é super meu cliente e tá tranquilo a gente mexer nessa dor de novo, porque quando eu mexo numa dor, automaticamente todo o meu mecanismo de defesa vai subir, aí eu tenho uma semana para me calçar, entende?”

## Conexões com a Wiki

- [[Conceito do Metodo HumanoSense]]
- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Camara HumanoSense]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio da Liberdade Consciente]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Conceito do Parceiro da Missao]]

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## Referência

ANDRESA MOLINA. *Aula 05 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/05   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.

---

## Aula 06 - Codigo Humanosense

# Aula 06 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `06   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 15.298 palavras; 542 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- A partir dos comandos, você conduz o assistido a acessar frequências elevadas de energia, promovendo limpeza, harmonização e reprogramação, ancorando a cura de forma integral no código manocência.
- Você, ela se conectou com aquele problema que você, ó, então peça para assistir se conectar com o que ele precisa resolver, ou seja, a dor ou a questão, guie ele num alfa profundo com o seu assistido.
- Então essa é dentro do campo de energia, a primeira parte eram as perguntas, que é a parte racionalizada e energética do inconsciente.
- Alguém e aí não é uma entidade, é uma equipe especializada, precisava de estravar que era a roda da carroça, recolheria a carroça e vai e no campo espiritual tudo o que todos nós vivemos é experiência.
- Ao aplicar os comandos, esgote plenamente a dor acessada, dê espaço para que ele fale tudo o que precisa dizer à pessoa envolvida na cena.
- E é no sangrar do feminino, é no sente, é nesse lugar, é neste corpo, é neste campo. que eu não vou me aprofundar aqui, que isso é semeado, é o útero da vida, mas se ele estiver cheio de lixo, de abortos e de dores e de apegos e de raiva e de rancor, tudo o que pode nascer na vida é raiva, rancor, angústia, medo e não tem um solo sagrado.
- Como então sangrar e vai sentir o quê? as cólicas, as dores, o medo e o desejo de esvaziar-se com consciência, decidindo fazê-lo.
- Então, é um trabalho profundo espiritual com a consciência da pessoa de fazer o que tem que ser feito, de soltar, de confiar na espiritualidade, porque estamos presos em muitos lugares e esse é um baita trabalho espiritual e de desobsessão de processos autobsessivos.
- Então, gente, se apropriem disso, sintam isso, repitam essas frases, se apropriem espiritualmente, conectem com a equipe espiritual, leiam tudo que tá escrito lá no passo a passo, tá tudo escrito.
- O se não é apenas um protocolo de atendimento, é um caminho vivo, sensível que conduz o assistido da dor à consciência, da consciência, a libertação e da libertação à criação de novas possibilidades.
- Aqui no portal humano você encontrará o passo a passo completo do método e as instruções práticas de aplicação, as videoaulas comigo explicando os conceitos e e a terapêutica.
- Você tem as páginas com perguntas e instruções específicas para cada mandala, que é a folha verde aqui, a parte verde, você tem a azul, que é eh os comandos espirituais de orientações práticas de condução.

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-68
- Então, até agora a gente falou bastante sobre a parte racional, eh, a parte de entendimento de energia do inconsciente, mas muito focado no entendimento, na racionalidade, na capacidade do nosso, eh, raciocínio compreender algumas coisas que estão, eh, nos dirigindo.
- Todo o trabalho energético e espiritual, ele não existe sem o Megregora que o mantenha, sem o deva, o guardião, o orientador, o mestre daquele trabalho.
- Então, não existe nada que seja energético e espiritual, que não tenha uma equipe espiritual que coordene, que dirija esse trabalho, que proteja nesse trabalho.

### Bloco 2 - frases 69-136
- Então são algumas frases, algumas inclusive se repetem que se você entender a lógica do processo você vai conseguir decorar, entendendo essa lógica, decorar e aí vai ter um recheio, porque isso te protege, te traz um começo, abre um campo e vai fechar.
- A partir dos comandos, você conduz o assistido a acessar frequências elevadas de energia, promovendo limpeza, harmonização e reprogramação, ancorando a cura de forma integral no código manocência.
- Você, ela se conectou com aquele problema que você, ó, então peça para assistir se conectar com o que ele precisa resolver, ou seja, a dor ou a questão, guie ele num alfa profundo com o seu assistido.

### Bloco 3 - frases 137-204
- Vá seguindo as orientações sobre sentir, transformar e transmutar, escutando atentamente o que ele fala e vá conduzindo o processo, perguntando sempre o que ele sente que deve fazer nessa situação e o auxilie a fazer, a falar, a mover, a soltar ou o que você sentir.
- Quando o processo de limpeza estiver encerrado, confirme com assistido se ele se sente bem para seguir com o processo de execução da criação e espiritualização do desejo.
- Então essa é dentro do campo de energia, a primeira parte eram as perguntas, que é a parte racionalizada e energética do inconsciente.

### Bloco 4 - frases 205-272
- Alguém e aí não é uma entidade, é uma equipe especializada, precisava de estravar que era a roda da carroça, recolheria a carroça e vai e no campo espiritual tudo o que todos nós vivemos é experiência.
- Ao aplicar os comandos, esgote plenamente a dor acessada, dê espaço para que ele fale tudo o que precisa dizer à pessoa envolvida na cena.
- E é no sangrar do feminino, é no sente, é nesse lugar, é neste corpo, é neste campo. que eu não vou me aprofundar aqui, que isso é semeado, é o útero da vida, mas se ele estiver cheio de lixo, de abortos e de dores e de apegos e de raiva e de rancor, tudo o que pode nascer na vida é raiva, rancor, angústia, medo e não tem um solo sagrado.

### Bloco 5 - frases 273-340
- E é cheio de códigos, cheio de informações, cheios de comando dentro desse espaço sagrado que a equipe espiritual me trouxe.
- Então, gente, se apropriem disso, sintam isso, repitam essas frases, se apropriem espiritualmente, conectem com a equipe espiritual, leiam tudo que tá escrito lá no passo a passo, tá tudo escrito.
- Cada cada mandala, cada comando e cada terapêutica se torna instrumento de cura e expansão da consciência.

### Bloco 6 - frases 341-408
- O se não é apenas um protocolo de atendimento, é um caminho vivo, sensível que conduz o assistido da dor à consciência, da consciência, a libertação e da libertação à criação de novas possibilidades.
- Aqui no portal humano você encontrará o passo a passo completo do método e as instruções práticas de aplicação, as videoaulas comigo explicando os conceitos e e a terapêutica.
- Você tem as páginas com perguntas e instruções específicas para cada mandala, que é a folha verde aqui, a parte verde, você tem a azul, que é eh os comandos espirituais de orientações práticas de condução.

### Bloco 7 - frases 409-476
- Então você faz as perguntas racionais para ele, pega a caneta, um papelzinho, faz a pergunta racional, ele te responde, você coloca lá qual foi a pergunta que você fez, automaticamente você vem aqui na mesa e pergunta pro inconsciente dele.
- Ó, então para quem tem dúvida nas perguntas, ó, mandala do amor, escolha apenas uma pergunta para cada energia masculina e feminino.
- E aí se você for sentindo alguma coisa, vai trabalhando e vai conversando com ela com tudo que você aprendeu sobre todos os conceitos, todas as bases.

### Bloco 8 - frases 477-542
- Como você quiser, aqui o passo a passo e aqui o bem-vindo, tá tudo aqui e os comandos todos e as perguntas estão aqui, tá?
- Então tem aqui o passo a passo, você pode olhar aqui e enquanto você olha o passo a passo, você pode ler os comandos aqui, entende?
- Então, se você precisa, se você traz energia ali de pombogira, oferta a energia da pombogira, traz elas, elas vem trazendo alegria, que elas venham limpando com a sua saia.

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Todo o trabalho energético e espiritual, ele não existe sem o Megregora que o mantenha, sem o deva, o guardião, o orientador, o mestre daquele trabalho.
- Então, não existe nada que seja energético e espiritual, que não tenha uma equipe espiritual que coordene, que dirija esse trabalho, que proteja nesse trabalho.
- Então, primeira coisa, todo o trabalho, o passo a passo, bem simples, bem mastigado, bem orientado, com cada detalhe está colocado na plataforma, tá lá o que você precisa fazer em cada passo.
- Então, tem uma parte fixa de comandos que preservam esse espaço que se cria para que você possa ser maleável e estar presente para fazer o que precisar naquele momento.
- Você, ela se conectou com aquele problema que você, ó, então peça para assistir se conectar com o que ele precisa resolver, ou seja, a dor ou a questão, guie ele num alfa profundo com o seu assistido.
- Alguém e aí não é uma entidade, é uma equipe especializada, precisava de estravar que era a roda da carroça, recolheria a carroça e vai e no campo espiritual tudo o que todos nós vivemos é experiência.
- Ao aplicar os comandos, esgote plenamente a dor acessada, dê espaço para que ele fale tudo o que precisa dizer à pessoa envolvida na cena.
- Pro campo energético não existe teste, não existe faz de conta, existe frequência, energia e espiritualidade.
- Então, gente, se apropriem disso, sintam isso, repitam essas frases, se apropriem espiritualmente, conectem com a equipe espiritual, leiam tudo que tá escrito lá no passo a passo, tá tudo escrito.
- Aqui você encontra o que tenho que fazer, o passo a passo, os estudos e as fichas para download. com tudo que você precisa preencher.

## Conceitos-Chave Extraídos

- Então, quando a gente fala da parte do respeito à técnica, é, na verdade respeito a essas energias e entidades que nos trazem essa técnica e, portanto, que são os guardiões desse trabalho, tá?
- Então, esse código, ele nos traz a possibilidade de um espaço sagrado, onde a gente pode estar protegido e induído para fazer o trabalho que precisa ser feito.
- A partir dos comandos, você conduz o assistido a acessar frequências elevadas de energia, promovendo limpeza, harmonização e reprogramação, ancorando a cura de forma integral no código manocência.
- Então essa é dentro do campo de energia, a primeira parte eram as perguntas, que é a parte racionalizada e energética do inconsciente.
- Alguém e aí não é uma entidade, é uma equipe especializada, precisava de estravar que era a roda da carroça, recolheria a carroça e vai e no campo espiritual tudo o que todos nós vivemos é experiência.
- E é no sangrar do feminino, é no sente, é nesse lugar, é neste corpo, é neste campo. que eu não vou me aprofundar aqui, que isso é semeado, é o útero da vida, mas se ele estiver cheio de lixo, de abortos e de dores e de apegos e de raiva e de rancor, tudo o que pode nascer na vida é raiva, rancor, angústia, medo e não tem um solo sagrado.
- Como então sangrar e vai sentir o quê? as cólicas, as dores, o medo e o desejo de esvaziar-se com consciência, decidindo fazê-lo.
- Então, é um trabalho profundo espiritual com a consciência da pessoa de fazer o que tem que ser feito, de soltar, de confiar na espiritualidade, porque estamos presos em muitos lugares e esse é um baita trabalho espiritual e de desobsessão de processos autobsessivos.
- Pro campo energético não existe teste, não existe faz de conta, existe frequência, energia e espiritualidade.
- Cada cada mandala, cada comando e cada terapêutica se torna instrumento de cura e expansão da consciência.
- O se não é apenas um protocolo de atendimento, é um caminho vivo, sensível que conduz o assistido da dor à consciência, da consciência, a libertação e da libertação à criação de novas possibilidades.
- Aqui no portal humano você encontrará o passo a passo completo do método e as instruções práticas de aplicação, as videoaulas comigo explicando os conceitos e e a terapêutica.
- Em mãos você terá o que perguntar e o que dizer com comandos espirituais e energéticos do Código Humanocense.
- Você tem as páginas com perguntas e instruções específicas para cada mandala, que é a folha verde aqui, a parte verde, você tem a azul, que é eh os comandos espirituais de orientações práticas de condução.
- E tem como objetivo identificar a raiz de um padrão, limpar o campo e abrir caminho para uma nova realidade, pra materialização de alguma coisa.
- Ó, então para quem tem dúvida nas perguntas, ó, mandala do amor, escolha apenas uma pergunta para cada energia masculina e feminino.


## Técnicas, Procedimentos e Orientações Práticas

- A partir dos comandos, você conduz o assistido a acessar frequências elevadas de energia, promovendo limpeza, harmonização e reprogramação, ancorando a cura de forma integral no código manocência.
- Você, ela se conectou com aquele problema que você, ó, então peça para assistir se conectar com o que ele precisa resolver, ou seja, a dor ou a questão, guie ele num alfa profundo com o seu assistido.
- Então essa é dentro do campo de energia, a primeira parte eram as perguntas, que é a parte racionalizada e energética do inconsciente.
- Ao aplicar os comandos, esgote plenamente a dor acessada, dê espaço para que ele fale tudo o que precisa dizer à pessoa envolvida na cena.
- Então, gente, se apropriem disso, sintam isso, repitam essas frases, se apropriem espiritualmente, conectem com a equipe espiritual, leiam tudo que tá escrito lá no passo a passo, tá tudo escrito.
- Cada cada mandala, cada comando e cada terapêutica se torna instrumento de cura e expansão da consciência.
- O se não é apenas um protocolo de atendimento, é um caminho vivo, sensível que conduz o assistido da dor à consciência, da consciência, a libertação e da libertação à criação de novas possibilidades.
- Mais do que aliviar sintomas, o humanocência ajuda o assistido a lembrar quem realmente é, rompendo com defesas dores e padrões que o afastam da sua essência e evolução.
- Aqui no portal humano você encontrará o passo a passo completo do método e as instruções práticas de aplicação, as videoaulas comigo explicando os conceitos e e a terapêutica.
- Aqui você encontra o que tenho que fazer, o passo a passo, os estudos e as fichas para download. com tudo que você precisa preencher.
- Você tem as páginas com perguntas e instruções específicas para cada mandala, que é a folha verde aqui, a parte verde, você tem a azul, que é eh os comandos espirituais de orientações práticas de condução.
- E tem como objetivo identificar a raiz de um padrão, limpar o campo e abrir caminho para uma nova realidade, pra materialização de alguma coisa.
- Então você faz as perguntas racionais para ele, pega a caneta, um papelzinho, faz a pergunta racional, ele te responde, você coloca lá qual foi a pergunta que você fez, automaticamente você vem aqui na mesa e pergunta pro inconsciente dele.
- Ó, então para quem tem dúvida nas perguntas, ó, mandala do amor, escolha apenas uma pergunta para cada energia masculina e feminino.


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- Todo o trabalho energético e espiritual, ele não existe sem o Megregora que o mantenha, sem o deva, o guardião, o orientador, o mestre daquele trabalho.
- A gente é protegido quando a gente consegue junto com a equipe espiritual manter porque esse processo do padrão que nos protege.
- Você, ela se conectou com aquele problema que você, ó, então peça para assistir se conectar com o que ele precisa resolver, ou seja, a dor ou a questão, guie ele num alfa profundo com o seu assistido.
- Alguém e aí não é uma entidade, é uma equipe especializada, precisava de estravar que era a roda da carroça, recolheria a carroça e vai e no campo espiritual tudo o que todos nós vivemos é experiência.
- Ao aplicar os comandos, esgote plenamente a dor acessada, dê espaço para que ele fale tudo o que precisa dizer à pessoa envolvida na cena.
- E é no sangrar do feminino, é no sente, é nesse lugar, é neste corpo, é neste campo. que eu não vou me aprofundar aqui, que isso é semeado, é o útero da vida, mas se ele estiver cheio de lixo, de abortos e de dores e de apegos e de raiva e de rancor, tudo o que pode nascer na vida é raiva, rancor, angústia, medo e não tem um solo sagrado.
- Como então sangrar e vai sentir o quê? as cólicas, as dores, o medo e o desejo de esvaziar-se com consciência, decidindo fazê-lo.
- Então, é um trabalho profundo espiritual com a consciência da pessoa de fazer o que tem que ser feito, de soltar, de confiar na espiritualidade, porque estamos presos em muitos lugares e esse é um baita trabalho espiritual e de desobsessão de processos autobsessivos.
- O se não é apenas um protocolo de atendimento, é um caminho vivo, sensível que conduz o assistido da dor à consciência, da consciência, a libertação e da libertação à criação de novas possibilidades.
- Mais do que aliviar sintomas, o humanocência ajuda o assistido a lembrar quem realmente é, rompendo com defesas dores e padrões que o afastam da sua essência e evolução.
- E tem como objetivo identificar a raiz de um padrão, limpar o campo e abrir caminho para uma nova realidade, pra materialização de alguma coisa.
- Então você faz as perguntas racionais para ele, pega a caneta, um papelzinho, faz a pergunta racional, ele te responde, você coloca lá qual foi a pergunta que você fez, automaticamente você vem aqui na mesa e pergunta pro inconsciente dele.


## Citações e Formulações de Alta Densidade

- “Todo o trabalho energético e espiritual, ele não existe sem o Megregora que o mantenha, sem o deva, o guardião, o orientador, o mestre daquele trabalho.”
- “Então, quando a gente fala da parte do respeito à técnica, é, na verdade respeito a essas energias e entidades que nos trazem essa técnica e, portanto, que são os guardiões desse trabalho, tá?”
- “Então, primeira coisa, todo o trabalho, o passo a passo, bem simples, bem mastigado, bem orientado, com cada detalhe está colocado na plataforma, tá lá o que você precisa fazer em cada passo.”
- “A gente é protegido quando a gente consegue junto com a equipe espiritual manter porque esse processo do padrão que nos protege.”
- “Então, tem uma parte fixa de comandos que preservam esse espaço que se cria para que você possa ser maleável e estar presente para fazer o que precisar naquele momento.”
- “Então, esse código, ele nos traz a possibilidade de um espaço sagrado, onde a gente pode estar protegido e induído para fazer o trabalho que precisa ser feito.”
- “Você, ela se conectou com aquele problema que você, ó, então peça para assistir se conectar com o que ele precisa resolver, ou seja, a dor ou a questão, guie ele num alfa profundo com o seu assistido.”
- “Alguém e aí não é uma entidade, é uma equipe especializada, precisava de estravar que era a roda da carroça, recolheria a carroça e vai e no campo espiritual tudo o que todos nós vivemos é experiência.”
- “Ao aplicar os comandos, esgote plenamente a dor acessada, dê espaço para que ele fale tudo o que precisa dizer à pessoa envolvida na cena.”
- “E é no sangrar do feminino, é no sente, é nesse lugar, é neste corpo, é neste campo. que eu não vou me aprofundar aqui, que isso é semeado, é o útero da vida, mas se ele estiver cheio de lixo, de abortos e de dores e de apegos e de raiva e de rancor, tudo o que pode nascer na vida é raiva, rancor,…”
- “O se não é apenas um protocolo de atendimento, é um caminho vivo, sensível que conduz o assistido da dor à consciência, da consciência, a libertação e da libertação à criação de novas possibilidades.”
- “Aqui você encontra o que tenho que fazer, o passo a passo, os estudos e as fichas para download. com tudo que você precisa preencher.”

## Conexões com a Wiki

- [[Conceito do Metodo HumanoSense]]
- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]
- [[Conceito da Camara HumanoSense]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio da Liberdade Consciente]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Enquadramento na Piramide]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Tecnica de Retorno a Consciencia e Harmonizacao]]
- [[Conceito do Parceiro da Missao]]

## FAQs para NotebookLM (Fase 2)

### Bloco 1: A Egrégora e a Ética da Preparação do Terapeuta

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
1. Como Andresa Molina justifica a proibição absoluta de alterar comandos ou pular passos no método Humanosense, explicando a nível energético o risco de abrir brechas para obsessores?
2. De que maneira a falta de preparo e estudo prévio do terapeuta divide a sua atenção somática e compromete a potência da egrégora de cura?
3. O que Andresa Molina afirma sobre o terapeuta mediano que atende "de qualquer jeito" ou "de graça" para treinar, e como essa atitude impacta a equipe espiritual do assistido?
4. Qual é a analogia usada por Andresa Molina com a música "Faroeste Caboclo" para rebater terapeutas que dizem ter dificuldade em decorar os comandos da mesa?
```

### Bloco 2: A Realidade Existencial e a ~~Câmara Astral~~ *(Nota: expressão não consta na transcrição; a autora usa 'Câmara Humanosense' ou 'campo energético')* do Espaço Humanidade

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
5. Como Andresa Molina descreve o "Princípio da Aceitação dos Fatos" e qual a relação clínica entre a briga contra a realidade e o adoecimento crônico?
6. Como o assistido muda de "estado plasmático" ao entrar na Câmara Humanosense e qual a estrutura espiritual e tecnológica que a sustenta?
7. Qual a diferença de atuação e competência técnica entre as "Entidades de Resgate" e as "Entidades Especialistas" dentro do campo espiritual de atendimento?
8. De que forma Andresa Molina conceitua a distinção entre "Espíritos Terrestres" (como Orixás e Ancestrais) e "Extraterrestres" no que tange ao domínio de elementos naturais e tecnologias de DNA?
```

### Bloco 3: O Sangramento do Útero e a Fecundação da Intenção

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
9. O que significa somatizar o "Sangramento do Útero da Vida" e por que o esvaziamento de traumas, abortos e raivas é um requisito orgânico obrigatório antes de cocriar?
10. Como se dá a "Fusão do Masculino e Feminino" no clímax do atendimento Humanosense e como essa alquimia ativada no corpo físico desperta a Kundalini?
11. De que maneira os "Três Cérebros" (Mente, Coração e Intestino/Vísceras) atuam como pilares de sustentação somática para ancorar e gestar a nova semente do desejo?
12. Por que o terapeuta deve expor o assistido a sentir desconforto, dor ou raiva na cena de transe em vez de tentar acalmar o paciente de imediato?
```

### Bloco 4: Procedimentos de Abertura, Confronto e Fechamento na Prática

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
13. Como deve ser executada a "Prática do Enquadramento em Pirâmide" em termos de pulsos magnéticos, e por que a geometria da pirâmide é insubstituível na egrégora?
14. Qual o propósito radiestésico e espiritual do "Comando de Abertura e Conexão" ao exigir que o assistido diga seu nome completo e data de nascimento em voz alta?
15. Como o terapeuta deve guiar o assistido no "Confronto e Resgate da Contraparte" quando ele tem medo de sair de uma cena traumática do passado?
16. Qual a verbalização exata e a funcionalidade do "Comando de Encaminhamento Padrão" no recolhimento das contrapartes de dor?
17. Em quais situações clínicas específicas o terapeuta deve evocar o "Comando de Intervenção Especializada" e de que maneira essas equipes astrais atuam?
18. Como é conduzido o passo a passo da "Prática de Esvaziamento e Fecundação" e qual o papel dos três cérebros na estabilização da semente?
19. Quais as etapas e comandos exatos para a "Prática de Encerramento e Harmonização", incluindo a limpeza e o reacoplamento de corpos de 5 a 1?
20. Como o terapeuta opera o pêndulo no encerramento da sessão com a trindade "Harmoniza, Potencializa e Liberta" e de que forma desliga energeticamente o assistido da mesa?
```

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## Referência

ANDRESA MOLINA. *Aula 06 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.

---

## Aula 07 - Codigo Humanosense

# Aula 07 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `07   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 17.500 palavras; 603 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- Vamos lá, vamos tirar algumas dúvidas, algumas questões que as pessoas estão perguntando, extremamente ansiosas e eu falando: "Calma, gente, a gente vai chegar lá, vocês, a gente ainda vai chegar nessa fase, então tenham calma que a gente tá chegando no finalmente, tá bom?
- Então, a primeira parte do passo a passo é a parte de você se preparar antes do seu cliente, do seu assistido chegar, certo?
- E explica, é uma tecnologia espiritual canalizada que atua em três níveis, no racional, no emocional e no espiritual. e tem como objetivo identificar a raiz de um padrão, limpar o campo, abrir e abrir caminho para uma nova realidade, tá?
- A pastinha lá na dele, tudo que ele fez com você tá dentro da pastinha dele, é seu cliente, se você ti então, mas para facilitar o processo agora, você pode colocar aqui no comecinho o número da pergunta se é uma, dois ou a três para você ter que escrever tudo ali, na vez vai demorar muito e perde um pouco do fluxo.
- Agora eu vou continuo fazendo perguntas, eu quero que você me responda zer na mandala da dor você não precisa seguir a sequência, você vai escolher uma de cada, tá?
- Então, lembrando sempre disso, o cliente chega em dor porque ele está iludido.
- Então essas são as questões que a gente precisa ajudar ele a sair daquele lugar, a perceber e se se acalmando e ter consciência de tudo isso.
- Ó, sinta a dor chegando sem medo, sem fugir, porque só o que é sentido por inteiro pode enem ser curado.
- Então vocês estão desdobrados, o cliente está desdobrado num campo de proteção onde tem uma plasticidade completamente, onde tem códigos completamente diferentes.
- Eh, no momento das perguntas, nas mandalas, eh, a cada investigação de cada pergunta, né, eh, é melhor a gente discutir com ele, com o assistido, eh, o que a gente tá visualizando ali ao fim de cada pergunta ou ao fim de cada pétala?
- Não é para terapeuta ai vou fazer uma não é trabalho, não é trabalho espiritual, não é trabalho de verdade dentro de uma linha de resgate, de uma linha de de cura de verdade, é só o gostosinho." Então, para vocês entenderem isso sim, a gente tá com a equipe, a equipe do código inocência é extremamente potente.
- Então, eh, minha dúvida é a seguinte, como eu também sou humanoterapeuta, né, eu também trabalho com amiza quântica, aí aqui que nos inícios da passo a passo do trabalho, a gente coloca o assistido ou dentro código, né, do situação unidade, coloca ele na mesa.

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-76
- Vamos lá, vamos tirar algumas dúvidas, algumas questões que as pessoas estão perguntando, extremamente ansiosas e eu falando: "Calma, gente, a gente vai chegar lá, vocês, a gente ainda vai chegar nessa fase, então tenham calma que a gente tá chegando no finalmente, tá bom?
- Então, a primeira parte do passo a passo é a parte de você se preparar antes do seu cliente, do seu assistido chegar, certo?
- E explica, é uma tecnologia espiritual canalizada que atua em três níveis, no racional, no emocional e no espiritual. e tem como objetivo identificar a raiz de um padrão, limpar o campo, abrir e abrir caminho para uma nova realidade, tá?

### Bloco 2 - frases 77-152
- Tem que falar, tem em voz alta sim, porque ele precisa autorizar e colocar magneticamente essa autorização no mundo.
- E aí você vai, pede pro assistido se conectar com o que ele precisa resolver, ou seja, a dor ou a questão que ele trouxe.
- E aí, antes disso, desculpa, antes disso que você colocou aqui, você vai fazer as perguntas da mandala do amor, ok?

### Bloco 3 - frases 153-228
- Se você escolher, no caso da Mandala do Amor, uma pergunta, a pergunta número um na energia, você no masculino, você vai escolher a pergunta número um na energia do feminino.
- A pastinha lá na dele, tudo que ele fez com você tá dentro da pastinha dele, é seu cliente, se você ti então, mas para facilitar o processo agora, você pode colocar aqui no comecinho o número da pergunta se é uma, dois ou a três para você ter que escrever tudo ali, na vez vai demorar muito e perde um pouco do fluxo.
- Agora eu vou continuo fazendo perguntas, eu quero que você me responda zer na mandala da dor você não precisa seguir a sequência, você vai escolher uma de cada, tá?

### Bloco 4 - frases 229-304
- Então, lembrando sempre disso, o cliente chega em dor porque ele está iludido.
- Então essas são as questões que a gente precisa ajudar ele a sair daquele lugar, a perceber e se se acalmando e ter consciência de tudo isso.
- Então você vai encontrar de acordo com todos os conceitos que a gente trouxe que estão todos explicadinhos aqui atrás, Andra, mas na hora que eu tiver com meu assistido não vou conseguir estar vendo o vídeo.

### Bloco 5 - frases 305-380
- Siga as orientações do bloco azul, comando de retorno à consciência para harmonizar na mesa, manos lugar, função e potência e encerrar a sessão com assistido.
- Então você vai virar o pêndulo no sentidora, fecha os olhos, relaxa, vou te harmonizar para você ir se acalmando e fica bem.
- Ó, sinta a dor chegando sem medo, sem fugir, porque só o que é sentido por inteiro pode enem ser curado.

### Bloco 6 - frases 381-456
- Então vocês estão desdobrados, o cliente está desdobrado num campo de proteção onde tem uma plasticidade completamente, onde tem códigos completamente diferentes.
- Da câmara humano e por isso funciona só por isso tem pequeno que a gente precisa entender que não somos nós que estamos trabalhando.
- Se lá, vocês vão ver o que vai acontecendo com a mediunidade de vocês, porque estamos na Câmara Humanoscense, desdobrados, você e ele, ancorados por toda a equipe que sustenta o espaço humanidade, espiritualmente falando, OK?

### Bloco 7 - frases 457-532
- Eh, você pode depois de um período, né, manter contato, tem data de nascimento, você pode, eh, mandar parabéns a nos aniversários e manter esse contato com o seu cliente, caso ele não seja um cliente seu já eh sempre.
- Eh, no momento das perguntas, nas mandalas, eh, a cada investigação de cada pergunta, né, eh, é melhor a gente discutir com ele, com o assistido, eh, o que a gente tá visualizando ali ao fim de cada pergunta ou ao fim de cada pétala?
- Não é para terapeuta ai vou fazer uma não é trabalho, não é trabalho espiritual, não é trabalho de verdade dentro de uma linha de resgate, de uma linha de de cura de verdade, é só o gostosinho." Então, para vocês entenderem isso sim, a gente tá com a equipe, a equipe do código inocência é extremamente potente.

### Bloco 8 - frases 533-603
- Então, eh, minha dúvida é a seguinte, como eu também sou humanoterapeuta, né, eu também trabalho com amiza quântica, aí aqui que nos inícios da passo a passo do trabalho, a gente coloca o assistido ou dentro código, né, do situação unidade, coloca ele na mesa.
- Na mesa quântica, quando a gente coloca o assistido, eu já estou acessando o o campo morfogenético dele e o inconsciente.
- Aí eu fiquei meia confusa com isso, porque quando eu coloco assistido na mesa quântica, eu já estou as perguntas que eu faço, ele já está ali no Eu já estou assistando.

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Então, sempre que a gente vai receber, a gente vai trabalhar energeticamente, nós precisamos estar prontos antes dele chegar.
- Então, antes do seu cliente chegar, de seu horário de abrir o zoom com ele à distância ou presencial, você precisa estar pronto, tá?
- E aí você vai, pede pro assistido se conectar com o que ele precisa resolver, ou seja, a dor ou a questão que ele trouxe.
- Consciente primeiro ele vai responder racionalmente, a gente vai fazer a leitura do campo energético, que é o inconsciente, trazer pro consciente uma informação do campo inconsciente energético.
- A pastinha lá na dele, tudo que ele fez com você tá dentro da pastinha dele, é seu cliente, se você ti então, mas para facilitar o processo agora, você pode colocar aqui no comecinho o número da pergunta se é uma, dois ou a três para você ter que escrever tudo ali, na vez vai demorar muito e perde um pouco do fluxo.
- Agora eu vou continuo fazendo perguntas, eu quero que você me responda zer na mandala da dor você não precisa seguir a sequência, você vai escolher uma de cada, tá?
- Então, lembrando sempre disso, o cliente chega em dor porque ele está iludido.
- Então essas são as questões que a gente precisa ajudar ele a sair daquele lugar, a perceber e se se acalmando e ter consciência de tudo isso.
- Então, vá seguindo as orientações sobre sentir, transformar e transmutar, executando atentamente o que ele fala e vá conduzindo o processo, perguntando sempre o que ele sente que deve fazer nessa situação.
- Da câmara humano e por isso funciona só por isso tem pequeno que a gente precisa entender que não somos nós que estamos trabalhando.

## Conceitos-Chave Extraídos

- Então, para facilitar um pouquinho a vida de vocês, embora esteja tudo eh no passo a passo do sistema.
- Ehos o que é comando tá na folha de comando, o que é passo a passo tá no passo a passo no sistema, tá bom?
- Então no passo quatro que tá aqui no sistema, você também tem uma orientação, tem até uma frase pronta para você não esquecer.
- E explica, é uma tecnologia espiritual canalizada que atua em três níveis, no racional, no emocional e no espiritual. e tem como objetivo identificar a raiz de um padrão, limpar o campo, abrir e abrir caminho para uma nova realidade, tá?
- Se você escolher, no caso da Mandala do Amor, uma pergunta, a pergunta número um na energia, você no masculino, você vai escolher a pergunta número um na energia do feminino.
- Consciente primeiro ele vai responder racionalmente, a gente vai fazer a leitura do campo energético, que é o inconsciente, trazer pro consciente uma informação do campo inconsciente energético.
- E aí você vai perguntar do femino, do energia, depois do tempo e você vai fazer todas as perguntas aqui da mandala do amor.
- Agora eu vou continuo fazendo perguntas, eu quero que você me responda zer na mandala da dor você não precisa seguir a sequência, você vai escolher uma de cada, tá?
- Então essas são as questões que a gente precisa ajudar ele a sair daquele lugar, a perceber e se se acalmando e ter consciência de tudo isso.
- Então você vai encontrar de acordo com todos os conceitos que a gente trouxe que estão todos explicadinhos aqui atrás, Andra, mas na hora que eu tiver com meu assistido não vou conseguir estar vendo o vídeo.
- Siga as orientações do bloco azul, comando de retorno à consciência para harmonizar na mesa, manos lugar, função e potência e encerrar a sessão com assistido.
- Então vocês estão desdobrados, o cliente está desdobrado num campo de proteção onde tem uma plasticidade completamente, onde tem códigos completamente diferentes.
- Eh, no momento das perguntas, nas mandalas, eh, a cada investigação de cada pergunta, né, eh, é melhor a gente discutir com ele, com o assistido, eh, o que a gente tá visualizando ali ao fim de cada pergunta ou ao fim de cada pétala?
- Não é para terapeuta ai vou fazer uma não é trabalho, não é trabalho espiritual, não é trabalho de verdade dentro de uma linha de resgate, de uma linha de de cura de verdade, é só o gostosinho." Então, para vocês entenderem isso sim, a gente tá com a equipe, a equipe do código inocência é extremamente potente.
- Então, eh, minha dúvida é a seguinte, como eu também sou humanoterapeuta, né, eu também trabalho com amiza quântica, aí aqui que nos inícios da passo a passo do trabalho, a gente coloca o assistido ou dentro código, né, do situação unidade, coloca ele na mesa.
- Na mesa quântica, quando a gente coloca o assistido, eu já estou acessando o o campo morfogenético dele e o inconsciente.


## Técnicas, Procedimentos e Orientações Práticas

- Vamos lá, vamos tirar algumas dúvidas, algumas questões que as pessoas estão perguntando, extremamente ansiosas e eu falando: "Calma, gente, a gente vai chegar lá, vocês, a gente ainda vai chegar nessa fase, então tenham calma que a gente tá chegando no finalmente, tá bom?
- Então, a primeira parte do passo a passo é a parte de você se preparar antes do seu cliente, do seu assistido chegar, certo?
- Então, antes do seu cliente chegar, de seu horário de abrir o zoom com ele à distância ou presencial, você precisa estar pronto, tá?
- Então, primeira coisa que é essa primeira parte do e do passo a passo, então, agendamento com assistido, preparação do ambiente e preparação do terapeuta, certo?
- Então no passo quatro que tá aqui no sistema, você também tem uma orientação, tem até uma frase pronta para você não esquecer.
- E explica, é uma tecnologia espiritual canalizada que atua em três níveis, no racional, no emocional e no espiritual. e tem como objetivo identificar a raiz de um padrão, limpar o campo, abrir e abrir caminho para uma nova realidade, tá?
- E aí você vai, pede pro assistido se conectar com o que ele precisa resolver, ou seja, a dor ou a questão que ele trouxe.
- Se você escolher, no caso da Mandala do Amor, uma pergunta, a pergunta número um na energia, você no masculino, você vai escolher a pergunta número um na energia do feminino.
- A pastinha lá na dele, tudo que ele fez com você tá dentro da pastinha dele, é seu cliente, se você ti então, mas para facilitar o processo agora, você pode colocar aqui no comecinho o número da pergunta se é uma, dois ou a três para você ter que escrever tudo ali, na vez vai demorar muito e perde um pouco do fluxo.
- Agora eu vou continuo fazendo perguntas, eu quero que você me responda zer na mandala da dor você não precisa seguir a sequência, você vai escolher uma de cada, tá?
- Então, lembrando sempre disso, o cliente chega em dor porque ele está iludido.
- Então vocês estão desdobrados, o cliente está desdobrado num campo de proteção onde tem uma plasticidade completamente, onde tem códigos completamente diferentes.
- Eh, no momento das perguntas, nas mandalas, eh, a cada investigação de cada pergunta, né, eh, é melhor a gente discutir com ele, com o assistido, eh, o que a gente tá visualizando ali ao fim de cada pergunta ou ao fim de cada pétala?
- Então, eh, minha dúvida é a seguinte, como eu também sou humanoterapeuta, né, eu também trabalho com amiza quântica, aí aqui que nos inícios da passo a passo do trabalho, a gente coloca o assistido ou dentro código, né, do situação unidade, coloca ele na mesa.


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- E explica, é uma tecnologia espiritual canalizada que atua em três níveis, no racional, no emocional e no espiritual. e tem como objetivo identificar a raiz de um padrão, limpar o campo, abrir e abrir caminho para uma nova realidade, tá?
- Aí a pessoa vai falando, ai porque lá no meu trabalho, eu tô com muito problema com meu chefe, eu tô com medo, tá correndo risco da semana embora ou na minha casa, eu tô com muito problema na minha casa, meu relacionamento era super bom e agora parece que tá não tá bom, tá esfriando.
- Tem que falar, tem em voz alta sim, porque ele precisa autorizar e colocar magneticamente essa autorização no mundo.
- E aí você vai, pede pro assistido se conectar com o que ele precisa resolver, ou seja, a dor ou a questão que ele trouxe.
- E aí, antes disso, desculpa, antes disso que você colocou aqui, você vai fazer as perguntas da mandala do amor, ok?
- Para algumas pessoas, você relaxa ela primeiro porque ela tá com raiva, ela tá com medo, ela tá angstiada, ela tá com síndrome do pânico, ela tá com cr ansiedade.
- Agora eu vou continuo fazendo perguntas, eu quero que você me responda zer na mandala da dor você não precisa seguir a sequência, você vai escolher uma de cada, tá?
- Femino ferido, não precisa falar para ele que é feminino ferido, porque ele não não necessariamente tem ideia disso.
- Então, lembrando sempre disso, o cliente chega em dor porque ele está iludido.
- Então você vai virar o pêndulo no sentidora, fecha os olhos, relaxa, vou te harmonizar para você ir se acalmando e fica bem.
- Ó, sinta a dor chegando sem medo, sem fugir, porque só o que é sentido por inteiro pode enem ser curado.
- Sem nada que não queira, porque aí eu tô invadindo o campo do outro sem autorização do outro.


## Citações e Formulações de Alta Densidade

- “Então, sempre que a gente vai receber, a gente vai trabalhar energeticamente, nós precisamos estar prontos antes dele chegar.”
- “Então, antes do seu cliente chegar, de seu horário de abrir o zoom com ele à distância ou presencial, você precisa estar pronto, tá?”
- “E aí você vai, pede pro assistido se conectar com o que ele precisa resolver, ou seja, a dor ou a questão que ele trouxe.”
- “Agora eu vou continuo fazendo perguntas, eu quero que você me responda zer na mandala da dor você não precisa seguir a sequência, você vai escolher uma de cada, tá?”
- “Então, lembrando sempre disso, o cliente chega em dor porque ele está iludido.”
- “Então essas são as questões que a gente precisa ajudar ele a sair daquele lugar, a perceber e se se acalmando e ter consciência de tudo isso.”
- “Então, vá seguindo as orientações sobre sentir, transformar e transmutar, executando atentamente o que ele fala e vá conduzindo o processo, perguntando sempre o que ele sente que deve fazer nessa situação.”
- “Ó, sinta a dor chegando sem medo, sem fugir, porque só o que é sentido por inteiro pode enem ser curado.”
- “Da câmara humano e por isso funciona só por isso tem pequeno que a gente precisa entender que não somos nós que estamos trabalhando.”
- “Não é para terapeuta ai vou fazer uma não é trabalho, não é trabalho espiritual, não é trabalho de verdade dentro de uma linha de resgate, de uma linha de de cura de verdade, é só o gostosinho." Então, para vocês entenderem isso sim, a gente tá com a equipe, a equipe do código inocência é…”
- “Na mesa quântica, quando a gente coloca o assistido, eu já estou acessando o o campo morfogenético dele e o inconsciente.”
- “Aí eu fiquei meia confusa com isso, porque quando eu coloco assistido na mesa quântica, eu já estou as perguntas que eu faço, ele já está ali no Eu já estou assistando.”

## Conexões com a Wiki

- [[Conceito do Metodo HumanoSense]]
- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]
- [[Conceito da Camara HumanoSense]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio da Liberdade Consciente]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Enquadramento na Piramide]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Tecnica de Retorno a Consciencia e Harmonizacao]]

## FAQs para NotebookLM (Fase 2)

### Bloco 1: A Ética Clínica e o Choque de Desilusão

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
1. Como Andresa Molina define o "Princípio da Objetividade Terapêutica" e por que "dar aula" de ~~mecânica quântica~~ *(Nota: expressão não consta na transcrição original da autora)* ou espiritualidade ~~dispersa o campo magnético~~ *(Nota: expressão não consta na transcrição; a autora refere-se a 'tira o cliente da frequência' ou 'dispersa a energia')* do assistido?
2. De que maneira a ilusão do paciente atua como o principal ~~fator de adoecimento~~ *(Nota: expressão não consta na transcrição; a autora foca em 'toda dor é ilusão' e repressões somatizadas)* e por que a "desilusão" promovida pela mesa Humanosense é considerada um ~~processo curativo e libertador~~ *(Nota: expressão não consta na transcrição)*?
3. Sob a ótica do "Princípio do Consentimento", quais são as consequências vibracionais e espirituais imediatas para o terapeuta que tenta aplicar a mesa em terceiros (como maridos ou filhos) sem autorização?
4. Como Andresa Molina explica que tentar sintonizar e tratar o campo de um familiar que não pediu ajuda transforma o terapeuta em um "obsessor" e ~~quebra seu próprio escudo magnético~~ *(Nota: expressão não consta na transcrição; a autora usa 'isso é o que nos protege')*?
```

### Bloco 2: O Diagnóstico Radiestésico e a Dissonância do Campo

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
5. O que é o "Princípio do Foco Primordial" e por que desviar do objetivo primário trazido pelo assistido fragmenta e prejudica a energia da sessão?
6. O que Andresa Molina descreve como "Afetos e Desafetos" no diagnóstico clínico e de que maneira um objeto inanimado (como uma empresa, um cargo ou um carro) pode concentrar a mesma dor de perda que uma morte familiar?
7. Como Andresa Molina conceitua a expressão "Gap Vibracional" e de que forma a divergência de três pontos ou mais entre a resposta lógica (consciente) e o pêndulo (inconsciente) sinaliza a autossabotagem do ego?
8. De que forma o Humanosense se diferencia da Humanoterapia no que tange a acessar a biologia profunda, epigenética e registros ancestrais do assistido?
```

### Bloco 3: Os Mecanismos de Fuga e a Condução do Transe

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
9. Como a mente infantil (arquétipo da Donzela e do Príncipe) se protege através da "Fuga para o Universo das Possibilidades" e qual a diferença entre focar no que é "possível" e no que é "provável"?
10. Como o terapeuta deve conduzir a sua própria preparação mental e a entrada em nível "Alfa" muito antes de abrir o atendimento ao assistido, e o que a autora orienta sobre o uso clínico de incensos, velas ou músicas?
11. Qual o propósito diagnóstico de avaliar o signo e os elementos naturais (Fogo, Terra, Água, Ar) na Ficha Cinza, e como a apatia de um paciente regido pelo elemento Fogo indica patologia biológica profunda?
12. Como o terapeuta deve extrair a "síntese" da queixa do assistido durante o preenchimento da Ficha Cinza em vez de se perder no enredo ou na história contada?
```

### Bloco 4: Práticas Operacionais de Choque, Resgate e Harmonização na Mesa

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
13. Como é executado o "Rastreio Duplo" no Bloco Verde e qual a regra para parear perguntas antagônicas entre as polaridades masculina e feminina na Mandala do Amor?
14. Qual a relevância mecânica do enquadramento em Pirâmide e do testemunho vocal em voz alta no momento do ancoramento no selo central da mesa?
15. Como o terapeuta opera a transição de "estado plasmático" do assistido para a Câmara Humanosense e como se dá o comando de desdobramento?
16. De que forma o terapeuta conduz a purgação da dor ("sangramento") durante o transe e por que a autora proíbe acalmar o paciente antes que a emoção seja esgotada por inteiro?
17. Qual a diferença de comando e atuação entre a egrégora de resgate padrão (habilidade, disponibilidade e autorização) e as entidades especialistas (pedreiros, bombeiros, cirurgiões astrais)?
18. Como é aplicada a "Técnica de Avaliação de Estado" e em quais circunstâncias clínicas o terapeuta deve suspender a sessão de transe e optar apenas pela harmonização?
19. Quais são os procedimentos e comandos exatos de encerramento da câmara, incluindo a passagem do solvente cósmico, água crística e o reacoplamento de corpos sutis de 5 a 1?
20. Como o terapeuta opera o pêndulo no sentido horário infundindo a trindade "Harmoniza, Potencializa e Liberta" e como desliza o dedo para desligar o assistido da mesa?
```

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## Referência

ANDRESA MOLINA. *Aula 07 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.

---

## Aula 08 - Codigo Humanosense

# Aula 08 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `08   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 18.540 palavras; 603 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- É o seguinte, o que eu queria saber é se você recomenda a autoaplicação do humano sense, olha, porque o humanoterapeuta a gente pode se autoaplicar.
- Porque você percebeu na aplicação que aconteceu em você que por mais que você tenha feito muitas outras práticas, ele te leva para um lugar e trabalha em lugares muito diferentes de tudo aquilo que você já tinha acessado, porque a gente tem todo um trabalho, muitos códigos aí que são e códigos no sentido de são códigos mesmos que me foram trazidos e que…
- Eh, na folha de retorno à consciência, que é aquela últimazinha lá, número três, eh, no final, né, quando tira a energia do assistido da mesa e aí depois tem uma bolinha falando, ative as forças da habilidade, disponibilidade e autorização.
- Alguns tm mais mediunidade, vão perceber melhor, outros não vão perceber com tanta clareza, mas o processo acontece que entra nesse inconsciente da pessoa, nesse campo energético dela e aí a gente tem a porte espiritual e aí estão os códigos, tá?
- Então eu consegui trazer de certa maneira as duas necessidades que sempre nos pedem, né? um passo a passo estruturado que traz a segurança, não só a segurança da pessoa, mas a segurança espiritual, né, como um espaço livre para ela conseguir conduzir.
- É isso, porque pode ser que você tenha perguntado, mas eu nunca vou falar, faça isso, porque não é hipnose, não é comando de faça, é um faz sentido para você?
- E aí uma coisa que é uma coisa que eu sempre faço, quando eu percebo que a pessoa vai entrando na dor e eu vou ajudando ela, porque ela precisa sangrar, eu sempre lembro ela vai e não esquece que a gente tá aqui na sala, eu tô aqui com você, pode ir, não esquece que eu tô aqui, não esquece que a gente tá aqui.
- Então, por exemplo, eh, código humano não tem, não vai traduzir, não precisa nem traduzir código, não precisa traduzir, por exemplo, eh, orixás.
- Então, às vezes é tão inconsciente isso, mas em algum lugar ele faz uma leitura que é é é algo a nossa psiquê, né, e a psicanálise espiritualidade já traz psicanálise como um todo, ela faz associações livres por conta que não fazem sentido, mas dentro dela faz sentir.
- E aí dá lá que é cobradora mesmo, por exemplo, alguma das perguntas, vocês p ela tem consciência que ela faz, isso também é um problema porque fala, você percebe que se você ficar tentando controlar tudo, você vai ficar louca, por isso que você tá com burnout, e você tá tentando controlar todas as variáveis do mundo ou por isso que você tá com depressão,…
- Então aí aí eu fiquei assim, mas momento que a gente tá protegida de outras técnicas eu não posso falar porque não conheço a técnica, não sei quem é o quem é o orientador espiritual da técnica, quem é o dirigente espiritual do trabalho, não sei quais são as não tenho como dizer, aí eu não Mas aqui quando você faz, vocês dois estarão dentro desse campo de…
- Só que assim, quando eles me mandaram o código de rastreio já o o o produto que assim, a minha casa sempre tem alguém, nunca deixo de trer porque eu recebo de trabalho bastante coisa.

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-76
- É o seguinte, o que eu queria saber é se você recomenda a autoaplicação do humano sense, olha, porque o humanoterapeuta a gente pode se autoaplicar.
- Porque você percebeu na aplicação que aconteceu em você que por mais que você tenha feito muitas outras práticas, ele te leva para um lugar e trabalha em lugares muito diferentes de tudo aquilo que você já tinha acessado, porque a gente tem todo um trabalho, muitos códigos aí que são e códigos no sentido de são códigos mesmos que me foram trazidos e que não serão revelados, porque são muitas informações, muitas…
- Eh, na folha de retorno à consciência, que é aquela últimazinha lá, número três, eh, no final, né, quando tira a energia do assistido da mesa e aí depois tem uma bolinha falando, ative as forças da habilidade, disponibilidade e autorização.

### Bloco 2 - frases 77-152
- Alguns tm mais mediunidade, vão perceber melhor, outros não vão perceber com tanta clareza, mas o processo acontece que entra nesse inconsciente da pessoa, nesse campo energético dela e aí a gente tem a porte espiritual e aí estão os códigos, tá?
- Então eu consegui trazer de certa maneira as duas necessidades que sempre nos pedem, né? um passo a passo estruturado que traz a segurança, não só a segurança da pessoa, mas a segurança espiritual, né, como um espaço livre para ela conseguir conduzir.
- É isso, porque pode ser que você tenha perguntado, mas eu nunca vou falar, faça isso, porque não é hipnose, não é comando de faça, é um faz sentido para você?

### Bloco 3 - frases 153-228
- Então, às vezes é tão inconsciente isso, mas em algum lugar ele faz uma leitura que é é é algo a nossa psiquê, né, e a psicanálise espiritualidade já traz psicanálise como um todo, ela faz associações livres por conta que não fazem sentido, mas dentro dela faz sentir.
- Hum. foreso la imare la cura de las escenas primeras mu fuerte lo sento cuero una sensación impresante agradecerteísimo fue muy emocionante e quando você sente no corpo os códigos se restabelecendo seus códigos a sua reconexão com essa com essa parte divina que cada um de nós temos Sim, foi uma imagem de muito amor, assim que foi muitoora.
- Eu posso pendular e quando eu faço as perguntas, ao escolher as perguntas em cada pétala e tudo mais, eu posso pendular pelo menos a primeira, porque depois a segunda pergunta é sempre a correspondente, né?

### Bloco 4 - frases 229-304
- E aí dá lá que é cobradora mesmo, por exemplo, alguma das perguntas, vocês p ela tem consciência que ela faz, isso também é um problema porque fala, você percebe que se você ficar tentando controlar tudo, você vai ficar louca, por isso que você tá com burnout, e você tá tentando controlar todas as variáveis do mundo ou por isso que você tá com depressão, por exemplo, né?
- Então qualquer energia externa não se aproxima, até porque no código tem os campos e os guardiões do trabalho.
- Então aí aí eu fiquei assim, mas momento que a gente tá protegida de outras técnicas eu não posso falar porque não conheço a técnica, não sei quem é o quem é o orientador espiritual da técnica, quem é o dirigente espiritual do trabalho, não sei quais são as não tenho como dizer, aí eu não Mas aqui quando você faz, vocês dois estarão dentro desse campo de proteção, tanto o assistido quanto o o o trabalhador, tá?

### Bloco 5 - frases 305-380
- E daí eu fiquei assim, a perguntar isso para ela, porque como eu amo ser professora e eu acredito que eu fazer cursos, quer fazer todos, eh, é porque eu quero saber no racional para ter clareza emocional assim, sabe, espiritual assim.
- É assim, ó, o código ele vai ajudar porque ele é racional e ele vai ajudar muito mesmo com os seus essa parte racional, porque você não vai só pelo sentido, você vai pelo inconsciente, vai falar: "Você tá falando uma coisa, mas na verdade percebe que aqui tá diferente, não vai ajudar muito." Só que às vezes dependendo do que é, a pessoa não vai trazer para você.
- Só que assim, quando eles me mandaram o código de rastreio já o o o produto que assim, a minha casa sempre tem alguém, nunca deixo de trer porque eu recebo de trabalho bastante coisa.

### Bloco 6 - frases 381-456
- Então, onde você tá tentando falar e não tá conseguindo comunicar, o percebe até na sua vida quando você precisa, quer falar com algo alguém e não consegue fazer a ponte de comunicação.
- Ela chama, ela vai me chamar aqui, é, no chat aqui, porque daí vocês já combinam e ela já fala com você e aí vocês já marcam tranquilo.
- Ã, e outra coisa, como eu assim eu tenho uma dúvida, como eu sou humanoterapeuta, quando o paciente o assistido chega para mim com uma uma dúvida específica, né?

### Bloco 7 - frases 457-532
- Aquelas 4 horas foi só para dizer, ó, separa um tempo, porque também você pode ficar meio nervoso no começo e ficar mais cansado, precisa dar mais cansadinha de entre um um cliente outro.
- E a última pergunta rapidinho e como nessa mesa não tem um um labirinto, a gente pode colocar ele e para algum lugar norte, sul ou não precisa não precisa porque a gente não tá trabalhando com radiestesia aqui.
- A gente tá isso não é radiostesia, isso isso tá muito além de de um trabalho material e só do campo eletromagnético, tá muito Ah, então não precisa fazer essa se colocar nesse norte, né?

### Bloco 8 - frases 533-603
- Então não é você, nem é o seu racional sendo sacana, nem é o seu inconsciente, é um fractal que tá em dor, ok?
- Minha mãe me esqueceu na escola, minha mãe não abandonou, só esqueceu, mas ali ficou um uma coisa que pegou muito e enfim e ali ficou uma dor, um medo, uma angústia, coisa né?
- Tudo isso que eu tô falando, isso a gente aprende num outro lugar, assim, a gente dentro da parceria, a gente conversa um pouco sobre essas coisas todas, mas assim, porque não é sobre acender a vela, mas eu também quando eu dou um comando, eu tô dando um comando mental, trabalhando no elemental, dando uma, pegando informação, trazendo espiritualidade, tô fazendo magia em cada minuto do que eu faço na minha vida.

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Então, seja bem objetivo, não precisa contar a história inteira que eu consigo identificar pontos, porque eu já faço isso há tanto tempo, eu consigo identificar pontos importantes, tá bom?
- E aí, se eu precisar de alguma coisa, eu mesmo vou perguntando para vocês, tá? só pra gente conseguir responder o maior número de pessoas e eh dar prioridade principalmente eh para quem tá falando sobre a parte eh uma mesmo do do da da parte das técnicas, não da teoria do meu cliente, da possibilidade do será, mas efetivamente o que a gente tem aqui, tá bom?
- Então eu consegui trazer de certa maneira as duas necessidades que sempre nos pedem, né? um passo a passo estruturado que traz a segurança, não só a segurança da pessoa, mas a segurança espiritual, né, como um espaço livre para ela conseguir conduzir.
- É isso, porque pode ser que você tenha perguntado, mas eu nunca vou falar, faça isso, porque não é hipnose, não é comando de faça, é um faz sentido para você?
- E aí uma coisa que é uma coisa que eu sempre faço, quando eu percebo que a pessoa vai entrando na dor e eu vou ajudando ela, porque ela precisa sangrar, eu sempre lembro ela vai e não esquece que a gente tá aqui na sala, eu tô aqui com você, pode ir, não esquece que eu tô aqui, não esquece que a gente tá aqui.
- Então, por exemplo, eh, código humano não tem, não vai traduzir, não precisa nem traduzir código, não precisa traduzir, por exemplo, eh, orixás.
- Então, às vezes é tão inconsciente isso, mas em algum lugar ele faz uma leitura que é é é algo a nossa psiquê, né, e a psicanálise espiritualidade já traz psicanálise como um todo, ela faz associações livres por conta que não fazem sentido, mas dentro dela faz sentir.
- Eu posso pendular e quando eu faço as perguntas, ao escolher as perguntas em cada pétala e tudo mais, eu posso pendular pelo menos a primeira, porque depois a segunda pergunta é sempre a correspondente, né?
- E ela fala: "Ah, eu mente mesmo não vou deixar ir, não gosto daquela nora, não vou vou falar que meu filho vai ficar aqui, vou falar mal dela e não vou dar o dinheiro porque não quero, porque eu não quero que eles vão um exemplo, entendeu?" E aí ela quer mudar, essa relação nunca vai melhorar, porque você tá fazendo isso e tem consciência que tá fazendo.
- Só que assim, quando eles me mandaram o código de rastreio já o o o produto que assim, a minha casa sempre tem alguém, nunca deixo de trer porque eu recebo de trabalho bastante coisa.

## Conceitos-Chave Extraídos

- Então vocês acessam, mas os códigos lhe acessam a partir de um trabalho comum, espiritual e material de cada um de nós, né?
- Porque você percebeu na aplicação que aconteceu em você que por mais que você tenha feito muitas outras práticas, ele te leva para um lugar e trabalha em lugares muito diferentes de tudo aquilo que você já tinha acessado, porque a gente tem todo um trabalho, muitos códigos aí que são e códigos no sentido de são códigos mesmos que me foram trazidos e que…
- Eh, na folha de retorno à consciência, que é aquela últimazinha lá, número três, eh, no final, né, quando tira a energia do assistido da mesa e aí depois tem uma bolinha falando, ative as forças da habilidade, disponibilidade e autorização.
- Alguns tm mais mediunidade, vão perceber melhor, outros não vão perceber com tanta clareza, mas o processo acontece que entra nesse inconsciente da pessoa, nesse campo energético dela e aí a gente tem a porte espiritual e aí estão os códigos, tá?
- Então eu consegui trazer de certa maneira as duas necessidades que sempre nos pedem, né? um passo a passo estruturado que traz a segurança, não só a segurança da pessoa, mas a segurança espiritual, né, como um espaço livre para ela conseguir conduzir.
- Então, por exemplo, eh, código humano não tem, não vai traduzir, não precisa nem traduzir código, não precisa traduzir, por exemplo, eh, orixás.
- Hum. foreso la imare la cura de las escenas primeras mu fuerte lo sento cuero una sensación impresante agradecerteísimo fue muy emocionante e quando você sente no corpo os códigos se restabelecendo seus códigos a sua reconexão com essa com essa parte divina que cada um de nós temos Sim, foi uma imagem de muito amor, assim que foi muitoora.
- E aí dá lá que é cobradora mesmo, por exemplo, alguma das perguntas, vocês p ela tem consciência que ela faz, isso também é um problema porque fala, você percebe que se você ficar tentando controlar tudo, você vai ficar louca, por isso que você tá com burnout, e você tá tentando controlar todas as variáveis do mundo ou por isso que você tá com depressão,…
- E ela fala: "Ah, eu mente mesmo não vou deixar ir, não gosto daquela nora, não vou vou falar que meu filho vai ficar aqui, vou falar mal dela e não vou dar o dinheiro porque não quero, porque eu não quero que eles vão um exemplo, entendeu?" E aí ela quer mudar, essa relação nunca vai melhorar, porque você tá fazendo isso e tem consciência que tá fazendo.
- E aí com todo o estudo que a gente fez, então vou sugerir todo mundo, gente, revisite os vídeos dos conceitos, porque a parte terapia e a explicação tá nos conceitos, que são os primeiros vídeos da da do curso todo.
- Aqui no manuscense você falou que a gente tá mais dentro pessoa, então fica imaginando se a pessoa está se visualizando no campo, eu também provavelmente vou começar a visualizar isso.
- Então, a minha pergunta era justamente sobre a ativação do da chama trina e sobre as iniciações, mas daí você já respondeu que foi na aula passada, né?
- Então qualquer energia externa não se aproxima, até porque no código tem os campos e os guardiões do trabalho.
- Então aí aí eu fiquei assim, mas momento que a gente tá protegida de outras técnicas eu não posso falar porque não conheço a técnica, não sei quem é o quem é o orientador espiritual da técnica, quem é o dirigente espiritual do trabalho, não sei quais são as não tenho como dizer, aí eu não Mas aqui quando você faz, vocês dois estarão dentro desse campo de…
- É assim, ó, o código ele vai ajudar porque ele é racional e ele vai ajudar muito mesmo com os seus essa parte racional, porque você não vai só pelo sentido, você vai pelo inconsciente, vai falar: "Você tá falando uma coisa, mas na verdade percebe que aqui tá diferente, não vai ajudar muito." Só que às vezes dependendo do que é, a pessoa não vai trazer para…
- Só que assim, quando eles me mandaram o código de rastreio já o o o produto que assim, a minha casa sempre tem alguém, nunca deixo de trer porque eu recebo de trabalho bastante coisa.


## Técnicas, Procedimentos e Orientações Práticas

- Então, seja bem objetivo, não precisa contar a história inteira que eu consigo identificar pontos, porque eu já faço isso há tanto tempo, eu consigo identificar pontos importantes, tá bom?
- E aí, se eu precisar de alguma coisa, eu mesmo vou perguntando para vocês, tá? só pra gente conseguir responder o maior número de pessoas e eh dar prioridade principalmente eh para quem tá falando sobre a parte eh uma mesmo do do da da parte das técnicas, não da teoria do meu cliente, da possibilidade do será, mas efetivamente o que a gente tem aqui, tá bom?
- É o seguinte, o que eu queria saber é se você recomenda a autoaplicação do humano sense, olha, porque o humanoterapeuta a gente pode se autoaplicar.
- Enquanto você não fizer aplicação em outras pessoas, entender qual é o processo, decorar todas as falas, porque a primeira coisa você não pode estar de olho aberto para fazer sua auto aplicação.
- Porque você percebeu na aplicação que aconteceu em você que por mais que você tenha feito muitas outras práticas, ele te leva para um lugar e trabalha em lugares muito diferentes de tudo aquilo que você já tinha acessado, porque a gente tem todo um trabalho, muitos códigos aí que são e códigos no sentido de são códigos mesmos que me foram trazidos e que…
- Eh, na folha de retorno à consciência, que é aquela últimazinha lá, número três, eh, no final, né, quando tira a energia do assistido da mesa e aí depois tem uma bolinha falando, ative as forças da habilidade, disponibilidade e autorização.
- Inclusive os comandos, as perguntas, eu só transcrevi tudo, tá Andresa, transcrevi tudo porque para enxergar melhor e poder copiar e colar, né?
- Então eu consegui trazer de certa maneira as duas necessidades que sempre nos pedem, né? um passo a passo estruturado que traz a segurança, não só a segurança da pessoa, mas a segurança espiritual, né, como um espaço livre para ela conseguir conduzir.
- É isso, porque pode ser que você tenha perguntado, mas eu nunca vou falar, faça isso, porque não é hipnose, não é comando de faça, é um faz sentido para você?
- Eu posso pendular e quando eu faço as perguntas, ao escolher as perguntas em cada pétala e tudo mais, eu posso pendular pelo menos a primeira, porque depois a segunda pergunta é sempre a correspondente, né?
- E aí dá lá que é cobradora mesmo, por exemplo, alguma das perguntas, vocês p ela tem consciência que ela faz, isso também é um problema porque fala, você percebe que se você ficar tentando controlar tudo, você vai ficar louca, por isso que você tá com burnout, e você tá tentando controlar todas as variáveis do mundo ou por isso que você tá com depressão,…
- Revisite aqui, vocês vão ter bastante tempo para reassistir aquilo, reviseite quantas vezes vocês precisarem, porque aquilo vai dar muito material de comunicação com com o cliente, tá bom?
- Aqui no manuscense você falou que a gente tá mais dentro pessoa, então fica imaginando se a pessoa está se visualizando no campo, eu também provavelmente vou começar a visualizar isso.
- Então aí aí eu fiquei assim, mas momento que a gente tá protegida de outras técnicas eu não posso falar porque não conheço a técnica, não sei quem é o quem é o orientador espiritual da técnica, quem é o dirigente espiritual do trabalho, não sei quais são as não tenho como dizer, aí eu não Mas aqui quando você faz, vocês dois estarão dentro desse campo de…


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- É o seguinte, o que eu queria saber é se você recomenda a autoaplicação do humano sense, olha, porque o humanoterapeuta a gente pode se autoaplicar.
- Enquanto você não fizer aplicação em outras pessoas, entender qual é o processo, decorar todas as falas, porque a primeira coisa você não pode estar de olho aberto para fazer sua auto aplicação.
- Depende do tamanho da ferida que você consegue cutucar em você, porque não adianta você fazer lá todo o seu trabalho, todo o processo de desdobramento e não ter coragem de cutucar ferida para ela sangrar, entende?
- Eh, na folha de retorno à consciência, que é aquela últimazinha lá, número três, eh, no final, né, quando tira a energia do assistido da mesa e aí depois tem uma bolinha falando, ative as forças da habilidade, disponibilidade e autorização.
- E aí uma coisa que é uma coisa que eu sempre faço, quando eu percebo que a pessoa vai entrando na dor e eu vou ajudando ela, porque ela precisa sangrar, eu sempre lembro ela vai e não esquece que a gente tá aqui na sala, eu tô aqui com você, pode ir, não esquece que eu tô aqui, não esquece que a gente tá aqui.
- Porque é como se, sabe um sonho onde você desdobra num lugar tão profundo, que eles sonhos tão vividos e tão los, que você desdobre, que daí não é exatamente um sonho, não só um sonho, que você desdobra num lugar tão e aí imagina que alguma parte sua te e aí você tá com medo, fala vai, pode ir porque nós estamos dormindo, ó, lembra disso.
- E aí dá lá que é cobradora mesmo, por exemplo, alguma das perguntas, vocês p ela tem consciência que ela faz, isso também é um problema porque fala, você percebe que se você ficar tentando controlar tudo, você vai ficar louca, por isso que você tá com burnout, e você tá tentando controlar todas as variáveis do mundo ou por isso que você tá com depressão,…
- Que venha para você como base de informação mesmo, porque existem vários tipos de captador, né?
- Então existem os captadores que são mais sensíveis e captam mais pro corpo e tem mais sensibilidade e outros que são mais racionais, né?
- Então aí aí eu fiquei assim, mas momento que a gente tá protegida de outras técnicas eu não posso falar porque não conheço a técnica, não sei quem é o quem é o orientador espiritual da técnica, quem é o dirigente espiritual do trabalho, não sei quais são as não tenho como dizer, aí eu não Mas aqui quando você faz, vocês dois estarão dentro desse campo de…
- Então não é você, nem é o seu racional sendo sacana, nem é o seu inconsciente, é um fractal que tá em dor, ok?
- Minha mãe me esqueceu na escola, minha mãe não abandonou, só esqueceu, mas ali ficou um uma coisa que pegou muito e enfim e ali ficou uma dor, um medo, uma angústia, coisa né?


## Citações e Formulações de Alta Densidade

- “Então, seja bem objetivo, não precisa contar a história inteira que eu consigo identificar pontos, porque eu já faço isso há tanto tempo, eu consigo identificar pontos importantes, tá bom?”
- “E aí, se eu precisar de alguma coisa, eu mesmo vou perguntando para vocês, tá? só pra gente conseguir responder o maior número de pessoas e eh dar prioridade principalmente eh para quem tá falando sobre a parte eh uma mesmo do do da da parte das técnicas, não da teoria do meu cliente, da…”
- “Eh, na folha de retorno à consciência, que é aquela últimazinha lá, número três, eh, no final, né, quando tira a energia do assistido da mesa e aí depois tem uma bolinha falando, ative as forças da habilidade, disponibilidade e autorização.”
- “Então eu consegui trazer de certa maneira as duas necessidades que sempre nos pedem, né? um passo a passo estruturado que traz a segurança, não só a segurança da pessoa, mas a segurança espiritual, né, como um espaço livre para ela conseguir conduzir.”
- “É isso, porque pode ser que você tenha perguntado, mas eu nunca vou falar, faça isso, porque não é hipnose, não é comando de faça, é um faz sentido para você?”
- “E aí uma coisa que é uma coisa que eu sempre faço, quando eu percebo que a pessoa vai entrando na dor e eu vou ajudando ela, porque ela precisa sangrar, eu sempre lembro ela vai e não esquece que a gente tá aqui na sala, eu tô aqui com você, pode ir, não esquece que eu tô aqui, não esquece que a…”
- “Porque é como se, sabe um sonho onde você desdobra num lugar tão profundo, que eles sonhos tão vividos e tão los, que você desdobre, que daí não é exatamente um sonho, não só um sonho, que você desdobra num lugar tão e aí imagina que alguma parte sua te e aí você tá com medo, fala vai, pode ir…”
- “Então, por exemplo, eh, código humano não tem, não vai traduzir, não precisa nem traduzir código, não precisa traduzir, por exemplo, eh, orixás.”
- “Hum. foreso la imare la cura de las escenas primeras mu fuerte lo sento cuero una sensación impresante agradecerteísimo fue muy emocionante e quando você sente no corpo os códigos se restabelecendo seus códigos a sua reconexão com essa com essa parte divina que cada um de nós temos Sim, foi uma…”
- “Eu posso pendular e quando eu faço as perguntas, ao escolher as perguntas em cada pétala e tudo mais, eu posso pendular pelo menos a primeira, porque depois a segunda pergunta é sempre a correspondente, né?”
- “Então aí aí eu fiquei assim, mas momento que a gente tá protegida de outras técnicas eu não posso falar porque não conheço a técnica, não sei quem é o quem é o orientador espiritual da técnica, quem é o dirigente espiritual do trabalho, não sei quais são as não tenho como dizer, aí eu não Mas aqui…”
- “Só que assim, quando eles me mandaram o código de rastreio já o o o produto que assim, a minha casa sempre tem alguém, nunca deixo de trer porque eu recebo de trabalho bastante coisa.”

## Conexões com a Wiki

- [[Conceito do Metodo HumanoSense]]
- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio da Liberdade Consciente]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Enquadramento na Piramide]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Tecnica de Retorno a Consciencia e Harmonizacao]]

## FAQs para NotebookLM (Fase 2)

### Bloco 1: A Ética Clínica do Transe e a Autossustentação

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
1. Como Andresa Molina justifica a proibição de dar ordens ao assistido durante o desdobramento na ~~Câmara Astral~~ *(Nota: expressão não consta na transcrição; a autora usa 'Câmara Humanosense' ou 'campo energético')*, e de que forma a condução por "convites e perguntas" preserva o livre-arbítrio?
2. Por que a autora proíbe terminantemente o toque físico (abraços, acolhimento corporal) no momento em que o assistido está vivenciando a catarse e o choro na sessão?
3. Como o terapeuta deve agir caso o assistido "amoleça" ou pareça estar prestes a cair da cadeira durante a purgação da dor, e qual a importância somática de forçá-lo a sustentar o próprio corpo físico?
4. Qual a postura exigida do terapeuta perante reações de ~~expurgo biológico~~ *(Nota: expressão não consta na transcrição; a autora usa 'processo natural de colocar para fora')* (enjoos, tosse, ânsias de vômito) do assistido, e como a naturalidade clínica impede a "criação de monstros"?
```

### Bloco 2: Os Impedimentos Familiares e a Troca de Atendimentos

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
5. Por que Andresa Molina recomenda o impedimento clínico de tratar familiares próximos (como filhos ou cônjuges) e de que maneira o ego da relação familiar contamina a egrégora da mesa?
6. Sob a ótica do "Princípio do Posicionamento de Valor", por que o terapeuta não deve fazer a devolução financeira para clientes que decidem ir embora no meio da sessão após o choque de realidade?
7. Por que a autora recusa administrativamente organizar duplas de troca "sorteadas" de atendimentos entre os alunos, e de que forma essa proibição respeita a lei de ressonância e fluxo magnético?
8. De que maneira a mesa Humanosense identifica e desfaz a "Personalidade Sombra" (Cobrador, Explorador, Limitador) quando o consciente do cliente nega possuir esses comportamentos de dor?
```

### Bloco 3: As Estruturas de Luto, Ilusão e Genética Celular

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
9. Como a criança ferida se protege na "Fantasia de Salvamento Infantil" e como esse abismo de carência de amparo sabota os relacionamentos e a vida profissional do adulto?
10. Como o luto mal resolvido provoca o "Deslocamento de Função" no sistema familiar e de que forma a mesa e a câmara corrigem a filha que assume a função de esposa energética de seu pai viúvo?
11. De que forma a mesa Humanosense se diferencia conceitualmente da Humanoterapia (limpeza passiva realizada de fora para dentro pelo terapeuta) e da Regressão Comum?
12. Por que Andresa Molina sustenta que o padrasto, por mais amor e cuidado que ofereça, jamais substitui o elo biológico do pai na biologia de defesa celular do assistido?
```

### Bloco 4: Didática Radiestésica e Ancoramento Somático

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
13. O que acusa o diagnóstico de "Ausência de Kundalini" (a pessoa não sente prazer nem calor) ao tentar fecundar e plantar a semente de futuro no útero esvaziado?
14. Como a tecnologia do Humanosense atua acelerando a mediunidade de terapeutas extremamente racionais de forma orgânica, sem alterar a sua configuração neurológica natural?
15. Como a autora conceitua a "Magia Prática" no Humanosense e de que maneira as reclamações repetidas e o ódio diário ativam e manipulam as forças elementais contra a própria pessoa?
16. Qual a relevância neurológica do intestino ("cérebro entérico") no processo de depressão inflamatória e como as marcas somáticas viscerais conduzem o corpo do assistido?
17. Por que Andresa Molina exige que o atendimento do Humanosense ocorra com o cliente sentado em uma cadeira, proibindo a catarse de sangramento deitada de costas na maca?
18. Quais os riscos e dificuldades mecânicas enfrentados por terapeutas iniciantes ao tentar realizar a autoaplicação do Código Humanosense?
19. Como o terapeuta deve usar a própria voz como "ancoramento na cena" durante o desdobramento profundo para que o assistido sinta segurança somática diante do terror do passado?
20. Como o terapeuta opera as frequências de "Harmoniza, Potencializa e Liberta" com o pêndulo no encerramento e de que forma desconecta fisicamente a energia do assistido da mesa?
21. Quais são as regras e limites concedidos pela autora para a tradução e internacionalização de comandos em outros idiomas sem perder a raiz nominal em português?
22. Quais as consequências de permitir que o pêndulo decida de forma cega qual pergunta diagnóstica fazer nas mandalas e qual a responsabilidade do terapeuta de "dar o nó no pingo d'água"?
23. Como é conduzido o rebaixamento cerebral (Alfa) com a contagem decrescente, incluindo o relaxamento abdominal na marca do "555" para estabilizar o batimento cardíaco?
24. Quais os limites de tempo teto recomendados para a sessão do Humanosense e quais as faixas de honorários indicadas para o posicionamento High-Ticket?
```

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## Referência

ANDRESA MOLINA. *Aula 08 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.

---

## Aula 09 - Codigo Humanosense

# Aula 09 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `09   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 12.797 palavras; 448 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- É claro que uma é completamente diferente da outra, né? não tem um atendimento que é igual, eles são completamente diferentes, porque eles são eh o o campo energético, espiritual, inconsciente da pessoa.
- Então, nós vamos conduzi-la no inconsciente, no energético e no espiritual, no plano multidimensional de outras vidas, enfim, da pessoa.
- Então, eh, nós temos uma base estruturada, né, de como fazer e aí tem aquele momento em que o terapeuta tem que ter a habilidade.
- Então, eu vou trazer aqui um pouquinho onde aquilo flui de uma maneira natural e precisa ter um processo de presença e de condução, de escuta, atenta e condução daquele processo.
- Porque quanto mais você fizer, mais habilidade você vai tendo, mais você conecta com o campo da pessoa dentro da Câmara Humanocense.
- Eu queria saber se de vocês que estão com as mãos levantadas se tem alguém que não passou por nada, nunca foi cliente do espaço humanidade, nunca fez metodologia terapeuta, nunca fez código não sabe de nada.
- Então eu só vou pedir para você e vou te pedir um favor que você fale e eu vou perguntar e aí eu gostaria que você repetisse seu nome completo em data de nascimento e dissesse eu, Patrícia, nome completo, e autorizo a divulgação dessa imagem pro código tá só pra gente deixar esse documentado para não ter problema.
- Porque você disse, e eu te fiz uma pergunta lá atrás que que falou agora, conforme eu falei da confiança, eu me lembrei e vou falar o que eu estou sentindo, que eu acho que eu não recebi dos meus pais o afeto, né, o amor, enfim, que eu deveria, que eu merecia o que eu precisava.
- Eu estou a falar, eu estou triste, eu estou com medo, falo tudo que você, eu estou triste, eu estou com medo, eu estou perdida, eu não consigo perceber o que é que se está a passar, nem consigo que as coisas entrem na minha cabeça, porque eu estou sempre a pensar outras coisas e eu estou sempre a tentar entender porque é que eu não não sou vista, porque é…
- Mas assim, se por acaso vocês não tivessem visto nada disso, não soubesse nome, não importa a energia que vem fazer esses recolhimentos de almas, de frações que precisam de cuidado, né, de um pequeno nível ali daquela consciência dela que você encontrou que tava perdido, que tava precisando de ajuda e você falou: "Não consigo ajudar", mas ele precisava de…
- E aí depois eu, se fosse meu cliente e eu precisasse usar essas fichinhas, eu apagaria e colocaria a pergunta aqui, porque depois quando eu for falar com ele aqui três meses, que ele quis quer fazer outro manência, por exemplo, eu sei o que aconteceu aqui.
- E todo o estudo, todo o processo de entendimento de padrão, isso facilita, mas não significa que vocês não vão conseguir conduzir todo o processo, porque a equipe espiritual da Câmara Manuciense tá atuando.

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-56
- É claro que uma é completamente diferente da outra, né? não tem um atendimento que é igual, eles são completamente diferentes, porque eles são eh o o campo energético, espiritual, inconsciente da pessoa.
- Eu queria saber se de vocês que estão com as mãos levantadas se tem alguém que não passou por nada, nunca foi cliente do espaço humanidade, nunca fez metodologia terapeuta, nunca fez código não sabe de nada.
- Então eu só vou pedir para você e vou te pedir um favor que você fale e eu vou perguntar e aí eu gostaria que você repetisse seu nome completo em data de nascimento e dissesse eu, Patrícia, nome completo, e autorizo a divulgação dessa imagem pro código tá só pra gente deixar esse documentado para não ter problema.

### Bloco 2 - frases 57-112
- A dificuldade que eu tenho é materializar e eu com o curso percebi que preciso de equilibrar a minha energia masculina e feminina.
- Então, não é sobre materializar o ser terapeuta, você se sente terapeuta, você já é terapeuta, você não tem clientes, é sobre viver de terapia e não sobre ser terapeuta, só para eu entender melhor onde tá esse perceb?
- Então tô colocando, tô construindo aqui uma pirâmide nessa sala virtual, colocando eu padrista Martins dentro da pirâmide, isolando essa pirâmide e isso de toda e qualquer energia que seja ausente de nós duas dentro desse campo de força de proteção.

### Bloco 3 - frases 113-168
- OK. aqui o que uma das coisas que ficaram bem latentes e que eu acho que é importante você observar é que quando você traz a sua questão principal, quando você eh quando você traz a sobre a materialização, eh aí você fala, né, tem aquela aquele viés invertido de segurança, ter ter o cliente para ter segurança, aí a gente conversou sobre ter a segurança para depois poder ter o cliente.
- Então, o quanto você está sem paciência, né, para construir, para se tornar a terapeuta, porque olha, a sua pergunta principal foi: "Eu quero materializar ser terapeuta".
- Então, materializar ser terapeuta significa estudar, significa buscar aperfeiçoamento.

### Bloco 4 - frases 169-224
- Aí eu vou me sentir confiante e vou conseguir materializar os meus clientes, automaticamente eu vou me sentir pronto o suficiente para atendê-lo.
- Quando você precisa ir para a batalha, se pôr na linha de frente, fazer as experiências, fazer gratuito, fazer cobrando barato, fazer nas pessoas isso que você tá aprendendo, então estudei bastante, legal, faz um ano e pouco tô estudando, acho legal, tá?
- Relacionamento nesse caso é se você for progredir, tá, como terapeuta, materializar e conseguir viver bem disso, ter os clientes, enfim, o quanto você acredita que tem dois pontos aqui que eu quero perguntar para você para entender se é mais um ou mais o outro.

### Bloco 5 - frases 225-280
- Porque você disse, e eu te fiz uma pergunta lá atrás que que falou agora, conforme eu falei da confiança, eu me lembrei e vou falar o que eu estou sentindo, que eu acho que eu não recebi dos meus pais o afeto, né, o amor, enfim, que eu deveria, que eu merecia o que eu precisava.
- Só que agora você tem uma um agora com essa conversa que a gente teve, a o seu desejo está mais alinhado, porque você entende que para ser terapeuta você precisa experienciar, ganhar a confiança, não ganhar, não ter cliente.
- O que que a gente Então mudou tudo porque você chegou querer materializar uma coisa e eu tô te dando consciência que tá vendo como não é isso ou tem algo a mais e aí você fala que você não se sentiu.

### Bloco 6 - frases 281-336
- Repare que a respiração já tá mais calma, que os batimentos cardíacos já estão mais tranquilos, que tudo já tá mais leve.
- Ajusto a coordenada e códigos de acesso para abertura da câmara humanocense anexa ao hospital astral do espaço de humanidade.
- Eu estou a falar, eu estou triste, eu estou com medo, falo tudo que você, eu estou triste, eu estou com medo, eu estou perdida, eu não consigo perceber o que é que se está a passar, nem consigo que as coisas entrem na minha cabeça, porque eu estou sempre a pensar outras coisas e eu estou sempre a tentar entender porque é que eu não não sou vista, porque é que vocês não me ajudam, porque é que vocês não não falam…

### Bloco 7 - frases 337-392
- Tô enquadrando essa cena, fazendo tratamento convencional, trazendo a energia de todo balu aí e recolhendo toda e qualquer consciência que tenha ficado nesse plano de nos planos astrais dessa fração, dessa consciência que precisa seguir colocando muito amor, muito caminho.
- Então eu consegui identificar que você tava muito acreditando que era a guerreira, mas quando você tá na guerreira guerreando, eu tô, eu tô fazendo, mas você não está fazendo porque só no seu inconsciente, na verdade, ele não tá fazendo, eu percebo que você não está tão na guerreira, você tá na donzela porque você tá acreditando que tá fazendo uma coisa que não tá.
- Mas assim, se por acaso vocês não tivessem visto nada disso, não soubesse nome, não importa a energia que vem fazer esses recolhimentos de almas, de frações que precisam de cuidado, né, de um pequeno nível ali daquela consciência dela que você encontrou que tava perdido, que tava precisando de ajuda e você falou: "Não consigo ajudar", mas ele precisava de ajuda e eu falei: "Você quer?" você ajudou porque o tempo em…

### Bloco 8 - frases 393-448
- E aí depois eu, se fosse meu cliente e eu precisasse usar essas fichinhas, eu apagaria e colocaria a pergunta aqui, porque depois quando eu for falar com ele aqui três meses, que ele quis quer fazer outro manência, por exemplo, eu sei o que aconteceu aqui.
- E porque o que eu falei com a Patrícia, ela falou, ela trouxe todas essas perguntas, síntese do sentimento, qual era o sentimento?
- E todo o estudo, todo o processo de entendimento de padrão, isso facilita, mas não significa que vocês não vão conseguir conduzir todo o processo, porque a equipe espiritual da Câmara Manuciense tá atuando.

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Então, eh, nós temos uma base estruturada, né, de como fazer e aí tem aquele momento em que o terapeuta tem que ter a habilidade.
- Então, eu vou trazer aqui um pouquinho onde aquilo flui de uma maneira natural e precisa ter um processo de presença e de condução, de escuta, atenta e condução daquele processo.
- Eu queria saber se de vocês que estão com as mãos levantadas se tem alguém que não passou por nada, nunca foi cliente do espaço humanidade, nunca fez metodologia terapeuta, nunca fez código não sabe de nada.
- Porque você disse, e eu te fiz uma pergunta lá atrás que que falou agora, conforme eu falei da confiança, eu me lembrei e vou falar o que eu estou sentindo, que eu acho que eu não recebi dos meus pais o afeto, né, o amor, enfim, que eu deveria, que eu merecia o que eu precisava.
- Só que agora você tem uma um agora com essa conversa que a gente teve, a o seu desejo está mais alinhado, porque você entende que para ser terapeuta você precisa experienciar, ganhar a confiança, não ganhar, não ter cliente.
- Eu acho que eu não consigo, acho que eu não sou tão forte assim, porque mas aqui você é porque você é, só que você não tá fazendo porque não lhe foi permitido fazer, porque te protegeram, não desconsideraram não por maldade, mas por falta de enfim de conhecimento, enfim, de tudo que quero que você não se sentiu amada porque justamente por isso, não é o…
- Eu estou a falar, eu estou triste, eu estou com medo, falo tudo que você, eu estou triste, eu estou com medo, eu estou perdida, eu não consigo perceber o que é que se está a passar, nem consigo que as coisas entrem na minha cabeça, porque eu estou sempre a pensar outras coisas e eu estou sempre a tentar entender porque é que eu não não sou vista, porque é…
- Tô enquadrando essa cena, fazendo tratamento convencional, trazendo a energia de todo balu aí e recolhendo toda e qualquer consciência que tenha ficado nesse plano de nos planos astrais dessa fração, dessa consciência que precisa seguir colocando muito amor, muito caminho.
- Mas assim, se por acaso vocês não tivessem visto nada disso, não soubesse nome, não importa a energia que vem fazer esses recolhimentos de almas, de frações que precisam de cuidado, né, de um pequeno nível ali daquela consciência dela que você encontrou que tava perdido, que tava precisando de ajuda e você falou: "Não consigo ajudar", mas ele precisava de…
- E aí depois eu, se fosse meu cliente e eu precisasse usar essas fichinhas, eu apagaria e colocaria a pergunta aqui, porque depois quando eu for falar com ele aqui três meses, que ele quis quer fazer outro manência, por exemplo, eu sei o que aconteceu aqui.

## Conceitos-Chave Extraídos

- É claro que uma é completamente diferente da outra, né? não tem um atendimento que é igual, eles são completamente diferentes, porque eles são eh o o campo energético, espiritual, inconsciente da pessoa.
- Então, eh, nós temos uma base estruturada, né, de como fazer e aí tem aquele momento em que o terapeuta tem que ter a habilidade.
- Porque quanto mais você fizer, mais habilidade você vai tendo, mais você conecta com o campo da pessoa dentro da Câmara Humanocense.
- Então é uma capacidade é que a gente vai desenvolvendo uma musculatura energética e espiritual, um campo de atuação que é um desenvolvimento mediúnico também, tá?
- Sem falar que a gente vai criando muito mais segurança, né? e entendendo de cara que sim, todos serão diferentes uns dos outros, porque são pessoas diferentes, com histórias diferentes, com códigos eh que que são eh desconectados de maneira diferente, enfim, só praticando.
- Eu queria saber se de vocês que estão com as mãos levantadas se tem alguém que não passou por nada, nunca foi cliente do espaço humanidade, nunca fez metodologia terapeuta, nunca fez código não sabe de nada.
- Então eu só vou pedir para você e vou te pedir um favor que você fale e eu vou perguntar e aí eu gostaria que você repetisse seu nome completo em data de nascimento e dissesse eu, Patrícia, nome completo, e autorizo a divulgação dessa imagem pro código tá só pra gente deixar esse documentado para não ter problema.
- Então Patrícia você e autoriza a divulgação desse material, né, do seu do seu vídeo pr pr as aulas do código Martins autoriza a divulgação desse material pro código aqui.
- Então tô colocando, tô construindo aqui uma pirâmide nessa sala virtual, colocando eu padrista Martins dentro da pirâmide, isolando essa pirâmide e isso de toda e qualquer energia que seja ausente de nós duas dentro desse campo de força de proteção.
- Então, materializar ser terapeuta significa estudar, significa buscar aperfeiçoamento.
- O que que a gente Então mudou tudo porque você chegou querer materializar uma coisa e eu tô te dando consciência que tá vendo como não é isso ou tem algo a mais e aí você fala que você não se sentiu.
- Tô enquadrando essa cena, fazendo tratamento convencional, trazendo a energia de todo balu aí e recolhendo toda e qualquer consciência que tenha ficado nesse plano de nos planos astrais dessa fração, dessa consciência que precisa seguir colocando muito amor, muito caminho.
- E ali e depois eu senti muito a energia de de eu vou eu vou chamar não sei se você tem conhecimento, mas como é um conhecimento para mim seria energia de um lu que traz resgates de alma e cois mais ainda que vocês não não soubessem o que é a veio, veio para resgatar outro nome mesia isso.
- Mas assim, se por acaso vocês não tivessem visto nada disso, não soubesse nome, não importa a energia que vem fazer esses recolhimentos de almas, de frações que precisam de cuidado, né, de um pequeno nível ali daquela consciência dela que você encontrou que tava perdido, que tava precisando de ajuda e você falou: "Não consigo ajudar", mas ele precisava de…
- E todo o estudo, todo o processo de entendimento de padrão, isso facilita, mas não significa que vocês não vão conseguir conduzir todo o processo, porque a equipe espiritual da Câmara Manuciense tá atuando.
- Então este essa parte do meio, ela é muito fluída e a prática, a experiência, os exemplos, milhares de exemplos é o que vai facilitar muito esse processo, tá bom?


## Técnicas, Procedimentos e Orientações Práticas

- É claro que uma é completamente diferente da outra, né? não tem um atendimento que é igual, eles são completamente diferentes, porque eles são eh o o campo energético, espiritual, inconsciente da pessoa.
- Então, eu vou trazer aqui um pouquinho onde aquilo flui de uma maneira natural e precisa ter um processo de presença e de condução, de escuta, atenta e condução daquele processo.
- Não pode cair, porque a gente tá aqui numa apresentação, né, Andresa, mas até acabei de responder uma pergunta agora lá no na no canal eh humanos.
- Eu queria saber se de vocês que estão com as mãos levantadas se tem alguém que não passou por nada, nunca foi cliente do espaço humanidade, nunca fez metodologia terapeuta, nunca fez código não sabe de nada.
- Então eu só vou pedir para você e vou te pedir um favor que você fale e eu vou perguntar e aí eu gostaria que você repetisse seu nome completo em data de nascimento e dissesse eu, Patrícia, nome completo, e autorizo a divulgação dessa imagem pro código tá só pra gente deixar esse documentado para não ter problema.
- Então, não é sobre materializar o ser terapeuta, você se sente terapeuta, você já é terapeuta, você não tem clientes, é sobre viver de terapia e não sobre ser terapeuta, só para eu entender melhor onde tá esse perceb?
- Então, o quanto você está sem paciência, né, para construir, para se tornar a terapeuta, porque olha, a sua pergunta principal foi: "Eu quero materializar ser terapeuta".
- Aí eu vou me sentir confiante e vou conseguir materializar os meus clientes, automaticamente eu vou me sentir pronto o suficiente para atendê-lo.
- Relacionamento nesse caso é se você for progredir, tá, como terapeuta, materializar e conseguir viver bem disso, ter os clientes, enfim, o quanto você acredita que tem dois pontos aqui que eu quero perguntar para você para entender se é mais um ou mais o outro.
- Porque você disse, e eu te fiz uma pergunta lá atrás que que falou agora, conforme eu falei da confiança, eu me lembrei e vou falar o que eu estou sentindo, que eu acho que eu não recebi dos meus pais o afeto, né, o amor, enfim, que eu deveria, que eu merecia o que eu precisava.
- Só que agora você tem uma um agora com essa conversa que a gente teve, a o seu desejo está mais alinhado, porque você entende que para ser terapeuta você precisa experienciar, ganhar a confiança, não ganhar, não ter cliente.
- Então eu consegui identificar que você tava muito acreditando que era a guerreira, mas quando você tá na guerreira guerreando, eu tô, eu tô fazendo, mas você não está fazendo porque só no seu inconsciente, na verdade, ele não tá fazendo, eu percebo que você não está tão na guerreira, você tá na donzela porque você tá acreditando que tá fazendo uma coisa…
- E aí depois eu, se fosse meu cliente e eu precisasse usar essas fichinhas, eu apagaria e colocaria a pergunta aqui, porque depois quando eu for falar com ele aqui três meses, que ele quis quer fazer outro manência, por exemplo, eu sei o que aconteceu aqui.
- E porque o que eu falei com a Patrícia, ela falou, ela trouxe todas essas perguntas, síntese do sentimento, qual era o sentimento?


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- Então eu só vou pedir para você e vou te pedir um favor que você fale e eu vou perguntar e aí eu gostaria que você repetisse seu nome completo em data de nascimento e dissesse eu, Patrícia, nome completo, e autorizo a divulgação dessa imagem pro código tá só pra gente deixar esse documentado para não ter problema.
- Então Patrícia você e autoriza a divulgação desse material, né, do seu do seu vídeo pr pr as aulas do código Martins autoriza a divulgação desse material pro código aqui.
- Eu sinto que ficou mais claro e que eu primeiro tenho que trabalhar em mim a minha autoestima e a minha confiança para depois então poder ajudar o outro.
- Eu tenho ganho consciência que eu eh não sei se tem a ver, mas vou dizer aquilo que eu estou a sentir que eu julguei muito os meus pais no sentido de achar que eles não tinham dado o amor que eu que achava que eles deveriam dar e eu sinto que pode vir daí essa sensação que eu tenho de abandono.
- Eh, o que eu sinto é que houve sim alturas da minha vida na na minha infância que eu senti que precisava de mais apoio e que daí vem essa sensação de abandono.
- Aí eu vou me sentir confiante e vou conseguir materializar os meus clientes, automaticamente eu vou me sentir pronto o suficiente para atendê-lo.
- Se eu não falo uma coisa pro meu filho porque ele não vai entender, ou eu não peço para ele resolver alguma coisa ou ficar perto de mim em alguma situação, ele não se sente merecedor da confiança.
- Eu acho que eu não consigo, acho que eu não sou tão forte assim, porque mas aqui você é porque você é, só que você não tá fazendo porque não lhe foi permitido fazer, porque te protegeram, não desconsideraram não por maldade, mas por falta de enfim de conhecimento, enfim, de tudo que quero que você não se sentiu amada porque justamente por isso, não é o…
- Vem uma imagem do meu pai a ralhar comigo e eu a querer me expressar e a querer falar e explicar e e sentir essa dor aqui não não conseguir e sentir-me pequena por por ver h a forma como ele tá a falar, a gritar e a expressão do corpo dele assim mais eh como se eu tivesse raiva.
- Eu estou a falar, eu estou triste, eu estou com medo, falo tudo que você, eu estou triste, eu estou com medo, eu estou perdida, eu não consigo perceber o que é que se está a passar, nem consigo que as coisas entrem na minha cabeça, porque eu estou sempre a pensar outras coisas e eu estou sempre a tentar entender porque é que eu não não sou vista, porque é…
- E todo o estudo, todo o processo de entendimento de padrão, isso facilita, mas não significa que vocês não vão conseguir conduzir todo o processo, porque a equipe espiritual da Câmara Manuciense tá atuando.
- Não tem como explicar como é esse lugar onde a gente de maneira consciente faz um trabalho espiritual, um trabalho de de processo de desobsessão e de processo autoobsessivo, né, de faixas e frações em tudo isso acabou, certo?


## Citações e Formulações de Alta Densidade

- “Então, eu vou trazer aqui um pouquinho onde aquilo flui de uma maneira natural e precisa ter um processo de presença e de condução, de escuta, atenta e condução daquele processo.”
- “Então, não é sobre materializar o ser terapeuta, você se sente terapeuta, você já é terapeuta, você não tem clientes, é sobre viver de terapia e não sobre ser terapeuta, só para eu entender melhor onde tá esse perceb?”
- “Então, o quanto você está sem paciência, né, para construir, para se tornar a terapeuta, porque olha, a sua pergunta principal foi: "Eu quero materializar ser terapeuta".”
- “Porque você disse, e eu te fiz uma pergunta lá atrás que que falou agora, conforme eu falei da confiança, eu me lembrei e vou falar o que eu estou sentindo, que eu acho que eu não recebi dos meus pais o afeto, né, o amor, enfim, que eu deveria, que eu merecia o que eu precisava.”
- “Só que agora você tem uma um agora com essa conversa que a gente teve, a o seu desejo está mais alinhado, porque você entende que para ser terapeuta você precisa experienciar, ganhar a confiança, não ganhar, não ter cliente.”
- “O que que a gente Então mudou tudo porque você chegou querer materializar uma coisa e eu tô te dando consciência que tá vendo como não é isso ou tem algo a mais e aí você fala que você não se sentiu.”
- “Eu acho que eu não consigo, acho que eu não sou tão forte assim, porque mas aqui você é porque você é, só que você não tá fazendo porque não lhe foi permitido fazer, porque te protegeram, não desconsideraram não por maldade, mas por falta de enfim de conhecimento, enfim, de tudo que quero que você…”
- “Eu estou a falar, eu estou triste, eu estou com medo, falo tudo que você, eu estou triste, eu estou com medo, eu estou perdida, eu não consigo perceber o que é que se está a passar, nem consigo que as coisas entrem na minha cabeça, porque eu estou sempre a pensar outras coisas e eu estou sempre a…”
- “Tô enquadrando essa cena, fazendo tratamento convencional, trazendo a energia de todo balu aí e recolhendo toda e qualquer consciência que tenha ficado nesse plano de nos planos astrais dessa fração, dessa consciência que precisa seguir colocando muito amor, muito caminho.”
- “Então eu consegui identificar que você tava muito acreditando que era a guerreira, mas quando você tá na guerreira guerreando, eu tô, eu tô fazendo, mas você não está fazendo porque só no seu inconsciente, na verdade, ele não tá fazendo, eu percebo que você não está tão na guerreira, você tá na…”
- “Mas assim, se por acaso vocês não tivessem visto nada disso, não soubesse nome, não importa a energia que vem fazer esses recolhimentos de almas, de frações que precisam de cuidado, né, de um pequeno nível ali daquela consciência dela que você encontrou que tava perdido, que tava precisando de…”
- “E aí depois eu, se fosse meu cliente e eu precisasse usar essas fichinhas, eu apagaria e colocaria a pergunta aqui, porque depois quando eu for falar com ele aqui três meses, que ele quis quer fazer outro manência, por exemplo, eu sei o que aconteceu aqui.”

## Conexões com a Wiki

- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Camara HumanoSense]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio da Liberdade Consciente]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Enquadramento na Piramide]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Conceito do Divorcio Energetico]]

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## FAQs para NotebookLM (Fase 2)

### Bloco 1: A Musculatura Energética e as Dinâmicas do Ego Clínico
```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
1. Como Andresa Molina conceitua a "Musculatura Energética", e de que forma a falta de prática clínica atrofia a percepção e a mediunidade do terapeuta?
2. Quais são as exigências de biossegurança do espaço físico no atendimento online, e por que a queda de internet no pico do transe é tratada como um risco biológico e espiritual grave?
3. De que maneira a "Lógica Invertida do Ego" sabota o terapeuta iniciante que condiciona a atração de clientes pagantes à conquista de sua autoconfiança?
4. Como é estruturado o "Princípio da Não-Indução" no Transe Astral e de que forma ele garante que a cura seja de autoria exclusiva do DNA emocional do assistido?
5. Por que a autora prefere atender o "Copo Vazio" (assistido leigo) a um colega de curso, e como a barreira teórica deste último atrapalha o transe na Câmara?
6. Como o pêndulo na mesa Humanosense desmascara a "Ilusão do Arquétipo" da Guerreira em clientes que operam, na verdade, na estagnação passiva da Donzela?
7. Como a "Dinâmica do Estagiário" deve ser trabalhada somática e emocionalmente pelo terapeuta em transição de carreira para esvaziar o orgulho e o medo do fracasso?
8. De que forma a superproteção familiar gera a dor da "Força Desconsiderada" na infância e como essa castração reflete na autoconfiança do adulto na vida prática?
```

### Bloco 2: A Causalidade Sistêmica, Anamnese e Blindagem de Campo
```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
9. Como a "Falsa Culpa Sistêmica" sabota o fluxo financeiro do adulto com base no seu julgamento presunçoso de que a relação ou vida dos pais é "ruim"?
10. Qual a importância clínica do arquivamento permanente das fichas cinzas com caneta após a sessão e de que forma isso otimiza o tratamento em consultas futuras?
11. Quais os passos e comandos práticos para gerenciar uma queda repentina de chamada ("resgate assíncrono") sem deixar a psique do assistido vulnerável no astral?
12. Descreva a "Anamnese por Desconstrução": como o terapeuta deve guiar as perguntas para afunilar a queixa racional do cliente até encontrar a emoção raiz?
13. Qual a diferença operacional na ativação da Pirâmide de enquadramento em sessões privadas versus apresentações públicas com plateia assistindo?
14. Como é conduzido o rebaixamento de frequência cerebral do assistido através da indução mecânica e varredura topográfica descrita pela autora?
15. Qual o decreto verbal exato para a abertura e desdobramento da Câmara Humanosense, unindo as linhagens da Terra com as tecnologias extraterrestres?
16. Por que o terapeuta deve forçar o assistido a verbalizar a dor da memória na "primeira pessoa" direcionando a fala ao holograma agressor na Câmara?
```

### Bloco 3: Operações no Transe, Esvaziamento e Selamento
```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
17. Como o terapeuta opera o "Resgate Emocional Especializado" quando a figura agressora na ~~Câmara Astral~~ *(Nota: expressão não consta na transcrição; a autora usa 'Câmara Humanosense' ou 'campo energético')* apresenta uma resistência de "coração de pedra"?
18. Descreva os passos somáticos e vibracionais da fecundação no vácuo e da ativação da Kundalini no encerramento do processo de sangramento.
19. Quais as etapas e os comandos exatos de assepsia e fechamento do portal da Câmara Humanosense para garantir a segurança dos corpos etéricos?
20. Como é executado o giro do pêndulo na Mandala da Cura infundindo a trindade no assistido e de que forma se dá o desligamento físico do campo na placa?
21. Por que o acúmulo de estudos teóricos ("falso movimento") atua como uma barreira que impede o terapeuta iniciante de ir para a linha de frente do campo prático?
22. Como o corpo da criança reage e somatiza a raiva ao perceber que seu tamanho espiritual foi desconsiderado e poupado dos problemas dos pais?
23. De que forma o terapeuta deve propor permutas e treinos gratuitos no início do estágio sem desvalorizar a tecnologia do Humanosense?
24. O que acusa no sistema nervoso do cliente a sensação física de "calafrio intenso, prazer e tesão de ser você mesmo" na subida da Kundalini pós-fecundação?
```

## Referência

ANDRESA MOLINA. *Aula 09 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.

---

## Aula 10 - Codigo Humanosense

# Aula 10 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `10   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 18.860 palavras; 636 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- Então, quando eu falei inclusive com a Patrícia que ela não estava, quando ela trouxe a questão de eh ela não ela ser terapeuta, então ela queria materializar ser terapeuta, quando na verdade ela não precisa materializar ser terapeuta, porque terapeuta ela já é. o que ela quer materializar é cliente.
- Então, eu permei todo o trabalho com as informações que vocês tm na mandala cura e com todas as informações que eh que eu trouxe como conceitos no começo, né?
- Então todas essas afirmações, essas questões, elas t a gente precisa ter um pouquinho de cuidado porque a gente faz de maneira despretenciosa, mas isso com o nosso emocional, um comando mental, a gente cria essa massa e essa massa ela vai atrair energia das mesmas frequências, então e vai desencadear um monte de outras coisas.
- Você vai conseguir colocar todos os dados do seu cliente e eu vou conseguir analisar o seu cliente, analisar aquele atendimento que você fez. eu vou conseguir analisar as perguntas que você fez, as respostas que ele deu, onde eu vou conseguir trazer um aspecto, onde você vai colocar ali tudo que aconteceu e eu vou ter como analisar tudo isso e trazer uma…
- É um processo de lapidação espiritual e profissional feito para terapeutas que querem atuar com mais confiança e clareza, dominar o método no campo de batalha, ter mais clientes e se profissionalizar e viver do código que carregam em si.
- O Mastercência é um movimento de expansão natural do terapeuta depois de acessar o código humanos para afiar o seu machado espiritual. é o lugar onde o terapeuta afia o machado espiritual e atua com mais precisão, consciência e confiança.
- Então é para quem quer ler e atuar diretamente no campo, acessar registros de memória inconsciente, registros acásticos e cármicos, tudo isso vivido e explicado em casos reais na prática.
- Então, acessar esses originários, esses arquétipos, desvendar os códigos primordiais dos povos originários e usar essas forças espirituais para limpar, equilibrar, curar e abrir o campo paraa manifestação dos desejos mais profundos.
- Essa matriz da consciência, ela vai conseguir identificar na vida do seu cliente quem são os possíveis cobradores, limitadores, exploradores." E ela vai responder algumas perguntas ao tudo automático, tudo digital, que você consegue identificar junto com ela.
- Ela também é uma ferramenta que vai deixar a possibilidade de você não precisar falar tudo de novo, de uma maneira, ah, não lembro meu cliente, hoje eu fiz um atendimento aqui, você deixando autorizado e a gente consegue então falar de um caso real, né, específico, trabalhar específico num caso para você melhorar, para quem um assistindo do outro acaba…
- Então, resumindo, seis meses de prática, direção e expansão, encontros quinzinis ao vivo comigo, sistema digital integrado, matriz da consciência, estudos de casos reais, e aprofundamento espiritual, crescimento da pessoa, do profissional e do financeiro, certo?
- Não é sobre um papel, né? é sobre a gente falando de códigos de espiritualidade, de equipe de cura, de integridade, de eh de libertar mentes aprisionadas que estão em dor, em campos ombralinos, porque é isso que o código faz, é desobsessão profunda, é trabalho de de de desfazimento de portais eh de acessos que estão entrando coisas que não deveriam.

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-80
- Então, quando eu falei inclusive com a Patrícia que ela não estava, quando ela trouxe a questão de eh ela não ela ser terapeuta, então ela queria materializar ser terapeuta, quando na verdade ela não precisa materializar ser terapeuta, porque terapeuta ela já é. o que ela quer materializar é cliente.
- Então, eu permei todo o trabalho com as informações que vocês tm na mandala cura e com todas as informações que eh que eu trouxe como conceitos no começo, né?
- Então todas essas afirmações, essas questões, elas t a gente precisa ter um pouquinho de cuidado porque a gente faz de maneira despretenciosa, mas isso com o nosso emocional, um comando mental, a gente cria essa massa e essa massa ela vai atrair energia das mesmas frequências, então e vai desencadear um monte de outras coisas.

### Bloco 2 - frases 81-160
- Não precisa se forçar, respeita porque eh ela ela entrou em contato com uma consciência dela mesmo que ela quer desfazer, uma sentimento que ela tem, mas ela não quer desfazer, entende?
- H, então, uma vez que só eh temos só tenho a possibilidade de uma pergunta boadinha de hoje, eu vou questionar acerca do atendimento que eu experimentei fazer hoje.
- Ela começou a ter eh eh a dizer que sentia um peso muito grande na cabeça, a curvar, portanto o corpo dela começou a manifestar e ela só dizia que tinha dor, que sentia a carregar, portanto parecia assim velhinha e começou a manifestar essa essa parte física, mas não via nada, não via ninguém, não entrava em contacto com nenhum outro conteúdo e eu fiquei assim um bocadinho perdida sem saber como dirigir e a dado…

### Bloco 3 - frases 161-240
- Ótimo, porque às vezes ela não consegue ir sozinha em lugares que só o humanoterapeuta consegue, o terapeuta consegue, que é o humanapeuta que quem vai terapeuta, né, não é o assistido.
- É, a minha a minha dúvida é uma um atendimento que eu fiz, né, que eu fiquei e na parte energética já, porque ela assim, ela não trouxe afetos e desafetos, por mais que ela já foi me assistido, eu sabia que tinha ali a parte de desafet mãe, só que ela não me trouxe isso dentro da situação que ela veio, né, falar.
- Mas o processo de tratamento espiritual, que é muito do código ele é sempre cuidado, sempre tem uma equipe espiritual que é a própria dela, né?

### Bloco 4 - frases 241-320
- Então quando eu abro o primeiro comando com a egrégora, com a câmera, uma se com a egrégora é como se tivesse passando na, como é que chama?
- Por isso você sente com ela e ali nesse lugar você vai sentindo quem vai precisar vir primeiro e vai dando como comando de acordo com cada sua tá tá tá perfeito.
- Esse trabalho é a desipnose, porque a hipnose criou a automagia e nós estão e as pessoas estão presas nos comandos que elas deram para si mesmas por ignorância, porque alguma sem saber que aquilo mais do que ajudar e atrapalhar e aprender, tá?

### Bloco 5 - frases 321-400
- Você vai conseguir colocar todos os dados do seu cliente e eu vou conseguir analisar o seu cliente, analisar aquele atendimento que você fez. eu vou conseguir analisar as perguntas que você fez, as respostas que ele deu, onde eu vou conseguir trazer um aspecto, onde você vai colocar ali tudo que aconteceu e eu vou ter como analisar tudo isso e trazer uma resposta extremamente eh apoiada nos dados que você preencheu.
- É um processo de lapidação espiritual e profissional feito para terapeutas que querem atuar com mais confiança e clareza, dominar o método no campo de batalha, ter mais clientes e se profissionalizar e viver do código que carregam em si.
- Essa matriz da consciência, ela vai conseguir identificar na vida do seu cliente quem são os possíveis cobradores, limitadores, exploradores." E ela vai responder algumas perguntas ao tudo automático, tudo digital, que você consegue identificar junto com ela.

### Bloco 6 - frases 401-480
- Então vamos imaginar que eu fosse fazer com ela agora, tá? que ela já é minha cliente, ela veio fazer a segunda sessão, já estaria o cadastro dela aqui, eu ia aplicar uma nova sessão, aí eu ia colocar a data da sessão.
- Então, a gente respeita a privacidade da terapia e aqui tem todos os dados que eu vou conseguir analisar e tem as perguntas que você fez.
- Ela também é uma ferramenta que vai deixar a possibilidade de você não precisar falar tudo de novo, de uma maneira, ah, não lembro meu cliente, hoje eu fiz um atendimento aqui, você deixando autorizado e a gente consegue então falar de um caso real, né, específico, trabalhar específico num caso para você melhorar, para quem um assistindo do outro acaba melhorando muito.

### Bloco 7 - frases 481-560
- Então, resumindo, seis meses de prática, direção e expansão, encontros quinzinis ao vivo comigo, sistema digital integrado, matriz da consciência, estudos de casos reais, e aprofundamento espiritual, crescimento da pessoa, do profissional e do financeiro, certo?
- Então as mesas elas têm os códigos, elas são codificadas e cada contato e e é mais do que um papel, é um campo espiritual.
- Não é sobre um papel, né? é sobre a gente falando de códigos de espiritualidade, de equipe de cura, de integridade, de eh de libertar mentes aprisionadas que estão em dor, em campos ombralinos, porque é isso que o código faz, é desobsessão profunda, é trabalho de de de desfazimento de portais eh de acessos que estão entrando coisas que não deveriam.

### Bloco 8 - frases 561-636
- A partir disso, eu tô trabalhando direto, tô atendendo direto, já apliquei o código, é fantástico, eu tô encantada, então essa dessa vez eu vou de cabeça e tô sonhando com 2007 pr minha aposentadoria que daí eu faço trans carreira de uma vez.
- Então assim, não é, a gente precisa ajudar todo mundo entrar no sistema, para onde que entra, onde é que faz perguntas, né?
- De verdade, eu não paro espiritualmente, a minha cabeça não para, eu recebo informações o tempo inteiro e quem tiver na mentoria, todas as atualizações, os próximos códigos já estão chegando, tudo isso vai sendo disponibilizado para quem seguir com a gente, porque quem segue com a gente nunca nunca perde, nunca se arrepende, porque a M.

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Então, quando eu fiz na aula passada e com a Patrícia, que eu fiz o tratamento dela, teve um momento em que eu tava falando com ela e eu falei sobre o lugar dela, ela estar fora do lugar com o pai, né, tentando assumir um lugar da mãe e a mãe aqui, ela não precisa cuidar do pai.
- Então, quando eu falei inclusive com a Patrícia que ela não estava, quando ela trouxe a questão de eh ela não ela ser terapeuta, então ela queria materializar ser terapeuta, quando na verdade ela não precisa materializar ser terapeuta, porque terapeuta ela já é. o que ela quer materializar é cliente.
- Então, se falta ela ter clientes, está faltando possivelmente a disponibilidade de fazer o que precisa ser feito para captar clientes, porque terapeuta ela já é: "Ah, mas eu não me sinto muito segura, então te falta o quê?
- Então todas essas afirmações, essas questões, elas t a gente precisa ter um pouquinho de cuidado porque a gente faz de maneira despretenciosa, mas isso com o nosso emocional, um comando mental, a gente cria essa massa e essa massa ela vai atrair energia das mesmas frequências, então e vai desencadear um monte de outras coisas.
- Não precisa se forçar, respeita porque eh ela ela entrou em contato com uma consciência dela mesmo que ela quer desfazer, uma sentimento que ela tem, mas ela não quer desfazer, entende?
- Você vai conseguir colocar todos os dados do seu cliente e eu vou conseguir analisar o seu cliente, analisar aquele atendimento que você fez. eu vou conseguir analisar as perguntas que você fez, as respostas que ele deu, onde eu vou conseguir trazer um aspecto, onde você vai colocar ali tudo que aconteceu e eu vou ter como analisar tudo isso e trazer uma…
- Então você vai ter uma base de dados dos seus clientes, você vai acessar e vai colocar todos os dados dele lá e aí você vai fazer a pergunta: "Vou mostrar toda digital, depois você arquiva tudo isso, tem um lugarzinho para você olhar depois os seus clientes, as datas, todas as informações.
- Ela também é uma ferramenta que vai deixar a possibilidade de você não precisar falar tudo de novo, de uma maneira, ah, não lembro meu cliente, hoje eu fiz um atendimento aqui, você deixando autorizado e a gente consegue então falar de um caso real, né, específico, trabalhar específico num caso para você melhorar, para quem um assistindo do outro acaba…
- Então assim, não é, a gente precisa ajudar todo mundo entrar no sistema, para onde que entra, onde é que faz perguntas, né?
- De verdade, eu não paro espiritualmente, a minha cabeça não para, eu recebo informações o tempo inteiro e quem tiver na mentoria, todas as atualizações, os próximos códigos já estão chegando, tudo isso vai sendo disponibilizado para quem seguir com a gente, porque quem segue com a gente nunca nunca perde, nunca se arrepende, porque a M.

## Conceitos-Chave Extraídos

- Mandala da cura, ela é orientação para você usar em todos os momentos, para você ir permeando cada fala com o seu assistido.
- Então, a mandala da cura ela é um instrumento para ajudar você a ter repertório e dando direção durante todo o processo, né?
- Então, eu permei todo o trabalho com as informações que vocês tm na mandala cura e com todas as informações que eh que eu trouxe como conceitos no começo, né?
- Não é só no campo energético, tem um potencial muito maior, porque a gente trabalha em desfazer alguns processos que possam ter uma massa espiritual ali.
- É um processo de lapidação espiritual e profissional feito para terapeutas que querem atuar com mais confiança e clareza, dominar o método no campo de batalha, ter mais clientes e se profissionalizar e viver do código que carregam em si.
- O Mastercência é um movimento de expansão natural do terapeuta depois de acessar o código humanos para afiar o seu machado espiritual. é o lugar onde o terapeuta afia o machado espiritual e atua com mais precisão, consciência e confiança.
- Então é para quem quer ler e atuar diretamente no campo, acessar registros de memória inconsciente, registros acásticos e cármicos, tudo isso vivido e explicado em casos reais na prática.
- Então, acessar esses originários, esses arquétipos, desvendar os códigos primordiais dos povos originários e usar essas forças espirituais para limpar, equilibrar, curar e abrir o campo paraa manifestação dos desejos mais profundos.
- Essa matriz da consciência, ela vai conseguir identificar na vida do seu cliente quem são os possíveis cobradores, limitadores, exploradores." E ela vai responder algumas perguntas ao tudo automático, tudo digital, que você consegue identificar junto com ela.
- Então, resumindo, seis meses de prática, direção e expansão, encontros quinzinis ao vivo comigo, sistema digital integrado, matriz da consciência, estudos de casos reais, e aprofundamento espiritual, crescimento da pessoa, do profissional e do financeiro, certo?
- Então as mesas elas têm os códigos, elas são codificadas e cada contato e e é mais do que um papel, é um campo espiritual.
- Não é sobre um papel, né? é sobre a gente falando de códigos de espiritualidade, de equipe de cura, de integridade, de eh de libertar mentes aprisionadas que estão em dor, em campos ombralinos, porque é isso que o código faz, é desobsessão profunda, é trabalho de de de desfazimento de portais eh de acessos que estão entrando coisas que não deveriam.
- Então para aqueles que fizerem sentido, quiserem estar mais pertinho de mim, efetivamente, eh o Master Sense é a sua oportunidade, não por mim, mas por conta não por mim como pessoa, mas eu não posso negar o quanto de experiência eu tenho tanto no campo espiritual quanto não, o código começou 5 anos, eu venho trabalhando nele.
- Eu tenho experiência de prática e de não só de prática com o cliente, mas de treinamento de quase 15 anos, né? espaço humanidade fez 10, mas eu já atuo nessa área há muito mais tempo, sem falar do campo espiritual, que como diz é a equipe espiritual, eu fui feita no berço.
- Então assim, não é, a gente precisa ajudar todo mundo entrar no sistema, para onde que entra, onde é que faz perguntas, né?
- De verdade, eu não paro espiritualmente, a minha cabeça não para, eu recebo informações o tempo inteiro e quem tiver na mentoria, todas as atualizações, os próximos códigos já estão chegando, tudo isso vai sendo disponibilizado para quem seguir com a gente, porque quem segue com a gente nunca nunca perde, nunca se arrepende, porque a M.


## Técnicas, Procedimentos e Orientações Práticas

- Mandala da cura, ela é orientação para você usar em todos os momentos, para você ir permeando cada fala com o seu assistido.
- Então, quando eu falei inclusive com a Patrícia que ela não estava, quando ela trouxe a questão de eh ela não ela ser terapeuta, então ela queria materializar ser terapeuta, quando na verdade ela não precisa materializar ser terapeuta, porque terapeuta ela já é. o que ela quer materializar é cliente.
- Então, se falta ela ter clientes, está faltando possivelmente a disponibilidade de fazer o que precisa ser feito para captar clientes, porque terapeuta ela já é: "Ah, mas eu não me sinto muito segura, então te falta o quê?
- Então todas essas afirmações, essas questões, elas t a gente precisa ter um pouquinho de cuidado porque a gente faz de maneira despretenciosa, mas isso com o nosso emocional, um comando mental, a gente cria essa massa e essa massa ela vai atrair energia das mesmas frequências, então e vai desencadear um monte de outras coisas.
- H, então, uma vez que só eh temos só tenho a possibilidade de uma pergunta boadinha de hoje, eu vou questionar acerca do atendimento que eu experimentei fazer hoje.
- Você vai conseguir colocar todos os dados do seu cliente e eu vou conseguir analisar o seu cliente, analisar aquele atendimento que você fez. eu vou conseguir analisar as perguntas que você fez, as respostas que ele deu, onde eu vou conseguir trazer um aspecto, onde você vai colocar ali tudo que aconteceu e eu vou ter como analisar tudo isso e trazer uma…
- É um processo de lapidação espiritual e profissional feito para terapeutas que querem atuar com mais confiança e clareza, dominar o método no campo de batalha, ter mais clientes e se profissionalizar e viver do código que carregam em si.
- Então é para quem quer ler e atuar diretamente no campo, acessar registros de memória inconsciente, registros acásticos e cármicos, tudo isso vivido e explicado em casos reais na prática.
- Então você vai ter uma base de dados dos seus clientes, você vai acessar e vai colocar todos os dados dele lá e aí você vai fazer a pergunta: "Vou mostrar toda digital, depois você arquiva tudo isso, tem um lugarzinho para você olhar depois os seus clientes, as datas, todas as informações.
- Essa matriz da consciência, ela vai conseguir identificar na vida do seu cliente quem são os possíveis cobradores, limitadores, exploradores." E ela vai responder algumas perguntas ao tudo automático, tudo digital, que você consegue identificar junto com ela.
- Ela também é uma ferramenta que vai deixar a possibilidade de você não precisar falar tudo de novo, de uma maneira, ah, não lembro meu cliente, hoje eu fiz um atendimento aqui, você deixando autorizado e a gente consegue então falar de um caso real, né, específico, trabalhar específico num caso para você melhorar, para quem um assistindo do outro acaba…
- Então, resumindo, seis meses de prática, direção e expansão, encontros quinzinis ao vivo comigo, sistema digital integrado, matriz da consciência, estudos de casos reais, e aprofundamento espiritual, crescimento da pessoa, do profissional e do financeiro, certo?
- Eu tenho experiência de prática e de não só de prática com o cliente, mas de treinamento de quase 15 anos, né? espaço humanidade fez 10, mas eu já atuo nessa área há muito mais tempo, sem falar do campo espiritual, que como diz é a equipe espiritual, eu fui feita no berço.
- Então assim, não é, a gente precisa ajudar todo mundo entrar no sistema, para onde que entra, onde é que faz perguntas, né?


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- E aí veio a questão do contato com escassez. contato com assim, é porque as pessoas chamam de contrato, mas na verdade toda vez que a gente faz qualquer coisa, qualquer contrato, a gente tá fazendo um processo de automagia.
- Ela começou a ter eh eh a dizer que sentia um peso muito grande na cabeça, a curvar, portanto o corpo dela começou a manifestar e ela só dizia que tinha dor, que sentia a carregar, portanto parecia assim velhinha e começou a manifestar essa essa parte física, mas não via nada, não via ninguém, não entrava em contacto com nenhum outro conteúdo e eu fiquei…
- Se eu tivesse a análise de tudo, eu conseguiria, mas assim, eu tô por possibilidade de tantas coisas que eu já vi que o que o que poderia ser feito, então tá tudo bem, se ela ficou melhor que bom, mas assim, ela ganhou pouca consciência sobre esse processo, então embora tenha melhorado, mas poderia ter eh um um jeito que você poderia ter feito é e o que…
- Porque era só uma, mas você já acabou de responder tava sincronizado, que meu atendimento também foi uma pessoa que tava com muita dor física, né?
- Esse trabalho é a desipnose, porque a hipnose criou a automagia e nós estão e as pessoas estão presas nos comandos que elas deram para si mesmas por ignorância, porque alguma sem saber que aquilo mais do que ajudar e atrapalhar e aprender, tá?
- Então dito isso, porque quem trabalha com comandos mentais no sentido de hipnótico, a não quero falar isso, deixa isso para falar, é são os magos, tá?
- E aí a gente vai fazendo porque conforme a pessoa vai e cada um vai aguentando e de acordo com o nível de de consciência, de de machado afiado também dela em relação ao próprio autoconhecimento.
- Essa matriz da consciência, ela vai conseguir identificar na vida do seu cliente quem são os possíveis cobradores, limitadores, exploradores." E ela vai responder algumas perguntas ao tudo automático, tudo digital, que você consegue identificar junto com ela.
- Quem é que tá sendo o limitador dela, quem é que tá sendo o explorador dela, quem é que tá sendo o cobrador dela? identifica com o nome da pessoa, se é a mãe, se a e ela vai trazer e você tem essa ferramenta para você aplicar com o seu cliente, né?
- Então não sei se dá para enxergar aí, mas raiva, medo, mágoa, então você consegue ter informações sobre o campo emocional dessa pessoa e as relações que ela tem com algumas pessoas, né?
- Ela também é uma ferramenta que vai deixar a possibilidade de você não precisar falar tudo de novo, de uma maneira, ah, não lembro meu cliente, hoje eu fiz um atendimento aqui, você deixando autorizado e a gente consegue então falar de um caso real, né, específico, trabalhar específico num caso para você melhorar, para quem um assistindo do outro acaba…
- Não é sobre um papel, né? é sobre a gente falando de códigos de espiritualidade, de equipe de cura, de integridade, de eh de libertar mentes aprisionadas que estão em dor, em campos ombralinos, porque é isso que o código faz, é desobsessão profunda, é trabalho de de de desfazimento de portais eh de acessos que estão entrando coisas que não deveriam.


## Citações e Formulações de Alta Densidade

- “Então, quando eu fiz na aula passada e com a Patrícia, que eu fiz o tratamento dela, teve um momento em que eu tava falando com ela e eu falei sobre o lugar dela, ela estar fora do lugar com o pai, né, tentando assumir um lugar da mãe e a mãe aqui, ela não precisa cuidar do pai.”
- “Então, quando eu falei inclusive com a Patrícia que ela não estava, quando ela trouxe a questão de eh ela não ela ser terapeuta, então ela queria materializar ser terapeuta, quando na verdade ela não precisa materializar ser terapeuta, porque terapeuta ela já é. o que ela quer materializar é…”
- “Então, se falta ela ter clientes, está faltando possivelmente a disponibilidade de fazer o que precisa ser feito para captar clientes, porque terapeuta ela já é: "Ah, mas eu não me sinto muito segura, então te falta o quê?”
- “Não é só no campo energético, tem um potencial muito maior, porque a gente trabalha em desfazer alguns processos que possam ter uma massa espiritual ali.”
- “Então todas essas afirmações, essas questões, elas t a gente precisa ter um pouquinho de cuidado porque a gente faz de maneira despretenciosa, mas isso com o nosso emocional, um comando mental, a gente cria essa massa e essa massa ela vai atrair energia das mesmas frequências, então e vai…”
- “Não precisa se forçar, respeita porque eh ela ela entrou em contato com uma consciência dela mesmo que ela quer desfazer, uma sentimento que ela tem, mas ela não quer desfazer, entende?”
- “Ela começou a ter eh eh a dizer que sentia um peso muito grande na cabeça, a curvar, portanto o corpo dela começou a manifestar e ela só dizia que tinha dor, que sentia a carregar, portanto parecia assim velhinha e começou a manifestar essa essa parte física, mas não via nada, não via ninguém, não…”
- “Ótimo, porque às vezes ela não consegue ir sozinha em lugares que só o humanoterapeuta consegue, o terapeuta consegue, que é o humanapeuta que quem vai terapeuta, né, não é o assistido.”
- “Ela também é uma ferramenta que vai deixar a possibilidade de você não precisar falar tudo de novo, de uma maneira, ah, não lembro meu cliente, hoje eu fiz um atendimento aqui, você deixando autorizado e a gente consegue então falar de um caso real, né, específico, trabalhar específico num caso…”
- “Não é sobre um papel, né? é sobre a gente falando de códigos de espiritualidade, de equipe de cura, de integridade, de eh de libertar mentes aprisionadas que estão em dor, em campos ombralinos, porque é isso que o código faz, é desobsessão profunda, é trabalho de de de desfazimento de portais eh…”
- “Eu tenho experiência de prática e de não só de prática com o cliente, mas de treinamento de quase 15 anos, né? espaço humanidade fez 10, mas eu já atuo nessa área há muito mais tempo, sem falar do campo espiritual, que como diz é a equipe espiritual, eu fui feita no berço.”
- “Então assim, não é, a gente precisa ajudar todo mundo entrar no sistema, para onde que entra, onde é que faz perguntas, né?”

## Conexões com a Wiki

- [[Conceito do Metodo HumanoSense]]
- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]
- [[Conceito da Camara HumanoSense]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Enquadramento na Piramide]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Tecnica de Retorno a Consciencia e Harmonizacao]]
- [[Conceito do Divorcio Energetico]]
- [[Conceito do Parceiro da Missao]]

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## FAQs para NotebookLM (Fase 2)

### Bloco 1: Ética Clínica, Desipnose e Comandos Ativos
```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
1. Como Andresa Molina conceitua a "Desipnose da Consciência", e de que forma a sugestão ou ~~hipnose clínica~~ *(Nota: expressão não consta na transcrição; a autora refere-se a 'sugestão hipnótica' ou 'desipnose' e afirma 'não é hipnose')* ~~viola o livre-arbítrio~~ *(Nota: expressão não consta na transcrição; a autora descreve 'aprisionar/libertar' e respeito à autorização)* e o propósito do método?
2. Por que a equipe espiritual necessita do comando mental e direcionamento ativo do operador encarnado para atuar no resgate? (Explique usando a metáfora do pão e da faca).
3. Como o terapeuta deve agir clinicamente e vibracionalmente quando o assistido resiste e se recusa a liberar a dor ou ~~perdoar o algoz~~ *(Nota: expressão não consta na transcrição; a autora descreve o ato de 'respeitar' e 'liberar o outro', sem forçar o perdão ou castigo)* (~~Princípio do ~~Respeito à Resistência~~ *(Nota: termo formal inexistente na transcrição; a autora refere-se ao ato de 'respeitar' a resistência)*~~ *(Nota: termo formal inexistente na transcrição; a autora refere-se ao ato de 'respeitar' a resistência e a recusa do cliente em liberar o outro)*)?
4. Quais são as limitações de idade impostas à aplicação do Código Humanosense, e qual o critério para avaliar se um adolescente está pronto para o desdobramento?
5. Quais as consequências energéticas e espirituais de se utilizar ~~pranchas~~ *(Nota: a autora refere-se a 'PDF' ou 'material digital')* ou mesas falsificadas/piratas (PDFs ~~xerocados~~ *(Nota: a autora refere-se a 'digitalizarem' ou 'material pirata')*) durante o atendimento?
```

### Bloco 2: Troca Fluídica, Somatização e Mediunidade
```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
6. Por que Andresa Molina sustenta que ceder magnetismo físico é inerente e inevitável ao ato terapêutico, e como os limites da biossegurança operam nessa troca?
7. Como a mediunidade reprimida ou a sensibilidade captadora não desenvolvida atua no corpo físico, gerando quadros de fibromialgia ou "dores que andam"?
8. Por que a assepsia e o resgate das captações efetuados pelo terapeuta na Câmara não garantem a cura definitiva das dores do cliente sensitivo "esponja"?
9. Como a lente da "Mandala da Cura" (Lugar/Função/Potência e Habilidade/Disponibilidade/Autorização) permeia os diagnósticos na anamnese e na sessão?
10. Como o terapeuta deve interpretar clinicamente o transe em que o assistido visualiza o resgate e a dor na Câmara, mas termina a cena sem chorar?
```

### Bloco 3: Leis Sistêmicas e Esvaziamento
```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
11. Sob a luz do "Princípio da Ocupação de Lugar", como a retenção energética de um relacionamento passado ou de uma dor impede a materialização de novas realidades?
12. Por que a quebra de um contrato ancestral de pobreza desfaz o voto exclusivamente para o assistido, e como a egrégora lida com o restante da família na miséria?
13. Qual a carga somática e emocional que o assistido precisa tolerar em seu campo pessoal e no trabalho terapêutico após quebrar individualmente um pacto de escassez da linhagem?
14. Como Andresa Molina define o "Divórcio Energético", e de que maneira contratos, casamentos ou alianças geram uma massa eletromagnética de atração?
```

### Bloco 4: Diagnóstico Temporal, Personificação e Matriz
```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
15. Como o terapeuta deve decidir qual intensidade energética testar na mesa quando a dor do passado foi imensa, mas a emoção do dia de hoje é outra?
16. Como se conduz o diálogo e a personificação visceral direta da dor somática quando o assistido apresenta espasmos e peso físico na Câmara, mas não visualiza cenários?
17. Descreva o protocolo passo a passo de "Desdobramento Reverso" e assepsia exigido no encerramento antecipado por bloqueio ou recusa de catarse do assistido.
18. Qual o propósito psíquico da ferramenta digital da "Matriz da Consciência" no mapeamento das identidades de Cobrador, Limitador e Explorador?
19. Explique a hierarquia de atuação clínica no Hospital Astral entre as Pombagiras (dores sentimentais) e as equipes e tecnologias especialistas (bombeiros astrais).
```

## Referência

ANDRESA MOLINA. *Aula 10 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.

---
