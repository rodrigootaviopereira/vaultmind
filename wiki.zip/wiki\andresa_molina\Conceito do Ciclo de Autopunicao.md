---
type: conceito
author: Andresa Molina
tags: [culpa, autopunicao, escassez, sabotagem, frequencia, 3a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito do Ciclo de Autopunição (Punição e Escassez)

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: O Ciclo de Autopunição é a mecânica energética e vibracional ativada pelo sentimento inconsciente de culpa (gerado pela raiva ou outros sentimentos reprimidos). Sob a premissa de que **"todo culpado merece castigo"**, o inconsciente emite um comando de punição, abaixando a frequência vibracional e atraindo ativamente cobranças físicas e financeiras (boletos, dívidas), escassez, perda de oportunidades e falhas em relacionamentos.
- **Formulação de apoio**: Quando a pessoa acumula raiva silenciosamente, ela atua como uma panela de pressão que eventualmente explode em um rompante ou surto. O arrependimento imediato gera uma culpa insuportável. Para equilibrar esse estado interno, o inconsciente busca o castigo correspondente, vibrando na frequência de autocobrança e autopunição. De acordo com a premissa de que "recebemos o que vibramos no mais íntimo", a energia da cobrança interna se materializa no ambiente externo sob a forma de dívidas financeiras e perda de prosperidade.

## Contexto de Uso

- Eixo diagnóstico no HumanoSense crucial para entender por que assistidos que trabalham duro continuam atraindo dívidas persistentes ou falências repetitivas. O terapeuta deve rastrear a raiva e a culpa subjacentes que alimentam a necessidade de castigo.

## Relação com Princípios

- [[Principio da Raiva como Potencial de Autonomia]]
- [[Principio do Amor Condicionado e Autoabandono]]
- [[Conceito da Raiva que Virou Culpa]]

## Exemplos do Material

- *"Quando escapa, a panela de pressão explode... você sente culpa e daí vem a raiva que virou culpa. E aí o que que você faz? você se pune, porque todo culpado merece castigo. [...] E quando você se cobra, o que que você vibra? cobrança. O que que você tem? Boleto, dívida, porque você vai ter o que você vibra no mais interno."*
- O assistido que sabota uma oportunidade real de promoção ou ganho financeiro logo após ter tido uma explosão de raiva com alguém próximo, expiando inconscientemente a culpa gerada.

## Aplicação Prática

1. **Rastrear a Culpa Trancada**: Identificar se o padrão de perdas financeiras ou dificuldades profissionais se intensifica após conflitos familiares ou momentos de estresse emocional.
2. **Desativar a Necessidade de Castigo**: Conduzir o assistido a desprogramar a crença infantil de que ele é culpado por impor limites ou expressar suas necessidades básicas.
3. **Desprogramar a Resposta Celular**: Utilizar a reconsolidação na coordenada somática para limpar a marca vibracional da culpa, permitindo que a vibração mude de "cobrança/autopunição" para "merecimento e autonomia".

## Perguntas Frequentes / Didática de Atendimento

### Como a culpa afeta a prosperidade financeira?

A culpa afeta a prosperidade financeira por meio de um ciclo inconsciente de autopunição e vibração energética.

Quando uma emoção natural reprimida (como a raiva) transborda e explode, a pessoa sente uma culpa profunda. A partir disso, ativa-se uma crença interna enraizada de que **"todo culpado merece castigo"**, fazendo com que o indivíduo passe a se punir inconscientemente.

Essa autopunição gera um estado de severa autocobrança. Como a realidade externa reflete a frequência vibracional interna, **ao vibrar constantemente na energia de "cobrança", a pessoa atrai mais cobranças literais para a sua vida, materializadas na forma de boletos e dívidas**.

Além desse fator vibracional, a culpa surge muitas vezes do ato de reprimir emoções para agradar os outros ou manter uma "falsa inteligência emocional". Esse processo faz com que o indivíduo invalide sua própria dor e deixe de dar valor aos seus próprios sentimentos. **Essa perda crônica de valor pessoal converte-se em perda de valor financeiro**, pois a escassez de dinheiro é um reflexo direto da falta de autovalorização **e do hábito inconsciente de engolir a própria indignação para garantir a validação e as "estrelinhas" dos outros**.

### Como identificar se estou vibrando na frequência da cobrança?

De acordo com os ensinamentos da 3ª Coordenada, a vibração na frequência da "cobrança" é o resultado de um ciclo inconsciente de raiva reprimida, culpa e autopunição, detalhado no [[Conceito do Ciclo de Autopunicao|Ciclo de Autopunição]]. Quando você reprime a sua raiva e explode, você sente culpa; e, regido pela crença de que "todo culpado merece castigo", você passa a exigir e cobrar excessivamente de si mesmo.

Você pode identificar que está vibrando ativamente nessa frequência através dos seguintes reflexos na sua realidade:

*   **Atração literal de dívidas e boletos:** O mundo externo materializa a sua vibração. Se você se cobra e se pune internamente, você emana a energia de cobrança, atraindo "cobranças" físicas manifestadas em boletos e dívidas recorrentes.
*   **Escassez financeira e perda de oportunidades:** Você percebe que a sua vida financeira não flui. Essa vibração afasta a prosperidade, fazendo com que você perca oportunidades de trabalho, viva com estagnação e enfrente escassez crônica.
*   **Ansiedade e Paralisia Profissional:** Você tem clareza do que precisa ser feito para prosperar (ideias e listas de tarefas), mas na hora de executar, algo o paralisa no plano físico.
*   **Sentimento crônico de culpa ao se defender:** Toda vez que você tenta impor limites, ativar o [[Conceito do Sistema RAGE|Sistema RAGE]] ou utilizar o [[Principio da Raiva como Potencial de Autonomia|Princípio da Raiva como Potencial de Autonomia]], você é consumido por culpa. Esse autojulgamento liga novamente o "botão" da autopunição.
*   **Relacionamentos mornos:** Como reflexo do [[Conceito da Raiva que Virou Culpa|Conceito da Raiva que Virou Culpa]] e da desvalorização interna, você passa a aceitar relacionamentos afetivos ruins ou insatisfatórios apenas por medo de ficar sozinho.

Se a sua vida externa está bloqueada por cobranças materiais e você se sente paralisado, esses são os indicadores mapeados na [[Tecnica de Mapeamento Somatico da Raiva|Prática de Mapeamento Somático da Raiva]] que sinalizam que seu corpo está rodando a programação de autopunição e vibrando na frequência da cobrança.

## Referência

ANDRESA MOLINA. *Conceito do Ciclo de Autopunição (Punição e Escassez)*. Aula 03 - Coordenada 3 (A Raiva que Virou Culpa). Fontes: [[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]].
