---
type: conceito
author: Andresa Molina
tags: [kundalini, fecundacao, bloqueio-vibracional, coerencia-interna]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# O Bloqueio na Fecundação / Ausência da Kundalini (O retraimento do corpo físico)

- **Definição Precisa**: A ausência de descarga somática e eletromagnética de prazer e calor físico (energia Kundalini) no encerramento da catarse, denunciando que a intenção racionalizada que o assistido dizia querer fecundar é inconsistente com a verdade profunda de sua alma.
- **Sinônimos/Variações**: Ausência de Kundalini no plantio, semente rejeitada, bloqueio do plantio.
- **Contexto de Uso**: Diagnosticado quando o assistido, ao tentar penetrar a semente de futuro no útero limpo da alma, relata "não sentir nada", revelando hesitação celular e medo de assumir as consequências de seu objetivo.
- **Relação com Princípios**: [[Principio da Consciencia que Cura]], [[Principio da Consciencia que Cura]]
- **Exemplos do Material**: "da comaline [Kundalini], eu não senti, mas aí talvez eu não precise sentir, né? Mas assim, eu não senti aquela coisa do nossa, eu tô plantando... E às vezes fal, nossa, eu disse que eu queria tanto uma coisa que no fundo, será que é isso mesmo. E aí a intensidade foi menor por conta disso, de tá de tomada de decisão de que é isso mesmo que quero, né? Nem imaginava que eu tava tão daquele jeito. Então, será que eu quero? Isso é meio um molde ou também é uma mudança de não sei se é isso que eu quero, não sei se tô pronta."
- **Aplicação Prática**: Investigar com o assistido se o desejo plantado não é apenas uma vaidade racional ou imposição de expectativas familiares, conduzindo-o a recalibrar sua semente de futuro com honestidade de peito.
- **Conexões Externas**: [[Conceito da Fusao do Masculino e Feminino]], [[Tecnica de Esvaziamento e Fecundacao]]

## Perguntas Frequentes / Didática de Atendimento

### 13. O que acusa o diagnóstico quando a pessoa não sente a "comaline" [Kundalini] ao plantar a semente?
**Resposta**: Quando a pessoa diz "eu não senti aquela coisa do nossa, eu tô plantando", isso acusa uma dissonância entre a intenção verbalizada e a verdade interna do indivíduo. A nível somático e energético, a biologia não gera a intensidade da força vital porque o corpo duvida da escolha feita. A autora diagnostica isso como uma ausência de "tomada de decisão de que é isso mesmo que quero", revelando que o assistido recua vibracionalmente e se questiona: "será que eu quero tanto mesmo assumir tudo isso que eu disse que quero?" ou "não sei se tô pronta". A intensidade elétrica cai porque a semente pode ser apenas "um molde" e não a verdadeira intenção orgânica.


## Referencia

ANDRESA MOLINA. *O Bloqueio na Fecundação / Ausência da Kundalini*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
