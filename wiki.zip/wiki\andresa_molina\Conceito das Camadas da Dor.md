---
type: conceito
author: Andresa Molina
tags: [camadas-da-dor, autossabotagem, repressao, sombra, cura]
sources: ["[[raw/archive/andresa_molina/transcriptions/01 - O CANSAÇO QUE NÃO PARA 1ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito das Camadas da Dor

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/01 - O CANSAÇO QUE NÃO PARA 1ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: O Conceito das Camadas da Dor descreve a estrutura de camadas progressivas e concêntricas de repressão, trauma e distorção energética que encobrem a essência (o Eu Sou) do indivíduo. Cada camada representa um nível de defesa ou reação inconsciente à dor ancestral ou de infância, indo desde justificativas lógicas superficiais até dinâmicas profundas de autodestruição e projeção de abuso.
- **Formulação de apoio**: O cansaço crônico e os padrões repetitivos de fracasso ou autossabotagem são sustentados por essas múltiplas camadas integradas. A cura real requer atravessar e descascar essas camadas em vez de apenas tratar o sintoma visível.

## Estrutura das Camadas (Passo a Passo)

Conforme a condução energética de Andresa Molina, a dor se estrutura de fora para dentro nas seguintes etapas:

1. **Camada Externa (A Máscara)**: É a fachada social. Justificativas lógicas superficiais para o cansaço ou sofrimento (ex: *"estou cansado porque trabalho muito"*, *"não tenho sorte"*). É a máscara necessária para transitar no mundo social.
2. **Desejos Ocultos Reprimidos**: Aquilo que a pessoa sente ou deseja, mas esconde por vergonha, medo do julgamento ou desconfiança. Há a repressão da busca por prazer ou felicidade verdadeira.
3. **Punição e Culpa**: A pessoa se culpa e se pune por desejar mais abundância ou felicidade. Há uma lealdade invisível à tristeza ancestral: *"Como posso ser feliz se minha mãe/família sofreu tanto?"*.
4. **O Medo de Não Existir**: O medo profundo da aniquilação ou da morte. Diante desse medo paralisante, o sistema inconsciente cria barreiras de segurança como doenças físicas ou pobreza, limitando a vida para tentar "salvá-la".
5. **Autodestruição e Abuso de Si**: A pessoa começa a violar a si mesma, realizando atividades contra o próprio coração, permitindo abusos internos, silenciando o próprio pulso de vida em prol da obediência externa.
6. **Obediência Cega e Projeção do Algoz**: O assistido permite que os outros abusem dele e sente orgulho dessa obediência desmedida. Em seguida, inverte o papel, tornando-se o algoz do outro — passando a exigir a mesma obediência cega e cobrando a dor sistêmica nas relações atuais. A dor atinge o nível mais denso (o "mal em si"), consolidando a pobreza material e espiritual.

## Contexto de Uso

- Usado no mapeamento do perfil do assistido e na identificação do ciclo de autossabotagem (ou ciclo de autopunição). Permite ao terapeuta compreender o nível de resistência e a profundidade em que o trauma está operando no campo vibracional do assistido.

## Relação com Princípios

- [[Principio da Memoria Celular Ancestral]]
- [[Conceito do Ciclo de Autopunicao]]
- [[Conceito de Personagens da Dor]]

## Aplicação Prática

- **Identificação da Máscara**: No início da sessão, o terapeuta deve acolher a queixa (Camada 1), mas não se fixar nela, investigando o que está por trás do discurso lógico (lacunas, incoerências emocionais).
- **Mapeamento do Algoz**: Verificar se o assistido reproduz a dor sofrida exigindo submissão das pessoas ao redor (parceiros, filhos, subordinados).
- **Desativação Progressiva**: Conduzir o tratamento energético (por meio da mesa, câmara ou reprogramação celular) limpando desde a camada mais externa de autossabotagem até a desativação da autodestruição ancestral profunda.

## Perguntas Frequentes / Didática de Atendimento

### Quais são os riscos de ignorar as camadas da dor?

Ignorar as camadas da dor e reprimir emoções sistêmicas cria uma "inflamação silenciosa" que contamina diversas áreas da vida do indivíduo. Os principais riscos são:

**1. Desenvolvimento de Doenças Físicas e Psicossomáticas**
As dores não validadas e emoções engolidas (muitas vezes disfarçadas sob a máscara de uma [[Conceito da Falsa Inteligencia Emocional|Falsa Inteligência Emocional]]) não desaparecem, mas se transformam em inflamação celular. O risco físico inclui o surgimento de úlceras, gastrites severas, dores musculares e articulares crônicas (pescoço, cabeça, costas) e o bloqueio de funções biológicas saudáveis, como uma dificuldade crônica de emagrecer por causa do corpo inflamado emocionalmente.

**2. Autodestruição e o Risco de "Tornar-se o Algoz"**
Como vimos na estrutura deste conceito, ignorar os níveis progressivos de trauma distancia a pessoa da sua verdadeira essência. Nas camadas mais fundas do sofrimento (como a autodestruição e a obediência cega), a pessoa se violenta e anula o próprio coração. O risco culminante é tornar-se o "algoz" do sistema: a pessoa esquece de quem é e passa a exigir, punir e projetar os abusos que sofreu nos outros. Para desarticular essa repetição, é essencial resgatar os fractais de dor e permitir a [[Tecnica do Trabalho Energetico de Sangria|sangria da ferida]] e o [[Conceito do Divorcio Energetico|divórcio energético]] desses padrões ancestrais.

**3. Escassez Financeira e Perda de Valor**
A recusa em olhar para as feridas internas destrói o referencial de valor próprio e sufoca a [[Conceito da Sensibilidade como Valor e Dinheiro|Sensibilidade como Valor]], impedindo o indivíduo de canalizar sua potência e sua missão. Quando a panela de pressão interna transborda, gerando explosões, entra em ação o [[Conceito do Ciclo de Autopunicao|Ciclo de Autopunição]]. A mente inconsciente, operando sob a regra de que "todo culpado merece castigo", gera uma frequência constante de autocobrança que atrai escassez material, materializada na forma de dificuldades financeiras, perda de empregos e atração de dívidas e cobranças literais.

**4. Vulnerabilidade a Abusos e Falência nas Relações**
Não ler o mapa da própria dor paralisa os sistemas de defesa natural do corpo humano, como o [[Conceito do Sistema RAGE|Sistema RAGE]] (sistema de autonomia e autodefesa). Ignorar isso significa perder a capacidade de impor limites claros. Consequentemente, o indivíduo entra em um padrão de submissão e passa a permitir que outras pessoas ultrapassem seus limites, abrindo brechas para a exploração financeira e emocional.

**5. Perda do Livre-Arbítrio e Crises Frequentes ("Do Nada")**
Se a marca não for tratada em sua camada originária com técnicas somáticas como a [[Tecnica de Mapeamento Somatico da Raiva|Prática de Mapeamento Somático da Raiva]] e o trabalho de desprogramação celular, ela continua operando como uma programação automática no sistema nervoso. Ocorre o disparo do [[Principio da Memoria Corporal Inconsciente|Princípio da Memória Corporal Inconsciente]], gerando crises de ansiedade aparentemente sem causa, procrastinação extrema, surtos ou choro "do nada". A pessoa torna-se uma mera "reagente" do seu histórico genético e emocional, perdendo o livre-arbítrio diante de situações sob pressão.

### Pode detalhar os 7 níveis das Camadas da Dor?

O conceito de **As Camadas da Dor** possui, na verdade, **6 níveis** progressivos de repressão. O número **7** refere-se às **7 Coordenadas do Mapa da Alma**, que compõem a jornada completa ensinada pela autora.

Abaixo, detalha-se a diferença estrutural entre ambos os conceitos:

#### Os 6 Níveis das Camadas da Dor
Estes são os níveis de aprofundamento nos traumas que distanciam o indivíduo de sua essência (o Eu Sou):
1. **Camada Externa:** A máscara social. É onde ficam as justificativas lógicas e superficiais para a dor (ex: *"estou cansado porque trabalho muito"*, *"não tenho sorte"*).
2. **Desejos Ocultos Reprimidos:** Refere-se aos desejos e prazeres que a pessoa tem vergonha de expor e, por isso, reprime.
3. **Punição e Culpa:** A fase de condenação de si mesmo, gerada por desejar ser feliz em um ambiente onde os ancestrais foram tristes e sofreram.
4. **O Medo de Não Existir:** Um medo profundo de aniquilação/morte que faz o sistema criar barreiras de segurança como doenças e pobreza.
5. **Autodestruição e Abuso:** O nível em que a pessoa passa a se violentar, fazendo o que não quer e obedecendo ordens externas enquanto ignora o próprio coração.
6. **Tornar-se o Algoz:** A camada mais densa do sofrimento. Nela, a pessoa esquece de quem é e torna-se "o mal em si", projetando e cobrando os abusos sofridos nos outros.

#### As 7 Coordenadas do Mapa da Alma
O número 7 refere-se às "marcas" ou registros somáticos armazenados no corpo que criam problemas e padrões invisíveis, compondo o [[Conceito do Mapa da Alma|Mapa da Alma]]:
* **1ª Coordenada:** O Cansaço que não para (peso físico e fadiga crônica ancestral).
* **2ª Coordenada:** O Amor que nunca voltou (onde o indivíduo doou tudo e o afeto/retorno não retornou).
* **3ª Coordenada:** A Raiva que virou culpa (a repressão da autonomia para agradar os outros e evitar o abandono).
* **4ª Coordenada:** A mulher que eu era antes de ser de todos (onde o indivíduo se anula para atender às demandas externas).
* *As Coordenadas 5, 6 e 7 completam as 7 etapas totais do mapeamento de desprogramação celular.*

## Referência

ANDRESA MOLINA. *Conceito das Camadas da Dor*. Aula 01 - Coordenada 1 (Cansaço que não para). Fontes: [[raw/archive/andresa_molina/transcriptions/01 - O CANSAÇO QUE NÃO PARA 1ª Coordenada - O Mapa da Alma.md]].
