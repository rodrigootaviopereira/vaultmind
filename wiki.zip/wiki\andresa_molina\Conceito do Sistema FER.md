---
type: conceito
author: Andresa Molina
tags: [neurociencia, sistema-fer, relacionamento, medo, sobrevivencia]
sources: ["[[raw/archive/andresa_molina/transcriptions/02 - O AMOR QUE NUNCA VOLTOU - 2ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito do Sistema FER

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/02 - O AMOR QUE NUNCA VOLTOU - 2ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: O Sistema FER (do inglês *Fear of Exclusion/Rejection* ou *Sistema de Ameaça de Separação*) representa um mecanismo neurobiológico e de sobrevivência que dispara um estado de alarme, pânico e ansiedade profunda quando o indivíduo percebe a iminência de ser rejeitado, excluído, abandonado ou de perder o afeto e pertencimento das pessoas de seu grupo familiar ou social.
- **Formulação de apoio (1ª Coordenada)**: Esse sistema foi projetado para manter a coesão social primitiva. Quando ativado de forma inflada (devido a traumas de infância ou marcas ancestrais de abandono), ele gera comportamentos compulsivos de agrado, obediência cega e anulação do Eu Sou para evitar a separação a qualquer custo.
- **Formulação de apoio (MasterSense)**: Ele aprofunda o HumanoSense no campo real dos atendimentos. A aula 03 do MasterSense reforça que receber sem culpa e reconhecer o que já chegou são etapas centrais da maturidade terapêutica e relacional. A aula 04 mostra que o terapeuta precisa modular linguagem, timing e intensidade para ajudar sem ferir a aliança com o assistido.
- **Limite do Sistema (MasterSense)**: O MasterSense é uma camada de lapidação do HumanoSense, não uma técnica-base separada do núcleo do método. Para não confundir MasterSense com Humanoterapeuta ou com o próprio HumanoSense, usar [[wiki/andresa_molina/Mapa dos Sistemas Terapeuticos de Andresa Molina.md|Mapa dos Sistemas Terapeuticos de Andresa Molina]].

## Contexto de Uso

- Usado para orientar leitura do assistido, organização da sessão, compreensão de padrões emocionais/energéticos e conexão entre método, ficha, mesa, câmara e condução espiritual no diagnóstico de dependência emocional e agrado compulsivo.

## Relação com Princípios

- [[Principio do Amor Condicionado e Autoabandono]]
- [[Principio da Causa Inconsciente e da Reconsolidacao]]
- [[wiki/andresa_molina/MasterSense - Mentoria do HumanoSense.md|MasterSense - Mentoria do HumanoSense]]

## Exemplos do Material

### Evidências da 2ª Coordenada (O amor que nunca voltou)
- *"Toda vez que esse fer perceber esse movimento, que alguém tá indo embora, você começa a fazer desesperadamente coisas pra pessoa ficar bem, para dar tudo certo. Você não pode errar... Você tem que ser a menina certa, a menina boazinha... para agradar."*
- O desespero financeiro ou o gasto compulsivo com estética e presentes para se sentir pertencente a um grupo ou parceiro são acionados pelo medo primitivo do Sistema FER.

### Evidências do MasterSense
- A mentoria insiste que o terapeuta não precisa sentir tudo mediunicamente para fazer um bom trabalho; primeiro ele deve aprender a ler bem o material que o assistido oferece através da ficha (MasterSense).

## Aplicação Prática

1. **Identificação do Gatilho**: Reconhecer a atitude desesperada ou a ansiedade do assistido quando há um pequeno conflito na relação (*"O outro não me respondeu, logo vou ser abandonada"*).
2. **Localização Corporal**: Identificar onde no corpo o alarme do FER é sentido fisicamente (ex: nó na garganta, perda de fôlego, aperto no peito).
3. **Desativação Terapêutica**: Conduzir o assistido à reconsolidação da memória de infância onde o amor condicionado ativou o alarme do FER, ajudando-o a nutrir a si mesmo com acolhimento e desvincular o seu valor pessoal da aprovação externa.

## Referência

ANDRESA MOLINA. *Conceito do Sistema FER*. Aula 02 - Coordenada 2 (O Amor que Nunca Voltou) e MasterSense. Fontes: [[raw/archive/andresa_molina/transcriptions/02 - O AMOR QUE NUNCA VOLTOU - 2ª Coordenada - O Mapa da Alma.md]] e material do MasterSense.

---

> [!NOTE]
> **Nota de Consolidação (Código HumanoSense & Mapa da Alma)**
> O **Sistema FER** (também grafado ou interpretado foneticamente como **Sistema FAIR**) é a chave neurobiológica que ativa a **2ª Coordenada (O Amor Que Nunca Voltou)**. Enquanto o Código HumanoSense descreve o circuito biológico do alarme de exclusão, o Mapa da Alma foca no rastreamento somático dessa dor relacional crônica de doação unilateral. A mentoria MasterSense atua lapidando o terapeuta para identificar a ativação do FER na leitura da ficha e evitar que o profissional sintonize com a carência ou autoabandono do assistido.

