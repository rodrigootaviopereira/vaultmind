---
type: principio
author: Andresa Molina
tags: [ancestralidade, epigenetica, cura, cansaco, memoria-celular, dna, 3a-coordenada, 7a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/01 - O CANSAÇO QUE NÃO PARA 1ª Coordenada - O Mapa da Alma.md]]", "[[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]]", "[[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]]"]
---

# Princípio da Memória Celular Ancestral (ou Transmissão Ancestral e Epigenética)

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/01 - O CANSAÇO QUE NÃO PARA 1ª Coordenada - O Mapa da Alma.md]]
  - [[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]]

## Definição

- **Definição**: O Princípio da Memória Celular Ancestral estabelece que traumas, medos, dores, repressões emocionais e bloqueios vivenciados pelos antepassados são herdados biologicamente pelas células (via genética/epigenética). Essa transmissão não ocorre apenas como uma herança espiritual abstrata, mas como material genético e vibracional celular impresso ativamente no corpo físico e no DNA.
- **Formulação de apoio (Transmissão Epigenética e Entrelaçamento Quântico)**: O corpo não é construído de forma linear (1, 2, 3), mas exponencial e multiplicativa através da divisão celular (1, 2, 4, 8) a partir de material celular cedido pelo pai e pela mãe. Durante a formação biológica e intrauterina, ocorre um **entrelaçamento quântico** perfeito. Qualquer medo, raiva, abuso ou violência silenciosa vivenciada pela mãe (e pelas gerações anteriores através do DNA) fica carimbada no corpo do indivíduo que está sendo gerado. Não há lembranças lógicas ou visuais desse período, mas a marca vibra ativamente no corpo físico do descendente.
- **Formulação de apoio (MasterSense)**: O MasterSense pega essa base e transforma em supervisao viva: o terapeuta aplica, registra, autoriza a analise e aprende a enxergar o que a ficha revela sobre afeto/desafeto, pai, mae, personagens, escassez, valor, fuga e memoria celular.
- **Segunda Camada - Leitura de Conjunto (MasterSense)**:
  - A aula 01 apresenta a moldura espiritual e profissional da mentoria.
  - A aula 02 confirma o metodo na pratica: a ficha nao e burocracia, e um mapa de fuga, defense, desejo, dor e incoerencia.
  - A mentoria insiste que o terapeuta nao precisa sentir tudo mediunicamente para fazer um bom trabalho; primeiro ele deve aprender a ler bem o material que o assistido oferece.
  - O MasterSense nao substitui o HumanoSense.
- **Formulação de apoio (1ª Coordenada)**: O corpo físico carrega em suas células a impressão das dores ancestrais. O óvulo que dá origem a uma geração se desenvolve no útero da avó, criando uma conexão biológica e emocional contínua entre múltiplas gerações.

## Justificativa

- É um pilar central porque demonstra que certos sintomas persistentes (como o cansaço crônico que não passa com o sono) ou reações emocionais inexplicáveis não têm origem racional ou fisiológica direta nesta encarnação. Portanto, tentar resolvê-los apenas pela mente lógica ou por "força de vontade" é ineficaz, pois a programação celular da dor continuará rodando de forma automática nas células.

## Evidências

### Evidências da 1ª Coordenada (O Cansaço que não para)
- *"Nós carregamos informações dentro do nosso corpo, nas nossas células, que são desencadeadas na nossa vida, fazendo com que a gente repita padrões de situações que a gente nem tem consciência..."*
- *"O seu pai e a sua mãe emprestaram material genético para você... Eles emprestaram células e essas células vieram carregadas de informação que hoje compõe o nosso campo genético e epigenético."*
- *Exemplo Prático (Andresa Molina)*: Sentia-se constantemente impotente, incapaz e com medo do fracasso profissional e afetivo, mesmo tendo capacidades de sucesso. Ao rastrear o campo, identificou que seu avô materno faleceu de forma grave enquanto sua mãe estava grávida dela. A dor da perda e o sentimento de impotência da mãe e do avô na gestação ficaram gravados em suas células, fazendo-a reproduzir esse padrão por anos.

### Evidências da 3ª Coordenada (A Raiva que virou Culpa)
- *"A minha mãe passou informações material genético para mim quando compôs o meu corpo físico, né? A minha mãe recebeu o material genético da minha avó, a minha avó da bisavó... Tudo isso vem sendo passado neste mapa, este DNA, que é o código genético. São códigos. [...] Vocês tiveram, vocês foram entrelaçados quanticamente. Então, entrelaçamento quântico. Então, vocês foram a mesma coisa e se expandiram. Então não tem como não sentir, mas não vai lembrar."*

### Evidências do MasterSense
- O MasterSense pega essa base e transforma em supervisao viva: o terapeuta aplica, registra, autoriza a analise e aprende a enxergar o que a ficha revela sobre afeto/desafeto, pai, mae, personagens, escassez, valor, fuga e memoria celular. Segunda Camada - Leitura de Conjunto: a aula 01 apresenta a moldura espiritual e profissional da mentoria; a aula 02 confirma o metodo na pratica. O MasterSense nao substitui o HumanoSense. (MasterSense - Mentoria do HumanoSense)

## Implicações

- **Responsabilidade de Cura**: A cura de um padrão não é apenas individual; ao reconsolidar a informação e liberar a dor no corpo, o assistido libera todo o seu sistema ancestral do sofrimento e impede a transmissão dessa carga epigenética para os filhos.
- **Insuficiência Racional**: Não basta entender o problema intelectualmente para curá-lo. É necessário acessar a memória emocional armazenada no corpo e fazer a reprogramação energética/celular.

## Conexões

- [[wiki/andresa_molina/MasterSense - Mentoria do HumanoSense.md|MasterSense - Mentoria do HumanoSense]]
- [[Conceito do Mapa da Alma]]
- [[Tecnica de Identificacao do Cancaco Ancestral]]
- [[Principio da Causa Inconsciente e da Reconsolidacao]]

## Notas Pessoais

- Reservado para observações do usuário no uso prático do princípio.

## Perguntas Frequentes / Didática de Atendimento

### Como identificar se um cansaço é físico ou ancestral?

Para identificar se um cansaço é puramente físico ou se possui uma origem ancestral (tratado no Mapa da Alma como a 1ª Coordenada), você deve observar como o seu corpo reage ao descanso e realizar um mapeamento intuitivo dessa sensação.

Com base nos mapeamentos da 1ª Coordenada e no aprofundamento das fontes, as principais formas de identificação são:

**1. A Ineficácia do Descanso Tradicional**
O principal indicativo de um cansaço ancestral é que **ele consiste em um esgotamento crônico e profundo que não é resolvido por sono, descanso físico, repouso, vitaminas ou atividades físicas**. Enquanto o cansaço físico cede após algumas horas de sono, o cansaço ancestral continua drenando sua energia. Ele se manifesta no corpo como um peso extremo, dores de cabeça, dores no pescoço e nas costas, levando a uma sensação absurda de que você simplesmente "não suporta mais".

**2. A Sensação de Exaustão "Do Nada"**
A exaustão ancestral frequentemente parece surgir de forma inexplicável, mesmo em dias onde não houve esforço físico ou mental exagerado. Esse cansaço não vem "do nada"; **ele é o acionamento de uma marca invisível e inconsciente no seu corpo**, relacionada ao [[Principio da Memoria Corporal Inconsciente|Princípio da Memória Corporal Inconsciente]]. Ele reflete o acúmulo de gerações inteiras de antepassados que lutaram e cujas dores estão rodando como um programa contínuo através do seu DNA e do seu corpo físico.

**3. Prática de Identificação (Questionamento Intuitivo)**
Como estudado na [[Tecnica de Identificacao do Cancaco Ancestral|Técnica de Identificação do Cansaço Ancestral]], você pode identificar a raiz desse cansaço contornando a sua mente racional através de um teste prático somático:
*   Feche os olhos, respire profundamente para aquietar a racionalidade.
*   Pergunte a si mesmo de forma direta, aceitando a primeira resposta que vier: **"Esse cansaço é só meu?"** e **"Eu trago esse cansaço dos meus ancestrais?"**.
*   Em seguida, perceba **onde esse peso e exaustão se concentram fisicamente** no seu corpo (ombros, costas, cabeça).

Se o descanso não funciona, se as crises de fadiga parecem surgir "do nada" e se a sua resposta intuitiva corporal sinaliza que há uma "marca" física carregando dores de quem veio antes de você, trata-se de um esgotamento informacional e ancestral. A partir da identificação dessa coordenada exata no corpo, torna-se possível fazer o trabalho de [[Conceito de Ressignificacao vs Reconsolidacao|Reconsolidação (Desprogramação)]] para liberar essa carga herdada.

### O que Andresa ensina sobre o "DNA Lixo" sob a perspectiva da ancestralidade e da memória celular?

Andresa ensina que a parte do nosso código genético que a ciência tradicional frequentemente rotula como "DNA lixo" — simplesmente por não saber como decodificá-lo ou entender a sua função — não tem nada de "lixo". A impossibilidade de decodificar essa área ocorre porque a ciência tenta ler essas informações pelo viés estritamente racional e biológico.

Sob a perspectiva da autora, essa porção do DNA é, na verdade, um grande reservatório de informações em camadas profundas que guardam as memórias celulares, as angústias e os padrões de dor de toda a nossa ancestralidade. Como nossas avós e bisavós nos emprestaram material genético para o nosso corpo existir, elas transferiram essas memórias acumuladas que agora habitam as nossas células. Assim, o chamado "DNA lixo" é o arquivo onde estão gravadas as histórias de sobrevivência da família, que continuam rodando automaticamente e, muitas vezes, bloqueiam a pessoa de manifestar o seu próprio projeto de vida.

### De acordo com o texto, qual é a diferença científica e clínica que a epigenética traz para a compreensão dos padrões de dor herdados?

A diferença fundamental que a epigenética traz é a comprovação científica de que a herança genética não é um destino rígido, mas sim um sistema dinâmico de informações que reage ao ambiente e às memórias. Andresa explica que a epigenética mostra que trazemos informações dos nossos ancestrais nas células que têm o poder de "abrir portas ou fechar".

Clinicamente, isso explica por que uma doença, um padrão de comportamento ou um ciclo de escassez familiar se manifesta em uma pessoa e não em outra. A epigenética responde "por que que você tem ou não, por que isso acorda ou não acorda". Ou seja, as dores e os bloqueios (como o abandono ou submissão constante) estão codificados e adormecidos nas células; quando a pessoa repete o padrão emocional da ancestralidade, ela "acorda" essa memória, ativando fisicamente doenças ou problemas que o seu pai ou avô tiveram.

### Como a física quântica (através do conceito de entrelaçamento quântico) explica que a cura de uma pessoa afeta retroativamente seus ancestrais e seus descendentes?

Andresa fundamenta a dimensão energética do seu trabalho no "entrelaçamento quântico". Esse princípio sugere que indivíduos de uma mesma linhagem familiar não estão separados no tempo e no espaço, mas permanecem profundamente conectados numa mesma rede de informação.

Por causa desse entrelaçamento, quando você acessa uma dor ancestral e realiza a reconsolidação mudando a informação celular dentro do seu próprio corpo, o efeito não fica restrito a você. A autora afirma que, ao mudar essa carga, "por intralaçamento quântico, você muda o seu e da sua tatara voz e de todos aqueles que vão vir". Ao invés de apenas continuar repassando as feridas de geração em geração de forma inconsciente (como sua mãe fez com você), a sua cura retroage limpando a memória daqueles que sofreram no passado e, simultaneamente, resolve "a vida dos seus filhos, dos seus netos", libertando as gerações futuras de herdar essa mesma programação traumática.

### Como o ambiente de gestação da mãe (mencionado por Andresa ao falar de sua infância) interfere na sensibilidade e captação energética da criança?

O ambiente de gestação transfere diretamente informações sensoriais, memórias e cargas energéticas para as células da criança. Andresa usa sua própria história para exemplificar isso: ela relata uma forte alegria e conexão com instrumentos de percussão e com o samba, justificando que a sua mãe frequentava a Umbanda enquanto estava grávida, de modo que ela "cresceu escutando" esses ritmos ainda "na barriga dela".

Além das influências sensoriais, **o útero materno é o primeiro ambiente onde ocorre a transferência do "DNA lixo" emocional**. A autora afirma que muitas das dores e marcas que precisamos reconsolidar hoje aconteceram e foram absorvidas enquanto ainda "estávamos na barriga da nossa mãe", provando que a captação energética da criança começa muito antes do nascimento e molda profundamente as suas reações na vida adulta.

### Como Andresa explica o empréstimo de "material genético" de toda a ancestralidade e de que maneira as dores, amores e horrores do passado familiar ficam ativos no corpo atual?
**Resposta**: Andresa baseia essa explicação no princípio da "epigenética". Ela afirma que a nossa existência física só é possível porque *"os pais eles emprestam material genético, células do corpo deles para que a gente possa existir"*. No entanto, esse empréstimo não é apenas biológico; ele é profundamente emocional e vibracional.

Ao recebermos as células dos nossos antepassados, acabamos *"pegando material genético emprestado de todas as dores, amores e horrores que a humanidade já viveu"*. Isso significa que a *"programação genética do medo, das guerras"* que um *"tataravô lá numa guerra"* precisou enfrentar para sobreviver continua gravada na base celular do indivíduo atual.

*   **Ativação no corpo atual**: Essas memórias ficam ativas como um sistema de alarme. Andresa cita a *"epigenética que já diz que a gente abre portas"*. Isso explica por que irmãos criados na mesma casa reagem de forma diferente: um deles pode *"desencadear"* e *"abrir"* a porta de um padrão de dor ancestral porque traz essa informação gravada no próprio corpo e tem a missão espiritual de resolvê-la.
*   **Impacto na linhagem de gerações**: O sofrimento de gerações passadas dita os *"acidentes"* e os padrões de *"famílias muito desestruturadas"* no presente. Ao fazer o processo de reconsolidação e curar essa marca na própria célula, o indivíduo realiza uma *"cura ancestral que cura dentro de cada um de nós"*, promovendo a *"libertação de processos de cura familiar e ancestral"*, interrompendo a repetição do trauma para as próximas gerações.

### Por que a nossa geração é apontada por Andresa como a "primeira geração" com a real possibilidade de interromper loops ancestrais de dor por meio da terapia?
**Resposta**: Andresa aponta isso porque as gerações passadas viviam presas em um ciclo de repetição inquestionável. Ao abordar os traumas causados pelos pais (como a exigência de utilidade na infância), ela convida o indivíduo a olhar para trás e entender o loop: *"fizeram isso com ela e que a pessoa que fez isso com ela também recebeu isso"*. Nossos antepassados não tinham recursos ou ambiente para questionar suas dores; eles apenas sobreviviam e repassavam a programação.

A mudança ocorre agora porque *"nós somos a primeira geração que tem a possibilidade de fazer terapia, a primeira geração que tem a possibilidade de falar disso com mais tranquilidade"*. O diferencial dessa oportunidade terapêutica moderna (que Andresa foca no aspecto espiritual e da reconsolidação) é a compreensão de que não se pode resolver o trauma com a *"cabeça racional"*, uma vez que a ferida *"não foi construído com a racionalidade, foi construído com bases emocionais, com bases ancestrais"*. Portanto, somos a primeira geração com abertura e ferramentas para acessar essas bases profundas, permitindo finalmente a interrupção de um padrão que vinha sendo empurrado geração após geração.

## Referência

ANDRESA MOLINA. *Princípio da Memória Celular Ancestral*. Aula 01 - Coordenada 1 (Cansaço que não para), Aula 03 - Coordenada 3 (A Raiva que Virou Culpa), Aula 07 - Coordenada 7 (A Cura Buscada em Todo Lugar) e MasterSense. Fontes: [[raw/archive/andresa_molina/transcriptions/01 - O CANSAÇO QUE NÃO PARA 1ª Coordenada - O Mapa da Alma.md]], [[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]], [[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]] e material do MasterSense.

---

> [!NOTE]
> **Nota de Consolidação (Código HumanoSense & Mapa da Alma)**
> O **Princípio da Memória Celular Ancestral** fundamenta a base de todos os diagnósticos do **Código HumanoSense** e do **Mapa da Alma**. No HumanoSense, esta memória se expressa como a egrégora do assistido na *Ficha de Identificação e Síntese da Dor* e rege as conduções na *Câmara HumanoSense*. Já no Mapa da Alma, ela se divide de forma prática nas **7 Coordenadas** somáticas que indicam em que locais do corpo o trauma transgeracional e epigenético das matriarcas (avó e mãe) está fisicamente operando. A mentoria **MasterSense** capacita o profissional a fazer a leitura fria e precisa dessas marcas somatizadas, sem se deixar hipnotizar pela narrativa puramente lógica do assistido.


### De que forma Andresa explica a transmissão somática da memória celular dos pais e mães para o corpo físico do assistido através da composição inicial das células?
**Resposta**: Andresa explica essa transmissão através da fusão material e biológica do corpo. A nível somático, a vida de um indivíduo não começa do nada; ela inicia quando "o óvulo e o espermatozoide se uniram. Duas células se unem formando uma única". Esse evento microscópico é o que a autora chama de "primeiro pulso de vida".

A transmissão somática ocorre porque essa célula única, que carrega as memórias, começa a se multiplicar fisicamente: "Uma vira duas, duas vira quatro, quatro vira oito e ela vai expandindo". A autora decreta que "o seu pai e sua mãe emprestaram material genético" e que a mãe "continua emprestando o corpo dela para você, para que você exista enquanto corpo". Como o corpo do assistido foi literalmente construído através do "empréstimo" de partes celulares dos pais, o indivíduo "é feito de pai, você é feito de mãe", recebendo de forma somática e indelével todas as dores, medos e traumas que aquelas células originais já haviam registrado.

### Sob a ótica da biologia geracional descrita na aula, como a história de vida de uma avó ou bisavó habita fisicamente no óvulo de uma mulher ou no corpo de um homem da geração atual?
**Resposta**: A biologia geracional atua como uma "matrioska" (bonecas russas) de formação celular. Andresa ensina que a formação das nossas células reprodutivas acontece muito antes do nosso próprio nascimento. 

A nível somático, "quando o corpo, o seu corpinho está sendo feito na barriga da sua mãe, você mulher já tem o óvulo que vai dar vida aos seus filhos". Seguindo essa lógica de retrocesso biológico contínuo, a autora conclui que: "o óvulo que deu vida a você estava na barriga da sua avó. O óvulo que deu vida a sua mãe estava na barriga da sua bisavó". Como a sua primeira semente física existiu e habitou o útero da sua avó e bisavó, o seu corpo absorveu as vivências daquela época. É por isso que, sendo "você um homem ou uma mulher", as "memórias de traumas, de dores, de dores, amores e horrores" dessas matriarcas "lhe habitam" fisicamente no presente.

### Quais são os eventos coletivos e ancestrais históricos (como as Guerras Mundiais e a formação do Brasil) citados como exemplos de marcas de dores, amores e horrores que se manifestam de forma inconsciente no corpo do indivíduo hoje?
**Resposta**: Para ilustrar o peso ancestral que carregamos de forma somática, Andresa cita grandes eventos históricos mundiais e nacionais que forjaram a biologia de sobrevivência dos nossos antepassados. Ela menciona textualmente:
*   As guerras globais: "a gente veio da Segunda Guerra Mundial e da Primeira Guerra Mundial".
*   A formação do nosso país: "A gente veio de todo um processo da nossa ancestralidade, de todo um processo de como o nosso país foi composto aqui no Brasil, né? Com dores, amores e horrores".

### De que maneira as feridas de humilhação, violência ou abandono vividas na árvore genealógica se manifestam como impulsos inconscientes de "levantar bandeiras" ou reações desproporcionais na vida cotidiana?
**Resposta**: A nível somático, essas feridas ancestrais operam como um **"gatilho"** invisível. Quando a pessoa caminha pela vida cotidiana e se depara com situações externas (como ver uma "criança abandonada", tomar conhecimento de "racismo", "violência" ou ver alguém sendo "humilhado"), a mente lógica não tem tempo de atuar, pois essa informação "startou no seu corpo uma informação".

Esse gatilho físico faz com que a pessoa reaja de forma desproporcional. A autora relata: "Não sei por que quando fala dessas coisas me fico com uma raiva ou quando fala disso me dá uma dor maior que parece que tem uma coisa dentro de mi". O impulso de intervir violentamente, onde "um vai lá e não suporta" e "quer levantar uma bandeira contra", ocorre de forma visceral, porque a dor presenciada no presente ressoou com a memória exata que as células carregam do passado familiar ("Isso te pega num lugar ou porque você viveu, ou porque os seus ancestrais viveram"). É a "sua história dentro de você, gatilhando o tempo inteiro".

### O que Andresa Molina quer dizer com a afirmação de que a cura ancestral não serve para curar os antepassados diretamente, mas sim para libertar as futuras gerações?
**Resposta**: Embora o documento da 7ª Coordenada não traga a afirmação literal de que "não serve para curar os antepassados" para "libertar gerações futuras", Andresa explica a mecânica da cura ancestral neste texto através do Princípio da Ressonância da Intenção e da auto-responsabilidade.

Andresa é clara ao afirmar que tentar curar os outros antes de si mesmo é ineficaz: "Eu preciso curar em mim e aí sim conseguir melhorar a vida dos outros que estão ao meu redor". 

Em vez de focar nos antepassados diretamente, a autora ensina que a intenção amorosa de curar a árvore familiar tem um "efeito bumerangue" somático e espiritual: "Se você vibra a cura do seu e dos seus ancestrais... essa cura lhe habita e vai curar a si mesmo." Ao curar a si mesmo (encontrando e cavando o seu "tesouro" interno nas coordenadas certas), o indivíduo quebra o ciclo de transmissão biológica da dor, garantindo que esse peso não seja repassado para frente, de forma a "not tornar ele uma maldição de família e sim uma libertação".
