---
type: principio
author: Andresa Molina
tags: [hierarquia, papeis, alfa-beta, familia, relacionamentos]
sources: ["[[raw/archive/transcriptions/01 - Aula Inaugural - HumanoSense - Andresa Molina.md]]"]
---

# Princípio da Hierarquia dos Papéis

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/transcriptions/01 - Aula Inaugural - HumanoSense - Andresa Molina.md]]

## Definição

- **Definição**: [INFERÊNCIA] Princípio da Hierarquia dos Papéis expressa uma regra estrutural do sistema terapêutico de Andresa Molina: sem este princípio, a técnica perde força, segurança ou coerência no atendimento.
- **Formulação de apoio**: [INFERÊNCIA] O princípio foi preservado como eixo de leitura da fonte.

## Justificativa

- [INFERÊNCIA] É central porque transforma conteúdo em postura terapêutica: não basta conhecer o método, é preciso aplicá-lo com presença, ordem, respeito ao campo e leitura da raiz da dor.

## Evidências

- [INFERÊNCIA] Evidência direta não localizada na varredura automática; consultar as fontes indicadas na rastreabilidade.

## Implicações

- [INFERÊNCIA] O terapeuta deve usar este princípio como critério de decisão antes de improvisar, interpretar ou conduzir o assistido.
- [INFERÊNCIA] Quando o princípio é ignorado, a sessão tende a ficar mental, apressada, fragmentada ou desconectada da equipe/campo de trabalho.

## Conexões

- [[Conceito do Metodo HumanoSense]]
- [[Arquitetura do HumanoSense]]

## Notas Pessoais

- Reservado para observações do usuário no uso prático da técnica.

## Referencia

ANDRESA MOLINA. *Princípio da Hierarquia dos Papéis*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/transcriptions/01 - Aula Inaugural - HumanoSense - Andresa Molina.md]]. Acesso em: 17 jun. 2026.
