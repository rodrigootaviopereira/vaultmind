---
type: principio
author: Andresa Molina
tags: [ancestralidade, sensibilidade, valor, prosperidade, 6a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]]"]
---

# Princípio do Chamado da Sensibilidade

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]]

## Definição

- **Definição**: O Princípio do Chamado da Sensibilidade estabelece que a alta sensibilidade (ou a captação sensorial/mediúnica exacerbada) não é um defeito biológico ou um desequilíbrio psicológico, mas sim um chamado de evolução espiritual e um dom da alma. Quando este chamado é ignorado em prol da mente puramente lógica ou racional, o indivíduo experimenta um vazio existencial profundo e bloqueios materiais/financeiros, pois anula a sua maior força de valor pessoal.
- **Justificativa**: A sociedade ocidental hiperestimula a razão intelectual e rotula pessoas altamente sensíveis como "exageradas", "neuróticas" ou "dramáticas". Sob a hipnose racional, o indivíduo desconsidera o seu "sentir" e tenta imitar o comportamento alheio. No entanto, a sensibilidade sutil é a própria moeda vibracional de valor do assistido. Rejeitá-la impede que a pessoa expresse o seu propósito espiritual (Dharma) e anula o magnetismo da prosperidade, uma vez que dinheiro é a materialização da energia do valor próprio.

## Evidências

- *"A neurociência vai chamar isso de alta sensibilidade... no nosso universo energético espiritual, isso é chamado de um tipo de mediunidade, mas não a mediunidade de incorporação... é a sensibilidade, a nossa capacidade de se conectar com as pessoas, de se conectar com o ambiente..."*
- *"Esta capacidade de conectar com algo além da matéria, ela é um dom, ela não é um problema. Só que durante uma vida toda a gente escutou que a gente era sensível demais, exagerado demais, dramático demais. E aí o que que a gente fez? A gente começou a ignorar essa sensibilidade."*
- *"E os altamente sensíveis que não se dão conta disso ou que ignoram ou que não atendem esse chamado, vão ficar doentes, vão ficar pobres, vão ficar escassos, porque você não aceita a sua maior força, que é o seu valor. Se você não aceita o seu valor, como é que você quer receber valores financeiros? Por quê? Dinheiro é a materialização de uma energia chamada valor."*

## Implicações

- **Vazio Existencial Crônico**: Tentar preencher o vazio gerado pelo chamado ignorado com escapes materiais (comida, bebida, compras, baladas, remédios) falha inevitavelmente, servindo apenas como desvio temporário.
- **Adoecimento Físico e Financeiro**: A repressão contínua da captação sensorial e o desalinhamento com a missão de servir/ajudar geram escassez material cronificada e somatizações físicas inexplicáveis ("dores do nada").
- **Consciência que Cura**: O reestabelecimento do fluxo exige reconhecer e aceitar a sensibilidade, transformando a maior dor do assistido (se sentir inadequado/deslocado) em sua principal força de atuação no mundo.

## Conexões

- [[Conceito da Sensibilidade como Valor e Dinheiro]]
- [[Conceito de Clara Evidencia]]
- [[Principio da Responsabilidade Espiritual]]
- [[Principio da Memoria Celular Ancestral]]

## Notas Pessoais

- Reservado para observações do usuário.

## Referência

ANDRESA MOLINA. *Princípio do Chamado da Sensibilidade*. Aula 06 - Coordenada 6 (O Chamado Ignorado). Fontes: [[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. Por que a nossa geração atual é apontada por Andresa como a "primeira geração" que possui a tranquilidade e a abertura sociocultural para fazer terapia e trabalhos energéticos sem a obrigatoriedade de dogmas ou vínculos religiosos?
**Resposta**: Embora o termo literal "abertura sociocultural" não conste neste documento, Andresa aponta que a nossa geração é a *"primeira geração que fala naturalmente de terapia e principalmente de terapia energética e espiritual sem vínculo religioso"*. Até então, o contato e a decodificação da sensibilidade estavam restritos aos dogmas ("quem tá na religião já tá").

A autora fundamenta que essa liberdade é necessária porque a captação sensorial e energética acontece no nível somático diário, e não num altar. A pessoa *"sente tudo"* fisicamente o tempo inteiro nos ambientes mundanos: *"lá no seu trabalho [...] no banco [...] no mercado, você encontra com as suas amigas"*. Logo, a terapia precisa ser desvinculada do dogma porque *"a espiritualidade não tá só no templo, ela não tá uma vez por semana, ela tá a cada minuto"*, e o indivíduo precisa aprender a decodificar o que o seu corpo capta em qualquer lugar da rotina.

### 2. Como o "processamento sensorial diferente" dos altamente sensíveis se conecta com o princípio sistêmico do "todos somos um" e com a cura biológica e ancestral das células?
**Resposta**: A nível somático, a neurociência define a alta sensibilidade como um *"processamento sensorial"* onde o indivíduo *"capta as coisas muito rápido e precisa processar isso dentro do seu corpo e você capta do outro"*. Andresa conecta isso ao princípio do "todos somos um" afirmando que essa captação entre corpos ocorre porque *"Cada um de nós é uma félula [célula], a humanidade. Nós somos uma unidade desse grande corpo chamado humanidade. Nós somos conectados"*.

No quesito da cura biológica ancestral, o texto explica que herdamos dores porque os nossos pais e avós *"emprestaram células do corpo deles para compor o nosso corpo físico"*. A pessoa altamente sensível, ao abraçar o seu dom terapêutico, faz um trabalho retroativo e futuro em sua própria biologia: *"Você veio para curar sua ancestralidade em você, não é para curar eles"*. Ao transmutar essas memórias no seu próprio corpo, ela limpa a linhagem, pois *"pode curar em você tantas coisas que não precisa ir pra frente pros seus filhos"*.

### 3. O que significa, para o espírito e para o Mapa da Alma, a expressão de Andresa Molina sobre "viver uma outra encarnação dentro da mesma encarnação"?
**Resposta**: Significa a quebra completa de um ciclo de sofrimento e de repressão sem a necessidade da morte física. Andresa explica que *"tem uma parte sua que sabe"* que existe algo maior, mas que, por muito tempo, esteve presa nas *"camadas"* da racionalidade, tentando se encolher para caber nas expectativas alheias e no julgamento de ser "louca". 

A nível somático e espiritual, o chamado é *"o seu espírito querendo sair da forma. sair da forma, mudar, mudar a vida. Ela não precisa ser sempre assim"*. Quando a pessoa aceita o chamado e expande a sua consciência além do limite da razão, a mudança no seu modo de funcionar e na sua realidade é tão drástica e libertadora que é *"como se fosse viver uma outra encarnação dentro da mesma encarnação. E é possível, a gente não precisa morrer para viver uma outra vida"*.

