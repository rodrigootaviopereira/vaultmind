---
type: conceito
author: Andresa Molina
tags: [criacao, kundalini, fusao, masculino, feminino, gestacao]
sources: ["[[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]]"]
---

# A Fusão do Masculino e Feminino (O útero, o sêmen, o vazio e a ativação da Kundalini na criação)

- **Definição Precisa**: O clímax alquímico do atendimento no qual a polaridade passiva receptora (Feminino/Útero/Solo Vazio) e a polaridade ativa focada (Masculino/Sêmen/Semente/Intenção) se fundem no corpo do assistido, gerando um atrito vibracional que ativa a energia criadora vital (Kundalini) necessária para plasmar uma nova realidade.
- **Sinônimos/Variações**: Fusão criacional, plantio da semente, ativação da Kundalini.
- **Contexto de Uso**: Conduzido na etapa final da sessão (fecundação) após o esvaziamento total da dor ancestral. O assistido visualiza o sêmen/semente de seu objetivo penetrar o útero limpo da sua alma, ativando uma sensação somática de prazer físico que deve correr pela espinha.
- **Relação com Princípios**: [[Principio do Equilibrio de Forcas Masculino e Feminino]], [[Principio da Fusao Criacional]]
- **Exemplos do Material**: "fecunde a ideia e penetre a semente. A semente que entra nesse espaço vazio e é fecundada. absorvida, abraçada por esse espaço, tornando-se um só com a semente e o solo, com o semen e o útero, o masculino e o feminino, tornando-se uno e ativando a cundanaline. Sinta esse prazer pelo tempo que precisar, se aproprie dele e quando sentir confortável, vá voltando... Sente esse prazer dessa fecundação... O segundo momento é o momento do plantil e do prazer e do tesão, da fusão do feminino e do masculino."
- **Aplicação Prática**: Conduzir o paciente a somatizar a união das polaridades através de sensações de calor e prazer (tesão pela vida/Kundalini), permitindo que o cérebro grave essa nova assinatura eletromagnética de abundância ou cura.
- **Conexões Externas**: [[Tecnica de Esvaziamento e Fecundacao]], [[Conceito da Sustentacao pelos Tres Cerebros]]

## Perguntas Frequentes / Didática de Atendimento

## Perguntas Frequentes / Didática de Atendimento

### 10. Como se dá a "Fusão do Masculino e Feminino" no clímax do atendimento Humanosense e como essa alquimia ativada no corpo físico desperta a Kundalini?
**Resposta**: Essa alquimia se dá no "momento do plantil e do prazer e do tesão, da fusão do feminino e do masculino". A nível somático, após o paciente esvaziar todo o seu campo de contenção (o "útero"/Feminino), o terapeuta o instrui a introduzir a nova intenção (o "sêmen"/Masculino) de maneira física e sensorial: "fecunde a ideia e penetre a semente".

O despertar da Kundalini acontece no exato instante dessa união alquímica no corpo. A "semente que entra nesse espaço vazio e é fecundada. absorvida, abraçada por esse espaço", cria uma anulação das polaridades, "tornando-se um só com a semente e o solo, com o semen e o útero, o masculino e o feminino, tornando-se uno e ativando a cundanaline [kundalini]". Esse choque de vida ("força criativa") explode no sistema nervoso do assistido, e o terapeuta o orienta a experimentar fisicamente essa corrente: "Sinta esse prazer pelo tempo que precisar, se aproprie dele".

## Referencia

ANDRESA MOLINA. *A Fusão do Masculino e Feminino*. Aula 06 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]].
