---
type: conceito
author: Andresa Molina
tags: [humanometria, humanosense, consciencia, profundidade, metodologias]
sources: ["[[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]"]
---

# A Complementaridade Metodológica (Humanoterapia vs. Humanosense)

- **Definição Precisa**: A integração técnica entre os sistemas terapêuticos de Andresa Molina: a Humanoterapia atua na limpeza de registros inconscientes profundos, celulares, epigenéticos e de vidas passadas (onde a mente racional não tem acesso), enquanto o Código Humanosense atua de forma ativa na desconstrução das ilusões da personalidade desperta do assistido.
- **Sinônimos/Variações**: Integração de sistemas, Humanoterapia vs. Humanosense.
- **Contexto de Uso**: Explicada para guiar o terapeuta na escolha de ferramentas: usa-se o Humanosense para "esfregar" o entendimento na mente racional do cliente, e a Humanoterapia para reprogramar a biologia inconsciente celular quando o indivíduo não consegue reagir mesmo possuindo a clareza lógica.
- **Relação com Princípios**: [[Principio da Causa Inconsciente e da Reconsolidacao]]
- **Exemplos do Material**: "A metodologia ela vai numa profundidade que o cliente não vai, ele não tem capacidade... a gente não vai em células, em memórias, a gente não vai no lugar da epigenética, a gente não vai no lugar dos registros ancestrais que estão gravados no corpo dele, entende? ...Pode ser que às vezes ele precise ir numa inocência e depois precisa um bloco de metodologia... Imagina que ele é uma extremamente racional... a gente faz uma não sei se esfrega na cara dele. Você não quer, não quer saber? Eu não queria entender. Toma aqui o entendimento. Era isso que você precisava."
- **Aplicação Prática**: Conduzir o cliente alternando entre as duas metodologias: iniciar com a desobstrução e choque mental do Humanosense e, em seguida, aplicar sessões de Humanoterapia para esvaziar a memória celular e a epigenética densa do corpo físico.
- **Conexões Externas**: [[Mapa dos Sistemas Terapeuticos de Andresa Molina]], [[HT - Conceito - Metodo Humanoterapeuta]]

## Perguntas Frequentes / Didática de Atendimento

### 8. De que forma o Humanosense se diferencia da "metodologia" (Humanoterapia) no que tange a acessar a biologia profunda e registros ancestrais?
**Resposta**: O Humanosense difere diametralmente da "metodologia" em relação à profundidade orgânica e ancestral porque ele foca o choque na mente e na consciência atual, não no arquivo biológico.

A nível somático e energético, a autora declara que, no Humanosense, "a gente não vai em células, em memórias, a gente não vai no lugar da epigenética, a gente não vai no lugar dos registros ancestrais que estão gravados no corpo dele". Essas instâncias ocultas e profundas do DNA pertencem exclusivamente à "metodologia", que "vai numa profundidade que o cliente não vai, ele não tem capacidade, só o terapeuta". O diferencial do Humanosense é confrontar o intelecto e a ilusão emocional de forma direta, sendo ideal para pacientes muito lógicos e com defesas racionais altas: "a gente faz uma não sei se esfrega na cara dele. Você não quer, não quer saber? Eu não queria entender. Toma aqui o entendimento. Era isso que você precisava".

## Referencia

ANDRESA MOLINA. *A Complementaridade Metodológica*. Aula 07 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]].
