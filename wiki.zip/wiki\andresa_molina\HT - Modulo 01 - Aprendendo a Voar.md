---
type: sintese
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, modulo_01, mente, corpos_sutis, energia]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_08_aprendendo_a_voar.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_13_mente_consciente_inconsciente_e_cosmica.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_30_os_chakras.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_34_consciencia_cosmica_parte_2.md]]"]
---

# HT - Modulo 01 - Aprendendo a Voar

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_08_aprendendo_a_voar.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_13_mente_consciente_inconsciente_e_cosmica.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_30_os_chakras.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_34_consciencia_cosmica_parte_2.md]]


## Nucleos do Modulo

- A mente e descrita em camadas e estados.
- O medo aparece como estrutura a ser enfrentada.
- O corpo e lido para alem do fisico, por corpos sutis e por dinamicas de energia.
- Sono, desdobramento e hemisferios entram como caminhos de leitura da consciencia.
- O final do modulo abre para chakras, pineal e consciencia cosmica como eixo de expansao.

## Referencia

ANDRESA MOLINA. *HT - Modulo 01 - Aprendendo a Voar*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_08_aprendendo_a_voar.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_13_mente_consciente_inconsciente_e_cosmica.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_30_os_chakras.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_34_consciencia_cosmica_parte_2.md]]. Acesso em: 17 jun. 2026.
