---
type: conceito
author: Andresa Molina
tags: [batismo, mediunidade, espiritualidade, bloqueio-sensorial, 6a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito do Bloqueio Sensorial pelo Batismo

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: O Bloqueio Sensorial pelo Batismo é a tese segundo a qual o ato de batizar uma criança utilizando o elemento água na testa (terceiro olho) atua como um fecho vibracional na capacidade de decodificação consciente das frequências e presenças espirituais ao redor. Esse processo inibe a vidência e a percepção espiritual aberta a fim de "proteger" a criança, mas faz com que o indivíduo continue sentindo o plano sutil sem conseguir enxergá-lo ou decodificá-lo, gerando a sensação crônica de inadequação, confusão mental e "loucura" na vida adulta.
- **Formulação de apoio**: Andresa esclarece que a infância tem um contato espiritual natural (amigos imaginários). A imposição do batismo retira do indivíduo a capacidade de autoproteção consciente: ao não ver mais a energia, a pessoa frequenta ambientes nocivos ou conecta-se a obsessores sem perceber o perigo. A cura desse bloqueio consiste em reativar a percepção sutil ("abrir o terceiro olho") por meio do ganho de consciência celular e do sentir corporal lúcido, permitindo a autodefesa energética.

## Contexto de Uso

- Aplicado para decodificar em consultório assistidos com alta sensibilidade descontrolada que se sentem perdidos, invadidos por ambientes ou culpados por surtos emocionais repentinos que captam do entorno.

## Relação com Princípios

- [[Principio do Chamado da Sensibilidade]]
- [[Principio da Memoria Celular Ancestral]]
- [[Principio do Respeito a Tecnica e a Equipe Espiritual]]

## Exemplos do Material

- *"Todos nós... fomos em algum ponto batizados... quando a gente é batizado, é usado o elemento água que coloca na nossa testa e faz com que a gente perca a nossa visão. Mas não é que é só a visão com o olho, é a nossa capacidade de decodificar o que tá no entorno. Então a gente para de ver... Só que não é porque a gente para de ver que deixa de existir... O batismo ele fecha a nossa capacidade de ver, mas não de sentir. E aí eu continuo sentindo, só que como eu não vejo nada, eu acho que eu tô doida."*

## Aplicação Prática

1. **Desmistificar a Loucura**: Explicar ao assistido altamente sensível que suas angústias sem motivo racional são captações espirituais e ambientais reais, e não histeria.
2. **Reativar o GPS Interno (Sentir)**: Treinar o assistido a decodificar as energias que capta no dia a dia, usando a Mesa ou Câmara do HumanoSense para reconfigurar a proteção do campo pessoal.
3. **Tomada de Decisão pelo Sentir**: Fazer a transição de um sistema passivo de vulnerabilidade para um estado ativo de "clara evidência", evitando conexões destrutivas no trabalho ou nos relacionamentos.

## Conexões Externas

- [[Conceito de Clara Evidencia]]
- [[Tecnica de Conexao com a Equipe Espiritual]]

## Referência

ANDRESA MOLINA. *Conceito do Bloqueio Sensorial pelo Batismo*. Aula 06 - Coordenada 6 (O Chamado Ignorado). Fontes: [[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. Como Andresa Molina explica que o ritual de batismo (através da aplicação do elemento água na testa/terceiro olho) atua como um fecho na capacidade de decodificar visualmente o plano espiritual na infância?
**Resposta**: A autora explica que o ritual utiliza o *"elemento água que coloca na nossa testa"* movido pela crença de que é preciso proteger a criança para que *"ela não seja acessada por maus espíritos"*. 

A nível somático, a água na testa atua bloqueando fisicamente o sensor visual energético ("terceiro olho"). Andresa afirma que essa ação *"faz com que a gente perca a nossa visão"*. Contudo, ela alerta que o bloqueio não se limita apenas ao globo ocular físico (*"não é que é só a visão com o olho"*), mas atua como um selo que desativa o "aparelho" visual interno, anulando diretamente a nossa *"capacidade de decodificar o que tá no entorno"*. Ao fechar essa via de acesso visual, a criança *"para de ver, logo a gente para de ter acesso a esse mundo de maneira aberta"*.

### 2. Se o batismo fecha a visão ("capacidade de decodificar com clareza"), por que o indivíduo continua sentindo as frequências sem compreender sua origem e como isso gera a sensação de "loucura" na vida adulta?
**Resposta**: O indivíduo continua sentindo porque o ritual age de forma parcial no corpo: Andresa decreta que *"o batismo ele fecha a nossa capacidade de ver, mas não de sentir"*.

A nível somático, o corpo físico mantém sua propriedade de "antena" e continua absorvendo as vibrações do ambiente (sentindo o peso, o enjoo, a irritação). A sensação de "loucura" na vida adulta nasce de um choque entre o corpo que sente e a mente que não enxerga a origem. A autora explica o ciclo lógico falho da pessoa: *"eu continuo sentindo, só que como eu não vejo nada, eu acho que eu tô doida"*. Sem a imagem para comprovar de onde a energia ruim veio, a mente racional conclui que o próprio indivíduo está com defeito, gerando o julgamento interno constante: *"Eu acho que eu tô louca. Eu sou a neurótica, eu sou a dramática, eu sou a exagerada, só que não sou"*.

### 3. De que maneira a perda da capacidade de enxergar frequências boas e ruins deixa a pessoa vulnerável e sem ferramentas de autoproteção consciente diante de ambientes densos e obsessores espirituais?
**Resposta**: Embora o termo literal "obsessores espirituais" não conste no documento, Andresa descreve que a perda da visão retira o poder de escolha, a autonomia e o escudo de autodefesa da pessoa contra "maus espíritos" ou "coisas ruins". Ela explica que, se a visão estivesse aberta, o corpo e a mente teriam a *"habilidade de tomar as minhas decisões"* analisando de antemão: *"Eu não vou aqui porque ali quando eu me conecto com aquilo, eu vejo coisas ruins e ali eu saio pior"*.

Sem esse "aparelho capaz de enxergar", a pessoa caminha cegamente no escuro. A autora aponta que *"quando isso me é tirado, eu perco poder sobre mim mesmo"*, e a pessoa passa a frequentar locais densos de forma imprudente porque *"eu vou em qualquer lugar e eu não sei porque que eu vou"*. A vulnerabilidade absoluta se instaura porque a crença ilusória de que "não ver" significa "estar protegido" cai por terra: *"quando tiram de você a sua capacidade de se autoproteger, você fica vulnerável. Qualquer coisa encosta e você não vê"*.

### 4. O que são os "amigos imaginários" na infância sob a ótica da egrégora humana e espiritual e por que esse contato sensorial aberto é considerado natural à natureza da criança?
**Resposta**: Embora o termo literal "egrégora humana e espiritual" não conste neste documento, Andresa afirma textualmente sob a perspectiva espiritual que *"as crianças têm amigos imaginários, eles não são imaginários"*. Eles são as consciências reais do *"plano espiritual"* que a criança acessa porque a sua visão e capacidade de decodificação ainda não foram seladas.

A nível somático, esse contato aberto é natural porque o corpo e a consciência infantil chegam ao mundo sem as travas lógicas dos adultos. A criança *"vem fluída, ela vem livre, ela tem... um contato muito grande com o plano espiritual"*. Esse acesso não é uma alucinação fabricada, nem é aprendido socialmente (pois a *"criança não aprende isso. Ela não escutou e fez por sugestão"*). A autora fundamenta isso em uma regra espiritual e biológica absoluta: esse contato faz parte do projeto inato da biologia humana, pois *"Se não fosse natural, Deus não dava. é da nossa natureza esse contato espiritual"*.

