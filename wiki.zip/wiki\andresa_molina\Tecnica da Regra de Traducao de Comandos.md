---
type: tecnica
author: Andresa Molina
tags: [traducao-comandos, internacionalizacao, nomes-proprios, egrégora]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# Regra da Tradução de Comandos (A preservação da raiz nominal)

- **Objetivo**: Conduzir o atendimento de clientes estrangeiros em suas respectivas línguas (traduzindo o conteúdo semântico dos comandos para permitir a compreensão lógica e o transe), mantendo intraduzíveis e em português os nomes próprios da egrégora para preservar a assinatura e potência magnética original.
- **Pré-requisitos**: Fluência na língua do assistido ou tradução prévia dos blocos.
- **Passo a Passo**:
  1. Ao atender assistidos hispânicos ou de outra língua, o terapeuta traduz a conversação clínica das mandalas e as perguntas para o idioma nativo deles.
  2. Ao verbalizar os comandos de abertura, desdobramento e invocação, traduz a estrutura geral do texto, mas mantém rigorosamente em português e sem alteração fonética os nomes próprios: *"Código Humanosense"*, *"Orixás"*, *"Câmara HumanoSense"*, *"Espaço Humanidade"*.
  3. Essa preservação impede a alteração da linha vibracional e garante o canal de resgate ativado na mesa.
- **Duração/Frequência**: Aplicada em sessões com assistidos que não compreendem a língua portuguesa.
- **Indicadores de Sucesso**: Entendimento racional pleno do assistido (permitindo sua catarse) mantendo a potência de arrasto e recolhimento das entidades de amparo.
- **Variações**: Condução de comandos adaptada ao espanhol vs. inglês.
- **Conceitos Envolvidos**: [[Principio da Objetividade Terapeutica]], [[Tecnica de Abertura e Conexao]]

## Perguntas Frequentes / Didática de Atendimento

### 21. Quais são as regras e limites para a tradução de comandos em outros idiomas sem perder a força?
**Resposta**: A autora autoriza plenamente a tradução do texto dos comandos para ajudar os assistidos ("Principalmente se você tiver atuando com pessoas sim hispânicas"), pois não há problema mecânico. A regra absoluta imposta é: "tudo que for nome próprio não traduza". A nível energético, termos como "orixás" ou "código humano" [Humanosense] guardam a assinatura vibracional da tecnologia: "Aí eu vou pedir para você não traduzir, porque daí você mantém essa essa linha e essa força para não virar uma outra coisa".


## Referencia

ANDRESA MOLINA. *Regra da Tradução de Comandos*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
