---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_05_passo_3_taquions_tock_desconstrucao_da_criacao_dos_campos_mental_e_emocional.md]]"]
---

# Cap 005 - Passo 3 Taquions Tock Desconstrucao Da Criacao Dos Campos Mental E Emocional

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_05_passo_3_taquions_tock_desconstrucao_da_criacao_dos_campos_mental_e_emocional.md]]

## Referencia

ANDRESA MOLINA. *Cap 005 - Passo 3 Taquions Tock Desconstrucao Da Criacao Dos Campos Mental E Emocional*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_05_passo_3_taquions_tock_desconstrucao_da_criacao_dos_campos_mental_e_emocional.md]]. Acesso em: 17 jun. 2026.
