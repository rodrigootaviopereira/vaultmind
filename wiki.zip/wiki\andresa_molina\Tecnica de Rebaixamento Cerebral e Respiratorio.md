---
type: technique
author: Andresa Molina
tags: [rebaixamento-cerebral, alfa, varredura-fisica, respiracao, esfriamento-biologico]
sources: ["[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"]
---

# Prática de Rebaixamento Cerebral e Respiratório (A indução mecânica)

- **Definição**: A indução lenta, contínua e topográfica (da cabeça aos pés) que o terapeuta utiliza para desacelerar o coração e as ondas cerebrais do assistido (entrando em Alfa), antes de acionar a viagem interdimensional.
- **Como praticar e seu Propósito**:
  1. **Sincronia Rítmica**: O terapeuta respira com o cliente: "Respira pelo nariz, segura, solta pela boca e segura sem ar. E nós vamos fazer isso juntos três vezes".
  2. **Varredura Descendente**: Comandar o relaxamento muscular de forma topográfica: "vai descendo agora, relaxando o pescoço... ombros... abdômen... aparelho genital".
  3. **Visualização Sensorial**: Criar imagens de paz (como uma vasilha com água perfumada) e focar o fluxo de energia na Glândula Pineal ("Imagina que um canudinho entra pela testa, outro pela nuca e ele se encontra bem no meio").
  O propósito somático é rebaixar a frequência para Alfa, permitindo que a psique relaxe e o corpo físico sinta-se em absoluta segurança material, desligando os estados de alerta de Beta.
- **Evidências**: "Respira pelo nariz, segura, solta pela boca e segura sem ar. E nós vamos fazer isso juntos três vezes... E vai descendo agora, relaxando o pescoço... Relaxa os braços... Vai descendo na região do abdômen... relaxando o aparelho genital... Repare que a respiração já tá mais calma, que os batimentos cardíacos já estão mais tranquilos, que tudo já tá mais leve... Imagina uma vasilha com uma água... com um perfume gostoso... Leva a atenção para sua glândula pineal. Imagina que um canudinho entra pela testa, outro pela nuca e ele se encontra bem no meio."
- **Conexões**: [[Tecnica de Rebaixamento Cerebral ou Alfa]], [[Tecnica de Preparacao e Alfa do Terapeuta]]

## Perguntas Frequentes / Didática de Atendimento

### 17. Como é conduzido o relaxamento do assistido através da sincronia mecânica e indução corporal?
**Resposta**: O relaxamento é conduzido unindo um ritmo respiratório forçado com comandos progressivos descendo pelo corpo físico. O terapeuta induz a estabilização somática ditando: **"Respira pelo nariz, segura, solta pela boca e segura sem ar. E nós vamos fazer isso juntos três vezes"**.

Em seguida, o terapeuta comanda que a musculatura ceda tensão de cima para baixo: **"relaxar o seu corpo cabeludo... descendo agora, relaxando o pescoço... relaxando os ombros... braços... Vai descendo na região do abdômen... aparelho genital"**. A nível biológico e somático, essa indução esfria o estado de alerta (sobrevivência) e derruba as ondas cerebrais ativas. A prova orgânica desse rebaixamento é declarada pela autora no meio do processo: **"Repare que a respiração já tá mais calma, que os batimentos cardíacos já estão mais tranquilos, que tudo já tá mais leve"**. Por fim, a atenção é afunilada para a **"glândula pineal"** antes do desdobramento.


## Referencia

ANDRESA MOLINA. *Prática de Rebaixamento Cerebral e Respiratório*. Aula 09 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]].
