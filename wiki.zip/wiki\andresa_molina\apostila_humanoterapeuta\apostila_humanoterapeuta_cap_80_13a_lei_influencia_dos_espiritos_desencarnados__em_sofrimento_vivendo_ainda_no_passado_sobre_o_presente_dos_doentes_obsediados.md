---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_80_13a_lei_influencia_dos_espiritos_desencarnados__em_sofrimento_vivendo_ainda_no_passado_sobre_o_presente_dos_doentes_obsediados.md]]"]
---

# Cap 080 - 13A Lei Influencia Dos Espiritos Desencarnados Em Sofrimento Vivendo Ainda No Passado Sobre O Presente Dos Doentes Obsediados

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_80_13a_lei_influencia_dos_espiritos_desencarnados__em_sofrimento_vivendo_ainda_no_passado_sobre_o_presente_dos_doentes_obsediados.md]]

## Referencia

ANDRESA MOLINA. *Cap 080 - 13A Lei Influencia Dos Espiritos Desencarnados Em Sofrimento Vivendo Ainda No Passado Sobre O Presente Dos Doentes Obsediados*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_80_13a_lei_influencia_dos_espiritos_desencarnados__em_sofrimento_vivendo_ainda_no_passado_sobre_o_presente_dos_doentes_obsediados.md]]. Acesso em: 17 jun. 2026.
