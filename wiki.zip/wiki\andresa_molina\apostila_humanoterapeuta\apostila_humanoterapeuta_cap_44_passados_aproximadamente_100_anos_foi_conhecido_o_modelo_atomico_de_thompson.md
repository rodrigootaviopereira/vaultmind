---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_44_passados_aproximadamente_100_anos_foi_conhecido_o_modelo_atomico_de_thompson.md]]"]
---

# Cap 044 - Passados Aproximadamente 100 Anos Foi Conhecido O Modelo Atomico De Thompson

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_44_passados_aproximadamente_100_anos_foi_conhecido_o_modelo_atomico_de_thompson.md]]

## Referencia

ANDRESA MOLINA. *Cap 044 - Passados Aproximadamente 100 Anos Foi Conhecido O Modelo Atomico De Thompson*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_44_passados_aproximadamente_100_anos_foi_conhecido_o_modelo_atomico_de_thompson.md]]. Acesso em: 17 jun. 2026.
