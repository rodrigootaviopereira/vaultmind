---
type: conceito
author: Andresa Molina
tags: [gatilho, somatizacao, comportamento-involuntario, trauma, 7a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito de Gatilho Somático (A Ativação não Racional)

- **Definição Precisa**: O Gatilho Somático é o processo pelo qual um estímulo externo (um barulho, um tom de voz, uma expressão facial alheia ou um assunto específico) dispara instantaneamente uma memória traumática armazenada nas células do corpo, provocando sensações corporais intensas e reações comportamentais automáticas antes que a mente lógica consiga processar o evento.
- **Sinônimos/Variações**: Gatilho Celular, Reação Corporal Automática, Start Somático.
- **Contexto de Uso**: Diagnosticado quando o assistido apresenta crises repentinas de ansiedade, perda de paciência, fuga emocional ou colapso físico em ambientes corriqueiros sem explicação racional consciente.
- **Relação com Princípios**:
  - [[Principio da Memoria Corporal Inconsciente]]
  - [[Principio da Memoria Celular vs Lembranca]]
  - [[Principio da Proporcao Inconsciente]]
- **Exemplos do Material**:
  - *"Quando a gente tem um gatilho... você tá lá bem e alguém acontece alguma coisa ou alguém faz uma cara estranha ou acontece um barulho lá fora ou alguém diz alguma coisa aleatória e aquilo te dá um gatilho, né? Aí você fica angustiada, assustada, com medo, ansiosa, tá? Este gatilho, ele gatilha no seu corpo uma informação, uma memória. E aí você começa a ter sensações e comportamentos baseados naquele gatilho..."*
  - *"Não vinha da sua cabeça, vinha de um gatilho que nem mesmo começou em você nesta vida ou na sua ancestralidade..."*
- **Aplicação Prática**:
  1. **Suspender o Autojulgamento Racional**: Auxiliar o assistido a compreender que suas reações intempestivas (ex: "perder a linha" em entrevistas de emprego ou falar bobagens em relacionamentos) são disparadas por memórias corporais e não por "burrice" ou falta de caráter.
  2. **Interrupção do Gatilho**: Rastrear a sensação somática exata (dor de cabeça, enjoo, aperto no peito) assim que ela se manifesta e aplicar a decodificação da frequência original.
  3. **Reconsolidação Celular**: Limpar a marca ancestral ou de infância que serve como "combustível" do gatilho para desprogramar a reação biológica definitiva.

## Conexões Externas

- [[Conceito de Ressignificacao vs Reconsolidacao]]
- [[Conceito da Falsa Inteligencia Emocional]]

## Referência

ANDRESA MOLINA. *Conceito de Gatilho Somático (A Ativação não Racional)*. Aula 07 - Coordenada 7 (A Cura Buscada em Todo Lugar). Fontes: [[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. O que é um "gatilho" somático segundo a aula e de que maneira ele starta sensações corporais e comportamentos automáticos e indesejados antes mesmo da intervenção da mente lógica?
**Resposta**: Segundo a aula, um gatilho é um evento externo aparentemente banal (como quando "alguém faz uma cara estranha ou acontece um barulho lá fora ou alguém diz alguma coisa aleatória") que aciona uma memória celular. 

A nível somático, ele *starta* sensações físicas de forma violenta e incontrolável porque atua diretamente no sistema biológico e emocional, contornando a mente analítica. A autora explica que "os gatilhos que liberam as memórias que estão no corpo não são racionais". Portanto, antes mesmo de a mente lógica intervir para tentar entender o que houve, o gatilho "gatilha no seu corpo uma informação, uma memória". O resultado é que a pessoa entra no piloto automático da somatização: "você começa a ter sensações e comportamentos baseados naquele gatilho que startou no seu corpo [...] e você nem sabe porque você tá fazendo aquilo", ficando "ansiosa" ou manifestando "dor de cabeça" sem nenhum controle lógico sobre o evento.

### 2. Quais são os exemplos de reações práticas do dia a dia (em entrevistas de emprego, relacionamentos e momentos íntimos) listados no texto como consequências de gatilhos corporais não conscientes?
**Resposta**: Andresa lista consequências altamente destrutivas de quando a memória celular não racional assume o controle do corpo físico na vida diária:
*   **A fuga diante de conflitos:** Quando a pessoa "já fugiu ao invés de enfrentar".
*   **O colapso profissional:** Quando o indivíduo "já perdeu a linha na entrevista de emprego".
*   **A autossabotagem nos relacionamentos:** Quando a pessoa sabota conexões promissoras e "já falou uma bobagem na frente daquela pessoa que tava tão legal aquele relacionamento que podia rolar".
*   **O bloqueio em momentos íntimos:** Quando, subitamente, o corpo desliga e a pessoa "já perdeu o tesão na hora, no momento". Em todas essas situações práticas, "aquilo que tava bom, de repente vai embora" devido à ativação de um gatilho somático e não por uma decisão racional.

