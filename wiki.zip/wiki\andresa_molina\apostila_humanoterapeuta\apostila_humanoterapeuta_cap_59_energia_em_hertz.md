---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_59_energia_em_hertz.md]]"]
---

# Cap 059 - Energia Em Hertz

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_59_energia_em_hertz.md]]

## Referencia

ANDRESA MOLINA. *Cap 059 - Energia Em Hertz*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_59_energia_em_hertz.md]]. Acesso em: 17 jun. 2026.
