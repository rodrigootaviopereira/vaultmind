﻿---
type: conceito
author: Andresa Molina
tags: [humanosense, mapa-da-alma, metodo, mesa, camara, anamnese, consolidacao]
sources:
  - "[[raw/archive/transcriptions/Aula 01 - Código Humanosense - Andresa Molina.md]]"
  - "[[raw/archive/transcriptions/07 Código Humanosense  - Andresa Molina.md]]"
  - "[[raw/archive/transcriptions/09 Código Humanosense  - Andresa Molina.md]]"
---
# Arquitetura do HumanoSense

## Definição
Nota-ponte que organiza a relação entre o `Mapa da Alma`, o `Método HumanoSense`, a `Mesa HumanoSense`, a `Ficha de Identificação` e a `Câmara HumanoSense`.

## Síntese
A wiki da autora mostra um encadeamento claro: primeiro a pessoa identifica as marcas e coordenadas da dor; depois traduz isso em ficha, método e condução prática; por fim trabalha a limpeza e a reorganização dentro de um campo guiado. Esta nota existe para impedir que esses elementos fiquem soltos em arquivos isolados.

## Eixos
- [[Conceito do Mapa da Alma]]
- [[Conceito do Metodo HumanoSense]]
- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]
- [[Conceito da Camara HumanoSense]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Tecnica de Aplicacao Guiada na Camara HumanoSense]]
- [[Mapa Estrutural da Wiki Andresa Molina]]

## Aplicação Prática
1. Use esta nota como porta de entrada quando o tema for integração geral do método.
2. Vá do mapa da dor para a ficha de identificação.
3. Da ficha, passe para a mesa e a câmara, onde a técnica se desenvolve.
4. Use o método como ligação entre diagnóstico, condução e reintegração.

## Relação com a Série
- O `Mapa da Alma` fornece a leitura da origem da dor.
- O `Método HumanoSense` organiza a prática.
- A `Mesa` e a `Câmara` são os espaços operativos da técnica.
- A `Ficha` e a `Anamnese` mantêm a sessão centrada na raiz.

## Referência
ANDRESA MOLINA. Transcrições de aulas do Código Humanosense e do Mapa da Alma. Arquivos de trabalho. [s.d.]. Fontes: [[raw/archive/transcriptions/Aula 01 - Código Humanosense - Andresa Molina.md]], [[raw/archive/transcriptions/07 Código Humanosense  - Andresa Molina.md]], [[raw/archive/transcriptions/09 Código Humanosense  - Andresa Molina.md]]. Acesso em: 16 jun. 2026.

## Camada MasterSense

- [[MasterSense - Mentoria do HumanoSense]] apresenta a mentoria como continuidade natural do HumanoSense.
- A aula 01 amplia a arquitetura ao mostrar que a tecnica opera junto de uma egregora, equipes espirituais e campos arquetipicos.
- A aula 02 confirma a arquitetura em casos reais: ficha, sistema digital, analise fria, personagens da dor e memoria celular deixam de ser conceitos separados e passam a funcionar como uma leitura integrada do atendimento.

## Limite do Sistema

- O HumanoSense deve ser lido como um sistema proprio dentro da autora, e nao como nome generico para toda a obra terapeutica dela.
- Para comparar sua arquitetura com os outros eixos da autora, usar [[Mapa dos Sistemas Terapeuticos de Andresa Molina]].
- O `Humanoterapeuta` e outra trilha formativa, mais ampla e com outras tecnicas.
- O `MasterSense` nao substitui a arquitetura do HumanoSense; ele a supervisiona e aprofunda.
