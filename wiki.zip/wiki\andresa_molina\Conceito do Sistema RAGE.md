---
type: conceito
author: Andresa Molina
tags: [neurociencia, sistema-rage, limites, autonomia, sobrevivencia]
sources: ["[[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito do Sistema RAGE

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: O Sistema RAGE (do inglês *Rage*, referindo-se ao circuito neurobiológico da raiva e autodefesa) é o mecanismo instintivo e neurológico responsável por regular a demarcação de limites, a autodefesa e a preservação do espaço vital (autonomia) de um indivíduo. Ele serve para sinalizar invasões, injustiças e abusos, fornecendo a força necessária para afastar a ameaça.
- **Formulação de apoio (3ª Coordenada)**: Quando este sistema é bloqueado ou interrompido de forma repetida na infância (através da repressão do choro ou da raiva pelos pais sob ameaça de abandono), a pessoa desaprende a defender seu território e a impor limites saudáveis. O sistema RAGE desregulado gera submissão compulsiva ou rompantes de agressividade desmedida (quando a panela de pressão acumula energia excessiva e explode).
- **Formulação de apoio (MasterSense)**: Ele aprofunda o HumanoSense no campo real dos atendimentos. A aula 03 do MasterSense reforça que receber sem culpa e reconhecer o que já chegou são etapas centrais da maturidade terapêutica e relacional. A aula 04 mostra que o terapeuta precisa modular linguagem, timing e intensidade para ajudar sem ferir a aliança com o assistido.
- **Limite do Sistema (MasterSense)**: O MasterSense é uma camada de lapidação do HumanoSense, não uma técnica-base separada do núcleo do método. Para não confundir MasterSense com Humanoterapeuta ou com o próprio HumanoSense, usar [[wiki/andresa_molina/Mapa dos Sistemas Terapeuticos de Andresa Molina.md|Mapa dos Sistemas Terapeuticos de Andresa Molina]].

## Contexto de Uso

- Usado para orientar leitura do assistido, organização da sessão, compreensão de padrões emocionais/energéticos e conexão entre método, ficha, mesa, câmara e condução espiritual no diagnóstico de submissão e limites violados.

## Relação com Princípios

- [[Principio da Raiva como Potencial de Autonomia]]
- [[Principio da Causa Inconsciente e da Reconsolidacao]]
- [[wiki/andresa_molina/MasterSense - Mentoria do HumanoSense.md|MasterSense - Mentoria do HumanoSense]]

## Exemplos do Material

### Evidências da 3ª Coordenada (A raiva que virou culpa)
- *"A neurociência diz que existe um sistema que se chama rage... que não é um sistema de agressividade, é um sistema de autonomia... O bloqueio repentino deste sistema na infância... ensina a criança que seus limites não são respeitados, que a sua raiva assusta as pessoas... e aí ela começa a perceber que é mais seguro ceder do que se defender."*
- O assistido que não consegue dizer não para empréstimos de dinheiro abusivos ou que aceita invasões constantes em sua intimidade tem uma desregulagem ou interrupção ativa no circuito do seu sistema RAGE.

### Evidências do MasterSense
- A aula 04 mostra que o terapeuta precisa modular linguagem, timing e intensidade para ajudar sem ferir a aliança com o assistido (MasterSense).

## Perguntas Frequentes / Didática de Atendimento

### O que é o sistema Rage na neurociência?

Na neurociência, o sistema *Rage* não é fundamentalmente um sistema voltado para a agressividade ou para a violência, mas sim um **sistema de autonomia e autodefesa**. Ele está associado à emoção natural da raiva que, quando devidamente equilibrada e regulada, possui uma função de proteção essencial.

O sistema *Rage* funciona como um "botão de volume" que fornece a força vital necessária para que o indivíduo seja efetivamente dono da sua própria vida. É este sistema que confere a liberdade e a potência para que a pessoa consiga **impor limites claros**, permitindo-lhe dizer "não" e bater na mesa para barrar abusos ou intrusões de terceiros sem sentir culpa.

Quando esse mecanismo é interrompido ou bloqueado, o que frequentemente ocorre na infância devido à repressão do choro e das emoções, a pessoa perde essa barreira natural de proteção. Como consequência da desregulação do sistema *Rage*, o indivíduo passa a operar em um padrão automático de submissão, onde entende que é mais seguro ceder do que se defender, tornando-se suscetível a ter seus limites desrespeitados, a permitir abusos frequentes e **a acumular essa pressão emocional em forma de marcas e tensões físicas crônicas (como dores nos ombros e no estômago)**.

### Quais sinais físicos indicam o bloqueio do sistema Rage?

O bloqueio do [[Conceito do Sistema RAGE|Sistema RAGE]] — que é o nosso sistema neurológico natural de autonomia e imposição de limites — faz com que o indivíduo reprima sua raiva e passe a "engolir" suas emoções para não desagradar os outros, gerando uma [[Conceito da Falsa Inteligencia Emocional|Falsa Inteligência Emocional]]. Essa repressão contínua cria uma "panela de pressão" e uma inflamação emocional crônica que afeta diretamente o corpo físico.

Os principais sinais físicos que indicam esse bloqueio e o acúmulo de raiva reprimida no corpo incluem:

*   **Problemas Gastrointestinais:** O desenvolvimento de úlceras e gastrite nervosa.
*   **Inflamação Sistêmica e Dificuldade de Emagrecer:** A raiva contida inflama fisicamente o estômago, o intestino e o sangue da pessoa. Essa inflamação constante impede que o corpo funcione de forma saudável, bloqueando o emagrecimento mesmo quando a pessoa faz dietas ou exercícios.
*   **Dores Crônicas:** O surgimento de dores constantes no corpo, especialmente dor de cabeça, dor no pescoço e dor nas costas, acompanhadas de uma forte sensação de peso e rigidez.
*   **Exaustão Extrema:** Um cansaço absurdo e inexplicável, no qual a pessoa sente que não suporta mais o peso de carregar as demandas alheias.
*   **Desregulação do Sistema Nervoso:** Crises de ansiedade em que a pessoa não sabe identificar o motivo do nervosismo, além de episódios de surtos ou choros reativos que "aparecem na hora errada" ou parecem surgir "do nada".

Esses sinais são as coordenadas físicas mapeadas na [[Tecnica de Mapeamento Somatico da Raiva|Prática de Mapeamento Somático da Raiva]] que indicam que a ferida emocional está aberta e infeccionada internamente. Como a emoção não foi direcionada para fora como forma de defesa e limite (a função original do [[Principio da Raiva como Potencial de Autonomia|Princípio da Raiva como Potencial de Autonomia]]), ela ataca e adoece as próprias células.

## Referência

ANDRESA MOLINA. *Conceito do Sistema RAGE*. Aula 03 - Coordenada 3 (A Raiva que Virou Culpa) e MasterSense. Fontes: [[raw/archive/andresa_molina/transcriptions/03 - A RAIVA QUE VIROU CULPA 3ª Coordenada - O Mapa da Alma.md]] e material do MasterSense.

---

> [!NOTE]
> **Nota de Consolidação (Código HumanoSense & Mapa da Alma)**
> O **Sistema RAGE** representa a força primária de autonomia e demarcação de limites do Código HumanoSense. Quando bloqueado por castração ou ameaça de perda na infância, ele ativa a **3ª Coordenada (A Raiva que Virou Culpa)**. A mentoria MasterSense ensina o terapeuta a rastrear o travamento desse sistema através dos sintomas somáticos (inflamação digestiva) e a modular a energia do atendimento para libertar o cliente da autopunição financeira e da culpa por se impor.

