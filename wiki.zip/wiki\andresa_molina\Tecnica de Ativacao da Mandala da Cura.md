---
type: tecnica
author: Andresa Molina
tags: [mandala-cura, encerramento, harmonizacao, trindade-vibracional]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# Técnica de Ativação da Mandala da Cura (A harmonização no encerramento)

- **Objetivo**: Ajustar e estabilizar vibracionalmente os corpos sutis do assistido por meio da ativação da Mandala da Cura da mesa, infundindo as três virtudes de Habilidade, Disponibilidade e Autorização no campo biológico.
- **Pré-requisitos**: Ancoramento e encerramento da fase de regressão/fecundação.
- **Passo a Passo**:
  1. O terapeuta (ou o assistido presencial) posiciona o dedo no selo central da mesa.
  2. O terapeuta gira o pêndulo no sentido horário sobre a área correspondente à Mandala da Cura.
  3. Repete verbalmente a trindade de encerramento: *"Harmoniza (habilidade), potencializa (disponibilidade) e liberta (autorização)"*, sustentando o giro até que o pêndulo atinja a oscilação harmônica padrão.
  4. A cura instalada permeia a biologia e é selada de forma definitiva.
- **Duração/Frequência**: Executada no rodapé de encerramento da mesa.
- **Indicadores de Sucesso**: Estabilização do pêndulo no selo, relaxamento imediato e sensação de paz declarada pelo assistido.
- **Variações**: Harmonização simplificada em atendimentos rápidos ou após suspensão clínica por exaustão.
- **Conceitos Envolvidos**: [[Tecnica de Retorno a Consciencia e Harmonizacao]], [[Principio da Liberdade Consciente]]

## Perguntas Frequentes / Didática de Atendimento

### 20. Como o terapeuta opera as frequências de "Harmoniza, Potencializa e Liberta" no encerramento e desconecta a pessoa da mesa?
**Resposta**: A nível vibracional, enquanto o cliente ainda está na mesa, o terapeuta ativa a "mandala da cura" verbalizando em sequência: "harmoniza, potencializa liberta, harmoniza, potencializa liberta, harmoniza, potencializa liberta". Essas palavras fazem com que a "cura vai permeando e no final a gente sela isso e encerra e entrega". Para desconecta a pessoa, a instrução nesta aula orienta simplesmente: "e depois você vai retirar ela da mesa".


## Referencia

ANDRESA MOLINA. *Técnica de Ativação da Mandala da Cura*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
