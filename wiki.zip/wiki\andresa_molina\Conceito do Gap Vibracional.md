---
type: conceito
author: Andresa Molina
tags: [gap-vibracional, racional, inconsciente, pendulo, diagnostico]
sources: ["[[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]"]
---

# O Gap Vibracional (A dissonância entre o consciente e o inconsciente)

- **Definição Precisa**: A distância numérica medida na régua da mesa quântica entre a nota declarada de forma lógica e racional pelo assistido (consciente) e a nota real detectada radiestesicamente pelo pêndulo no seu campo bioenergético (inconsciente) para uma mesma pergunta diagnóstica.
- **Sinônimos/Variações**: Dissonância consciente-inconsciente, gap de choque, distância quântica.
- **Contexto de Uso**: Rastreia-se o gap para mensurar o nível de autoengano e sabotagem do assistido em relação às suas próprias competências ou superação de dores (especialmente quando a distância é de três pontos ou mais).
- **Relação com Princípios**: [[Principio da Desilusao]], [[Principio da Causa Inconsciente e da Reconsolidacao]]
- **Exemplos do Material**: "Ele diz que ele consegue criar e sustentar, mas na verdade não é isso que ele faz. Ele não significa que ele é um mentiroso. Significa às vezes é porque a gente mente pra gente para caramba... Às vezes é porque ele não percebe que ele tá fazendo aquilo. Ele acha que ele tá fazendo tudo e por isso ele tá angustiado, mas ele não tá... Quando tá uns dois, três pontos de distância, o consciente, o inconsciente de três para cima, tá muito estranho, porque ele pensa que é uma coisa, ele diz que é uma coisa, mas inconscientemente ele tá se movendo por outra e os problemas estão exatamente nessa raiz."
- **Aplicação Prática**: O terapeuta anota as notas racional e quântica lado a lado e apresenta a divergência ao assistido, desarmando de imediato a falsa narrativa de controle mental do ego e conduzindo-o à percepção de sua real vulnerabilidade.
- **Conexões Externas**: [[Tecnica de Rastreio Duplo nas Mandalas]], [[Tecnica de Diagnostico de Alinhamento Consciente-Inconsciente]]

## Perguntas Frequentes / Didática de Atendimento

### 7. Como Andresa Molina conceitua a divergência entre a resposta lógica e o pêndulo, e de que forma isso sinaliza uma mentira interna?
**Resposta**: A autora conceitua essa divergência como a distância mensurável de autoilusão do paciente. Quando o cliente dá uma nota alta para si mesmo, mas o pêndulo corta em uma nota baixa, isso revela que "Ele diz que ele consegue criar e sustentar, mas na verdade não é isso que ele faz".

A nível somático e mental, uma divergência profunda ("quando tá uns dois, três pontos de distância, o consciente, o inconsciente de três para cima") acusa um colapso vibracional grave. A autora explica que "tá muito estranho, porque ele pensa que é uma coisa, ele diz que é uma coisa, mas inconscientemente ele tá se movendo por outra e os problemas estão exatamente nessa raiz". Essa "autossabotagem" ocorre porque "a gente mente pra gente para caramba" ou porque a pessoa "tá iludido, acreditando que faz uma coisa no fundo, é um sentimento invertido". Fisicamente, o paciente acha que sua vida não dá resultados por acaso, mas é o seu próprio inconsciente travando a ação real.

## Referencia

ANDRESA MOLINA. *O Gap Vibracional*. Aula 07 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]].
