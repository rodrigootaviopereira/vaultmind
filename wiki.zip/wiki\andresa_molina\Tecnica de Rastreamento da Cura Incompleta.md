---
type: tecnica
author: Andresa Molina
tags: [tecnica, autoanalise, 7a-coordenada, conexao-corporal, rastreamento, cura]
sources: ["[[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]]"]
---

# Técnica de Rastreamento da Cura Incompleta (Rastreio da Cura Falha)

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]]

## Objetivo

- Evidenciar e desmascarar a ilusão mental de que tratamentos terapêuticos e energéticos passados resolveram efetivamente as dores do assistido, mapeando as dores e escassezes que ainda persistem no inconsciente e no corpo para direcionar o atendimento à causa-raiz.

## Pré-requisitos

- Relaxamento corporal preliminar (ex: [[Tecnica de Conexao e Respiracao das Coordenadas]]).
- Ancoragem no estado de presença, suspendendo cobranças intelectuais ou autojulgamentos.

## Passo a Passo

1. **Entrar no Estado de Ancoragem**:
   - Solicitar ao assistido que feche os olhos e respire fundo para baixar as defesas lógicas da mente racional.
2. **Autoquestionamento Direto (Sem Julgamento)**:
   - Apresentar as três perguntas diagnósticas essenciais, instruindo o paciente a registrar a primeira resposta somática ou mental que surgir espontaneamente, sem filtrar:
     - **Pergunta 1: O Investimento Ineficaz**: *"O que você buscou até hoje para se curar? O que você tentou?"* (relembrar cursos, terapias, remédios, harmonizações).
     - **Pergunta 2: A Prova do Analgésico**: *"O que melhorou e o que voltou?"* (identificar se a melhora foi temporária, agindo como um paliativo).
     - **Pergunta 3: O Rastreio do Desejo**: *"O que ainda falta? O que ainda não chegou onde você precisava? O que ainda precisa de cura ou resolução?"*
3. **Mapeamento da Reincidência**:
   - Analisar o que "voltou". Se o sintoma ou o travamento financeiro retornou, explicar didaticamente ao assistido que a intervenção anterior funcionou apenas como um "analgésico para dor de cabeça", deixando a raiz celular ativa.
4. **Ancoragem da Resposta Somática**:
   - Direcionar a atenção do paciente para o local do corpo onde a angústia ou insatisfação dessas respostas ressoa fisicamente, preparando a rota de escavação da dor.

## Duração/Frequência

- Executado na fase inicial da anamnese diagnóstica (5 a 10 minutos).

## Indicadores de Sucesso

- Quebra da barreira de negação ou otimismo cego do assistido sobre seu estado atual.
- Conscientização lúcida de que as tentativas anteriores foram analgésicos mentais ou puramente energéticos na superfície.
- Identificação exata da dor persistente e do desejo legítimo do espírito do assistido.

## Conceitos Envolvidos

- [[Conceito da 7a Coordenada]]
- [[Conceito de Cura-Raiz vs Alivio Analgesico]]
- [[Princopio da Proporcao Inconsciente]]

## Notas Pessoais

- Reservado para registros de aplicação do usuário.

## Referência

ANDRESA MOLINA. *Técnica de Rastreamento da Cura Incompleta (Rastreio da Cura Falha)*. Aula 07 - Coordenada 7 (A Cura Buscada em Todo Lugar). Fontes: [[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]].
