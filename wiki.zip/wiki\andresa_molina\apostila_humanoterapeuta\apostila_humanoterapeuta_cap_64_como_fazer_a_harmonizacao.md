---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_64_como_fazer_a_harmonizacao.md]]"]
---

# Cap 064 - Como Fazer A Harmonizacao

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_64_como_fazer_a_harmonizacao.md]]

## Referencia

ANDRESA MOLINA. *Cap 064 - Como Fazer A Harmonizacao*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_64_como_fazer_a_harmonizacao.md]]. Acesso em: 17 jun. 2026.
