---
type: transcricao
author: Bashar
tags: [bashar, permissao, crenças, conflito, vitima]
sources: ["[[raw/transcriptions/Como quebrar padrões e TER PERMISSÃO  Bashar explica  Análises críticas.md]]"]
---

# Permissão e Crenças que Sustentam Conflito

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/transcriptions/Como quebrar padrões e TER PERMISSÃO  Bashar explica  Análises críticas.md]]


## Síntese

A transcrição liga conflito à sensação de impotência e crenças de desconexão. O ponto de virada é reconhecer que crenças negativas são construções, não fatos.

## 80/20

- Conflito nasce da sensação de falta de poder.
- Crenças negativas sustentam identidades de vítima.
- A permissão dissolve a necessidade de forçar a realidade.

## Leitura Analítica

- O texto trabalha a substituição de confronto por autonomia e suavidade.

## Referencia

BASHAR. *Permissão e Crenças que Sustentam Conflito*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/transcriptions/Como quebrar padrões e TER PERMISSÃO  Bashar explica  Análises críticas.md]]. Acesso em: 17 jun. 2026.
