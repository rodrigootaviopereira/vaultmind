---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_108_todas_ondas_eletromagneticas_do_universo.md]]"]
---

# Cap 108 - Todas Ondas Eletromagneticas Do Universo

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_108_todas_ondas_eletromagneticas_do_universo.md]]

## Referencia

ANDRESA MOLINA. *Cap 108 - Todas Ondas Eletromagneticas Do Universo*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_108_todas_ondas_eletromagneticas_do_universo.md]]. Acesso em: 17 jun. 2026.
