---
type: conceito
author: Hélio Couto
tags: [auto-sabotagem, ego, resistencia, mudanca, programacao-mental]
sources: ["[[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_12_introdução.txt]]", "[[raw/archive/investigando_seu_sistema_de_crenas_44_helio_couto/investigando_seu_sistema_de_crenas_44_helio_couto_cap_01_livro_completo.txt]]"]
---

# Conceito de Autossabotagem

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_12_introdução.txt]]
  - [[raw/archive/investigando_seu_sistema_de_crenas_44_helio_couto/investigando_seu_sistema_de_crenas_44_helio_couto_cap_01_livro_completo.txt]]

## Referencia

HÉLIO COUTO. *Conceito de Autossabotagem*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_12_introdução.txt]], [[raw/archive/investigando_seu_sistema_de_crenas_44_helio_couto/investigando_seu_sistema_de_crenas_44_helio_couto_cap_01_livro_completo.txt]]. Acesso em: 17 jun. 2026.
