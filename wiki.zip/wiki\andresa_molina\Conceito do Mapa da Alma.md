---
type: conceito
author: Andresa Molina
tags: [mapa-da-alma, autoconhecimento, cura, marcas, diagnostico]
sources: ["[[raw/archive/andresa_molina/transcriptions/01 - O CANSAÇO QUE NÃO PARA 1ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito do Mapa da Alma

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/01 - O CANSAÇO QUE NÃO PARA 1ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: O Mapa da Alma representa a cartografia de marcas emocionais, energéticas e biológicas que estão gravadas no corpo físico de uma pessoa. Essas marcas funcionam como "coordenadas" que indicam onde a dor (seja desta vida ou herdada de ancestrais) está cristalizada e como ela afeta o fluxo de energia e de comportamento da pessoa.
- **Formulação de apoio (1ª Coordenada)**: *"Toda coordenada tem uma marca e toda marca ela precisa ser decifrada... Tudo o que acontece na nossa vida, ela fica registrada no nosso corpo, não só nas nossas lembranças. Então elas são memórias. E memórias é diferente de lembrança. Por isso é que você não consegue se lembrar do que aconteceu. Mas isso não significa que ela não continue rodando como um padrão dentro de você..."*
- **Formulação de apoio (Arquitetura do HumanoSense)**: Use o método como ligação entre diagnóstico, condução e reintegração. O `Mapa da Alma` fornece a leitura da origem da dor.

## Sinônimos/Variações

- Coordenadas do Corpo, Marcas da Alma, Mapa de Fuga e Dor, Cartografia da Memória Celular.

## Contexto de Uso

- Serve como o primeiro passo de diagnóstico no método HumanoSense. Permite ao terapeuta e ao assistido localizarem no corpo físico a âncora energética de um bloqueio persistente (como escassez, autossabotagem, cansaço crônico) para guiar o processo subsequente de reconsolidação emocional.

## Relação com Princípios

- [[Principio da Memoria Celular Ancestral]]
- [[Principio da Causa Inconsciente e da Reconsolidacao]]

## Exemplos do Material

- O cansaço físico que não passa mesmo após dormir ou tomar vitaminas é uma coordenada no Mapa da Alma que aponta para uma marca ancestral de impotência ou exaustão emocional sistêmica carregada por gerações.
- As dores físicas localizadas (peso nos ombros, aperto no peito, dor na coluna) são registros celulares (memórias emocionais) e não simples problemas musculares.
- Use o método como ligação entre diagnóstico, condução e reintegração. Relação com a Série: O `Mapa da Alma` fornece a leitura da origem da dor; o `Método HumanoSense` organiza a prática; a `Mesa` e a `Câmara` são os espaços operativos da técnica; a `Ficha` e a `Anamnese` mantêm a sessão centrada na raiz. (Arquitetura do HumanoSense)

## Aplicação Prática

1. **Localização Corporal**: Identificar onde no corpo físico a dor ou desconforto se manifesta (cabeça, ombros, peito, abdômen, etc.).
2. **Definição de Autoria**: Identificar se a coordenada de dor pertence ao assistido ou se é uma marca ancestral carregada de forma inconsciente.
3. **Mapeamento de Linhagem**: Determinar se a marca provém da linhagem materna ou paterna.
4. **Decodificação**: Utilizar a marca localizada como ponto de partida para a reprogramação energética e celular, acessando as camadas mais profundas de trauma para realizar a reconsolidação.

## Conexões Externas

- [[wiki/andresa_molina/Arquitetura do HumanoSense.md|Arquitetura do HumanoSense]]
- [[wiki/andresa_molina/MasterSense - Mentoria do HumanoSense.md|MasterSense - Mentoria do HumanoSense]]
- [[wiki/andresa_molina/HT - Apostila Humanoterapeuta - Andresa Molina.md|HT - Apostila Humanoterapeuta - Andresa Molina]]
- [[Tecnica de Identificacao do Cancaco Ancestral]]

## Perguntas Frequentes / Didática de Atendimento

### Como as 7 Coordenadas se conectam no Mapa da Alma?

No ensinamento de Andresa, o "Mapa da Alma" e as suas "7 Coordenadas" conectam-se como um sistema unificado de leitura corporal e energética, projetado para rastrear e curar traumas sistêmicos e ancestrais.

A conexão entre elas funciona da seguinte forma:

**1. O Corpo como o "Mapa"**
A premissa central é que o nosso corpo físico funciona como um grande mapa que registra e armazena todas as experiências, dores e memórias (inclusive as herdadas por genética e ancestralidade). Como o intelecto não acessa essas informações, o disparo do [[Principio da Memoria Corporal Inconsciente|Princípio da Memória Corporal Inconsciente]] faz com que a pessoa sofra com crises financeiras, emocionais e dores físicas que parecem surgir "do nada". O objetivo do processo é aprender a ler esse mapa interior.

**2. As Coordenadas como o "X" do Problema**
As coordenadas são os locais exatos, as "marcas" físicas no corpo onde essas dores estão ancoradas. Encontrar uma coordenada significa rastrear a dor emocional até o ponto em que ela pesa, dói ou repuxa fisicamente no corpo.

As 7 coordenadas não são problemas isolados; **"uma tá entrelaçada na outra"** e todas conduzem à leitura completa do mapa da alma. Ao longo do processo, mapeiam-se progressivamente:
*   **1ª Coordenada (O Cansaço Extremo):** O esgotamento profundo de quem carrega dores que não são apenas suas, mapeado no [[Principio da Memoria Celular Ancestral|Princípio da Memória Celular Ancestral]].
*   **2ª Coordenada (O Amor que não voltou):** O padrão de doar e ceder excessivamente sem receber afeto de volta, gerando o medo do abandono e do [[Conceito do Abandono de Si|Abandono de Si]].
*   **3ª Coordenada (A Raiva que virou culpa):** A supressão da autonomia natural para não desagradar os outros, gerando inflamação física e o [[Conceito do Ciclo de Autopunicao|Ciclo de Autopunição]].
*   **4ª Coordenada (A mulher que eu era antes de ser de todos):** Onde o indivíduo se perdeu e se anulou completamente para atender às demandas de todo mundo.
*(As outras três coordenadas completam o roteiro de sete passos desse rastreamento)*

**3. A Geometria e a Desprogramação**
A grande conexão entre as 7 coordenadas é que, juntas, elas formam a "geometria sagrada" da dor do indivíduo, relacionada à [[Conceito da Geometria Sagrada|Geometria Sagrada]]. Quando a pessoa consegue identificar e conectar todas essas marcas ("fazer um X nessa marca"), ela deixa de estar confusa com suas próprias reações.

A partir dessa leitura completa e interconectada, torna-se possível realizar o que a autora chama de **reconsolidação de memória** ou desipnose, estudada em [[Conceito de Ressignificacao vs Reconsolidacao|Ressignificação vs Reconsolidação]]. Esse é o trabalho energético que desprograma o padrão de sofrimento registrado em todas essas coordenadas, libertando o indivíduo de seus bloqueios e ciclos de escassez.

## Referência

ANDRESA MOLINA. *Conceito do Mapa da Alma*. Aula 01 - Coordenada 1 (Cansaço que não para) e Arquitetura do HumanoSense. Fontes: [[raw/archive/andresa_molina/transcriptions/01 - O CANSAÇO QUE NÃO PARA 1ª Coordenada - O Mapa da Alma.md]].
