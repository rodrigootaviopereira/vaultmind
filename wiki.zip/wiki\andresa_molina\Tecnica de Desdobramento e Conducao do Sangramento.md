---
type: tecnica
author: Andresa Molina
tags: [desdobramento, camara-humanosense, sangramento, transe, catarse]
sources: ["[[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]"]
---

# O Desdobramento e a Condução do Sangramento (O transe de dor e a purgação na cena)

- **Objetivo**: Conduzir o desdobramento da consciência do assistido para dentro do estado plasmático da Câmara Humanosense, localizando a cena de dor ancestral associada à queixa e estimulando a catarse/sangramento do afeto estagnado.
- **Pré-requisitos**: Consentimento do assistido e estabilidade energética constatada no rastreio da mesa.
- **Passo a Passo**:
  1. **Desdobramento Astral**: O terapeuta recita o comando para conduzir a consciência à Câmara: *"Desdobro ambos pra câmara manocência em 1 2 3 4 e 5. E ativo os códigos senses"*.
  2. **Ancoramento na Cena**: O terapeuta investiga a tela mental do assistido por meio de perguntas ativas: *"O que você está vendo? Onde você está? Quem mais está na cena?"*, guiando-o a localizar o fragmento/contraparte ferida.
  3. **Sangramento da Dor**: O terapeuta força ativamente a catarse somática e verbal, proibindo amortecimentos ou consolação rápida: *"Fala com ela... Sangra. Chora. Coloca tudo para fora"*. O assistido deve esvaziar totalmente a dor reprimida (gritar, chorar) até a exaustão da carga emocional.
- **Duração/Frequência**: Executada durante o transe de regressão e liberação de memórias traumáticas.
- **Indicadores de Sucesso**: Esvaziamento total da angústia ancestral da contraparte, relaxamento corporal somático após o choro e sensação de alívio profundo no peito.
- **Variações**: Condução de sangramento de raiva ancestral (gritar em silêncio) vs. sangramento de dores de rejeição materna ou paterna.
- **Conceitos Envolvidos**: [[Conceito do Sangramento do Utero da Vida]], [[Conceito da Camara HumanoSense]], [[Tecnica do Confronto e Resgate da Contraparte]]

## Perguntas Frequentes / Didática de Atendimento

### 15. Como o terapeuta opera a transição do assistido para a Câmara Humanosense e como se dá o comando de desdobramento?
**Resposta**: O terapeuta opera a transição de consciência guiando um "alfa profundo" (um relaxamento) para sincronizar o campo somático: "respira pelo nariz, solta pela boca... entra em sintonia com ele no campo energético".

Em seguida, o terapeuta evoca a equipe espiritual e dá o comando verbal de desdobramento da consciência do paciente para o ambiente de cura: "Eu, Andresa Molina, membro da igrega humanse, ajusto as coordenadas e códigos de acesso para abertura da Câmara Homanocense... Conecto com os povos originários... povos das estrelas... Desdobro ambos pra câmera manocência em 1 2 3 4 e 5. E ativo os códigos senses".

### 16. De que forma o terapeuta conduz o "sangramento" da dor e por que a autora exige que a emoção seja esgotada por inteiro?
**Resposta**: O terapeuta conduz esse esvaziamento incitando o paciente a enfrentar a memória e não fugir dela: "Vai lá e fala: Pai, não bate na mãe... Fala. Sangra. Chora. E vai falando. Vai sangrando. Pode falar".

A nível somático, a autora ensina que a emoção não pode ser reprimida (acalmada antecipadamente) porque "só o que é sentido por inteiro pode enem ser curado". O corpo precisa excretar a energia estagnada; o terapeuta obedece à regra de "permita que a dor exista sem tentar expulsá-la". A dor deve jorrar até acabar naturalmente, pois "Ninguém fica sangrando para todo o resto da vida, tu morre. Só que quem não sangrou morre também". Se a pessoa não esvaziar tudo na mesa, o resíduo do trauma continua apodrecendo a biologia dela.

## Referencia

ANDRESA MOLINA. *O Desdobramento e a Condução do Sangramento*. Aula 07 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]].
