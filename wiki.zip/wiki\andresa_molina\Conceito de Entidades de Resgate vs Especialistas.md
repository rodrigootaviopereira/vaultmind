---
type: conceito
author: Andresa Molina
tags: [entidades-resgate, especialistas, egregora, tecnologia-espiritual]
sources: ["[[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]]"]
---

# Entidades de Resgate vs. Entidades Especialistas (A divisão de atuação no campo espiritual)

- **Definição Precisa**: A divisão operacional das equipes da egrégora que o terapeuta invoca, dividida entre as equipes de resgate geral (responsáveis por limpeza, recolhimento e encaminhamento de fractais de dor à [[Conceito da Camara HumanoSense|Câmara HumanoSense]]) e as equipes de especialistas (entidades com habilidades técnicas específicas chamadas para intervenções mecânicas ou cirúrgicas precisas na cena astral).
- **Sinônimos/Variações**: Equipe de Limpeza e Resgate vs. Equipes Especializadas.
- **Contexto de Uso**: Invoca-se as Entidades de Resgate padrão para limpar o campo vibracional e recolher as almas feridas. Já as Entidades Especialistas são acionadas quando há barreiras mecânicas, correntes, desabamentos, ferimentos cirúrgicos ou obstruções complexas no campo astral do assistido.
- **Relação com Princípios**: [[Principio do Respeito a Tecnica e a Equipe Espiritual]]
- **Exemplos do Material**: "As entidades com habilidade, disponibilidade e autorização são as entidades que vão fazer a limpeza e o recolhimento e encaminhamento dessas consciências. Essas entidades especialistas, elas vão fazer alguma coisa que não tem a ver com o recolhimento em si... precisava de alguém para especializado para recolher a carroça. Alguém... precisava de estravar que era a roda da carroça... Pode vir um pedreiro porque a casa caiu. Pode vir um bombeiro para tirar dos resgat para tirar dos destroços. Pode vir um piloto para ajudar a retomar uma rota."
- **Aplicação Prática**: Ao visualizar a cena espiritual de dor do assistido, o terapeuta deve avaliar se a contraparte está livre para ir embora ou se precisa de auxílio especializado para desfazer amarras ou resolver o cenário. Diante disso, escolhe o comando adequado.
- **Conexões Externas**: [[Tecnica do Comando de Encaminhamento Padrao]], [[Tecnica do Comando de Intervencao Especializada]]

## Perguntas Frequentes / Didática de Atendimento

## Perguntas Frequentes / Didática de Atendimento

### 7. Qual a diferença de atuação e competência técnica entre as "Entidades de Resgate" e as "Entidades Especialistas" dentro do campo espiritual de atendimento?
**Resposta**: *(Nota: A autora denomina as equipes de resgate padrão como "entidades com habilidade, disponibilidade e autorização").*
A divisão de competências na dimensão astral ocorre pela natureza mecânica ou vibracional da barreira a ser superada na cena traumática do assistido:
*   **A Equipe Padrão ("Habilidade, Disponibilidade e Autorização"):** São convocadas para atuar na emoção estagnada. Elas **"são as entidades que vão fazer a limpeza e o recolhimento e encaminhamento dessas consciências"** para a Câmara Humanosense assim que a dor se esgota.
*   **As Entidades Especialistas:** São acionadas exclusivamente para **"tratamentos de situações específicas"** e a sua atuação **"não tem a ver com o recolhimento em si"**. A nível estrutural na cena projetada, essas equipes funcionam como engenheiros, engenheiros de combate, enfermeiros ou militares astrais acionados para resolver entraves físicos do holograma. A autora detalha as competências: **"precisava de estravar que era a roda da carroça... Pode vir um pedreiro porque a casa caiu. Pode vir um bombeiro para tirar dos resgat para tirar dos destroços. Pode vir um piloto para ajudar a retomar uma rota"**.

## Referencia

ANDRESA MOLINA. *Entidades de Resgate vs. Entidades Especialistas*. Aula 06 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]].
