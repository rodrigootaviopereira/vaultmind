---
type: principio
author: Andresa Molina
tags: [naturalidade-clinica, catarse, medo-do-terapeuta, purgação]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio da Naturalidade Clínica (A desmistificação de reações catárticas)

- **Definição**: A postura de frieza, calma e naturalidade exigida do terapeuta perante reações fisiológicas de expurgo somático do assistido (como tosse, enjoo ou vômito) durante o transe, desarmando a dramatização e fantasia espiritual.
- **Justificativa**: Muitos terapeutas criam medos irracionais de que os clientes vão incorporar demônios ou ter colapsos físicos durante o desdobramento. A autora esclarece que reações físicas são manifestações normais do corpo eliminando toxinas acumuladas. Manter a naturalidade clínica impede a alimentação de uma atmosfera de drama que assustaria o cliente e interromperia a cura.
- **Evidências**: "Vocês criam os priores. Você pelo amor de Deus, não tem nada disso. Vocês queram falar: 'Meu Deus, vai vir uma pessoa aqui, ela vai incorporar, vomitar, cair da cadeira'. A gente queria um monstro, calma, não vai acontecer nada. Fique em paz, tá tudoado. E se acontecer qualquer coisa com naturalidade, volta para cá, presta atenção no seu corpo... Lida com naturalidade, porque é um processo natural do nosso corpo, né? É, de colocar para fora e a pessoa lida com naturalidade."
- **Implicações**: O terapeuta deve reagir com serenidade prática a qualquer manifestação corporal do cliente, reconduzindo-o suavemente ao sentir.
- **Conexões**: [[Tecnica de Avaliacao de Estado]], [[Tecnica de Desdobramento e Conducao do Sangramento]]
- **Notas Pessoais**: Desmistificar o plano espiritual previne dramas infantis de possessão.

## Perguntas Frequentes / Didática de Atendimento

### 4. Qual a postura exigida do terapeuta perante reações de expurgo (enjoos, tosse), e como a naturalidade clínica impede a "criação de monstros"?
**Resposta**: A postura exigida é a de absoluta calma. Se o assistido apresentar reações físicas e instintivas — como **"tir aquele movimento energético, sabe? Parece que tem uma tose, mas que não é"** —, o terapeuta deve encarar isso de forma tranquila, pois **"é um processo natural do nosso corpo, né? É, de colocar para fora"**.

A "naturalidade" clínica blinda a sessão contra o misticismo doentio. A autora critica terapeutas que criam pânico e fantasmas na própria mente: **"Vocês criam os priores. Você pelo amor de Deus, não tem nada disso. Vocês queram falar: 'Meu Deus, vai vir uma pessoa aqui, ela vai incorporar, vomitar, cair da cadeira'. A gente queria um monstro"**. Para não criar esse monstro vibracional, o terapeuta não pode demonstrar medo; ele deve ancorar a segurança do ambiente ordenando: **"Fique em paz... E se acontecer qualquer coisa com naturalidade, volta para cá, presta atenção no seu corpo, não deixa qualquer coisa entrar"**.


## Referencia

ANDRESA MOLINA. *Princípio da Naturalidade Clínica*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
