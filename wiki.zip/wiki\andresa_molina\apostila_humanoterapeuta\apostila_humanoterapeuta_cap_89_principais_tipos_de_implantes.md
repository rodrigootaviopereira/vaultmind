---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_89_principais_tipos_de_implantes.md]]"]
---

# Cap 089 - Principais Tipos De Implantes

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_89_principais_tipos_de_implantes.md]]

## Referencia

ANDRESA MOLINA. *Cap 089 - Principais Tipos De Implantes*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_89_principais_tipos_de_implantes.md]]. Acesso em: 17 jun. 2026.
