---
type: principio
author: Andresa Molina
tags: [neutralidade, familiar, manipulação, transferencia-de-dor]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio da Neutralidade Familiar / Impedimento Clínico (O risco magnético com parentes)

- **Definição**: A diretriz ética que recomenda que o terapeuta evite atender parentes próximos (como filhos ou cônjuges), devido ao risco severo de contaminação magnética, transferência de dores e tentativa subconsciente de manipulação dos resultados da sessão.
- **Justificativa**: O terapeuta deve atuar como um canal limpo e neutro. Atender parentes inviabiliza essa neutralidade de duas maneiras: primeiro, o ego e a intimidade familiar (ex: ter que discutir a vida sexual de um filho com a mãe terapeuta) inibem o cliente; segundo, a dor do parente reverbera na própria história do terapeuta, provocando um colapso vibracional no campo ("quando junta piora"). Há também o perigo da manipulação consciente ou inconsciente dos decretos da mesa devido ao apego pessoal da terapeuta pelo destino do filho.
- **Evidências**: "Se eu não consigo lidar com alguma coisa porque pega em mim ou porque dói porque eu quero manipular, porque eu não gostaria que ela fosse embora, por exemplo, aí é melhor eu não fazer porque é uma dor que tá e dói em mim... imagina um filho tendo que falar e chorar uma dor de uma questão sexual dele com a mãe. Não vai trazer... Se ela tá na dor e eu entro na dor, eu alimento, deixo ela em mais dor, toma a dor dela com a minha, quando junta piora."
- **Implicações**: Casos de familiares devem ser encaminhados a colegas terapeutas para garantir a integridade do processo de cura.
- **Conexões**: [[Principio do Consentimento e Invasao de Campo]], [[Conceito de Invasao Energetica ou Obsessao]]
- **Notas Pessoais**: Encaminhar familiares demonstra maturidade técnica e ética.

## Perguntas Frequentes / Didática de Atendimento

### 5. Por que Andresa Molina recomenda não tratar familiares e de que maneira a relação contamina a mesa?
**Resposta**: A autora desaconselha o atendimento de familiares próximos porque o terapeuta perde a neutralidade necessária para a egrégora atuar, sendo corrompido pelo seu próprio desejo de intervir na vida do parente: **"eu quero manipular, porque eu não gostaria que ela fosse embora"**. Além disso, a intimidade atua como um bloqueio intransponível: **"Imagina um filho tendo que falar e chorar uma dor de uma questão sexual dele com a mãe. Não vai trazer"**.

A nível somático e vibracional, se o terapeuta se comove com a dor do parente, ele deixa de ser um canal de cura e iguala a sua vibração à da ferida: **"se eu entro na dor, eu não sou, deixa ser terapeuta, porque daí a gente tá falando de frequência, vibração. Aí eu não tô mandando, não tô transferindo para ela a frequência que ela precisa"**. Ao invés de curar, o corpo do terapeuta absorve a carga e a intensifica: **"toma a dor dela com a minha, quando junta piora"**.


## Referencia

ANDRESA MOLINA. *Princípio da Neutralidade Familiar / Impedimento Clínico*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
