---
type: conceito
author: Andresa Molina
tags: [geometria-sagrada, energia, biologia, cura]
sources: ["[[raw/transcriptions/01 - O CANSAÇO QUE NÃO PARA 1ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito da Geometria Sagrada

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/transcriptions/01 - O CANSAÇO QUE NÃO PARA 1ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: [INFERÊNCIA] Conceito da Geometria Sagrada nomeia um eixo recorrente da obra de Andresa Molina que deve ser lido dentro do HumanoSense/Humanoterapeuta como categoria de diagnóstico, leitura de campo ou condução terapêutica.
- **Formulação de apoio**: [INFERÊNCIA] A nota preserva um conceito citado nas fontes e conectado às aulas estruturadas.

## Sinônimos/Variações

- [INFERÊNCIA] Varia conforme a aula: pode aparecer como campo, código, mandala, personagem, sistema, memória, técnica ou postura terapêutica.

## Contexto de Uso

- Usado para orientar leitura do assistido, organização da sessão, compreensão de padrões emocionais/energéticos e conexão entre método, ficha, mesa, câmara e condução espiritual.

## Relação com Princípios

- [[Arquitetura do HumanoSense]]
- [[Conceito do Metodo HumanoSense]]

## Exemplos do Material

- [INFERÊNCIA] Evidência direta não localizada na varredura automática; consultar as fontes indicadas na rastreabilidade.

## Aplicação Prática

- [INFERÊNCIA] Ao encontrar este tema em atendimento, use-o como pergunta de aprofundamento: onde ele aparece na queixa, no corpo, na ficha, no afeto/desafeto e na relação entre consciência e inconsciente?
- [INFERÊNCIA] Verifique se a pessoa está usando este padrão como defesa, fuga, repetição de dor ou caminho de reorganização.

## Conexões Externas

- [[Consolidacao Tematica - Andresa Molina]]

## Referencia

ANDRESA MOLINA. *Conceito da Geometria Sagrada*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/transcriptions/01 - O CANSAÇO QUE NÃO PARA 1ª Coordenada - O Mapa da Alma.md]]. Acesso em: 17 jun. 2026.
