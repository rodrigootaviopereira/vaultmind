---
type: principio
author: Bob Proctor
tags: [bob-proctor, introducao, mentalidade, desenvolvimento-pessoal, pensamento]
sources: ["[[raw/archive/transcriptions/Bob Proctor - Você nasceu rico (Seminário dublado) - INTRODUÇÃO.md]]"]
---

# Princípio: Crescimento exige sair da zona de conforto

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/transcriptions/Bob Proctor - Você nasceu rico (Seminário dublado) - INTRODUÇÃO.md]]


## Síntese Analítica

A introdução estabelece o tom do seminário: o conteúdo não serve apenas para informar, mas para reposicionar a pessoa frente à própria vida. A mensagem central é que há um custo em permanecer no automático e que a expansão pede decisão, repetição e disposição para aprender.

## Referencia

BOB PROCTOR. *Princípio: Crescimento exige sair da zona de conforto*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/transcriptions/Bob Proctor - Você nasceu rico (Seminário dublado) - INTRODUÇÃO.md]]. Acesso em: 17 jun. 2026.
