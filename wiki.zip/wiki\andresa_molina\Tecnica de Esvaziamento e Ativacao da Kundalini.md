---
type: technique
author: Andresa Molina
tags: [esvaziamento, fecundacao, ancoramento-somatico, kundalini, tesao-existencial]
sources: ["[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"]
---

# Prática de Esvaziamento e Ativação da Kundalini (O plantio no vácuo)

- **Definição**: A etapa somática pós-purgação que obriga o assistido a tolerar a ausência total de caos na sua mente ("o desconforto do vazio"), para só então penetrar a semente purificada no útero da sua biologia, ativando a descarga de força vital (Kundalini).
- **Como praticar e seu Propósito**:
  1. **Ancorar no Vazio**: Após remover os fios e memórias do trauma, guiar a mente para o silêncio absoluto: "Vai sentindo um vazio... não preenche com nada. Sustente com os três cérebros: mente, coração e intestino. Sustenta com inteligência, com amor, com instinto".
  2. **Penetração da Semente**: Orientar a inserção da intenção no solo estéril: "fecunde a ideia e penetre a semente. A semente, ela entra nesse espaço vazio e é fecundada... tornando-se uma só com a semente e o solo... o masculino e o feminino se tornando uno".
  3. **Disparar a Frequência**: Dar o comando para a subida da energia vital no corpo: "ativando a Condaline [Kundalini]. Sinta esse prazer... esse tesão de ser você mesma".
  O propósito somático é restabelecer os códigos biológicos saudáveis do paciente, promovendo calafrios benéficos e êxtase celular ao unificar as polaridades internas após a cura.
- **Evidências**: "Vai sentindo um vazio, vai sentindo um nada... Deixa tudo bem vazio, vazio, vazio. Não tem nada. Não preenche com nada. Vai ampliando de tamanho... sustente com os três cérebros, a mente, coração e intestino, o que você quer de verdade... Sustenta com inteligência, com amor, com instinto... fecunde a ideia e penetre a semente. A semente, ela entra nesse espaço vazio e é fecundada... tornando-se uma só com a semente e o solo... o masculino e o feminino, tornando-se uno e ativando a Condaline. Sinta esse prazer pelo tempo que você precisar. Sente esse prazer, esse tesão de ser você mesma."
- **Conexões**: [[Conceito do Bloqueio na Fecundacao ou Ausencia da Kundalini]], [[Conceito da Sustentacao pelos Tres Cerebros]]

## Perguntas Frequentes / Didática de Atendimento

### 21. Descreva os passos somáticos e vibracionais da fecundação no vácuo e da ativação da "Condaline" no encerramento.
**Resposta**: Os passos exigem que a biologia suporte a desconstrução total antes de criar algo novo:
1. **O Esvaziamento Somático:** O terapeuta induz o vácuo: **"Vai sentindo um vazio, vai sentindo um nada... Deixa tudo bem vazio, vazio, vazio. Não tem nada. Não preenche com nada. Vai ampliando de tamanho e vai abrindo o espaço"**.
2. **A Sustentação (Os Três Cérebros):** Para não colapsar no vazio, o corpo é forçado a ancorar a nova realidade: **"sustente com os três cérebros, a mente, coração e intestino, o que você quer de verdade... Sustenta com inteligência, com amor, com instinto, sem se perder"**.
3. **A Fecundação e a Faísca:** Ocorre a alquimia orgânica. O terapeuta comanda o plantio onde a ideia etérica se funde à matéria: **"fecunde a ideia e penetre a semente. A semente, ela entra nesse espaço vazio e é fecundada... tornando-se uma só com a semente e o solo, com o semen e o útero, o masculino e o feminino, tornando-se uno e ativando a Condaline"**.

### 22. O que acusa no sistema nervoso a sensação física de prazer e "tesão de ser você mesmo" na subida da "Condaline"?
**Resposta**: O terapeuta instiga essa ativação ordenando: **"Sinta esse prazer pelo tempo que você precisar. Sente esse prazer, esse tesão de ser você mesma. Fecunda, se apropria dele, sente essa desejo"**.

A nível somático e neurológico, isso acusa um religamento brutal da força vital que estava paralisada. O sistema nervoso da paciente reage com uma descarga elétrica intensa, que ela descreve fisicamente: **"Sinto como se fosse uma força muito grande e uma vibração. Sinto meio que o corpo e quando às vezes a gente perde a força nos músculos... E muito calor também. Meio tonta"**. Essa "perda de força" e a tontura acusam que a biologia está sendo banhada por uma frequência interdimensional nova, substituindo o medo infantil por uma **"sensação de de luz e esperança de força"**.


## Referencia

ANDRESA MOLINA. *Prática de Esvaziamento e Ativação da Kundalini*. Aula 09 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]].
