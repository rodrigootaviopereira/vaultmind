---
type: principio
author: Andresa Molina
tags: [autossustentacao, toque-fisico, protecao-magnetica, catarse, acolhimento]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio da Autossustentação Física (A proibição do toque físico)

- **Definição**: A regra de biossegurança vibracional que proíbe o terapeuta de abraçar, tocar ou amparar fisicamente o paciente enquanto ele está no campo energético do sangramento emocional, exigindo que o próprio paciente sustente o seu corpo material.
- **Justificativa**: A nível somático, a cura acontece quando o indivíduo suporta a própria dor sem que ninguém o "salve". Quando o terapeuta interfere oferecendo "colo" físico durante o choro no transe, ele corta o processo de purgação da toxina emocional. Além disso, se a pessoa "amolece" (quase desmaiando na cadeira), o terapeuta não a segura. Ele comanda firmemente com a voz: "levanta. Porque se você não levantar, você vai cair no chão e deixa cair". O objetivo é forçar a pessoa a tomar posse do seu próprio corpo físico ("quem manda no seu corpo é você, não deixa entrar nada"). Tocar na pessoa durante a catarse abre um duto de contaminação vibracional, misturando a dor do assistido com a do terapeuta.
- **Evidências**: "Se for presencial, se for, não vai abraçar e nem tocar e nem fazer nada, enquanto ele tá no campo energético... Ah, mas ele tá chorando, deixa chorar... Tá caindo na cadeira, tu fala assim, ó, tá caindo, levanta. Porque se você não levantar, você vai cair no chão e deixa cair, mas vai, olha, levanta o corpo, ajuda, sustenta seu corpo, segura, porque quem manda, quem manda no seu corpo é você... quando é o sentir a dor, deixa doer, não acolhe, porque o objetivo é doer, é sangrar."
- **Implicações**: O terapeuta deve usar a firmeza da sua voz em vez do toque físico para guiar o assistido que está cambaleando energeticamente.
- **Conexões**: [[Tecnica da Posicao Somatica ou Cadeira]], [[Conceito do Sangramento do Utero da Vida]]
- **Notas Pessoais**: O não-toque é uma forma profunda de respeito e empoderamento do assistido.

## Perguntas Frequentes / Didática de Atendimento

### 2. Por que a autora proíbe terminantemente o toque físico no momento em que o assistido está vivenciando a catarse e o choro?
**Resposta**: A autora proíbe o toque determinando que o terapeuta **"não vai abraçar e nem tocar e nem fazer nada, enquanto ele tá no campo energético"**.

A nível somático, a catarse é um esvaziamento físico e energético absolutamente necessário para a cura. Se o terapeuta afagar o paciente, ele interrompe a purgação da toxina emocional. Andresa é contundente ao afirmar que a dor não deve ser acolhida naquele momento: **"Ah, mas ele tá chorando, deixa chorar. Não é para ele chorar, é para chorar. Lembra que é para sangrar? É para sentir ali"**. O terapeuta deve deixar a biologia do assistido exaurir a emoção, pois **"quando é o sentir a dor, deixa doer, não acolhe, porque o objetivo é doer, é sangrar, né? É sentir para colocar para fora pra limpeza"**.

### 3. Como o terapeuta deve agir caso o assistido "amoleça" ou pareça cair da cadeira, e qual a importância somática de forçá-lo a sustentar o corpo?
**Resposta**: Se o paciente começar a desfalecer ou ceder fisicamente, o terapeuta deve usar uma voz de comando firme e não o segurar: **"Se a pessoa tá caindo na cadeira, tu fala assim, ó, tá caindo, levanta. Porque se você não levantar, você vai cair no chão e deixa cair"**.

A importância somática e vibracional dessa exigência é forçar a pessoa a retomar a posse e a soberania sobre o seu próprio corpo material: **"levanta o corpo, ajuda, sustenta seu corpo, segura, porque quem manda, quem manda no seu corpo é você"**. Quando a pessoa "amolece", ela cede espaço no seu campo magnético. Obrigá-la a sentar reto com **"Firmeza, ok?"** é a defense neurológica contra invasões energéticas, pois o terapeuta adverte o paciente: **"não deixa entrar nada... se deixar entrar qualquer porcaria vai ficar com a porcaria, presta atenção"**.


## Referencia

ANDRESA MOLINA. *Princípio da Autossustentação Física*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
