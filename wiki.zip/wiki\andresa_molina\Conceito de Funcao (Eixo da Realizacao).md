---
type: conceito
author: Andresa Molina
tags: [realizacao, funcao, servico, missao, entrega, essencia]
sources: ["[[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]]"]
---

# Conceito de Funcao (Eixo da Realizacao)

- **Definição**: A expressão prática do talento e da missão existencial no mundo, onde o indivíduo entrega aquilo que é específico de sua essência com assinatura pessoal única.
- **Justificativa**: Ocupar a função correta simplifica o fluxo da vida, pois o indivíduo liberta-se da obsessão infantil de ser tudo para todos e concentra sua energia na sua verdadeira competência.
- **Evidências**: "Função é o que você faz quando está em sintonia com quem você é. É a expressão prática da sua missão. O movimento que transforma o dom em serviço, talento em entrega. [...] é quando você compreende que não precisa ser tudo para todos, precisa apenas fazer bem aquilo que você nasceu para entregar do seu jeito e com a sua assinatura."
- **Implicações**: Na clínica, ajuda a frear o comportamento de Ocupado ou Lixeiro que assume tarefas do sistema para comprar amor e foge da sua verdadeira obrigação.
- **Conexões**: [[Conceito do Eixo da Realizacao]], [[Principio de Lugar Funcao e Potencia]]
- **Notas Pessoais**: Fazer um bom trabalho na própria função é apenas a obrigação mínima de troca.

## Referencia

ANDRESA MOLINA. *Conceito de Funcao (Eixo da Realizacao)*. Aula 04 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]].
