---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_36_pecados_e_julgamentos.md]]"]
---

# Cap 036 - Pecados E Julgamentos

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_36_pecados_e_julgamentos.md]]

## Referencia

ANDRESA MOLINA. *Cap 036 - Pecados E Julgamentos*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_36_pecados_e_julgamentos.md]]. Acesso em: 17 jun. 2026.
