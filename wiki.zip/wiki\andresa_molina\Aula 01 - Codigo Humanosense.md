---
type: aula
author: Andresa Molina
tags: [codigo-humanosense, humanosense, aula-01, reingestao-2026-06-19]
sources:
  - "[[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]]"
---
# Aula 01 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `01   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 17.044 palavras; 581 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- Então, nesse primeiro momento, eu trago mais conteúdo que precisa dessas bases para vocês conseguirem fazer a aplicação, as perguntas depois e aí mais para frente eu abro com um embasamento maior e até as perguntas de vocês vão ficar mais embasadas, conseguir entender melhor e formular um pouco melhor e o raciocínio para executar essas perguntas, tá bom?
- Então, primeiro eu vou trazer informações conceituais extremamente importantes para que vocês tenham capacidade de executar o atendimento, conversar com o seu cliente, identificar os processos dele, identificar onde estão os problemas, os nós, os entraves, conseguir ter material intelectual para conversar com ele, para mostrar para ele onde tá o problema,…
- E aí depois dessa segunda parte a gente vai pra parte da técnica energética espiritual, dos comandos que a gente precisa, do como a gente vai fazer a parte onde a gente mergulha num padrão do do espírito da espiritualidade, no padrão energético, no padrão inconsciente da pessoa.
- O humanocense não é apenas um protocolo, é um caminho vivo, sensível que conduz o assistido da dor à consciência, da consciência à liberação e da liberação à criação de novas possibilidades.
- Aqui no portal humanoense você vai encontrar o passo a passo completo do método, as videoaulas comigo, explicando os conceitos e a terapêutica, as instruções práticas de aplicação e as fichas para download que irão guiar os seus atendimentos com clareza, leveza e profundidade.
- Então lá você tem o passo a passo, lá você vai ter as videoaulas, você vai ter as instruções práticas e você vai ter as fichas de atendimento para você poder as fichas de atendimento imprimir quantas vocês quiserem para você poder, eu espero que você tenha muito cliente, que você precise de muitas fichas de atendimento.
- Então você vai ter em mãos ferramentas como a mesa humanocense e as suas variações específicas que tem nela na mesa a mandala do amor, mandala da dor e a mandala da cura.
- Então quando a gente diz que o portal orienta, é porque aqui você encontra o que você tem que fazer, o passo a passo, os estudos e a ficha para download com tudo que precisa preencher.
- O kit físico teancora porque você tem em mãos, você terá o que perguntar e o que dizer com comandos espirituais energéticos do código manocência, perguntas estruturadas e condução prática. e a sua presença que conduz, porque é o sentir, a sua escuta e a sua entrega que complementam o processo.
- E somente com trabalho espiritual, energético, consciencial, profundo e tecnológico, é que se pode acabar com a autoobsessão, que muitos chamam de autossabotagem.
- Se você quer entender racionalmente o que te trava, aprender a tratar energeticamente, espiritualmente o que te bloqueia e criar um campo fértil para plantar suas novas criações e possibilidades, eu te convido a acessar o código inocência, que é uma energia viva, uma entidade organizada, inteligente que atua junto com o terapeuta e o assistido para…
- Então esse é o grande objetivo do humanos curar esse feminino, né, essas frações que estejam desequilibradas, como com esse ganho de consciência e com essas técnicas pra gente trabalhar essas sombras que não são só são só ideias e que são facilmente manipuladas pela espiritualidade e por nós também quando sabemos usar isso, né? que o que eu manipulo na…

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-73
- Então, nesse primeiro momento, eu trago mais conteúdo que precisa dessas bases para vocês conseguirem fazer a aplicação, as perguntas depois e aí mais para frente eu abro com um embasamento maior e até as perguntas de vocês vão ficar mais embasadas, conseguir entender melhor e formular um pouco melhor e o raciocínio para executar essas perguntas, tá bom?
- Então, primeiro eu vou trazer informações conceituais extremamente importantes para que vocês tenham capacidade de executar o atendimento, conversar com o seu cliente, identificar os processos dele, identificar onde estão os problemas, os nós, os entraves, conseguir ter material intelectual para conversar com ele, para mostrar para ele onde tá o problema, poder também ter entendimento para fazer as perguntas e…
- E aí depois dessa segunda parte a gente vai pra parte da técnica energética espiritual, dos comandos que a gente precisa, do como a gente vai fazer a parte onde a gente mergulha num padrão do do espírito da espiritualidade, no padrão energético, no padrão inconsciente da pessoa.

### Bloco 2 - frases 74-146
- Aqui no portal humanoense você vai encontrar o passo a passo completo do método, as videoaulas comigo, explicando os conceitos e a terapêutica, as instruções práticas de aplicação e as fichas para download que irão guiar os seus atendimentos com clareza, leveza e profundidade.
- Então lá você tem o passo a passo, lá você vai ter as videoaulas, você vai ter as instruções práticas e você vai ter as fichas de atendimento para você poder as fichas de atendimento imprimir quantas vocês quiserem para você poder, eu espero que você tenha muito cliente, que você precise de muitas fichas de atendimento.
- O kit físico teancora porque você tem em mãos, você terá o que perguntar e o que dizer com comandos espirituais energéticos do código manocência, perguntas estruturadas e condução prática. e a sua presença que conduz, porque é o sentir, a sua escuta e a sua entrega que complementam o processo.

### Bloco 3 - frases 147-219
- Nessa fase, após a limpeza emocional e espiritual e definição responsável do que se quer manifestar, partimos para a fecundação e materialização do desejo do assistido, facilitando a fusão entre o masculino e o feminino.
- Uma fase racional em que a pessoa vai entender o problema dela, compreender, identificar o problema. uma fase de limpeza onde essa pessoa vai conseguir chorar essa dor, limpar esse terreno fétil, essas sementes que foram plantadas, esses abortos que aconteceram de coisas que não vingaram e que estão sobrecarregando o sistema dela, fazer toda essa limpeza.
- Então o trabalho aqui, ele tem consciência, ele tem limpeza energética espiritual, tudo consciente, tudo consciente e ele tem o processo de manifestação e materialização a partir de um solo limpo, sagrado.

### Bloco 4 - frases 220-292
- E aí você se sente culpada porque você tenta, você faz tudo e o outro ainda tá infeliz porque o outro não precisa do que você tem.
- Não, dito isso, isso é uma coisa que vai, por isso que eu falei, vai embasar todo o trabalho sempre, porque muitas vezes as pessoas chegam para conversar com a gente, para trazer uma questão e tá tudo isso nesse balaio.
- Então, de maneira simbólica ou real, essa castração precisa acontecer ou pelo pai, ou ela vai acontecer pela vida, ou ela vai acontecer pelo pelo chefe, ou ela ela sempre vai, alguém vai precisar frustrar e dizer não.

### Bloco 5 - frases 293-365
- Não, eu ganho consciência ao ponto de querer reparar, de querer, de entender a dor que eu causei no outro, de entender que se eu não estou, porque o karma nada mais é do que a lei da semeadura.
- Mas o que o que a espiritualidade explica sempre é que não existe este pecado no sentido que tem que pagar, que tem que sofrer, não.
- Quando eu entendo que foi a dor no outro, eu quero reparar porque eu falo, gente, eu fui o mago desta magia, eu criei aquela dor.

### Bloco 6 - frases 366-438
- Você precisa matar o pai da criança porque não existe mais criança.
- E aí você vai ver, eu tô falando isso porque eu tô falando com muita gente, gente que teve pais e mães que foram malvados, violentos, abusivos e que ficou essa história de que tem que honrar pai e mãe e tem que tem honrar uma coisa, mas ele não é seu dono que você deva tudo, você deve sim o a honra, o agradecimento pelo ve que você não precisa se humilhar, rebaixar, se penci abusado, invadido, ferido por essa…
- Não significa que a gente não tenha que tratar energeticamente, que é o que propõe o código mas para eu ter o entendimento de tudo isso, para eu conseguir fazer o meu assistido tratar isso, eu preciso ter essa frequência em mim habitando.

### Bloco 7 - frases 439-511
- E somente com trabalho espiritual, energético, consciencial, profundo e tecnológico, é que se pode acabar com a autoobsessão, que muitos chamam de autossabotagem.
- Então, ah, o Código Humanocia, ele vai trabalhar dentro de tudo isso, de encontrar essas alminhas que a gente chama de fractal, de como transmutar isso, de como trabalhar isso, de quais as equipes espirituais, quais são os códigos pra gente se reconectar com as nossas essências.
- Se você quer entender racionalmente o que te trava, aprender a tratar energeticamente, espiritualmente o que te bloqueia e criar um campo fértil para plantar suas novas criações e possibilidades, eu te convido a acessar o código inocência, que é uma energia viva, uma entidade organizada, inteligente que atua junto com o terapeuta e o assistido para solucionar os entraves e abrir as portas pro novo.

### Bloco 8 - frases 512-581
- E aí se a gente dá o nome de obsessão lá fora chamando de autossabotagem e aí acham que só por ressignificar aí vai resolver.
- É o que então quando o meu feminino está magoado, com medo, melindroso, mimimi, chiliquento, é tudo o feminino ferido.
- Então esse é o grande objetivo do humanos curar esse feminino, né, essas frações que estejam desequilibradas, como com esse ganho de consciência e com essas técnicas pra gente trabalhar essas sombras que não são só são só ideias e que são facilmente manipuladas pela espiritualidade e por nós também quando sabemos usar isso, né? que o que eu manipulo na pessoa é a sombra dela.

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Então, nesse primeiro momento, eu trago mais conteúdo que precisa dessas bases para vocês conseguirem fazer a aplicação, as perguntas depois e aí mais para frente eu abro com um embasamento maior e até as perguntas de vocês vão ficar mais embasadas, conseguir entender melhor e formular um pouco melhor e o raciocínio para executar essas perguntas, tá bom?
- Esse código Manocense ele veio baseado em alguns pilares estruturais, né, onde vocês precisam compreender esses pilares para que depois na parte de execução vocês consigam executar o que vocês aprenderam desses pilares, tá?
- E aí depois dessa segunda parte a gente vai pra parte da técnica energética espiritual, dos comandos que a gente precisa, do como a gente vai fazer a parte onde a gente mergulha num padrão do do espírito da espiritualidade, no padrão energético, no padrão inconsciente da pessoa.
- Nessa primeira aula, que é uma aula que eu chamo de eh uma aula inaugural, eu vou trazer alguns conceitos que são extremamente importantes e que no decorrer do processo como um todo eles vão sempre estar ali num lugar bastante significativo de toda a técnica, de todo o caminho, tanto do curso quanto do seu cliente.
- Então esse isso você vai precisar sempre, muitos, se Deus quiser, você vai ter um monte de cliente vai ser um monte, tá bom?
- Então quando a gente diz que o portal orienta, é porque aqui você encontra o que você tem que fazer, o passo a passo, os estudos e a ficha para download com tudo que precisa preencher.
- Não, eu ganho consciência ao ponto de querer reparar, de querer, de entender a dor que eu causei no outro, de entender que se eu não estou, porque o karma nada mais é do que a lei da semeadura.
- E somente com trabalho espiritual, energético, consciencial, profundo e tecnológico, é que se pode acabar com a autoobsessão, que muitos chamam de autossabotagem.
- Então, o que mais a gente precisa, a gente vai falar muito disso, do masculino e do feminino ainda, mas a gente precisa entender que o que a gente julga, o que a gente toda vez que tem algum problema, é o nosso feminino que está ferido, sejamos nós homens ou mulheres, porque o nosso masculino vai lá e faz, ele é o que põe para fora, ele é o que impulsiona,…
- Então, para que a gente materialize qualquer coisa, a gente não precisa ter essas essas consciências, porque senão eu sou sempre a vítima.

## Conceitos-Chave Extraídos

- Esse código Manocense ele veio baseado em alguns pilares estruturais, né, onde vocês precisam compreender esses pilares para que depois na parte de execução vocês consigam executar o que vocês aprenderam desses pilares, tá?
- Nessa primeira aula, que é uma aula que eu chamo de eh uma aula inaugural, eu vou trazer alguns conceitos que são extremamente importantes e que no decorrer do processo como um todo eles vão sempre estar ali num lugar bastante significativo de toda a técnica, de todo o caminho, tanto do curso quanto do seu cliente.
- Então você acaba de acessar um código, uma tecnologia espiritual de cura que tem o poder de transformar vidas e também a forma como você atua como terapeuta.
- O humanocense não é apenas um protocolo, é um caminho vivo, sensível que conduz o assistido da dor à consciência, da consciência à liberação e da liberação à criação de novas possibilidades.
- Aqui no portal humanoense você vai encontrar o passo a passo completo do método, as videoaulas comigo, explicando os conceitos e a terapêutica, as instruções práticas de aplicação e as fichas para download que irão guiar os seus atendimentos com clareza, leveza e profundidade.
- Então você vai ter em mãos ferramentas como a mesa humanocense e as suas variações específicas que tem nela na mesa a mandala do amor, mandala da dor e a mandala da cura.
- O kit físico teancora porque você tem em mãos, você terá o que perguntar e o que dizer com comandos espirituais energéticos do código manocência, perguntas estruturadas e condução prática. e a sua presença que conduz, porque é o sentir, a sua escuta e a sua entrega que complementam o processo.
- Então o trabalho aqui, ele tem consciência, ele tem limpeza energética espiritual, tudo consciente, tudo consciente e ele tem o processo de manifestação e materialização a partir de um solo limpo, sagrado.
- Não, eu ganho consciência ao ponto de querer reparar, de querer, de entender a dor que eu causei no outro, de entender que se eu não estou, porque o karma nada mais é do que a lei da semeadura.
- Não significa que a gente não tenha que tratar energeticamente, que é o que propõe o código mas para eu ter o entendimento de tudo isso, para eu conseguir fazer o meu assistido tratar isso, eu preciso ter essa frequência em mim habitando.
- E somente com trabalho espiritual, energético, consciencial, profundo e tecnológico, é que se pode acabar com a autoobsessão, que muitos chamam de autossabotagem.
- Então, ah, o Código Humanocia, ele vai trabalhar dentro de tudo isso, de encontrar essas alminhas que a gente chama de fractal, de como transmutar isso, de como trabalhar isso, de quais as equipes espirituais, quais são os códigos pra gente se reconectar com as nossas essências.
- Se você quer entender racionalmente o que te trava, aprender a tratar energeticamente, espiritualmente o que te bloqueia e criar um campo fértil para plantar suas novas criações e possibilidades, eu te convido a acessar o código inocência, que é uma energia viva, uma entidade organizada, inteligente que atua junto com o terapeuta e o assistido para…
- E aí se a gente dá o nome de obsessão lá fora chamando de autossabotagem e aí acham que só por ressignificar aí vai resolver.
- É o que então quando o meu feminino está magoado, com medo, melindroso, mimimi, chiliquento, é tudo o feminino ferido.
- Então esse é o grande objetivo do humanos curar esse feminino, né, essas frações que estejam desequilibradas, como com esse ganho de consciência e com essas técnicas pra gente trabalhar essas sombras que não são só são só ideias e que são facilmente manipuladas pela espiritualidade e por nós também quando sabemos usar isso, né? que o que eu manipulo na…


## Técnicas, Procedimentos e Orientações Práticas

- Então, nesse primeiro momento, eu trago mais conteúdo que precisa dessas bases para vocês conseguirem fazer a aplicação, as perguntas depois e aí mais para frente eu abro com um embasamento maior e até as perguntas de vocês vão ficar mais embasadas, conseguir entender melhor e formular um pouco melhor e o raciocínio para executar essas perguntas, tá bom?
- Então, primeiro eu vou trazer informações conceituais extremamente importantes para que vocês tenham capacidade de executar o atendimento, conversar com o seu cliente, identificar os processos dele, identificar onde estão os problemas, os nós, os entraves, conseguir ter material intelectual para conversar com ele, para mostrar para ele onde tá o problema,…
- Depois a gente tem uma parte efetivamente prática onde você tem as perguntas para fazer e essas perguntas você vai identificar padrões conscientes e inconscientes.
- E aí depois dessa segunda parte a gente vai pra parte da técnica energética espiritual, dos comandos que a gente precisa, do como a gente vai fazer a parte onde a gente mergulha num padrão do do espírito da espiritualidade, no padrão energético, no padrão inconsciente da pessoa.
- Nessa primeira aula, que é uma aula que eu chamo de eh uma aula inaugural, eu vou trazer alguns conceitos que são extremamente importantes e que no decorrer do processo como um todo eles vão sempre estar ali num lugar bastante significativo de toda a técnica, de todo o caminho, tanto do curso quanto do seu cliente.
- O humanocense não é apenas um protocolo, é um caminho vivo, sensível que conduz o assistido da dor à consciência, da consciência à liberação e da liberação à criação de novas possibilidades.
- Aqui no portal humanoense você vai encontrar o passo a passo completo do método, as videoaulas comigo, explicando os conceitos e a terapêutica, as instruções práticas de aplicação e as fichas para download que irão guiar os seus atendimentos com clareza, leveza e profundidade.
- Então lá você tem o passo a passo, lá você vai ter as videoaulas, você vai ter as instruções práticas e você vai ter as fichas de atendimento para você poder as fichas de atendimento imprimir quantas vocês quiserem para você poder, eu espero que você tenha muito cliente, que você precise de muitas fichas de atendimento.
- Essas, o passo a passo vai estar no portal e as fichas de atendimento vai estar no portal para você imprimir quantas, 10, 20, 50, 200, 400, 1 milhão, quantas clientes você tiver.
- Então esse isso você vai precisar sempre, muitos, se Deus quiser, você vai ter um monte de cliente vai ser um monte, tá bom?
- Então quando a gente diz que o portal orienta, é porque aqui você encontra o que você tem que fazer, o passo a passo, os estudos e a ficha para download com tudo que precisa preencher.
- O kit físico teancora porque você tem em mãos, você terá o que perguntar e o que dizer com comandos espirituais energéticos do código manocência, perguntas estruturadas e condução prática. e a sua presença que conduz, porque é o sentir, a sua escuta e a sua entrega que complementam o processo.
- Então tem perguntas em que eu vou ter racionalmente saber o que fazer, vou perguntar, a pessoa vai me responder o racional dela, mas eu vou conseguir investigar o que está no padrão inconsciente dela.
- Se você quer entender racionalmente o que te trava, aprender a tratar energeticamente, espiritualmente o que te bloqueia e criar um campo fértil para plantar suas novas criações e possibilidades, eu te convido a acessar o código inocência, que é uma energia viva, uma entidade organizada, inteligente que atua junto com o terapeuta e o assistido para…


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- Então, primeiro eu vou trazer informações conceituais extremamente importantes para que vocês tenham capacidade de executar o atendimento, conversar com o seu cliente, identificar os processos dele, identificar onde estão os problemas, os nós, os entraves, conseguir ter material intelectual para conversar com ele, para mostrar para ele onde tá o problema,…
- E aí depois dessa segunda parte a gente vai pra parte da técnica energética espiritual, dos comandos que a gente precisa, do como a gente vai fazer a parte onde a gente mergulha num padrão do do espírito da espiritualidade, no padrão energético, no padrão inconsciente da pessoa.
- O humanocense não é apenas um protocolo, é um caminho vivo, sensível que conduz o assistido da dor à consciência, da consciência à liberação e da liberação à criação de novas possibilidades.
- Então você vai ter em mãos ferramentas como a mesa humanocense e as suas variações específicas que tem nela na mesa a mandala do amor, mandala da dor e a mandala da cura.
- Então tem perguntas em que eu vou ter racionalmente saber o que fazer, vou perguntar, a pessoa vai me responder o racional dela, mas eu vou conseguir investigar o que está no padrão inconsciente dela.
- Nessa fase, nós iremos conectar o assistido aos fractais de dor que ele carrega e fazê-lo sentir essa dor, autorizando as suas emoções reprimidas para que possamos esgotar esse fractal que foi magnetizado por anos e consecutivamente faremos a limpeza espiritual desse fractal que por ter sido alimentado por muito tempo com o ectoplasma já se torna um…
- Não, eu ganho consciência ao ponto de querer reparar, de querer, de entender a dor que eu causei no outro, de entender que se eu não estou, porque o karma nada mais é do que a lei da semeadura.
- E somente com trabalho espiritual, energético, consciencial, profundo e tecnológico, é que se pode acabar com a autoobsessão, que muitos chamam de autossabotagem.
- Se você quer entender racionalmente o que te trava, aprender a tratar energeticamente, espiritualmente o que te bloqueia e criar um campo fértil para plantar suas novas criações e possibilidades, eu te convido a acessar o código inocência, que é uma energia viva, uma entidade organizada, inteligente que atua junto com o terapeuta e o assistido para…
- E aí se a gente dá o nome de obsessão lá fora chamando de autossabotagem e aí acham que só por ressignificar aí vai resolver.
- Então, o que mais a gente precisa, a gente vai falar muito disso, do masculino e do feminino ainda, mas a gente precisa entender que o que a gente julga, o que a gente toda vez que tem algum problema, é o nosso feminino que está ferido, sejamos nós homens ou mulheres, porque o nosso masculino vai lá e faz, ele é o que põe para fora, ele é o que impulsiona,…
- É o que então quando o meu feminino está magoado, com medo, melindroso, mimimi, chiliquento, é tudo o feminino ferido.


## Citações e Formulações de Alta Densidade

- “Então, nesse primeiro momento, eu trago mais conteúdo que precisa dessas bases para vocês conseguirem fazer a aplicação, as perguntas depois e aí mais para frente eu abro com um embasamento maior e até as perguntas de vocês vão ficar mais embasadas, conseguir entender melhor e formular um pouco…”
- “Esse código Manocense ele veio baseado em alguns pilares estruturais, né, onde vocês precisam compreender esses pilares para que depois na parte de execução vocês consigam executar o que vocês aprenderam desses pilares, tá?”
- “E aí depois dessa segunda parte a gente vai pra parte da técnica energética espiritual, dos comandos que a gente precisa, do como a gente vai fazer a parte onde a gente mergulha num padrão do do espírito da espiritualidade, no padrão energético, no padrão inconsciente da pessoa.”
- “Nessa primeira aula, que é uma aula que eu chamo de eh uma aula inaugural, eu vou trazer alguns conceitos que são extremamente importantes e que no decorrer do processo como um todo eles vão sempre estar ali num lugar bastante significativo de toda a técnica, de todo o caminho, tanto do curso…”
- “O humanocense não é apenas um protocolo, é um caminho vivo, sensível que conduz o assistido da dor à consciência, da consciência à liberação e da liberação à criação de novas possibilidades.”
- “Então esse isso você vai precisar sempre, muitos, se Deus quiser, você vai ter um monte de cliente vai ser um monte, tá bom?”
- “Então quando a gente diz que o portal orienta, é porque aqui você encontra o que você tem que fazer, o passo a passo, os estudos e a ficha para download com tudo que precisa preencher.”
- “Não, eu ganho consciência ao ponto de querer reparar, de querer, de entender a dor que eu causei no outro, de entender que se eu não estou, porque o karma nada mais é do que a lei da semeadura.”
- “E somente com trabalho espiritual, energético, consciencial, profundo e tecnológico, é que se pode acabar com a autoobsessão, que muitos chamam de autossabotagem.”
- “Então, o que mais a gente precisa, a gente vai falar muito disso, do masculino e do feminino ainda, mas a gente precisa entender que o que a gente julga, o que a gente toda vez que tem algum problema, é o nosso feminino que está ferido, sejamos nós homens ou mulheres, porque o nosso masculino vai…”
- “É o que então quando o meu feminino está magoado, com medo, melindroso, mimimi, chiliquento, é tudo o feminino ferido.”
- “Então esse é o grande objetivo do humanos curar esse feminino, né, essas frações que estejam desequilibradas, como com esse ganho de consciência e com essas técnicas pra gente trabalhar essas sombras que não são só são só ideias e que são facilmente manipuladas pela espiritualidade e por nós…”

## Conexões com a Wiki

- [[Conceito do Metodo HumanoSense]]
- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]
- [[Conceito da Camara HumanoSense]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio da Liberdade Consciente]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Conceito do Divorcio Energetico]]
- [[Conceito do Parceiro da Missao]]

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. 
### Bloco 1: A Estrutura do Método HumanoSense e as Fases de Cura
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
1. Como Andresa Molina descreve a divisão metodológica do Código HumanoSense em suas três etapas macro (Identificação, Depuração e Execução)?
2. Qual é a diferença prática entre "ressignificar racionalmente" e a real "transmutação/mudança de estado" na resolução de um entrave de vida?
3. De que maneira o questionário racional consciente e a investigação do campo energético inconsciente (por meio da radiestesia com pêndulo) se cruzam para evidenciar "a mentira" do assistido?
4. Como Andresa Molina diferencia somática e energeticamente os três estados fundamentais da cura: "sentir", "transformar" e "transmutar"?
5. De que forma o "esvaziamento e limpeza do terreno fértil" na fase de depuração prepara o útero/sistema do assistido para uma manifestação ou cocriação responsável?





### Bloco 2: A Biologia Oculta dos Papéis e a Dinâmica de Lugar, Função e Potência
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
6. Como o conceito biológico/instintivo de "macho alfa e fêmea alfa" regula as lideranças e responsabilidades dentro de um sistema de relacionamentos de acordo com Andresa?
7. Qual é a regra hierárquica estabelecida pela autora quando os pais visitam a casa dos filhos e vice-versa, e quais são os impactos somáticos de desrespeitar esse fluxo natural?
8. De que forma a divisão societária e de relacionamento íntimo entre Andresa e Rodrigo exemplifica a alternância de polaridades alfa e beta nos níveis administrativo e terapêutico?
9. Como a autora conecta a perda de potência pessoal e profissional diretamente ao desalinhamento de um indivíduo em relação ao seu "lugar" e "função" no sistema?
10. Por que a tentativa de "competir com o parceiro" ou "metralhar ordens na casa dos pais" ativa reações instintivas de defesa e embate no nível mais primário do cérebro?

### Bloco 3: A Castração Psíquica, Frustração e Conflitos de Autoridade
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
11. Sob a ótica do Código HumanoSense, por que o pai é o responsável por "castrar o menino" e a mãe por "castrar a menina", e o que isso significa em termos práticos de limite?
12. Quais são as consequências na vida adulta (especialmente nas relações com chefes ou no mercado de trabalho) de uma criança que não passou pela castração parental na infância?
13. Como Andresa Molina explica que a frustração gerada pelo "não" parental auxilia o desenvolvimento somático do indivíduo para lidar com os embates e limites da vida?
14. Por que a ausência de posicionamento e imposição de limites pelos pais gera o comportamento de projetar neles (ou nos parceiros/chefes) a satisfação de todas as necessidades infantis?
15. De que maneira a egrégora do trabalho ou da empresa reage quando um profissional tenta se comportar fora do seu lugar por não ter resolvido a castração com seus pais?

### Bloco 4: Rompimento de Vínculos Infantis e "Matar Pai e Mãe"
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
16. O que significa, no contexto espiritual abordado por Andresa Molina, a expressão literal "matar pai e mãe" para poder amar e ser amado de verdade?
17. Como a autora desconstrói a ideia de posse sobre os espíritos familiares, afirmando que pais e mães são apenas "veículos que emprestaram material genético"?
18. Por que a tentativa de ser "esposa do próprio pai" ou "marido da própria mãe" anula a potência de atração de relacionamentos afetivos saudáveis?
19. De que maneira a culpa infantil por não conseguir curar a infelicidade ou preencher o vazio existencial dos pais aprisiona a energia vital do assistido?
20. Como a transição de olhar para os pais não mais como provedores de dívidas emocionais, mas como "espíritos iguais" que fazem parte da jornada, liberta o fluxo da vida?

### Bloco 5: Formas-Pensamento, Abortos de Criação e Autoobsessão
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
21. O que são os "pequenos abortos" mencionados por Andresa Molina no contexto de projetos e objetivos iniciados e não sustentados, e como eles afetam a fertilidade do "solo"?
22. Como o ectoplasma humano alimenta o que a autora chama de "alminhas" ou "fractais de dor", gerando a dinâmica de autoobsessão comumente rotulada de autossabotagem?
23. De que maneira a incapacidade do feminino em "sangrar" (chorar os lutos, sentir a dor e a falta) impede a capacidade masculina de "dar o sangue" e realizar a materialização?
24. Por que o trabalho tecnológico, energético e consciencial do Código HumanoSense é necessário para dissolver a "magia" que o próprio assistido fez em si mesmo e que amarra o outro?
25. Como o restabelecimento da harmonia entre o sentir feminino e o fazer masculino permite a fecundação responsável de novos desejos e criações?

## Referência

ANDRESA MOLINA. *Aula 01 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.

