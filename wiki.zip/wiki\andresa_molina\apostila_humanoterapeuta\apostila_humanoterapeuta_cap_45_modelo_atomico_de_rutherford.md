---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_45_modelo_atomico_de_rutherford.md]]"]
---

# Cap 045 - Modelo Atomico De Rutherford

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_45_modelo_atomico_de_rutherford.md]]

## Referencia

ANDRESA MOLINA. *Cap 045 - Modelo Atomico De Rutherford*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_45_modelo_atomico_de_rutherford.md]]. Acesso em: 17 jun. 2026.
