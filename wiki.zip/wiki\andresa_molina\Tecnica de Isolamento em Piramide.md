---
type: tecnica
author: Andresa Molina
tags: [isolamento-piramide, egrégora, campo-de-forca, magnetismo]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# Prática do Isolamento em Pirâmide (A criação do campo contra invasões)

- **Objetivo**: Erguer uma cápsula de geometria sagrada piramidal ao redor do terapeuta e do assistido antes do preenchimento da ficha e das perguntas, bloqueando interferências, parasitismo vibracional ou agressões de obsessores externos.
- **Pré-requisitos**: Consciência focada e aplicação de estalos de dedos.
- **Passo a Passo**:
  1. Bem no início da consulta, antes de dar início à varredura das mandalas, o terapeuta mentaliza a pirâmide perfeita ao redor da sala.
  2. Executa pulsos magnéticos com os dedos marcando os cantos da pirâmide espacial.
  3. Decreta verbalmente: *"Tô enquadrando nós dois uma pirâmide aqui criando um campo de força. Isola pirâmide"*.
  4. Todo o trabalho e leitura ocorrem blindados dentro desse perímetro até a etapa final da sessão.
- **Duração/Frequência**: Executada no início de todos os atendimentos.
- **Indicadores de Sucesso**: Neutralidade do campo, ausência de cansaço súbito ou perda de vitalidade no terapeuta durante a captação.
- **Variações**: Enquadramento e isolamento piramidal de cenas específicas durante a regressão.
- **Conceitos Envolvidos**: [[Tecnica de Enquadramento na Piramide]], [[Principio do Consentimento e Invasao de Campo]]

## Perguntas Frequentes / Didática de Atendimento

## Referencia

ANDRESA MOLINA. *Prática do Isolamento em Pirâmide*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
