---
type: concept
author: Andresa Molina
tags: [copo-vazio, assistido-leigo, barreira-teorica, pureza-clinica]
sources: ["[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"]
---

# O Copo Vazio / O Assistido Leigo (O desafio e a vantagem da ignorância técnica)

- **Definição**: A condição do paciente que chega à sessão sem nenhum conhecimento prévio sobre mesas radiestésicas, chakras, física quântica ou "frequências em Alfa". Longe de ser um problema, o "copo vazio" representa um campo mental purificado e livre de autossabotagens intelectuais.
- **Justificativa**: Terapeutas costumam ter medo de atender céticos ou pessoas muito leigas porque não podem usar "jargões espirituais". A nível vibracional, a autora prefere fazer a demonstração com alguém totalmente "zerado" para provar que a tecnologia independe do intelecto do paciente para funcionar. Quando um colega de curso senta para ser atendido, ele já sabe como funciona o relaxamento ("ele já sabe até fazer o alfa") e o seu ego pode falsear reações ou controlar o processo. O assistido leigo, como um copo vazio, simplesmente recebe os comandos e desce aos infernos da própria dor de forma brutal e autêntica, sem tentar performar "elevação espiritual".
- **Evidências**: "Eu queria saber se de vocês... tem alguém que não passou por nada, nunca foi cliente do espaço humanidade, nunca fez metodologia terapeuta, nunca fez código não sabe de nada... porque eu queria que vocês vissem alguém que... pode chegar para você, uma pessoa que não sabe nada, com copo extremamente vazio, tá? Então acho que é legal porque esse é o maior desafio... porque quando chegou coleguinha que já sabe mais ou menos, ele já sabe até fazer o alfa e quando chega uma pessoa que não tem consciência nenhuma."
- **Implicações**: O terapeuta deve falar em termos simples e mundanos, sem tentar dar aulas teóricas para pacientes leigos.
- **Conexões**: [[Principio da Objetividade Terapeutica]], [[Tecnica da Anamnese por Desconstrucao]]
- **Notas Pessoais**: Pacientes leigos costumam curar-se muito mais rápido porque não intelectualizam o transe.

## Perguntas Frequentes / Didática de Atendimento

### 9. Por que a autora prefere atender o "Copo Vazio" (assistido leigo) a um colega de curso, e como a bagagem prévia muda a dinâmica?
**Resposta**: Andresa prefere o **"copo extremamente vazio"** para a demonstração clínica porque atender alguém sem nenhum conhecimento prévio é **"o maior desafio"** para provar a eficácia do método. O leigo obriga o terapeuta a guiar organicamente **"uma pessoa que não tem consciência nenhuma daquele processo"**.

A autora não diz que o conhecimento teórico "atrapalha" o transe, mas sim que o facilita a ponto de não refletir a realidade crua de um atendimento comum. Se ela atende um colega, o corpo e a mente dessa pessoa já estão condicionados somaticamente à técnica: **"porque quando chegou coleguinha que já sabe mais ou menos, ele já sabe até fazer o alfa"**. Uma pessoa leiga, por outro lado, obriga o terapeuta a construir o relaxamento e o transe do zero, enfrentando todas as barreiras instintivas de forma autêntica.


## Referencia

ANDRESA MOLINA. *O Copo Vazio / O Assistido Leigo*. Aula 09 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]].
