---
type: aula
author: Andresa Molina
tags: [codigo-humanosense, humanosense, aula-08, reingestao-2026-06-19]
sources:
  - "[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"
---
# Aula 08 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `08   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 18.540 palavras; 603 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- É o seguinte, o que eu queria saber é se você recomenda a autoaplicação do humano sense, olha, porque o humanoterapeuta a gente pode se autoaplicar.
- Porque você percebeu na aplicação que aconteceu em você que por mais que você tenha feito muitas outras práticas, ele te leva para um lugar e trabalha em lugares muito diferentes de tudo aquilo que você já tinha acessado, porque a gente tem todo um trabalho, muitos códigos aí que são e códigos no sentido de são códigos mesmos que me foram trazidos e que…
- Eh, na folha de retorno à consciência, que é aquela últimazinha lá, número três, eh, no final, né, quando tira a energia do assistido da mesa e aí depois tem uma bolinha falando, ative as forças da habilidade, disponibilidade e autorização.
- Alguns tm mais mediunidade, vão perceber melhor, outros não vão perceber com tanta clareza, mas o processo acontece que entra nesse inconsciente da pessoa, nesse campo energético dela e aí a gente tem a porte espiritual e aí estão os códigos, tá?
- Então eu consegui trazer de certa maneira as duas necessidades que sempre nos pedem, né? um passo a passo estruturado que traz a segurança, não só a segurança da pessoa, mas a segurança espiritual, né, como um espaço livre para ela conseguir conduzir.
- É isso, porque pode ser que você tenha perguntado, mas eu nunca vou falar, faça isso, porque não é hipnose, não é comando de faça, é um faz sentido para você?
- E aí uma coisa que é uma coisa que eu sempre faço, quando eu percebo que a pessoa vai entrando na dor e eu vou ajudando ela, porque ela precisa sangrar, eu sempre lembro ela vai e não esquece que a gente tá aqui na sala, eu tô aqui com você, pode ir, não esquece que eu tô aqui, não esquece que a gente tá aqui.
- Então, por exemplo, eh, código humano não tem, não vai traduzir, não precisa nem traduzir código, não precisa traduzir, por exemplo, eh, orixás.
- Então, às vezes é tão inconsciente isso, mas em algum lugar ele faz uma leitura que é é é algo a nossa psiquê, né, e a psicanálise espiritualidade já traz psicanálise como um todo, ela faz associações livres por conta que não fazem sentido, mas dentro dela faz sentir.
- E aí dá lá que é cobradora mesmo, por exemplo, alguma das perguntas, vocês p ela tem consciência que ela faz, isso também é um problema porque fala, você percebe que se você ficar tentando controlar tudo, você vai ficar louca, por isso que você tá com burnout, e você tá tentando controlar todas as variáveis do mundo ou por isso que você tá com depressão,…
- Então aí aí eu fiquei assim, mas momento que a gente tá protegida de outras técnicas eu não posso falar porque não conheço a técnica, não sei quem é o quem é o orientador espiritual da técnica, quem é o dirigente espiritual do trabalho, não sei quais são as não tenho como dizer, aí eu não Mas aqui quando você faz, vocês dois estarão dentro desse campo de…
- Só que assim, quando eles me mandaram o código de rastreio já o o o produto que assim, a minha casa sempre tem alguém, nunca deixo de trer porque eu recebo de trabalho bastante coisa.

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-76
- É o seguinte, o que eu queria saber é se você recomenda a autoaplicação do humano sense, olha, porque o humanoterapeuta a gente pode se autoaplicar.
- Porque você percebeu na aplicação que aconteceu em você que por mais que você tenha feito muitas outras práticas, ele te leva para um lugar e trabalha em lugares muito diferentes de tudo aquilo que você já tinha acessado, porque a gente tem todo um trabalho, muitos códigos aí que são e códigos no sentido de são códigos mesmos que me foram trazidos e que não serão revelados, porque são muitas informações, muitas…
- Eh, na folha de retorno à consciência, que é aquela últimazinha lá, número três, eh, no final, né, quando tira a energia do assistido da mesa e aí depois tem uma bolinha falando, ative as forças da habilidade, disponibilidade e autorização.

### Bloco 2 - frases 77-152
- Alguns tm mais mediunidade, vão perceber melhor, outros não vão perceber com tanta clareza, mas o processo acontece que entra nesse inconsciente da pessoa, nesse campo energético dela e aí a gente tem a porte espiritual e aí estão os códigos, tá?
- Então eu consegui trazer de certa maneira as duas necessidades que sempre nos pedem, né? um passo a passo estruturado que traz a segurança, não só a segurança da pessoa, mas a segurança espiritual, né, como um espaço livre para ela conseguir conduzir.
- É isso, porque pode ser que você tenha perguntado, mas eu nunca vou falar, faça isso, porque não é hipnose, não é comando de faça, é um faz sentido para você?

### Bloco 3 - frases 153-228
- Então, às vezes é tão inconsciente isso, mas em algum lugar ele faz uma leitura que é é é algo a nossa psiquê, né, e a psicanálise espiritualidade já traz psicanálise como um todo, ela faz associações livres por conta que não fazem sentido, mas dentro dela faz sentir.
- Hum. foreso la imare la cura de las escenas primeras mu fuerte lo sento cuero una sensación impresante agradecerteísimo fue muy emocionante e quando você sente no corpo os códigos se restabelecendo seus códigos a sua reconexão com essa com essa parte divina que cada um de nós temos Sim, foi uma imagem de muito amor, assim que foi muitoora.
- Eu posso pendular e quando eu faço as perguntas, ao escolher as perguntas em cada pétala e tudo mais, eu posso pendular pelo menos a primeira, porque depois a segunda pergunta é sempre a correspondente, né?

### Bloco 4 - frases 229-304
- E aí dá lá que é cobradora mesmo, por exemplo, alguma das perguntas, vocês p ela tem consciência que ela faz, isso também é um problema porque fala, você percebe que se você ficar tentando controlar tudo, você vai ficar louca, por isso que você tá com burnout, e você tá tentando controlar todas as variáveis do mundo ou por isso que você tá com depressão, por exemplo, né?
- Então qualquer energia externa não se aproxima, até porque no código tem os campos e os guardiões do trabalho.
- Então aí aí eu fiquei assim, mas momento que a gente tá protegida de outras técnicas eu não posso falar porque não conheço a técnica, não sei quem é o quem é o orientador espiritual da técnica, quem é o dirigente espiritual do trabalho, não sei quais são as não tenho como dizer, aí eu não Mas aqui quando você faz, vocês dois estarão dentro desse campo de proteção, tanto o assistido quanto o o o trabalhador, tá?

### Bloco 5 - frases 305-380
- E daí eu fiquei assim, a perguntar isso para ela, porque como eu amo ser professora e eu acredito que eu fazer cursos, quer fazer todos, eh, é porque eu quero saber no racional para ter clareza emocional assim, sabe, espiritual assim.
- É assim, ó, o código ele vai ajudar porque ele é racional e ele vai ajudar muito mesmo com os seus essa parte racional, porque você não vai só pelo sentido, você vai pelo inconsciente, vai falar: "Você tá falando uma coisa, mas na verdade percebe que aqui tá diferente, não vai ajudar muito." Só que às vezes dependendo do que é, a pessoa não vai trazer para você.
- Só que assim, quando eles me mandaram o código de rastreio já o o o produto que assim, a minha casa sempre tem alguém, nunca deixo de trer porque eu recebo de trabalho bastante coisa.

### Bloco 6 - frases 381-456
- Então, onde você tá tentando falar e não tá conseguindo comunicar, o percebe até na sua vida quando você precisa, quer falar com algo alguém e não consegue fazer a ponte de comunicação.
- Ela chama, ela vai me chamar aqui, é, no chat aqui, porque daí vocês já combinam e ela já fala com você e aí vocês já marcam tranquilo.
- Ã, e outra coisa, como eu assim eu tenho uma dúvida, como eu sou humanoterapeuta, quando o paciente o assistido chega para mim com uma uma dúvida específica, né?

### Bloco 7 - frases 457-532
- Aquelas 4 horas foi só para dizer, ó, separa um tempo, porque também você pode ficar meio nervoso no começo e ficar mais cansado, precisa dar mais cansadinha de entre um um cliente outro.
- E a última pergunta rapidinho e como nessa mesa não tem um um labirinto, a gente pode colocar ele e para algum lugar norte, sul ou não precisa não precisa porque a gente não tá trabalhando com radiestesia aqui.
- A gente tá isso não é radiostesia, isso isso tá muito além de de um trabalho material e só do campo eletromagnético, tá muito Ah, então não precisa fazer essa se colocar nesse norte, né?

### Bloco 8 - frases 533-603
- Então não é você, nem é o seu racional sendo sacana, nem é o seu inconsciente, é um fractal que tá em dor, ok?
- Minha mãe me esqueceu na escola, minha mãe não abandonou, só esqueceu, mas ali ficou um uma coisa que pegou muito e enfim e ali ficou uma dor, um medo, uma angústia, coisa né?
- Tudo isso que eu tô falando, isso a gente aprende num outro lugar, assim, a gente dentro da parceria, a gente conversa um pouco sobre essas coisas todas, mas assim, porque não é sobre acender a vela, mas eu também quando eu dou um comando, eu tô dando um comando mental, trabalhando no elemental, dando uma, pegando informação, trazendo espiritualidade, tô fazendo magia em cada minuto do que eu faço na minha vida.

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Então, seja bem objetivo, não precisa contar a história inteira que eu consigo identificar pontos, porque eu já faço isso há tanto tempo, eu consigo identificar pontos importantes, tá bom?
- E aí, se eu precisar de alguma coisa, eu mesmo vou perguntando para vocês, tá? só pra gente conseguir responder o maior número de pessoas e eh dar prioridade principalmente eh para quem tá falando sobre a parte eh uma mesmo do do da da parte das técnicas, não da teoria do meu cliente, da possibilidade do será, mas efetivamente o que a gente tem aqui, tá bom?
- Então eu consegui trazer de certa maneira as duas necessidades que sempre nos pedem, né? um passo a passo estruturado que traz a segurança, não só a segurança da pessoa, mas a segurança espiritual, né, como um espaço livre para ela conseguir conduzir.
- É isso, porque pode ser que você tenha perguntado, mas eu nunca vou falar, faça isso, porque não é hipnose, não é comando de faça, é um faz sentido para você?
- E aí uma coisa que é uma coisa que eu sempre faço, quando eu percebo que a pessoa vai entrando na dor e eu vou ajudando ela, porque ela precisa sangrar, eu sempre lembro ela vai e não esquece que a gente tá aqui na sala, eu tô aqui com você, pode ir, não esquece que eu tô aqui, não esquece que a gente tá aqui.
- Então, por exemplo, eh, código humano não tem, não vai traduzir, não precisa nem traduzir código, não precisa traduzir, por exemplo, eh, orixás.
- Então, às vezes é tão inconsciente isso, mas em algum lugar ele faz uma leitura que é é é algo a nossa psiquê, né, e a psicanálise espiritualidade já traz psicanálise como um todo, ela faz associações livres por conta que não fazem sentido, mas dentro dela faz sentir.
- Eu posso pendular e quando eu faço as perguntas, ao escolher as perguntas em cada pétala e tudo mais, eu posso pendular pelo menos a primeira, porque depois a segunda pergunta é sempre a correspondente, né?
- E ela fala: "Ah, eu mente mesmo não vou deixar ir, não gosto daquela nora, não vou vou falar que meu filho vai ficar aqui, vou falar mal dela e não vou dar o dinheiro porque não quero, porque eu não quero que eles vão um exemplo, entendeu?" E aí ela quer mudar, essa relação nunca vai melhorar, porque você tá fazendo isso e tem consciência que tá fazendo.
- Só que assim, quando eles me mandaram o código de rastreio já o o o produto que assim, a minha casa sempre tem alguém, nunca deixo de trer porque eu recebo de trabalho bastante coisa.

## Conceitos-Chave Extraídos

- Então vocês acessam, mas os códigos lhe acessam a partir de um trabalho comum, espiritual e material de cada um de nós, né?
- Porque você percebeu na aplicação que aconteceu em você que por mais que você tenha feito muitas outras práticas, ele te leva para um lugar e trabalha em lugares muito diferentes de tudo aquilo que você já tinha acessado, porque a gente tem todo um trabalho, muitos códigos aí que são e códigos no sentido de são códigos mesmos que me foram trazidos e que…
- Eh, na folha de retorno à consciência, que é aquela últimazinha lá, número três, eh, no final, né, quando tira a energia do assistido da mesa e aí depois tem uma bolinha falando, ative as forças da habilidade, disponibilidade e autorização.
- Alguns tm mais mediunidade, vão perceber melhor, outros não vão perceber com tanta clareza, mas o processo acontece que entra nesse inconsciente da pessoa, nesse campo energético dela e aí a gente tem a porte espiritual e aí estão os códigos, tá?
- Então eu consegui trazer de certa maneira as duas necessidades que sempre nos pedem, né? um passo a passo estruturado que traz a segurança, não só a segurança da pessoa, mas a segurança espiritual, né, como um espaço livre para ela conseguir conduzir.
- Então, por exemplo, eh, código humano não tem, não vai traduzir, não precisa nem traduzir código, não precisa traduzir, por exemplo, eh, orixás.
- Hum. foreso la imare la cura de las escenas primeras mu fuerte lo sento cuero una sensación impresante agradecerteísimo fue muy emocionante e quando você sente no corpo os códigos se restabelecendo seus códigos a sua reconexão com essa com essa parte divina que cada um de nós temos Sim, foi uma imagem de muito amor, assim que foi muitoora.
- E aí dá lá que é cobradora mesmo, por exemplo, alguma das perguntas, vocês p ela tem consciência que ela faz, isso também é um problema porque fala, você percebe que se você ficar tentando controlar tudo, você vai ficar louca, por isso que você tá com burnout, e você tá tentando controlar todas as variáveis do mundo ou por isso que você tá com depressão,…
- E ela fala: "Ah, eu mente mesmo não vou deixar ir, não gosto daquela nora, não vou vou falar que meu filho vai ficar aqui, vou falar mal dela e não vou dar o dinheiro porque não quero, porque eu não quero que eles vão um exemplo, entendeu?" E aí ela quer mudar, essa relação nunca vai melhorar, porque você tá fazendo isso e tem consciência que tá fazendo.
- E aí com todo o estudo que a gente fez, então vou sugerir todo mundo, gente, revisite os vídeos dos conceitos, porque a parte terapia e a explicação tá nos conceitos, que são os primeiros vídeos da da do curso todo.
- Aqui no manuscense você falou que a gente tá mais dentro pessoa, então fica imaginando se a pessoa está se visualizando no campo, eu também provavelmente vou começar a visualizar isso.
- Então, a minha pergunta era justamente sobre a ativação do da chama trina e sobre as iniciações, mas daí você já respondeu que foi na aula passada, né?
- Então qualquer energia externa não se aproxima, até porque no código tem os campos e os guardiões do trabalho.
- Então aí aí eu fiquei assim, mas momento que a gente tá protegida de outras técnicas eu não posso falar porque não conheço a técnica, não sei quem é o quem é o orientador espiritual da técnica, quem é o dirigente espiritual do trabalho, não sei quais são as não tenho como dizer, aí eu não Mas aqui quando você faz, vocês dois estarão dentro desse campo de…
- É assim, ó, o código ele vai ajudar porque ele é racional e ele vai ajudar muito mesmo com os seus essa parte racional, porque você não vai só pelo sentido, você vai pelo inconsciente, vai falar: "Você tá falando uma coisa, mas na verdade percebe que aqui tá diferente, não vai ajudar muito." Só que às vezes dependendo do que é, a pessoa não vai trazer para…
- Só que assim, quando eles me mandaram o código de rastreio já o o o produto que assim, a minha casa sempre tem alguém, nunca deixo de trer porque eu recebo de trabalho bastante coisa.


## Técnicas, Procedimentos e Orientações Práticas

- Então, seja bem objetivo, não precisa contar a história inteira que eu consigo identificar pontos, porque eu já faço isso há tanto tempo, eu consigo identificar pontos importantes, tá bom?
- E aí, se eu precisar de alguma coisa, eu mesmo vou perguntando para vocês, tá? só pra gente conseguir responder o maior número de pessoas e eh dar prioridade principalmente eh para quem tá falando sobre a parte eh uma mesmo do do da da parte das técnicas, não da teoria do meu cliente, da possibilidade do será, mas efetivamente o que a gente tem aqui, tá bom?
- É o seguinte, o que eu queria saber é se você recomenda a autoaplicação do humano sense, olha, porque o humanoterapeuta a gente pode se autoaplicar.
- Enquanto você não fizer aplicação em outras pessoas, entender qual é o processo, decorar todas as falas, porque a primeira coisa você não pode estar de olho aberto para fazer sua auto aplicação.
- Porque você percebeu na aplicação que aconteceu em você que por mais que você tenha feito muitas outras práticas, ele te leva para um lugar e trabalha em lugares muito diferentes de tudo aquilo que você já tinha acessado, porque a gente tem todo um trabalho, muitos códigos aí que são e códigos no sentido de são códigos mesmos que me foram trazidos e que…
- Eh, na folha de retorno à consciência, que é aquela últimazinha lá, número três, eh, no final, né, quando tira a energia do assistido da mesa e aí depois tem uma bolinha falando, ative as forças da habilidade, disponibilidade e autorização.
- Inclusive os comandos, as perguntas, eu só transcrevi tudo, tá Andresa, transcrevi tudo porque para enxergar melhor e poder copiar e colar, né?
- Então eu consegui trazer de certa maneira as duas necessidades que sempre nos pedem, né? um passo a passo estruturado que traz a segurança, não só a segurança da pessoa, mas a segurança espiritual, né, como um espaço livre para ela conseguir conduzir.
- É isso, porque pode ser que você tenha perguntado, mas eu nunca vou falar, faça isso, porque não é hipnose, não é comando de faça, é um faz sentido para você?
- Eu posso pendular e quando eu faço as perguntas, ao escolher as perguntas em cada pétala e tudo mais, eu posso pendular pelo menos a primeira, porque depois a segunda pergunta é sempre a correspondente, né?
- E aí dá lá que é cobradora mesmo, por exemplo, alguma das perguntas, vocês p ela tem consciência que ela faz, isso também é um problema porque fala, você percebe que se você ficar tentando controlar tudo, você vai ficar louca, por isso que você tá com burnout, e você tá tentando controlar todas as variáveis do mundo ou por isso que você tá com depressão,…
- Revisite aqui, vocês vão ter bastante tempo para reassistir aquilo, reviseite quantas vezes vocês precisarem, porque aquilo vai dar muito material de comunicação com com o cliente, tá bom?
- Aqui no manuscense você falou que a gente tá mais dentro pessoa, então fica imaginando se a pessoa está se visualizando no campo, eu também provavelmente vou começar a visualizar isso.
- Então aí aí eu fiquei assim, mas momento que a gente tá protegida de outras técnicas eu não posso falar porque não conheço a técnica, não sei quem é o quem é o orientador espiritual da técnica, quem é o dirigente espiritual do trabalho, não sei quais são as não tenho como dizer, aí eu não Mas aqui quando você faz, vocês dois estarão dentro desse campo de…


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- É o seguinte, o que eu queria saber é se você recomenda a autoaplicação do humano sense, olha, porque o humanoterapeuta a gente pode se autoaplicar.
- Enquanto você não fizer aplicação em outras pessoas, entender qual é o processo, decorar todas as falas, porque a primeira coisa você não pode estar de olho aberto para fazer sua auto aplicação.
- Depende do tamanho da ferida que você consegue cutucar em você, porque não adianta você fazer lá todo o seu trabalho, todo o processo de desdobramento e não ter coragem de cutucar ferida para ela sangrar, entende?
- Eh, na folha de retorno à consciência, que é aquela últimazinha lá, número três, eh, no final, né, quando tira a energia do assistido da mesa e aí depois tem uma bolinha falando, ative as forças da habilidade, disponibilidade e autorização.
- E aí uma coisa que é uma coisa que eu sempre faço, quando eu percebo que a pessoa vai entrando na dor e eu vou ajudando ela, porque ela precisa sangrar, eu sempre lembro ela vai e não esquece que a gente tá aqui na sala, eu tô aqui com você, pode ir, não esquece que eu tô aqui, não esquece que a gente tá aqui.
- Porque é como se, sabe um sonho onde você desdobra num lugar tão profundo, que eles sonhos tão vividos e tão los, que você desdobre, que daí não é exatamente um sonho, não só um sonho, que você desdobra num lugar tão e aí imagina que alguma parte sua te e aí você tá com medo, fala vai, pode ir porque nós estamos dormindo, ó, lembra disso.
- E aí dá lá que é cobradora mesmo, por exemplo, alguma das perguntas, vocês p ela tem consciência que ela faz, isso também é um problema porque fala, você percebe que se você ficar tentando controlar tudo, você vai ficar louca, por isso que você tá com burnout, e você tá tentando controlar todas as variáveis do mundo ou por isso que você tá com depressão,…
- Que venha para você como base de informação mesmo, porque existem vários tipos de captador, né?
- Então existem os captadores que são mais sensíveis e captam mais pro corpo e tem mais sensibilidade e outros que são mais racionais, né?
- Então aí aí eu fiquei assim, mas momento que a gente tá protegida de outras técnicas eu não posso falar porque não conheço a técnica, não sei quem é o quem é o orientador espiritual da técnica, quem é o dirigente espiritual do trabalho, não sei quais são as não tenho como dizer, aí eu não Mas aqui quando você faz, vocês dois estarão dentro desse campo de…
- Então não é você, nem é o seu racional sendo sacana, nem é o seu inconsciente, é um fractal que tá em dor, ok?
- Minha mãe me esqueceu na escola, minha mãe não abandonou, só esqueceu, mas ali ficou um uma coisa que pegou muito e enfim e ali ficou uma dor, um medo, uma angústia, coisa né?


## Citações e Formulações de Alta Densidade

- “Então, seja bem objetivo, não precisa contar a história inteira que eu consigo identificar pontos, porque eu já faço isso há tanto tempo, eu consigo identificar pontos importantes, tá bom?”
- “E aí, se eu precisar de alguma coisa, eu mesmo vou perguntando para vocês, tá? só pra gente conseguir responder o maior número de pessoas e eh dar prioridade principalmente eh para quem tá falando sobre a parte eh uma mesmo do do da da parte das técnicas, não da teoria do meu cliente, da…”
- “Eh, na folha de retorno à consciência, que é aquela últimazinha lá, número três, eh, no final, né, quando tira a energia do assistido da mesa e aí depois tem uma bolinha falando, ative as forças da habilidade, disponibilidade e autorização.”
- “Então eu consegui trazer de certa maneira as duas necessidades que sempre nos pedem, né? um passo a passo estruturado que traz a segurança, não só a segurança da pessoa, mas a segurança espiritual, né, como um espaço livre para ela conseguir conduzir.”
- “É isso, porque pode ser que você tenha perguntado, mas eu nunca vou falar, faça isso, porque não é hipnose, não é comando de faça, é um faz sentido para você?”
- “E aí uma coisa que é uma coisa que eu sempre faço, quando eu percebo que a pessoa vai entrando na dor e eu vou ajudando ela, porque ela precisa sangrar, eu sempre lembro ela vai e não esquece que a gente tá aqui na sala, eu tô aqui com você, pode ir, não esquece que eu tô aqui, não esquece que a…”
- “Porque é como se, sabe um sonho onde você desdobra num lugar tão profundo, que eles sonhos tão vividos e tão los, que você desdobre, que daí não é exatamente um sonho, não só um sonho, que você desdobra num lugar tão e aí imagina que alguma parte sua te e aí você tá com medo, fala vai, pode ir…”
- “Então, por exemplo, eh, código humano não tem, não vai traduzir, não precisa nem traduzir código, não precisa traduzir, por exemplo, eh, orixás.”
- “Hum. foreso la imare la cura de las escenas primeras mu fuerte lo sento cuero una sensación impresante agradecerteísimo fue muy emocionante e quando você sente no corpo os códigos se restabelecendo seus códigos a sua reconexão com essa com essa parte divina que cada um de nós temos Sim, foi uma…”
- “Eu posso pendular e quando eu faço as perguntas, ao escolher as perguntas em cada pétala e tudo mais, eu posso pendular pelo menos a primeira, porque depois a segunda pergunta é sempre a correspondente, né?”
- “Então aí aí eu fiquei assim, mas momento que a gente tá protegida de outras técnicas eu não posso falar porque não conheço a técnica, não sei quem é o quem é o orientador espiritual da técnica, quem é o dirigente espiritual do trabalho, não sei quais são as não tenho como dizer, aí eu não Mas aqui…”
- “Só que assim, quando eles me mandaram o código de rastreio já o o o produto que assim, a minha casa sempre tem alguém, nunca deixo de trer porque eu recebo de trabalho bastante coisa.”

## Conexões com a Wiki

- [[Conceito do Metodo HumanoSense]]
- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio da Liberdade Consciente]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Enquadramento na Piramide]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Tecnica de Retorno a Consciencia e Harmonizacao]]

## FAQs para NotebookLM (Fase 2)

### Bloco 1: A Ética Clínica do Transe e a Autossustentação

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
1. Como Andresa Molina justifica a proibição de dar ordens ao assistido durante o desdobramento na Câmara Astral, e de que forma a condução por "convites e perguntas" preserva o livre-arbítrio?
2. Por que a autora proíbe terminantemente o toque físico (abraços, acolhimento corporal) no momento em que o assistido está vivenciando a catarse e o choro na sessão?
3. Como o terapeuta deve agir caso o assistido "amoleça" ou pareça estar prestes a cair da cadeira durante a purgação da dor, e qual a importância somática de forçá-lo a sustentar o próprio corpo físico?
4. Qual a postura exigida do terapeuta perante reações de expurgo biológico (enjoos, tosse, ânsias de vômito) do assistido, e como a naturalidade clínica impede a "criação de monstros"?
```

### Bloco 2: Os Impedimentos Familiares e a Troca de Atendimentos

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
5. Por que Andresa Molina recomenda o impedimento clínico de tratar familiares próximos (como filhos ou cônjuges) e de que maneira o ego da relação familiar contamina a egrégora da mesa?
6. Sob a ótica do "Princípio do Posicionamento de Valor", por que o terapeuta não deve fazer a devolução financeira para clientes que decidem ir embora no meio da sessão após o choque de realidade?
7. Por que a autora recusa administrativamente organizar duplas de troca "sorteadas" de atendimentos entre os alunos, e de que forma essa proibição respeita a lei de ressonância e fluxo magnético?
8. De que maneira a mesa Humanosense identifica e desfaz a "Personalidade Sombra" (Cobrador, Explorador, Limitador) quando o consciente do cliente nega possuir esses comportamentos de dor?
```

### Bloco 3: As Estruturas de Luto, Ilusão e Genética Celular

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
9. Como a criança ferida se protege na "Fantasia de Salvamento Infantil" e como esse abismo de carência de amparo sabota os relacionamentos e a vida profissional do adulto?
10. Como o luto mal resolvido provoca o "Deslocamento de Função" no sistema familiar e de que forma a mesa e a câmara corrigem a filha que assume a função de esposa energética de seu pai viúvo?
11. De que forma a mesa Humanosense se diferencia conceitualmente da Humanoterapia (limpeza passiva realizada de fora para dentro pelo terapeuta) e da Regressão Comum?
12. Por que Andresa Molina sustenta que o padrasto, por mais amor e cuidado que ofereça, jamais substitui o elo biológico do pai na biologia de defesa celular do assistido?
```

### Bloco 4: Didática Radiestésica e Ancoramento Somático

```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
13. O que acusa o diagnóstico de "Ausência de Kundalini" (a pessoa não sente prazer nem calor) ao tentar fecundar e plantar a semente de futuro no útero esvaziado?
14. Como a tecnologia do Humanosense atua acelerando a mediunidade de terapeutas extremamente racionais de forma orgânica, sem alterar a sua configuração neurológica natural?
15. Como a autora conceitua a "Magia Prática" no Humanosense e de que maneira as reclamações repetidas e o ódio diário ativam e manipulam as forças elementais contra a própria pessoa?
16. Qual a relevância neurológica do intestino ("cérebro entérico") no processo de depressão inflamatória e como as marcas somáticas viscerais conduzem o corpo do assistido?
17. Por que Andresa Molina exige que o atendimento do Humanosense ocorra com o cliente sentado em uma cadeira, proibindo a catarse de sangramento deitada de costas na maca?
18. Quais os riscos e dificuldades mecânicas enfrentados por terapeutas iniciantes ao tentar realizar a autoaplicação do Código Humanosense?
19. Como o terapeuta deve usar a própria voz como "ancoramento na cena" durante o desdobramento profundo para que o assistido sinta segurança somática diante do terror do passado?
20. Como o terapeuta opera as frequências de "Harmoniza, Potencializa e Liberta" com o pêndulo no encerramento e de que forma desconecta fisicamente a energia do assistido da mesa?
21. Quais são as regras e limites concedidos pela autora para a tradução e internacionalização de comandos em outros idiomas sem perder a raiz nominal em português?
22. Quais as consequências de permitir que o pêndulo decida de forma cega qual pergunta diagnóstica fazer nas mandalas e qual a responsabilidade do terapeuta de "dar o nó no pingo d'água"?
23. Como é conduzido o rebaixamento cerebral (Alfa) com a contagem decrescente, incluindo o relaxamento abdominal na marca do "555" para estabilizar o batimento cardíaco?
24. Quais os limites de tempo teto recomendados para a sessão do Humanosense e quais as faixas de honorários indicadas para o posicionamento High-Ticket?
```

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## Referência

ANDRESA MOLINA. *Aula 08 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.
