---
type: sintese
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, modulo_02, temperamento, elementos, julgamentos]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_35_temperamento_e_elementos_pecados_e_julgamentos.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_36_pecados_e_julgamentos.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_39_temperamentos_e_signos.md]]"]
---

# HT - Modulo 02 - Temperamento e Elementos

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_35_temperamento_e_elementos_pecados_e_julgamentos.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_36_pecados_e_julgamentos.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_39_temperamentos_e_signos.md]]


## Nucleos do Modulo

- Os elementos funcionam como chave de leitura do comportamento.
- Pecados e julgamentos entram como distorcoes da estrutura humana.
- Signos aparecem como linguagem complementar de temperamento.

## Síntese

- [INFERÊNCIA] HT - Modulo 02 - Temperamento e Elementos é uma nota de apoio dentro da wiki de Andresa Molina e precisa ser lida em conjunto com as aulas e mapas estruturais já conectados.

## Evidências do Material

- Esta nota existe para impedir que esses elementos fiquem soltos em arquivos isolados. ## Eixos - [[Conceito do Mapa da Alma]] - [[Conceito do Metodo HumanoSense]] - [[Conceito da Mesa HumanoSense]] - [[Conceito da Ficha de Identificacao e Sintese da Dor]] - [[Conceito da Camara HumanoSense]] - [[Tecnica de Identificacao da Raiz na Anamnese]] - [[Tecnica de Aplicacao Guiada na Camara HumanoSense]] - [[Mapa Estrutural da Wiki Andresa Molina]] ## Aplicação Prática 1. (Arquitetura do HumanoSense)

## Conexões

- [[Arquitetura do HumanoSense]]

## Referencia

ANDRESA MOLINA. *HT - Modulo 02 - Temperamento e Elementos*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_35_temperamento_e_elementos_pecados_e_julgamentos.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_36_pecados_e_julgamentos.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_39_temperamentos_e_signos.md]]. Acesso em: 17 jun. 2026.
