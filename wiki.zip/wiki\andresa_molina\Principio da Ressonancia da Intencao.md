---
type: principio
author: Andresa Molina
tags: [efeito-bumerangue, intencao, vibracao, magnetismo, 7a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]]"]
---

# Princípio da Ressonância da Intenção (O Efeito Bumerangue da Destruição/Cura)

- **Definição**: A lei vibracional segundo a qual a intenção direcionada ao próximo não se projeta apenas para fora, mas passa a habitar e a moldar a realidade biológica e espiritual do próprio emissor.
- **Justificativa**: Não é possível entrar em uma "guerra" de ódio ou destruição para tentar consertar a vida sem sofrer os danos somáticos e energéticos equivalentes. O que desejamos e projetamos ativamente para o mundo, seja de bom ou ruim, se retroalimenta instantaneamente em nosso próprio campo magnético e corporal.
- **Evidências**: *"Se você vibra destruir o outro, esta vibração lhe habita e você vai destruir a si mesmo. Se você vibra potencializar o outro, esta potência lhe habita e você vai potencializar a si mesmo. Se você vibra a cura do seu e dos seus ancestrais, familiares, amigos, todos que por alguma razão estão ao seu lado e também distantes, que é a humanidade toda, essa cura lhe habita e vai curar a si mesmo."*
- **Implicações**: A cura compassiva direcionada à ancestralidade e à humanidade atua, em primeiro lugar, desarmando os sintomas e bloqueios do próprio indivíduo. Por outro lado, sustentar sentimentos de vingança ou hostilidade retroalimenta o colapso e a auto-sabotagem.
- **Conexões**: [[Principio do Consentimento e Invasao de Campo]], [[Principio da Responsabilidade Espiritual]]

## Notas Pessoais

- Reservado para observações do usuário.

## Referência

ANDRESA MOLINA. *Princípio da Ressonância da Intenção (O Efeito Bumerangue da Destruição/Cura)*. Aula 07 - Coordenada 7 (A Cura Buscada em Todo Lugar). Fontes: [[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. De que maneira a emanação frequencial de "ser abandonável" ou "ser magoável" no cotidiano determina, sob a ótica vibracional, o tratamento ou as agressões que o indivíduo recebe de terceiros?
**Resposta**: A nível somático e vibracional, o tratamento recebido de terceiros é apenas um espelho magnético da frequência que o próprio indivíduo sustenta em seu campo através do autoabandono e da autodepreciação. 

Andresa estabelece a regra de correspondência inegociável de que "se a gente se abandona, a gente não pode reclamar que o outro nos abandonou". O mundo externo apenas responde ao que o corpo emana. Portanto, o agressor externo não ataca ao acaso; ele ataca porque é sintonizado pela permissividade do campo da vítima. A autora decreta de forma literal: "se alguém te abandona, é porque você está abandonável. Se alguém, se você se magoa todos os dias e aí alguém de fora te magoa, é porque a frequência que você está emanando é de que você está magoável". A pessoa muitas vezes "não faz isso porque você quer", mas enquanto o seu corpo e emoções emitirem esse sinal constante de abandono, ela continuará atraindo essas agressões.

