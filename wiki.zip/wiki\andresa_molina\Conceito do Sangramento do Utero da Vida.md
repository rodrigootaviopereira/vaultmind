---
type: conceito
author: Andresa Molina
tags: [sangrar, utero-da-vida, esvaziamento-emocional, catarse]
sources: ["[[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]]"]
---

# O Sangramento do Útero da Vida (O esvaziamento emocional como requisito orgânico para a nova criação)

- **Definição Precisa**: O processo somático e energético de catarse e purgação no qual o assistido precisa entrar em contato profundo com a dor, o medo e a raiva reprimida, esvaziando o receptáculo do seu feminino interno (útero) antes de tentar conceber ou plantar um novo futuro.
- **Sinônimos/Variações**: Sangramento do feminino, esvaziar o útero da vida, sangrar com consciência.
- **Contexto de Uso**: Induzido ativamente na fase de desipnose, onde o terapeuta força o assistido a vivenciar plenamente a cólica emocional de sua dor e a chorar suas perdas passadas, limpando o lixo energético do sistema de contenção.
- **Relação com Princípios**: [[Principio da Aceitacao dos Fatos]], [[Principio do Vazio como Bussola]]
- **Exemplos do Material**: "É preciso limpar o útero da vida. É preciso limpar e deixar esse espaço sagrado limpo. E é no sangrar do feminino, é no sente... não dá para fecundar nada num útero preenchido, não tem como nascer nada numa terra que não é fértil... se ele estiver cheio de lixo, de abortos e de dores e de apegos e de raiva e de rancor, tudo o que pode nascer na vida é raiva, rancor, angústia, medo e não tem um solo sagrado... Então sangrar e vai sentir o quê? as cólicas, as dores, o medo e o desejo de esvaziar-se com consciência."
- **Aplicação Prática**: O terapeuta não deve aliviar a dor do assistido prematuramente durante a catarse. Deve instruí-lo a exprimir toda a mágoa e raiva acumulada ("sangrar") para que o "solo" emocional se torne vazio e fértil para uma nova semeadura.
- **Conexões Externas**: [[Tecnica do Trabalho Energetico de Sangria]], [[Conceito da Fusao do Masculino e Feminino]]

## Perguntas Frequentes / Didática de Atendimento

## Perguntas Frequentes / Didática de Atendimento

### 9. O que significa somatizar o "Sangramento do Útero da Vida" e por que o esvaziamento de traumas, abortos e raivas é um requisito orgânico obrigatório antes de cocriar?
**Resposta**: Somatizar o "Sangramento do Útero da Vida" significa vivenciar, no próprio corpo e campo energético, a purgação visceral de memórias e dores. A nível físico e emocional, é o momento em que o assistido chora, sente "as cólicas, as dores, o medo e o desejo de esvaziar-se com consciência".

Esse esvaziamento é um requisito orgânico obrigatório para cocriar porque a biologia espiritual imita a natureza. A autora decreta que "não dá para fecundar nada num útero preenchido, não tem como nascer nada numa terra que não é fértil". Se o "espaço sagrado" da pessoa estiver ocupado por "lixo, de abortos e de dores e de apegos e de raiva e de rancor", qualquer tentativa de semear uma vida próspera resultará nessas mesmas toxinas: "tudo o que pode nascer na vida é raiva, rancor, angústia, medo e não tem um solo sagrado". É preciso limpar o receptáculo ("sangrar o feminino") para a semente florescer.

## Referencia

ANDRESA MOLINA. *O Sangramento do Útero da Vida*. Aula 06 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]].
