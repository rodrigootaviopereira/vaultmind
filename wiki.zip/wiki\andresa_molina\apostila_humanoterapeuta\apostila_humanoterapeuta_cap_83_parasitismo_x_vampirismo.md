---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_83_parasitismo_x_vampirismo.md]]"]
---

# Cap 083 - Parasitismo X Vampirismo

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_83_parasitismo_x_vampirismo.md]]

## Referencia

ANDRESA MOLINA. *Cap 083 - Parasitismo X Vampirismo*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_83_parasitismo_x_vampirismo.md]]. Acesso em: 17 jun. 2026.
