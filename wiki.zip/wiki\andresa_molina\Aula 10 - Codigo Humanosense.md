---
type: aula
author: Andresa Molina
tags: [codigo-humanosense, humanosense, aula-10, reingestao-2026-06-19]
sources:
  - "[[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]"
---
# Aula 10 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `10   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 18.860 palavras; 636 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- Então, quando eu falei inclusive com a Patrícia que ela não estava, quando ela trouxe a questão de eh ela não ela ser terapeuta, então ela queria materializar ser terapeuta, quando na verdade ela não precisa materializar ser terapeuta, porque terapeuta ela já é. o que ela quer materializar é cliente.
- Então, eu permei todo o trabalho com as informações que vocês tm na mandala cura e com todas as informações que eh que eu trouxe como conceitos no começo, né?
- Então todas essas afirmações, essas questões, elas t a gente precisa ter um pouquinho de cuidado porque a gente faz de maneira despretenciosa, mas isso com o nosso emocional, um comando mental, a gente cria essa massa e essa massa ela vai atrair energia das mesmas frequências, então e vai desencadear um monte de outras coisas.
- Você vai conseguir colocar todos os dados do seu cliente e eu vou conseguir analisar o seu cliente, analisar aquele atendimento que você fez. eu vou conseguir analisar as perguntas que você fez, as respostas que ele deu, onde eu vou conseguir trazer um aspecto, onde você vai colocar ali tudo que aconteceu e eu vou ter como analisar tudo isso e trazer uma…
- É um processo de lapidação espiritual e profissional feito para terapeutas que querem atuar com mais confiança e clareza, dominar o método no campo de batalha, ter mais clientes e se profissionalizar e viver do código que carregam em si.
- O Mastercência é um movimento de expansão natural do terapeuta depois de acessar o código humanos para afiar o seu machado espiritual. é o lugar onde o terapeuta afia o machado espiritual e atua com mais precisão, consciência e confiança.
- Então é para quem quer ler e atuar diretamente no campo, acessar registros de memória inconsciente, registros acásticos e cármicos, tudo isso vivido e explicado em casos reais na prática.
- Então, acessar esses originários, esses arquétipos, desvendar os códigos primordiais dos povos originários e usar essas forças espirituais para limpar, equilibrar, curar e abrir o campo paraa manifestação dos desejos mais profundos.
- Essa matriz da consciência, ela vai conseguir identificar na vida do seu cliente quem são os possíveis cobradores, limitadores, exploradores." E ela vai responder algumas perguntas ao tudo automático, tudo digital, que você consegue identificar junto com ela.
- Ela também é uma ferramenta que vai deixar a possibilidade de você não precisar falar tudo de novo, de uma maneira, ah, não lembro meu cliente, hoje eu fiz um atendimento aqui, você deixando autorizado e a gente consegue então falar de um caso real, né, específico, trabalhar específico num caso para você melhorar, para quem um assistindo do outro acaba…
- Então, resumindo, seis meses de prática, direção e expansão, encontros quinzinis ao vivo comigo, sistema digital integrado, matriz da consciência, estudos de casos reais, e aprofundamento espiritual, crescimento da pessoa, do profissional e do financeiro, certo?
- Não é sobre um papel, né? é sobre a gente falando de códigos de espiritualidade, de equipe de cura, de integridade, de eh de libertar mentes aprisionadas que estão em dor, em campos ombralinos, porque é isso que o código faz, é desobsessão profunda, é trabalho de de de desfazimento de portais eh de acessos que estão entrando coisas que não deveriam.

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-80
- Então, quando eu falei inclusive com a Patrícia que ela não estava, quando ela trouxe a questão de eh ela não ela ser terapeuta, então ela queria materializar ser terapeuta, quando na verdade ela não precisa materializar ser terapeuta, porque terapeuta ela já é. o que ela quer materializar é cliente.
- Então, eu permei todo o trabalho com as informações que vocês tm na mandala cura e com todas as informações que eh que eu trouxe como conceitos no começo, né?
- Então todas essas afirmações, essas questões, elas t a gente precisa ter um pouquinho de cuidado porque a gente faz de maneira despretenciosa, mas isso com o nosso emocional, um comando mental, a gente cria essa massa e essa massa ela vai atrair energia das mesmas frequências, então e vai desencadear um monte de outras coisas.

### Bloco 2 - frases 81-160
- Não precisa se forçar, respeita porque eh ela ela entrou em contato com uma consciência dela mesmo que ela quer desfazer, uma sentimento que ela tem, mas ela não quer desfazer, entende?
- H, então, uma vez que só eh temos só tenho a possibilidade de uma pergunta boadinha de hoje, eu vou questionar acerca do atendimento que eu experimentei fazer hoje.
- Ela começou a ter eh eh a dizer que sentia um peso muito grande na cabeça, a curvar, portanto o corpo dela começou a manifestar e ela só dizia que tinha dor, que sentia a carregar, portanto parecia assim velhinha e começou a manifestar essa essa parte física, mas não via nada, não via ninguém, não entrava em contacto com nenhum outro conteúdo e eu fiquei assim um bocadinho perdida sem saber como dirigir e a dado…

### Bloco 3 - frases 161-240
- Ótimo, porque às vezes ela não consegue ir sozinha em lugares que só o humanoterapeuta consegue, o terapeuta consegue, que é o humanapeuta que quem vai terapeuta, né, não é o assistido.
- É, a minha a minha dúvida é uma um atendimento que eu fiz, né, que eu fiquei e na parte energética já, porque ela assim, ela não trouxe afetos e desafetos, por mais que ela já foi me assistido, eu sabia que tinha ali a parte de desafet mãe, só que ela não me trouxe isso dentro da situação que ela veio, né, falar.
- Mas o processo de tratamento espiritual, que é muito do código ele é sempre cuidado, sempre tem uma equipe espiritual que é a própria dela, né?

### Bloco 4 - frases 241-320
- Então quando eu abro o primeiro comando com a egrégora, com a câmera, uma se com a egrégora é como se tivesse passando na, como é que chama?
- Por isso você sente com ela e ali nesse lugar você vai sentindo quem vai precisar vir primeiro e vai dando como comando de acordo com cada sua tá tá tá perfeito.
- Esse trabalho é a desipnose, porque a hipnose criou a automagia e nós estão e as pessoas estão presas nos comandos que elas deram para si mesmas por ignorância, porque alguma sem saber que aquilo mais do que ajudar e atrapalhar e aprender, tá?

### Bloco 5 - frases 321-400
- Você vai conseguir colocar todos os dados do seu cliente e eu vou conseguir analisar o seu cliente, analisar aquele atendimento que você fez. eu vou conseguir analisar as perguntas que você fez, as respostas que ele deu, onde eu vou conseguir trazer um aspecto, onde você vai colocar ali tudo que aconteceu e eu vou ter como analisar tudo isso e trazer uma resposta extremamente eh apoiada nos dados que você preencheu.
- É um processo de lapidação espiritual e profissional feito para terapeutas que querem atuar com mais confiança e clareza, dominar o método no campo de batalha, ter mais clientes e se profissionalizar e viver do código que carregam em si.
- Essa matriz da consciência, ela vai conseguir identificar na vida do seu cliente quem são os possíveis cobradores, limitadores, exploradores." E ela vai responder algumas perguntas ao tudo automático, tudo digital, que você consegue identificar junto com ela.

### Bloco 6 - frases 401-480
- Então vamos imaginar que eu fosse fazer com ela agora, tá? que ela já é minha cliente, ela veio fazer a segunda sessão, já estaria o cadastro dela aqui, eu ia aplicar uma nova sessão, aí eu ia colocar a data da sessão.
- Então, a gente respeita a privacidade da terapia e aqui tem todos os dados que eu vou conseguir analisar e tem as perguntas que você fez.
- Ela também é uma ferramenta que vai deixar a possibilidade de você não precisar falar tudo de novo, de uma maneira, ah, não lembro meu cliente, hoje eu fiz um atendimento aqui, você deixando autorizado e a gente consegue então falar de um caso real, né, específico, trabalhar específico num caso para você melhorar, para quem um assistindo do outro acaba melhorando muito.

### Bloco 7 - frases 481-560
- Então, resumindo, seis meses de prática, direção e expansão, encontros quinzinis ao vivo comigo, sistema digital integrado, matriz da consciência, estudos de casos reais, e aprofundamento espiritual, crescimento da pessoa, do profissional e do financeiro, certo?
- Então as mesas elas têm os códigos, elas são codificadas e cada contato e e é mais do que um papel, é um campo espiritual.
- Não é sobre um papel, né? é sobre a gente falando de códigos de espiritualidade, de equipe de cura, de integridade, de eh de libertar mentes aprisionadas que estão em dor, em campos ombralinos, porque é isso que o código faz, é desobsessão profunda, é trabalho de de de desfazimento de portais eh de acessos que estão entrando coisas que não deveriam.

### Bloco 8 - frases 561-636
- A partir disso, eu tô trabalhando direto, tô atendendo direto, já apliquei o código, é fantástico, eu tô encantada, então essa dessa vez eu vou de cabeça e tô sonhando com 2007 pr minha aposentadoria que daí eu faço trans carreira de uma vez.
- Então assim, não é, a gente precisa ajudar todo mundo entrar no sistema, para onde que entra, onde é que faz perguntas, né?
- De verdade, eu não paro espiritualmente, a minha cabeça não para, eu recebo informações o tempo inteiro e quem tiver na mentoria, todas as atualizações, os próximos códigos já estão chegando, tudo isso vai sendo disponibilizado para quem seguir com a gente, porque quem segue com a gente nunca nunca perde, nunca se arrepende, porque a M.

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Então, quando eu fiz na aula passada e com a Patrícia, que eu fiz o tratamento dela, teve um momento em que eu tava falando com ela e eu falei sobre o lugar dela, ela estar fora do lugar com o pai, né, tentando assumir um lugar da mãe e a mãe aqui, ela não precisa cuidar do pai.
- Então, quando eu falei inclusive com a Patrícia que ela não estava, quando ela trouxe a questão de eh ela não ela ser terapeuta, então ela queria materializar ser terapeuta, quando na verdade ela não precisa materializar ser terapeuta, porque terapeuta ela já é. o que ela quer materializar é cliente.
- Então, se falta ela ter clientes, está faltando possivelmente a disponibilidade de fazer o que precisa ser feito para captar clientes, porque terapeuta ela já é: "Ah, mas eu não me sinto muito segura, então te falta o quê?
- Então todas essas afirmações, essas questões, elas t a gente precisa ter um pouquinho de cuidado porque a gente faz de maneira despretenciosa, mas isso com o nosso emocional, um comando mental, a gente cria essa massa e essa massa ela vai atrair energia das mesmas frequências, então e vai desencadear um monte de outras coisas.
- Não precisa se forçar, respeita porque eh ela ela entrou em contato com uma consciência dela mesmo que ela quer desfazer, uma sentimento que ela tem, mas ela não quer desfazer, entende?
- Você vai conseguir colocar todos os dados do seu cliente e eu vou conseguir analisar o seu cliente, analisar aquele atendimento que você fez. eu vou conseguir analisar as perguntas que você fez, as respostas que ele deu, onde eu vou conseguir trazer um aspecto, onde você vai colocar ali tudo que aconteceu e eu vou ter como analisar tudo isso e trazer uma…
- Então você vai ter uma base de dados dos seus clientes, você vai acessar e vai colocar todos os dados dele lá e aí você vai fazer a pergunta: "Vou mostrar toda digital, depois você arquiva tudo isso, tem um lugarzinho para você olhar depois os seus clientes, as datas, todas as informações.
- Ela também é uma ferramenta que vai deixar a possibilidade de você não precisar falar tudo de novo, de uma maneira, ah, não lembro meu cliente, hoje eu fiz um atendimento aqui, você deixando autorizado e a gente consegue então falar de um caso real, né, específico, trabalhar específico num caso para você melhorar, para quem um assistindo do outro acaba…
- Então assim, não é, a gente precisa ajudar todo mundo entrar no sistema, para onde que entra, onde é que faz perguntas, né?
- De verdade, eu não paro espiritualmente, a minha cabeça não para, eu recebo informações o tempo inteiro e quem tiver na mentoria, todas as atualizações, os próximos códigos já estão chegando, tudo isso vai sendo disponibilizado para quem seguir com a gente, porque quem segue com a gente nunca nunca perde, nunca se arrepende, porque a M.

## Conceitos-Chave Extraídos

- Mandala da cura, ela é orientação para você usar em todos os momentos, para você ir permeando cada fala com o seu assistido.
- Então, a mandala da cura ela é um instrumento para ajudar você a ter repertório e dando direção durante todo o processo, né?
- Então, eu permei todo o trabalho com as informações que vocês tm na mandala cura e com todas as informações que eh que eu trouxe como conceitos no começo, né?
- Não é só no campo energético, tem um potencial muito maior, porque a gente trabalha em desfazer alguns processos que possam ter uma massa espiritual ali.
- É um processo de lapidação espiritual e profissional feito para terapeutas que querem atuar com mais confiança e clareza, dominar o método no campo de batalha, ter mais clientes e se profissionalizar e viver do código que carregam em si.
- O Mastercência é um movimento de expansão natural do terapeuta depois de acessar o código humanos para afiar o seu machado espiritual. é o lugar onde o terapeuta afia o machado espiritual e atua com mais precisão, consciência e confiança.
- Então é para quem quer ler e atuar diretamente no campo, acessar registros de memória inconsciente, registros acásticos e cármicos, tudo isso vivido e explicado em casos reais na prática.
- Então, acessar esses originários, esses arquétipos, desvendar os códigos primordiais dos povos originários e usar essas forças espirituais para limpar, equilibrar, curar e abrir o campo paraa manifestação dos desejos mais profundos.
- Essa matriz da consciência, ela vai conseguir identificar na vida do seu cliente quem são os possíveis cobradores, limitadores, exploradores." E ela vai responder algumas perguntas ao tudo automático, tudo digital, que você consegue identificar junto com ela.
- Então, resumindo, seis meses de prática, direção e expansão, encontros quinzinis ao vivo comigo, sistema digital integrado, matriz da consciência, estudos de casos reais, e aprofundamento espiritual, crescimento da pessoa, do profissional e do financeiro, certo?
- Então as mesas elas têm os códigos, elas são codificadas e cada contato e e é mais do que um papel, é um campo espiritual.
- Não é sobre um papel, né? é sobre a gente falando de códigos de espiritualidade, de equipe de cura, de integridade, de eh de libertar mentes aprisionadas que estão em dor, em campos ombralinos, porque é isso que o código faz, é desobsessão profunda, é trabalho de de de desfazimento de portais eh de acessos que estão entrando coisas que não deveriam.
- Então para aqueles que fizerem sentido, quiserem estar mais pertinho de mim, efetivamente, eh o Master Sense é a sua oportunidade, não por mim, mas por conta não por mim como pessoa, mas eu não posso negar o quanto de experiência eu tenho tanto no campo espiritual quanto não, o código começou 5 anos, eu venho trabalhando nele.
- Eu tenho experiência de prática e de não só de prática com o cliente, mas de treinamento de quase 15 anos, né? espaço humanidade fez 10, mas eu já atuo nessa área há muito mais tempo, sem falar do campo espiritual, que como diz é a equipe espiritual, eu fui feita no berço.
- Então assim, não é, a gente precisa ajudar todo mundo entrar no sistema, para onde que entra, onde é que faz perguntas, né?
- De verdade, eu não paro espiritualmente, a minha cabeça não para, eu recebo informações o tempo inteiro e quem tiver na mentoria, todas as atualizações, os próximos códigos já estão chegando, tudo isso vai sendo disponibilizado para quem seguir com a gente, porque quem segue com a gente nunca nunca perde, nunca se arrepende, porque a M.


## Técnicas, Procedimentos e Orientações Práticas

- Mandala da cura, ela é orientação para você usar em todos os momentos, para você ir permeando cada fala com o seu assistido.
- Então, quando eu falei inclusive com a Patrícia que ela não estava, quando ela trouxe a questão de eh ela não ela ser terapeuta, então ela queria materializar ser terapeuta, quando na verdade ela não precisa materializar ser terapeuta, porque terapeuta ela já é. o que ela quer materializar é cliente.
- Então, se falta ela ter clientes, está faltando possivelmente a disponibilidade de fazer o que precisa ser feito para captar clientes, porque terapeuta ela já é: "Ah, mas eu não me sinto muito segura, então te falta o quê?
- Então todas essas afirmações, essas questões, elas t a gente precisa ter um pouquinho de cuidado porque a gente faz de maneira despretenciosa, mas isso com o nosso emocional, um comando mental, a gente cria essa massa e essa massa ela vai atrair energia das mesmas frequências, então e vai desencadear um monte de outras coisas.
- H, então, uma vez que só eh temos só tenho a possibilidade de uma pergunta boadinha de hoje, eu vou questionar acerca do atendimento que eu experimentei fazer hoje.
- Você vai conseguir colocar todos os dados do seu cliente e eu vou conseguir analisar o seu cliente, analisar aquele atendimento que você fez. eu vou conseguir analisar as perguntas que você fez, as respostas que ele deu, onde eu vou conseguir trazer um aspecto, onde você vai colocar ali tudo que aconteceu e eu vou ter como analisar tudo isso e trazer uma…
- É um processo de lapidação espiritual e profissional feito para terapeutas que querem atuar com mais confiança e clareza, dominar o método no campo de batalha, ter mais clientes e se profissionalizar e viver do código que carregam em si.
- Então é para quem quer ler e atuar diretamente no campo, acessar registros de memória inconsciente, registros acásticos e cármicos, tudo isso vivido e explicado em casos reais na prática.
- Então você vai ter uma base de dados dos seus clientes, você vai acessar e vai colocar todos os dados dele lá e aí você vai fazer a pergunta: "Vou mostrar toda digital, depois você arquiva tudo isso, tem um lugarzinho para você olhar depois os seus clientes, as datas, todas as informações.
- Essa matriz da consciência, ela vai conseguir identificar na vida do seu cliente quem são os possíveis cobradores, limitadores, exploradores." E ela vai responder algumas perguntas ao tudo automático, tudo digital, que você consegue identificar junto com ela.
- Ela também é uma ferramenta que vai deixar a possibilidade de você não precisar falar tudo de novo, de uma maneira, ah, não lembro meu cliente, hoje eu fiz um atendimento aqui, você deixando autorizado e a gente consegue então falar de um caso real, né, específico, trabalhar específico num caso para você melhorar, para quem um assistindo do outro acaba…
- Então, resumindo, seis meses de prática, direção e expansão, encontros quinzinis ao vivo comigo, sistema digital integrado, matriz da consciência, estudos de casos reais, e aprofundamento espiritual, crescimento da pessoa, do profissional e do financeiro, certo?
- Eu tenho experiência de prática e de não só de prática com o cliente, mas de treinamento de quase 15 anos, né? espaço humanidade fez 10, mas eu já atuo nessa área há muito mais tempo, sem falar do campo espiritual, que como diz é a equipe espiritual, eu fui feita no berço.
- Então assim, não é, a gente precisa ajudar todo mundo entrar no sistema, para onde que entra, onde é que faz perguntas, né?


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- E aí veio a questão do contato com escassez. contato com assim, é porque as pessoas chamam de contrato, mas na verdade toda vez que a gente faz qualquer coisa, qualquer contrato, a gente tá fazendo um processo de automagia.
- Ela começou a ter eh eh a dizer que sentia um peso muito grande na cabeça, a curvar, portanto o corpo dela começou a manifestar e ela só dizia que tinha dor, que sentia a carregar, portanto parecia assim velhinha e começou a manifestar essa essa parte física, mas não via nada, não via ninguém, não entrava em contacto com nenhum outro conteúdo e eu fiquei…
- Se eu tivesse a análise de tudo, eu conseguiria, mas assim, eu tô por possibilidade de tantas coisas que eu já vi que o que o que poderia ser feito, então tá tudo bem, se ela ficou melhor que bom, mas assim, ela ganhou pouca consciência sobre esse processo, então embora tenha melhorado, mas poderia ter eh um um jeito que você poderia ter feito é e o que…
- Porque era só uma, mas você já acabou de responder tava sincronizado, que meu atendimento também foi uma pessoa que tava com muita dor física, né?
- Esse trabalho é a desipnose, porque a hipnose criou a automagia e nós estão e as pessoas estão presas nos comandos que elas deram para si mesmas por ignorância, porque alguma sem saber que aquilo mais do que ajudar e atrapalhar e aprender, tá?
- Então dito isso, porque quem trabalha com comandos mentais no sentido de hipnótico, a não quero falar isso, deixa isso para falar, é são os magos, tá?
- E aí a gente vai fazendo porque conforme a pessoa vai e cada um vai aguentando e de acordo com o nível de de consciência, de de machado afiado também dela em relação ao próprio autoconhecimento.
- Essa matriz da consciência, ela vai conseguir identificar na vida do seu cliente quem são os possíveis cobradores, limitadores, exploradores." E ela vai responder algumas perguntas ao tudo automático, tudo digital, que você consegue identificar junto com ela.
- Quem é que tá sendo o limitador dela, quem é que tá sendo o explorador dela, quem é que tá sendo o cobrador dela? identifica com o nome da pessoa, se é a mãe, se a e ela vai trazer e você tem essa ferramenta para você aplicar com o seu cliente, né?
- Então não sei se dá para enxergar aí, mas raiva, medo, mágoa, então você consegue ter informações sobre o campo emocional dessa pessoa e as relações que ela tem com algumas pessoas, né?
- Ela também é uma ferramenta que vai deixar a possibilidade de você não precisar falar tudo de novo, de uma maneira, ah, não lembro meu cliente, hoje eu fiz um atendimento aqui, você deixando autorizado e a gente consegue então falar de um caso real, né, específico, trabalhar específico num caso para você melhorar, para quem um assistindo do outro acaba…
- Não é sobre um papel, né? é sobre a gente falando de códigos de espiritualidade, de equipe de cura, de integridade, de eh de libertar mentes aprisionadas que estão em dor, em campos ombralinos, porque é isso que o código faz, é desobsessão profunda, é trabalho de de de desfazimento de portais eh de acessos que estão entrando coisas que não deveriam.


## Citações e Formulações de Alta Densidade

- “Então, quando eu fiz na aula passada e com a Patrícia, que eu fiz o tratamento dela, teve um momento em que eu tava falando com ela e eu falei sobre o lugar dela, ela estar fora do lugar com o pai, né, tentando assumir um lugar da mãe e a mãe aqui, ela não precisa cuidar do pai.”
- “Então, quando eu falei inclusive com a Patrícia que ela não estava, quando ela trouxe a questão de eh ela não ela ser terapeuta, então ela queria materializar ser terapeuta, quando na verdade ela não precisa materializar ser terapeuta, porque terapeuta ela já é. o que ela quer materializar é…”
- “Então, se falta ela ter clientes, está faltando possivelmente a disponibilidade de fazer o que precisa ser feito para captar clientes, porque terapeuta ela já é: "Ah, mas eu não me sinto muito segura, então te falta o quê?”
- “Não é só no campo energético, tem um potencial muito maior, porque a gente trabalha em desfazer alguns processos que possam ter uma massa espiritual ali.”
- “Então todas essas afirmações, essas questões, elas t a gente precisa ter um pouquinho de cuidado porque a gente faz de maneira despretenciosa, mas isso com o nosso emocional, um comando mental, a gente cria essa massa e essa massa ela vai atrair energia das mesmas frequências, então e vai…”
- “Não precisa se forçar, respeita porque eh ela ela entrou em contato com uma consciência dela mesmo que ela quer desfazer, uma sentimento que ela tem, mas ela não quer desfazer, entende?”
- “Ela começou a ter eh eh a dizer que sentia um peso muito grande na cabeça, a curvar, portanto o corpo dela começou a manifestar e ela só dizia que tinha dor, que sentia a carregar, portanto parecia assim velhinha e começou a manifestar essa essa parte física, mas não via nada, não via ninguém, não…”
- “Ótimo, porque às vezes ela não consegue ir sozinha em lugares que só o humanoterapeuta consegue, o terapeuta consegue, que é o humanapeuta que quem vai terapeuta, né, não é o assistido.”
- “Ela também é uma ferramenta que vai deixar a possibilidade de você não precisar falar tudo de novo, de uma maneira, ah, não lembro meu cliente, hoje eu fiz um atendimento aqui, você deixando autorizado e a gente consegue então falar de um caso real, né, específico, trabalhar específico num caso…”
- “Não é sobre um papel, né? é sobre a gente falando de códigos de espiritualidade, de equipe de cura, de integridade, de eh de libertar mentes aprisionadas que estão em dor, em campos ombralinos, porque é isso que o código faz, é desobsessão profunda, é trabalho de de de desfazimento de portais eh…”
- “Eu tenho experiência de prática e de não só de prática com o cliente, mas de treinamento de quase 15 anos, né? espaço humanidade fez 10, mas eu já atuo nessa área há muito mais tempo, sem falar do campo espiritual, que como diz é a equipe espiritual, eu fui feita no berço.”
- “Então assim, não é, a gente precisa ajudar todo mundo entrar no sistema, para onde que entra, onde é que faz perguntas, né?”

## Conexões com a Wiki

- [[Conceito do Metodo HumanoSense]]
- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]
- [[Conceito da Camara HumanoSense]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Enquadramento na Piramide]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Tecnica de Retorno a Consciencia e Harmonizacao]]
- [[Conceito do Divorcio Energetico]]
- [[Conceito do Parceiro da Missao]]

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## FAQs para NotebookLM (Fase 2)

### Bloco 1: Ética Clínica, Desipnose e Comandos Ativos
```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
1. Como Andresa Molina conceitua a "Desipnose da Consciência", e de que forma a sugestão ou hipnose clínica viola o livre-arbítrio e o propósito do método?
2. Por que a equipe espiritual necessita do comando mental e direcionamento ativo do operador encarnado para atuar no resgate? (Explique usando a metáfora do pão e da faca).
3. Como o terapeuta deve agir clinicamente e vibracionalmente quando o assistido resiste e se recusa a liberar a dor ou perdoar o algoz (Princípio do Respeito à Resistência)?
4. Quais são as limitações de idade impostas à aplicação do Código Humanosense, e qual o critério para avaliar se um adolescente está pronto para o desdobramento?
5. Quais as consequências energéticas e espirituais de se utilizar pranchas ou mesas falsificadas/piratas (PDFs xerocados) durante o atendimento?
```

### Bloco 2: Troca Fluídica, Somatização e Mediunidade
```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
6. Por que Andresa Molina sustenta que ceder magnetismo físico é inerente e inevitável ao ato terapêutico, e como os limites da biossegurança operam nessa troca?
7. Como a mediunidade reprimida ou a sensibilidade captadora não desenvolvida atua no corpo físico, gerando quadros de fibromialgia ou "dores que andam"?
8. Por que a assepsia e o resgate das captações efetuados pelo terapeuta na Câmara não garantem a cura definitiva das dores do cliente sensitivo "esponja"?
9. Como a lente da "Mandala da Cura" (Lugar/Função/Potência e Habilidade/Disponibilidade/Autorização) permeia os diagnósticos na anamnese e na sessão?
10. Como o terapeuta deve interpretar clinicamente o transe em que o assistido visualiza o resgate e a dor na Câmara, mas termina a cena sem chorar?
```

### Bloco 3: Leis Sistêmicas e Esvaziamento
```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
11. Sob a luz do "Princípio da Ocupação de Lugar", como a retenção energética de um relacionamento passado ou de uma dor impede a materialização de novas realidades?
12. Por que a quebra de um contrato ancestral de pobreza desfaz o voto exclusivamente para o assistido, e como a egrégora lida com o restante da família na miséria?
13. Qual a carga somática e emocional que o assistido precisa tolerar em seu campo pessoal e no trabalho terapêutico após quebrar individualmente um pacto de escassez da linhagem?
14. Como Andresa Molina define o "Divórcio Energético", e de que maneira contratos, casamentos ou alianças geram uma massa eletromagnética de atração?
```

### Bloco 4: Diagnóstico Temporal, Personificação e Matriz
```text
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
15. Como o terapeuta deve decidir qual intensidade energética testar na mesa quando a dor do passado foi imensa, mas a emoção do dia de hoje é outra?
16. Como se conduz o diálogo e a personificação visceral direta da dor somática quando o assistido apresenta espasmos e peso físico na Câmara, mas não visualiza cenários?
17. Descreva o protocolo passo a passo de "Desdobramento Reverso" e assepsia exigido no encerramento antecipado por bloqueio ou recusa de catarse do assistido.
18. Qual o propósito psíquico da ferramenta digital da "Matriz da Consciência" no mapeamento das identidades de Cobrador, Limitador e Explorador?
19. Explique a hierarquia de atuação clínica no Hospital Astral entre as Pombagiras (dores sentimentais) e as equipes e tecnologias especialistas (bombeiros astrais).
```

## Referência

ANDRESA MOLINA. *Aula 10 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.
