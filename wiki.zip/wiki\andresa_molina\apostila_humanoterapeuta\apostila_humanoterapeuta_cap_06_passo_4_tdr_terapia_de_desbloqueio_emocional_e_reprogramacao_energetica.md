---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_06_passo_4_tdr_terapia_de_desbloqueio_emocional_e_reprogramacao_energetica.md]]"]
---

# Cap 006 - Passo 4 Tdr Terapia De Desbloqueio Emocional E Reprogramacao Energetica

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_06_passo_4_tdr_terapia_de_desbloqueio_emocional_e_reprogramacao_energetica.md]]

## Referencia

ANDRESA MOLINA. *Cap 006 - Passo 4 Tdr Terapia De Desbloqueio Emocional E Reprogramacao Energetica*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_06_passo_4_tdr_terapia_de_desbloqueio_emocional_e_reprogramacao_energetica.md]]. Acesso em: 17 jun. 2026.
