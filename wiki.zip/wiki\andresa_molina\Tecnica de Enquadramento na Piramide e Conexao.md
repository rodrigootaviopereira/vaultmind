---
type: tecnica
author: Andresa Molina
tags: [enquadramento, piramide, conexao-astral, selo-mesa, testemunho-vocal]
sources: ["[[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]"]
---

# Prática do Enquadramento em Pirâmide e Conexão (Ancoramento e autorização sonora)

- **Objetivo**: Isolar o campo vibracional do terapeuta e do assistido dentro da geometria protetora de uma pirâmide astral e conectar o DNA do assistido com a egrégora do Espaço Humanidade por meio de sua voz e do selo central da mesa.
- **Pré-requisitos**: Consciência focada do terapeuta.
- **Passo a Passo**:
  1. **Enquadramento em Pirâmide**: No início da sessão, o terapeuta executa 5 estalos de dedos ("pulsos magnéticos") nos cantos espaciais ao redor de si e do assistido para erguer uma pirâmide invisível, verbalizando: *"Tô enquadrando nós dois em uma pirâmide... 1, 2, 3, 4 e 5. Tô isolando essa pirâmide"*.
  2. **Ancoramento Físico**: O terapeuta (ou o próprio assistido, se presencial) posiciona o dedo indicador de sustentação no centro da mesa Humanosense, sobre o selo central do Espaço Humanidade.
  3. **Testemunho Vocal**: O assistido verbaliza o seu nome completo e a sua data de nascimento em voz alta. O registro acústico desses dados físicos atua como o livre-arbítrio e a concessão de acesso exigida pela equipe espiritual.
- **Duração/Frequência**: Executada obrigatoriamente na abertura de todo atendimento.
- **Indicadores de Sucesso**: Estabilização energética do campo da mesa e permissão da egrégora para varredura de memórias.
- **Variações**: Enquadramento presencial (dedo do cliente no selo) vs. online (dedo do terapeuta no selo representando a egrégora do cliente).
- **Conceitos Envolvidos**: [[Principio do Consentimento e Invasao de Campo]], [[Conceito da Mesa HumanoSense]], [[Tecnica de Enquadramento na Piramide]]

## Perguntas Frequentes / Didática de Atendimento

### 14. Qual a relevância mecânica do enquadramento em Pirâmide e da fala em voz alta no momento do ancoramento no selo central da mesa?
**Resposta**: A relevância mecânica do enquadramento é o isolamento do campo energético. O terapeuta usa "pulsos magnéticos" com os dedos para marcar 4 bases e 1 ponta superior, decretando: "Tô enquadrando nós dois em uma pirâmide... Isola essa pirâmide", criando uma sala no campo astral segura para a sessão.

O ancoramento no selo central da mesa (com o dedo) exige que o cliente fale "nome completo e a data de nascimento... em voz alta". A relevância vibracional e somática de usar as cordas vocais é que a pessoa utiliza a própria vibração física para dar consentimento espiritual. A autora explica que isso é obrigatório "porque ele precisa autorizar e colocar magneticamente essa autorização no mundo", gerando que a equipe de luz não está invadindo o livre-arbítrio.

## Referencia

ANDRESA MOLINA. *Prática do Enquadramento em Pirâmide e Conexão*. Aula 07 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]].
