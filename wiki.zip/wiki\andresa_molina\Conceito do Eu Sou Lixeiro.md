---
type: conceito
author: Andresa Molina
tags: [lixo-emocional, salvador, exaustao, sobrecarga, excesso]
sources: ["[[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]"]
---

# Conceito do Eu Sou Lixeiro

- **Definição**: O padrão comportamental e energético (associado ao arquétipo do Salvador) em que o indivíduo acumula e carrega os problemas, dores e tarefas dos outros, confundindo exaustão severa com amor.
- **Justificativa**: O lixeiro não suporta viver sem problemas e, por não lidar com as suas próprias carências, assume as dores alheias, tornando-se uma lixeira emocional e sentindo-se insubstituível enquanto adoece de cansaço.
- **Evidências**: "Eu sou um lixeiro. [...] ele vai lincar lá com um monte de coisa que a gente já falou. [...] ele tem exaustão disfarçada de força, porque ele é o salvador. A salvadora é aquela mãe. Eu faço tudo por todo mundo. Estou exausta. É a lixeira. carrega o problema de todos e se sente insubstituível. [...] Eu sou um lixeiro porque eu não dou conta de viver sem lixo. Então eu não tenho problema, mas eu quero o problema dos outros para mim."
- **Implicações**: O terapeuta deve redistribuir as tarefas sistêmicas do assistido para que ele fique sem nenhum problema alheio, forçando-o a olhar para o seu próprio vazio e essência.
- **Conexões**: [[Conceito de Lixo Emocional]], [[Conceito do Preocupado Emocional]]
- **Notas Pessoais**: O salvador lixeiro esconde um profundo medo de exclusão e desvalor.

## Referencia

ANDRESA MOLINA. *Conceito do Eu Sou Lixeiro*. Aula 03 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]].
