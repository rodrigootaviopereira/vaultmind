---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_138_conceitos_e_definicoes.md]]"]
---

# Cap 138 - Conceitos E Definicoes

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_138_conceitos_e_definicoes.md]]

## Referencia

ANDRESA MOLINA. *Cap 138 - Conceitos E Definicoes*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_138_conceitos_e_definicoes.md]]. Acesso em: 17 jun. 2026.
