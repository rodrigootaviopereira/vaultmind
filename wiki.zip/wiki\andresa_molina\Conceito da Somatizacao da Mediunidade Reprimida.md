---
type: concept
author: Andresa Molina
tags: [mediunidade-reprimida, fibromialgia, somatizacao, dor-migratoria, esponja-energetica]
sources: ["[[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]"]
---

# A Somatização da Mediunidade Reprimida (A biologia como esponja)

- **Definição**: O diagnóstico energético que associa dores físicas intensas, migratórias e sem causa médica aparente (como a Fibromialgia, ataques de pânico e depressões graves) à retenção orgânica de mediunidade não desenvolvida (o fenômeno da "esponja").
- **Justificativa**: A nível somático, um médium não lapilado é um aspirador de pó cósmico ligado no máximo. Ele entra em ambientes e seu sistema nervoso "capta" as dores dos outros e do astral. Se o indivíduo "não desenvolve a sua mediunidade", a energia elétrica da captação densa não tem por onde sair ("descarrego") e se acumula na biologia. A dor "não tá em lugar nenhum, faz exame, não existe nada". O paciente sente o ombro pesar, o terapeuta limpa, e amanhã o paciente acorda com dor nas pernas ("a dor que anda"). O paciente não vai curar essas dores crônicas com remédios físicos; ele precisa de uma estrutura mediúnica de sustentação contínua para drenar a toxina captada.
- **Evidências**: "É o típico, o clássico processo de fibromialgia. É uma dor que tá aqui, outra dor que tá ali, depois ela anda, ela sai de um lugar, ela vai pro outro... Uma pessoa que tem sensibilidade, tem mediunidade, não desenvolve a sua mediunidade, muitos desencadeiam a fibromialgogia, que é a dor que anda... O que que você fez? Você enquadrou o que estava com ela e encaminhou. Só que ela não vai melhorar. Sabe por quê quê? Porque ela vai captar outra. Porque se ela é médium, é isso que ela faz... precisa ter um lugar... de descarrego, principalmente se tem aí um tipo de mediunidade... porque estão captando muita coisa... e não estão se carregando."
- **Implicações**: Auxiliar o paciente com fibromialgia ou dores migratórias a compreender a necessidade de desenvolvimento ou de possuir práticas de descarga periódica de seu canal sensitivo.
- **Conexões**: [[Conceito da Alta Sensibilidade]], [[Conceito da Ampliacao Mediunica Organica]]
- **Notas Pessoais**: Tratar a sensibilidade como doença em vez de musculatura mal gerida sabota o paciente.

## Perguntas Frequentes / Didática de Atendimento

### 7. Como a mediunidade reprimida ou a sensibilidade captadora não desenvolvida atua no corpo físico gerando fibromialgia?
**Resposta**: A mediunidade não desenvolvida atua no corpo físico colapsando o sistema nervoso e muscular devido ao acúmulo de toxinas energéticas absorvidas do ambiente. A autora explica que **"Uma pessoa que tem sensibilidade, tem mediunidade, não desenvolve a sua mediunidade, muitos desencadeiam a fibromialgogia"**.

A nível somático, essa carga que não tem por onde sair ("descarrego") apodrece na matéria e transforma-se em dor: **"ela não tá em lugar nenhum, faz exame, não existe nada, é uma dor meio que muscular e nervos"**. Por ser de origem magnética externa ("porque estão captando muita coisa... e não estão se carregando"), essa dor é somatizada de forma migratória: **"É o típico, o clássico processo de fibromialgia. É uma dor que tá aqui, outra dor que tá ali, depois ela anda, ela sai de um lugar, ela vai pro outro"**.

### 8. Por que a assepsia e o resgate na Câmara não garantem a cura definitiva das dores do cliente sensitivo?
**Resposta**: O terapeuta não garante a cura definitiva porque a estrutura biológica do paciente atua ativamente absorvendo novas cargas o tempo todo. A autora adverte o terapeuta que tirou a dor na sessão: **"O que que você fez? Você enquadrou o que estava com ela e encaminhou. Só que ela não vai melhorar. Sabe por quê quê? Porque ela vai captar outra. Porque se ela é médium, é isso que ela faz"**.

A nível somático, o canal psíquico do cliente está escancarado. Limpar o trauma de hoje não impede o corpo de aspirar a carga do ambiente amanhã: **"ela vai captar sempre, ela vai captar em qualquer lugar que ela for. É seguro."**. Para haver cura permanente, essa pessoa necessita urgentemente de um ancoramento biológico contínuo, um **"lugar de descarrego"** (trabalho mediúnico constante), onde a biologia possa organicamente operar o ciclo de **"solta o que precisa soltar... capta e solta, capta e solta"**.


## Referencia

ANDRESA MOLINA. *A Somatização da Mediunidade Reprimida*. Aula 10 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]].
