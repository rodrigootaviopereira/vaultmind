---
type: conceito
author: Andresa Molina
tags: [lixo-emocional, identidade, doenca, culpa, punicao]
sources: ["[[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]"]
---

# Conceito de Lixo Emocional

- **Definição**: O estado em que a dor se torna a identidade do indivíduo, moldando negativamente sua capacidade de receber e gerando ciclos somatizados de punição, mágoa e autoataque.
- **Justificativa**: Quando a dor é tão profunda que a pessoa a adota como definição de si mesma (identidade de cicatriz), ela sabota a prosperidade e adoece o próprio corpo como forma de autopunição inconsciente.
- **Evidências**: "Carregar o lixo emocional, seja como culpa, mágoa ou excesso de responsabilidade. Ela cria ciclos de punição, cobrança e exaustão. Esse lixo não é só sofrimento, é uma forma de existir construída para tentar controlar, compensar ou sobreviver emocionalmente. [...] O trabalho terapêutico é transformar esse peso em consciência para que a identidade deixe de ser cicatriz e volte a ser essência."
- **Implicações**: Casos de doenças físicas crônicas muitas vezes revelam o lixo emocional atuando como decomposição inconsciente do corpo.
- **Conexões**: [[Principio da Mandala da Dor]]
- **Notas Pessoais**: O lixo emocional impede a pessoa de receber o fluxo de valor do universo.

## Referencia

ANDRESA MOLINA. *Conceito de Lixo Emocional*. Aula 03 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]].
