---
type: principio
author: Andresa Molina
tags: [livre-arbitrio, consentimento, protecao-magnetica, obsessor, invasao]
sources: ["[[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio do Consentimento / Proteção Magnética (A proibição absoluta de invasão de campo)

- **Definição**: A regra magna de segurança astral que proíbe o terapeuta de realizar intervenções energéticas ou diagnósticos na mesa Humanosense para terceiros que não deram consentimento lúcido, sob o risco de rebaixar a própria frequência e atuar como um obsessor espiritual.
- **Justificativa**: A egrégora do Espaço Humanidade e a Câmara funcionam estritamente sob as leis universais do livre-arbítrio. Tentar tratar maridos, filhos ou parentes "por boa intenção" à revelia deles constitui uma invasão dimensional que quebra a proteção magnética do terapeuta. Sem a permissão do dono do campo, o terapeuta se acopla à energia umbralina da pessoa e fica desprotegido. O respeito ao "não" do assistido é o escudo técnico do operador.
- **Evidências**: "A única coisa que não pode de jeito nenhum, absolutamente é fazer em quem não quer. Vou fazer para o meu filho. Vem uma pessoa e fala: 'Vou fazer para minha irmã'... Sem nada que não queira, porque aí eu tô invadindo o campo do outro sem autorização do outro. Eu me tornei obsessor. Eu tô na mesma faixa de frequência. Aí eu tô entregando a minha energia para obsessor. Entendeu? Não é não e ponto. Só isso... O outro não quer, tá tudo bem, a gente respeita. Isso é o que nos protege."
- **Implicações**: O terapeuta deve recusar atendimentos indiretos encomendados por parentes. Toda sessão exige o testemunho vocal direto do assistido autorizando o trabalho.
- **Conexões**: [[Tecnica de Abertura e Conexao]], [[Conceito de Invasao Energetica ou Obsessao]]
- **Notas Pessoais**: Respeitar o livre-arbítrio é o princípio mais básico da cosmoética.

## Perguntas Frequentes / Didática de Atendimento

### 3. Sob a ótica do consentimento, quais são as consequências imediatas para o terapeuta que tenta aplicar a mesa em terceiros sem autorização?
**Resposta**: A autora proíbe essa prática de forma absoluta: "A única coisa que não pode de jeito nenhum, absolutamente é fazer em quem não quer. Vou fazer para o meu filho... Vou fazer para minha irmã".

Se o terapeuta desrespeitar isso e aplicar a técnica, a consequência vibracional imediata é uma invasão cósmica: "eu tô invadindo o campo do outro sem autorização do outro". Espiritualmente, isso corrompe o terapeuta no mesmo instante, pois ele perde a egrégora de luz e se acopla a frequências umbralinas: "Eu tô na mesma faixa de frequência. Aí eu tô entregando a minha energia para obsessor".

### 4. Como Andresa Molina explica que tentar sintonizar e tratar o campo de um familiar transforma o terapeuta em um "obsessor" e destrói sua proteção?
**Resposta**: Andresa explica que tentar curar quem não pediu ajuda é um ato de violação do livre-arbítrio: "Invadir o espaço do outro sem que o outro queira". Ao cometer essa invasão magnética, a pessoa não atua mais como um canal de cura, assumindo literalmente a função de ataque espiritual: "Eu me tornei obsessor".

A quebra da proteção ocorre porque a segurança dimensional da Câmara Humanosense depende do respeito às leis universais. A autora ensina que acolher a negativa do familiar ("O outro não quer, tá tudo bem, a gente respeita") é o verdadeiro mecanismo de defesa do profissional: "Isso é o que nos protege. A técnica nos protege". Quando o terapeuta age pelo orgulho e não respeita o "não", ele rasga essa proteção técnica e se expõe a todas as cargas obsessivas por ter se igualado à frequência de um invasor.

## Referencia

ANDRESA MOLINA. *Princípio do Consentimento / Proteção Magnética*. Aula 07 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]].
