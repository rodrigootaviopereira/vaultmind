---
type: tecnica
author: Andresa Molina
tags: [ficha-cinza, anamnese, diagnostico-elemental, extracao-de-sintese]
sources: ["[[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]"]
---

# Técnica de Preenchimento da Ficha Cinza (A anamnese focada e o diagnóstico elemental)

- **Objetivo**: Extrair de forma precisa a queixa principal e o sentimento raiz (síntese) do assistido, e analisar a harmonia elemental biológica com base no signo do cliente, evitando dispersão teórica.
- **Pré-requisitos**: Estado de presença do terapeuta (nível Alfa).
- **Passo a Passo**:
  1. **Nome Magnético**: Registrar na Ficha Cinza o nome civil com o qual o assistido de fato se identifica, garantindo a sintonia exata na mesa radiestésica.
  2. **Avaliação dos Elementos**: Mapear o signo do assistido para identificar seu elemento principal (Fogo, Terra, Água, Ar) e cruzar com seu estado atual de ânimo (ex: um assistido de Fogo operando em apatia profunda denota um desequilíbrio vital severo).
  3. **Extração da Síntese do Sentimento**: Ouvir o relato longo do cliente sobre seus problemas práticos e filtrá-lo direcionando a pergunta ao sentir: *"Qual o sentimento que você tem em relação a isso? Medo do quê?"*. Anotar a resposta destilada de uma ou duas palavras na caixinha de "Síntese".
- **Duração/Frequência**: Realizada nos primeiros 10 a 15 minutos de atendimento.
- **Indicadores de Sucesso**: Identificação clara de uma queixa primordial e da emoção raiz dominante, e mapeamento do elemento biológico desequilibrado.
- **Variações**: Condução de anamnese rápida em atendimentos de retorno vs. anamnese profunda em primeira consulta.
- **Conceitos Envolvidos**: [[Conceito de Afetos e Desafetos]], [[Principio do Foco Primordial]], [[Conceito da Ficha de Identificacao e Sintese da Dor]]

## Perguntas Frequentes / Didática de Atendimento

### 11. Qual o propósito diagnóstico de avaliar o signo e os elementos naturais na Ficha Cinza, e como a apatia no elemento Fogo indica adoecimento profundo?
**Resposta**: O propósito de avaliar o signo e os elementos (Terra, Água, Fogo e Ar) não é místico, mas biológico e energético, pois eles compõem "o composto físico da pessoa e isso dita muitas coisas". Isso fornece "muita direção" para o terapeuta entender a mecânica orgânica do assistido.

A nível somático, um paciente do elemento Fogo que chega "nervosa, que tá raivosa, até que tá dentro do elemento dela... é natural que ela seja assim brava, irritada". No entanto, se essa mesma pessoa de Fogo se apresenta "muito apática", o terapeuta identifica imediatamente "um desequilíbrio muito profundo". Isso significa que a pessoa está violando a sua força vital e natureza ("apagada, tem alguma coisa muito errada"), reprimindo agressivamente a sua biologia a ponto de adoecer, sendo um estado onde "ela precisa ser apática para continuar vivendo".

### 12. Como o terapeuta deve extrair a "síntese" da queixa durante o preenchimento da ficha em vez de se perder na história contada?
**Resposta**: Durante o preenchimento, o cliente frequentemente despeja a narrativa externa da sua vida (ex: "tô com muito problema com meu chefe" ou "meu relacionamento... tá esfriando"). Para não se perder na situação, o terapeuta deve focar diretamente no registro somático da dor, perguntando: "como é que você se sente com isso? Qual o sentimento que você tem?".

O terapeuta extrai a síntese espremendo essa emoção central "nessa conversa fluida". A autora instrui a buscar impiedosamente a raiz: "Você vai tentar entender a síntese do que ele tá trazendo, né? aquela principal emoção... qual é a angústia dessa pessoa, qual é a dor, qual é o medo". Se o cliente responder apenas "medo", o terapeuta não aceita a resposta superficial e confronta a mente dele exigindo exatidão: "Sim, medo. Medo do quê? Medo todo mundo tem, né? Medo do quê?", até que o real bloqueio interno seja revelado e anotado na ficha ("tenho medo de eu querer trair de novo", "Medo você mandar embora").

## Referencia

ANDRESA MOLINA. *Técnica de Preenchimento da Ficha Cinza*. Aula 07 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]].
