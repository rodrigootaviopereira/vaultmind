---
type: principio
author: Andresa Molina
tags: [ancestralidade, pai, mae, prosperidade, atracao-retencao]
sources: ["[[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]"]
---
# Princípio da Atração e Retenção (A Aceitação da Força dos Pais)

- **Definição**: A regra sistêmica e energética que correlaciona diretamente o sucesso financeiro e afetivo de um indivíduo à sua capacidade de aceitar a força arquetípica de seus pais, onde o Pai governa a atração (o vir) e a Mãe governa a retenção (o ficar).
- **Justificativa**: Conflitos não resolvidos com o pai impedem o fluxo de atração (oportunidades e dinheiro não chegam), enquanto conflitos com a mãe impossibilitam a retenção (o dinheiro vaza e relacionamentos duram pouco).
- **Evidências**: "Tudo o que faz não vir, pai. Ai, vou pena do pai. Tudo o que faz não ficar mãe. Então, se eu tenho problema com pai e mãe, eu não aceito nem a força do pai, nem a força da mãe... E se você tiver problema com os dois... O dinheiro nem vem e nem fica é uma tragédia. Os relacionamentos não acha ninguém... 100% de possibilidade de dar errado."
- **Implicações**: A prosperidade real exige limpar julgamentos de pena ou raiva dirigidos aos pais para que as forças de atração e retenção fluam.
- **Conexões**: [[Conceito da Representacao Paterna]], [[Conceito da Representacao Materna]]
- **Notas Pessoais**: A conta bancária e a estabilidade afetiva espelham diretamente o estado das relações com o pai e a mãe.

## Referencia

ANDRESA MOLINA. *Princípio da Atração e Retenção (A Aceitação da Força dos Pais)*. Aula 02 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]].
