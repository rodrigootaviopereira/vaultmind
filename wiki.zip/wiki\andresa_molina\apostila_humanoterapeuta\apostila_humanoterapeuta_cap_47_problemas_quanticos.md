---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_47_problemas_quanticos.md]]"]
---

# Cap 047 - Problemas Quanticos

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_47_problemas_quanticos.md]]

## Referencia

ANDRESA MOLINA. *Cap 047 - Problemas Quanticos*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_47_problemas_quanticos.md]]. Acesso em: 17 jun. 2026.
