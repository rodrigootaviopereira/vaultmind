---
type: conceito
author: Andresa Molina
tags: [energia-feminina, nutricao, gestacao, paciencia]
sources: ["[[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]"]
---
# Energia Feminina (A Gestação, a Nutrição e a Força de Sustentação)

- **Definição Precisa**: A polaridade arquetípica de criação (presente em todos os seres) que governa o mundo interno, a paciência, a nutrição de ideias e a resiliência para planejar e manter os projetos no tempo.
- **Sinônimos/Variações**: Força Feminina, Carga Feminina, Energia de Contenção, Polaridade Feminina
- **Contexto de Uso**: Sustentação de projetos, relacionamentos e ancoragem emocional.
- **Relação com Princípios**: [[Principio da Fusao Criacional]], [[Principio do Poder do Tres]]
- **Exemplos do Material**: "A energia feminina é a energia que acolhe, que sustenta, que nutre, que transforma. [...] O feminino é o que gesta aquilo que foi semeado, né? É a gestação, não é de gestão, é de gestação... É o que vai dar esse processo de nutrição... Por que que a maioria das pessoas não faz ou não termina as coisas? Porque elas não sustentam."
- **Aplicação Prática**: Sustentar a constância diária em projetos difíceis, superando a impaciência de querer resultados imediatos.
- **Conexões Externas**: [[Conceito de Energia Masculina]]

## Perguntas Frequentes / Didática de Atendimento

**Pergunta 5: Como Andresa descreve o "processo de gestação" (diferenciando de "gestão") associado à energia feminina e por que as pessoas desistem por falta dessa força no sistema?**

Andresa diferencia os termos estabelecendo que a força feminina não se trata de administração lógica: "É a gestação, não é de gestão, é de gestação. Não é de gerência, é de gerar".

A nível somático e energético, a gestação é descrita como um processo visceral e físico de contenção e nutrição. A autora detalha que "gestar é um processo demorado, longo, que precisa de nutrição, que precisa de introspecção, que precisa de espera". O corpo reage a esse peso, pois "ele dá cólicas e ele dá vontade de será que eu vou conseguir? Ele dá medo".
As pessoas desistem (abortam) porque a criação vai ficando "grande, aquilo vai ficando pesado". A falta dessa força feminina no sistema faz com que o indivíduo não suporte o peso do processo: "Se eu tiver muito, eu tenho que sustentar muito e eu não tenho força para sustentar muito... Então eu não vou conseguir... e aí eu faço o quê? Eu aborto todas as minhas ideias".

## Referencia

ANDRESA MOLINA. *Energia Feminina (A Gestação, a Nutrição e a Força de Sustentação)*. Aula 02 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]].
