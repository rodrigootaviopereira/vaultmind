---
type: tecnica
author: Andresa Molina
tags: [autoaplicação, maturidade-terapeutica, risco-clinico]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# Prática de Autoaplicação (O requisito da maturidade terapêutica)

- **Objetivo**: Aplicar os comandos e sintonizações do Humanosense em si mesmo de forma segura, burlar a autodefesa racional e esvaziar/fecundar suas próprias feridas sem a necessidade de um operador externo.
- **Pré-requisitos**: Ampla experiência aplicando o método em terceiros (maturidade clínica).
- **Passo a Passo**:
  1. O terapeuta deve decorar de forma absoluta todos os comandos fixos da folha para não interromper o transe buscando referências escritas de olho aberto.
  2. O operador fecha os olhos e induz em si mesmo a contagem decrescente (Alfa), mergulhando no campo de regressão.
  3. Exige-se a postura madura de adulto para "cutucar" as próprias marcas e forçar o choro e a dor, evitando que a mente crie desvios infantis de alívio analgésico. Em casos de feridas profundas, é recomendado solicitar a aplicação de um colega.
- **Duração/Frequência**: Executada excepcionalmente por terapeutas experientes.
- **Indicadores de Sucesso**: Esvaziamento real de traumas e catarse consciente em si mesmo sem ilusão mental.
- **Variações**: Autoaplicação com foco exclusivo em harmonização radiestésica simplificada.
- **Conceitos Envolvidos**: [[Conceito da Autoaplicacao do HumanoSense]], [[Conceito de Cura-Raiz vs Alivio Analgesico]]

## Perguntas Frequentes / Didática de Atendimento

### 18. Quais as dificuldades mecânicas enfrentadas por iniciantes ao tentar realizar a autoaplicação?
**Resposta**: Mecanicamente, a primeira dificuldade é que o terapeuta "não pode estar de olho aberto para fazer sua auto aplicação. Você tem que estar mergulhado" no transe, o que exige ter decorado todas as falas. A nível emocional e somático, o indivíduo entra em conflito biológico porque "not adianta você fazer lá todo o seu trabalho, todo o processo de desdobramento e não ter coragem de cutucar ferida para ela sangrar". Na autoaplicação, o praticante "vai ter que estar em dois lugares ao mesmo tempo", sustentando a egrégora técnica e forçando o próprio corpo a suportar o choro, o que é muito difícil sem a ancoragem de um operador externo.


## Referencia

ANDRESA MOLINA. *Prática de Autoaplicação*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
