---
type: conceito
author: Andresa Molina
tags: [coordenadas, chamados, cura, 7a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]]"]
---

# A 7ª Coordenada (A Cura Buscada em Todo Lugar)

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: A 7ª Coordenada (A Cura Buscada em Todo Lugar) representa o estado de frustração e exaustão do assistido que busca a cura de suas dores ou a realização de seus desejos em múltiplos tratamentos externos de forma desordenada e exclusivamente racional. A cura não é encontrada porque o indivíduo carece da coordenada somática exata, ou seja, da localização biológica e ancestral das memórias e carimbos emocionais gravados em seu corpo físico.
- **Formulação de apoio**: Andresa explica que, para encontrar o "tesouro" (que representa a cura física, estabilidade financeira, paz ou relacionamentos saudáveis), não basta saber o que se procura, é necessário saber onde procurar. Sem as coordenadas físicas e a leitura das impressões gravadas no corpo (herdadas da ancestralidade ou geradas na infância), o assistido "cava no lugar errado", gerando apenas fadiga, automutilação energética e a sensação de impotência ("sentir-se burro"). A 7ª Coordenada atua como o ponto de convergência que direciona o assistido a parar de buscar analgésicos mentais e a sintonizar a causa raiz que reside em seu inconsciente corporal.

## Sinônimos/Variações

- A Cura Buscada em Todo Lugar, A Coordenada do Tesouro, Marca do X Somática.

## Contexto de Uso

- Aplicado em diagnósticos de assistidos que passaram por múltiplos cursos, terapias ou tratamentos sem resolução efetiva, e que demonstram uma forte resistência em sair da esfera puramente intelectual (racionalidade de 5%).

## Relação com Princípios

- [[Principio do Chamado da Sensibilidade]]
- [[Principio da Memoria Celular vs Lembranca]]
- [[Principio do Consentimento e Invasao de Campo]]
- [[Principio da Memoria Celular Ancestral]]

## Exemplos do Material

- *"Você sabe que existe o tesouro, você sabe que você pode buscar, só que você não faz ideia de onde ele tá... é uma cura buscada em todo lugar, mas não encontrada, porque você precisa de uma coordenada. Alguém precisa te dizer mais ou menos em que país esse essa pessoa fica..."*
- *"Não adianta você cavar no lugar errado, porque você só vai fazer um buraco. Você vai cavar, cavar, cavar, ficar exausta, fica cansada, fica com raiva, fica com medo, fica se sentindo burra e você cava, cava e não tem nada lá. O que a minha proposta é que a gente busque para que a gente possa encontrar o lugar certo, marcar o X..."*

## Aplicação Prática

1. **Localizar o Ponto do X**: Identificar onde a dor ou o desconforto reside somaticamente no corpo (tensão, calor, peso nas costas, aperto no peito) diante do gatilho trazido pelo assistido.
2. **Cessar Busca por Analgésicos**: Esclarecer ao assistido que terapias puramente lógicas ou tratamentos energéticos paliativos atuam apenas como analgésicos para dores agudas, sendo necessário mapear o registro geracional.
3. **Cruzamento de Coordenadas**: Utilizar o Mapa da Alma para traduzir a angústia invisível em termos biológicos/ancestrais, permitindo que a mente do assistido se desarme e autorize o processo de cura profunda.

## Conexões Externas

- [[Conceito do Mapa da Alma]]
- [[Principio do Vazio como Bussola]]
- [[Conceito do Cuidado que Esgota]]

## Referência

ANDRESA MOLINA. *A 7ª Coordenada (A Cura Buscada em Todo Lugar)*. Aula 07 - Coordenada 7 (A Cura Buscada em Todo Lugar). Fontes: [[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. Qual é a analogia que Andresa Molina faz entre procurar uma pessoa sem direção em uma cidade e a busca humana pela cura de suas dores ou desejos sem uma coordenada clara?
**Resposta**: Andresa utiliza a analogia de tentar encontrar alguém em uma cidade sem um endereço. Ela explica que "se você pega e precisa procurar alguém numa cidade, mas você não faz a menor ideia de onde essa pessoa tá, vai ficar muito mais difícil você encontrar. Embora você saiba o que você tá procurando". 

Essa metáfora ilustra o drama sistêmico da "cura buscada em todo lugar". O ser humano sabe perfeitamente qual é o seu objetivo (a "pessoa" que procura) — seja resolver uma dor profunda ou alcançar um desejo —, mas ele fracassa porque não possui a "coordenada". A nível somático, isso significa que a pessoa procura soluções "em todo lugar" (no ambiente externo, em terapias lógicas), quando na verdade a coordenada exata de onde essa cura está escondida fica localizada nos "caminhos dentro da sua, do seu corpo". Sem saber onde acessar essa marca física, a busca torna-se exaustiva e inútil.

### 2. Como a autora define o "tesouro" individual e qual é o papel do "Mapa da Alma" e das coordenadas somáticas em contraste com a mera posse de um mapa sem direcionamento?
**Resposta**: A autora define que "Tudo o que vai se curar em você é o seu tesouro, é o seu bem mais precioso". Esse tesouro pode ser tanto a cura de uma dor (física, emocional, mental ou espiritual) quanto a conquista de um desejo vital (como "mais dinheiro, mais estabilidade... mais paz").

O contraste brutal que Andresa faz é que "não adianta ter um mapa na mão se você não faz ideia de onde esse tesouro está". Apenas possuir o mapa (o conhecimento racional sobre a vida) é insuficiente se você não tiver as "coordenadas". As coordenadas somáticas são as instruções precisas que apontam para as "memórias que ficam gravadas no nosso corpo". Elas indicam "o lugar onde você vai encontrar o seu tesouro" para que você possa "marcar o X" e decidir "cavar". Sem essa bússola corporal, a pessoa vai "cavar no lugar errado", e a nível somático ela só vai se desgastar fisicamente: "Você vai cavar, cavar, cavar, ficar exausta, fica cansada... e não tem nada lá".

### 3. Como Andresa Molina decodifica a máxima "não é sobre fazer sentido, é sobre fazer sentir" como um direcionamento terapêutico clínico para localizar marcas no corpo físico?
**Resposta**: Andresa decodifica essa máxima retirando a validação da cura das mãos da razão ("fazer sentido") e devolvendo-a para o nível somático ("fazer sentir"). Como direcionamento terapêutico clínico, o paciente é instruído a parar de tentar entender logicamente o motivo das suas dores e começar a mapear onde a informação vibra fisicamente ("pega em você em algum lugar").

A autora explica que quando algo é dito e a pessoa "nem sabe porquê, mas emocionalmente aquilo te traz um gatilho", essa reação corporal é a própria coordenada se revelando. A máxima significa que a comprovação do problema não exige uma tese lógica, mas sim uma sensação viva de que a dor habita o corpo: "eu sinto que existe, porque não é sobre fazer sentido, é sobre fazer sentir". É através desse "sentir" desconfortável que o terapeuta e o assistido conseguem localizar as "marcas no corpo" que precisam de cura.

### 4. Como o terapeuta pode usar a "magia da consciência" e o direcionamento sutil da equipe espiritual para conduzir o assistido a um portal de abundância, sem cair no controle mental?
**Resposta**: O terapeuta conduz o paciente não pela imposição lógica, mas induzindo-o a rastrear as marcas somáticas no próprio corpo ("Veja onde isso pega no seu corpo"). Andresa explica que, ao falar, ela gera "uma condução que não tá racionalizada completamente".

Isso jamais cai no controle mental autoritário porque a autora garante que "não é um processo hipnótico, não é uma magia, não é nada escuro, não". Em vez de dominar a psique do indivíduo, o terapeuta ativa a "magia da consciência". A nível somático e espiritual, o facilitador atua apenas como um guia que aponta a bússola; quem efetivamente realiza a transformação celular e vibracional é o próprio ser superior do paciente. A autora define que essa condução "é uma magia divina da sua espiritualidade que te conduz para esse lugar de amor, de abundância, porque a vida é abundante, a vida é alegre".

### 5. Por que o número 7 é caracterizado na aula como um número de extremo poder vibracional e como as 7 coordenadas preparam a base de registros emocionais para a revelação do Mapa da Alma?
**Resposta**: O número 7 é caracterizado como "um número extremamente poderoso" e a autora garante que "ele não tá aqui aleatório". Esse poder deriva de sua profunda correspondência com as leis universais e espirituais, refletindo-se nos "sete dias da semana", nas "sete linhas da direita, sete linhas da esquerda dentro da Umbanda" e na própria anatomia oculta humana, que é composta por "sete corpos".

A nível somático e energético, a preparação acontece porque as 7 coordenadas atuam ativamente para acessar o corpo específico ("um deles") "onde ficam os nossos registros e as nossas memórias emocionais". Ao percorrer todas as 7 coordenadas vibracionais, a base energética da pessoa é forçada a expor essas marcas ocultas. Isso deixa o assistido "pronto para olhar", pois essas direções "dão o ponto exato de onde as coisas estão em você, na sua marca", formando o alicerce fundamental para que o Mapa da Alma completo possa ser revelado e compreendido.

### 6. O que Andresa Molina garante que ocorrerá na jornada do Mapa da Alma em relação à descoberta da raiz dos problemas recorrentes e qual é a decisão que resta ao indivíduo uma vez revelado o seu "X"?
**Resposta**: Andresa garante que o Mapa da Alma destruirá a confusão e a ignorância sobre os motivos das dores sistêmicas. Ela afirma categoricamente: "eu garanto que você vai sair de lá sabendo qual é a questão principal e o que é que você precisa resolver. Qual é o problema, onde está a raiz desse problema?". A imersão promete revelar "exatamente o por é que você não se cura ou por é que as coisas não dão certo na sua vida".

Uma vez que o diagnóstico da "raiz" for exposto e a coordenada do "X" estiver clara na mão da pessoa, o processo terapêutico passa a depender unicamente do livre-arbítrio. A decisão definitiva que resta ao indivíduo, diante da revelação do seu próprio corpo e destino, é o movimento da ação. A autora explica que "se você vai querer cavar e tirar o tesouro ou não, é uma decisão" que a própria pessoa deverá tomar lá, avaliando internamente "se você efetivamente quer resolver isso ou não".




