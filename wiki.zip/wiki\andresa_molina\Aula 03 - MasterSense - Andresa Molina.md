---
type: transcricao
author: Andresa Molina
tags: [andresa_molina, mastersense, aula_03, humanosense, reingestao_2026_06_19]
sources:
  - "[[raw/archive/andresa_molina/transcriptions/03   Mastersense - Andresa Molina.md]]"
---
# Aula 03 - MasterSense - Andresa Molina

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/03   Mastersense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `03   Mastersense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 18.500 palavras; 614 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão do encontro por mapa granular, reforçar conceitos existentes e criar conexões sem duplicar cegamente a wiki.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Organização dos trechos de maior densidade; os itens preservam a formulação da transcrição sempre que possível.

- Possivelmente uma pessoa que ela tem o elemento terra como como base, né, como estrutura de equilíbrio do corpo físico, da manifestação dela, se ela tá muito diferente disso, pode ser que ela esteja negando a sua natureza e por isso ela esteja em desequilíbrio.
- Então ó, o quando você sente que precisa sofrer ou se diminuir para que esse processo ou alguém fique por perto, ela diz conscientemente que é cinco, mas o inconsciente dela diz que tem um alguém que é oito.
- Ela diz que sete pode ser para fora, mas pode ser que ela menta ou a mente pro outro, o que eu não acredito que seja verdade porque ela coloca sete aqui, ela tem consciência, ela acha que ela não que ela se compromete, ela falha de vez em quando, que é só sete, mas ainda assim ela mente possivelmente para si mesma.
- Mas percebe que faz sentido com o que eu falei, se ela não tem vitalidade, porque eu sou um lixo e o lixo é saúde física, vou deteriorar o meu corpo físico, ainda que ela não esteja doente, ela tem baixa energia, ela não tem força para conseguir fazer as coisas.
- Eh, uma descarga de algum hormônio que quando o corpo precisa se autorregular, ele entra em dor, tá?
- Aí eu vou fazer o que aconteceu feliz ano novo ruim vai ser diferente não passa do dia três porque tá cansada mas é tá muito cansada não tem energia e não tá conseguindo e aí esse padrão muito baixo em todos os processos vai abrir a brecha obsessiva só que essa brecha obsessiva tá sendo mantida por essa estrutura sistêmica da psiqui dela nem motivo.
- Então se a gente precisa encontrar e eu como investigador eu vou fazer pergunta, vou fazer pergunta que lá já ficar em contentosa.
- E eu queria ver Andres assim, ver se eu entendi bem essa essa questão que eu achei muito legal, porque eu fiz o atendimento agora do manoterapeuta um antes do outro da gente entrar aqui, que veio muito essa questão da enchaqueta e aí quando você falou da dor de cabeça ali, eu falei, hum, tem alguma coisa ali que agora tá fazendo ainda mais sentido.
- E aí eu sem fal, [ ] merda, no dia de descansar eu fico toda ferrada porque o meu corpo teve tanta descarga de mormônio, de controle, mas com muita descarga de adrenalina, de endorfina, de tudo que precisa disso, de tudo, principalmente de alé, mesmo que não tenha dado nada muito errado, porque eu não tenho medo, então não tenho cortisol, eu tá, poderia ter em…
- Então quando a gente começa a entender a ausência do medo, a confiança a minha dor nas costas, a minha cisol começa a seificar.
- Mas quando eu vou fazer essa análise que a gente tá a fazer agora, eu tenho sempre essa tendência de olhar para para a pessoa da relação da pessoa com ela mesma e bate sempre certo, sempre certo, porque é interno, a dor é interna e a projeção para para o externo é é sobre a dor dela.
- E quando estou a aplicar as perguntas da Mandala e passo para a próxima, também tenho dificuldade porque repete ou não apareceu para preencher no seguinte e volto atrás para confirmar.

## Mapa Granular da Fonte

> Segunda passada aplicada: os blocos abaixo servem como trilha de auditoria para retornar à fonte integral.

### Bloco 1 - frases 1-88
- Eu também consigo perguntar pra pessoa, a gente não precisa expor o assistido, mas eu consigo perguntando como é que foi, como é que aconteceu.
- Possivelmente uma pessoa que ela tem o elemento terra como como base, né, como estrutura de equilíbrio do corpo físico, da manifestação dela, se ela tá muito diferente disso, pode ser que ela esteja negando a sua natureza e por isso ela esteja em desequilíbrio.
- Então ó, o quando você sente que precisa sofrer ou se diminuir para que esse processo ou alguém fique por perto, ela diz conscientemente que é cinco, mas o inconsciente dela diz que tem um alguém que é oito.

### Bloco 2 - frases 89-176
- Ela diz que sete pode ser para fora, mas pode ser que ela menta ou a mente pro outro, o que eu não acredito que seja verdade porque ela coloca sete aqui, ela tem consciência, ela acha que ela não que ela se compromete, ela falha de vez em quando, que é só sete, mas ainda assim ela mente possivelmente para si mesma.
- Mas percebe que faz sentido com o que eu falei, se ela não tem vitalidade, porque eu sou um lixo e o lixo é saúde física, vou deteriorar o meu corpo físico, ainda que ela não esteja doente, ela tem baixa energia, ela não tem força para conseguir fazer as coisas.
- Eh, uma descarga de algum hormônio que quando o corpo precisa se autorregular, ele entra em dor, tá?

### Bloco 3 - frases 177-264
- O que é muito comum, por mais que a coisa, ah, mas a minha mãe sofre por isso, isso eu já resolvi, mas sempre tem, então tem que às vezes acontece, não podemos desconsiderar, pode perguntar.
- Aí eu vou fazer o que aconteceu feliz ano novo ruim vai ser diferente não passa do dia três porque tá cansada mas é tá muito cansada não tem energia e não tá conseguindo e aí esse padrão muito baixo em todos os processos vai abrir a brecha obsessiva só que essa brecha obsessiva tá sendo mantida por essa estrutura sistêmica da psiqui dela nem motivo.
- Mas o que eu quero dizer que não significa tá certo ou errado, significa que alguém que coloca ela num lugar que se limita.

### Bloco 4 - frases 265-352
- Então se a gente precisa encontrar e eu como investigador eu vou fazer pergunta, vou fazer pergunta que lá já ficar em contentosa.
- E eu queria ver Andres assim, ver se eu entendi bem essa essa questão que eu achei muito legal, porque eu fiz o atendimento agora do manoterapeuta um antes do outro da gente entrar aqui, que veio muito essa questão da enchaqueta e aí quando você falou da dor de cabeça ali, eu falei, hum, tem alguma coisa ali que agora tá fazendo ainda mais sentido.
- E aí eu sem fal, [ ] merda, no dia de descansar eu fico toda ferrada porque o meu corpo teve tanta descarga de mormônio, de controle, mas com muita descarga de adrenalina, de endorfina, de tudo que precisa disso, de tudo, principalmente de alé, mesmo que não tenha dado nada muito errado, porque eu não tenho medo, então não tenho cortisol, eu tá, poderia ter em outras porção nessa.

### Bloco 5 - frases 353-440
- Então quando a gente começa a entender a ausência do medo, a confiança a minha dor nas costas, a minha cisol começa a seificar.
- Então, sempre faz. até uma outra questão linda também, eu não sei o que as outras pessoas têm passado, mas eu acho que eu tô encontrando a necessidade de quebrar em duas sessões.
- 6 e se ela tá consciência, mas é uma nota razoamente baixa, mas é consciente inconsciente alinhada de zer a 10, o quanto você tem dificuldade de tomar decisão ou firmar um compromisso, ela diz que seis, mas é 10.

### Bloco 6 - frases 441-528
- Quero que fique bem importante isso aqui que eu falei, porque aqui como a pessoa se sente, aí eu preciso validar com ela se é verdade aí, mas teu marido te cobra, não.
- Mas quando eu vou fazer essa análise que a gente tá a fazer agora, eu tenho sempre essa tendência de olhar para para a pessoa da relação da pessoa com ela mesma e bate sempre certo, sempre certo, porque é interno, a dor é interna e a projeção para para o externo é é sobre a dor dela.
- E quando estou a aplicar as perguntas da Mandala e passo para a próxima, também tenho dificuldade porque repete ou não apareceu para preencher no seguinte e volto atrás para confirmar.

### Bloco 7 - frases 529-614
- Sim, foi foi um ganho de consciência muito grande que ela teve aí, porque ela saiu do lugar do de projetar para o outro para ela olhar para ela nessa nessa situação dessa dor e ver porque que ela tinha perdido.
- Então será que ela, ó, e aí eu não tô olhando com o olhar certo, errado, bom, ruim da terapia de ser a dona da própria vida ou não tô dizendo de um padrão bem espiritual.
- Eh, queria dizer e e pedir para vocês para vocês aplicarem e colocarem lá no sistema, gente, pra gente poder, então vou fazer desse jeito, vou sempre tentar pegar uma de vocês que estão aqui, que daí a gente consegue desenvolvendo a conversa como foi, o que a pessoa falou e claro, posso pegar também do que tem lá, mas tem muito já de parceiros, é, de pessoas que já estão bastante, que já estão usando o sistema como…

## Princípios Extraídos

- Possivelmente uma pessoa que ela tem o elemento terra como como base, né, como estrutura de equilíbrio do corpo físico, da manifestação dela, se ela tá muito diferente disso, pode ser que ela esteja negando a sua natureza e por isso ela esteja em desequilíbrio.
- Então ó, o quando você sente que precisa sofrer ou se diminuir para que esse processo ou alguém fique por perto, ela diz conscientemente que é cinco, mas o inconsciente dela diz que tem um alguém que é oito.
- Ela diz que sete pode ser para fora, mas pode ser que ela menta ou a mente pro outro, o que eu não acredito que seja verdade porque ela coloca sete aqui, ela tem consciência, ela acha que ela não que ela se compromete, ela falha de vez em quando, que é só sete, mas ainda assim ela mente possivelmente para si mesma.
- Mas percebe que faz sentido com o que eu falei, se ela não tem vitalidade, porque eu sou um lixo e o lixo é saúde física, vou deteriorar o meu corpo físico, ainda que ela não esteja doente, ela tem baixa energia, ela não tem força para conseguir fazer as coisas.
- Eh, uma descarga de algum hormônio que quando o corpo precisa se autorregular, ele entra em dor, tá?
- Então se a gente precisa encontrar e eu como investigador eu vou fazer pergunta, vou fazer pergunta que lá já ficar em contentosa.
- E eu queria ver Andres assim, ver se eu entendi bem essa essa questão que eu achei muito legal, porque eu fiz o atendimento agora do manoterapeuta um antes do outro da gente entrar aqui, que veio muito essa questão da enchaqueta e aí quando você falou da dor de cabeça ali, eu falei, hum, tem alguma coisa ali que agora tá fazendo ainda mais sentido.
- E aí quando eu paro de tomar aquele medicamento para de entrar aquela substância, o meu corpo precisa se autorregular.
- E aí eu sem fal, [ ] merda, no dia de descansar eu fico toda ferrada porque o meu corpo teve tanta descarga de mormônio, de controle, mas com muita descarga de adrenalina, de endorfina, de tudo que precisa disso, de tudo, principalmente de alé, mesmo que não tenha dado nada muito errado, porque eu não tenho medo, então não tenho cortisol, eu tá, poderia ter em…
- Mas quando eu vou fazer essa análise que a gente tá a fazer agora, eu tenho sempre essa tendência de olhar para para a pessoa da relação da pessoa com ela mesma e bate sempre certo, sempre certo, porque é interno, a dor é interna e a projeção para para o externo é é sobre a dor dela.


## Conceitos-Chave Extraídos

- Então vou dar só um tempinho para entrar mais pessoas, vou fazer a análise mais básica de um e quero conversar um pouquinho com vocês sobre isso, sobre como é que tá sendo e a aplicação do do código para vocês, tá bom?
- Possivelmente uma pessoa que ela tem o elemento terra como como base, né, como estrutura de equilíbrio do corpo físico, da manifestação dela, se ela tá muito diferente disso, pode ser que ela esteja negando a sua natureza e por isso ela esteja em desequilíbrio.
- Então ela tem força, eh, mas ela precisa reconhecer o quanto você tem energia de dedicação e paciência para construir algo.
- Então ó, o quando você sente que precisa sofrer ou se diminuir para que esse processo ou alguém fique por perto, ela diz conscientemente que é cinco, mas o inconsciente dela diz que tem um alguém que é oito.
- Ela diz que sete pode ser para fora, mas pode ser que ela menta ou a mente pro outro, o que eu não acredito que seja verdade porque ela coloca sete aqui, ela tem consciência, ela acha que ela não que ela se compromete, ela falha de vez em quando, que é só sete, mas ainda assim ela mente possivelmente para si mesma.
- Mas percebe que faz sentido com o que eu falei, se ela não tem vitalidade, porque eu sou um lixo e o lixo é saúde física, vou deteriorar o meu corpo físico, ainda que ela não esteja doente, ela tem baixa energia, ela não tem força para conseguir fazer as coisas.
- Eh, uma descarga de algum hormônio que quando o corpo precisa se autorregular, ele entra em dor, tá?
- Aí eu vou fazer o que aconteceu feliz ano novo ruim vai ser diferente não passa do dia três porque tá cansada mas é tá muito cansada não tem energia e não tá conseguindo e aí esse padrão muito baixo em todos os processos vai abrir a brecha obsessiva só que essa brecha obsessiva tá sendo mantida por essa estrutura sistêmica da psiqui dela nem motivo.
- Mas o que eu quero dizer que não significa tá certo ou errado, significa que alguém que coloca ela num lugar que se limita.
- E eu queria ver Andres assim, ver se eu entendi bem essa essa questão que eu achei muito legal, porque eu fiz o atendimento agora do manoterapeuta um antes do outro da gente entrar aqui, que veio muito essa questão da enchaqueta e aí quando você falou da dor de cabeça ali, eu falei, hum, tem alguma coisa ali que agora tá fazendo ainda mais sentido.
- E aí ela precisa ir limpando isso porque às vezes ela já tem consciência, mas aquela massa falá e isso é um processo de cobrança.
- E aí quando eu paro de tomar aquele medicamento para de entrar aquela substância, o meu corpo precisa se autorregular.
- Então quando a gente começa a entender a ausência do medo, a confiança a minha dor nas costas, a minha cisol começa a seificar.
- Mas quando eu vou fazer essa análise que a gente tá a fazer agora, eu tenho sempre essa tendência de olhar para para a pessoa da relação da pessoa com ela mesma e bate sempre certo, sempre certo, porque é interno, a dor é interna e a projeção para para o externo é é sobre a dor dela.
- E quando estou a aplicar as perguntas da Mandala e passo para a próxima, também tenho dificuldade porque repete ou não apareceu para preencher no seguinte e volto atrás para confirmar.
- Eh, queria dizer e e pedir para vocês para vocês aplicarem e colocarem lá no sistema, gente, pra gente poder, então vou fazer desse jeito, vou sempre tentar pegar uma de vocês que estão aqui, que daí a gente consegue desenvolvendo a conversa como foi, o que a pessoa falou e claro, posso pegar também do que tem lá, mas tem muito já de parceiros, é, de pessoas que já…


## Técnicas, Procedimentos e Orientações Práticas

- Eu também consigo perguntar pra pessoa, a gente não precisa expor o assistido, mas eu consigo perguntando como é que foi, como é que aconteceu.
- Então vou dar só um tempinho para entrar mais pessoas, vou fazer a análise mais básica de um e quero conversar um pouquinho com vocês sobre isso, sobre como é que tá sendo e a aplicação do do código para vocês, tá bom?
- Então alguém que explora pela dor, nós vamos tentar olhar porque vai ter matriz, então acho que eu vou conseguir identificar pela matriz aqui.
- Você fica perguntando uma conversa normal que a gente faz com pouca pessoa quando a gente acabou de conhecer, já tentando entender quem é essa pessoa que tá na nossa mente, você ainda não tratamento, ainda um amigo novo, né?
- O que é muito comum, por mais que a coisa, ah, mas a minha mãe sofre por isso, isso eu já resolvi, mas sempre tem, então tem que às vezes acontece, não podemos desconsiderar, pode perguntar.
- Então se a gente precisa encontrar e eu como investigador eu vou fazer pergunta, vou fazer pergunta que lá já ficar em contentosa.
- Porque esse lugar interessado e amigável é como se a gente tivesse conhecendo um amigo pela primeira vez, uma amiga e a gente começou a se perguntar pra pessoa: "Oi, tudo bem?
- Não se misturar na história, conseguir isolar isso para poder ser uma ferramenta melhor, mas o real interesse ele vão ser essas sutilezas e a gente vai perguntando, validando como investigador da polícia encontrando o o bandido mal que na verdade é medida múa, enfim, um vazio, o que quer que seja.
- E eu queria ver Andres assim, ver se eu entendi bem essa essa questão que eu achei muito legal, porque eu fiz o atendimento agora do manoterapeuta um antes do outro da gente entrar aqui, que veio muito essa questão da enchaqueta e aí quando você falou da dor de cabeça ali, eu falei, hum, tem alguma coisa ali que agora tá fazendo ainda mais sentido.
- Eu vou repetir essas perguntas que de certa forma tá fresca no cabelo, como seria a parte prática para várias questões.
- 6 e se ela tá consciência, mas é uma nota razoamente baixa, mas é consciente inconsciente alinhada de zer a 10, o quanto você tem dificuldade de tomar decisão ou firmar um compromisso, ela diz que seis, mas é 10.
- E quando estou a aplicar as perguntas da Mandala e passo para a próxima, também tenho dificuldade porque repete ou não apareceu para preencher no seguinte e volto atrás para confirmar.
- Depois trabalhamos mais um bocado essa trazer essa consciência que ela tem valor, que por conta de tudo o que ela passou, ela tem essa sensação, essa perspectiva e que ela dei vários exemplos que ela me falou também, aproveitei e ela que ela estava h a querer pagar ao marido em trabalho, em servir em casa, eh, e para compensar isso e trouxe essa consciência toda e…
- Eh, queria dizer e e pedir para vocês para vocês aplicarem e colocarem lá no sistema, gente, pra gente poder, então vou fazer desse jeito, vou sempre tentar pegar uma de vocês que estão aqui, que daí a gente consegue desenvolvendo a conversa como foi, o que a pessoa falou e claro, posso pegar também do que tem lá, mas tem muito já de parceiros, é, de pessoas que já…


## Padrões Mentais e Dinâmicas Recorrentes

- Então não consegue se autovalorizar porque se cobre por do passado, naturalmente vai refletir isso que eh em relação ao ao valor financeiro dela, tá?
- Então ó, o quando você sente que precisa sofrer ou se diminuir para que esse processo ou alguém fique por perto, ela diz conscientemente que é cinco, mas o inconsciente dela diz que tem um alguém que é oito.
- Então alguém que explora pela dor, nós vamos tentar olhar porque vai ter matriz, então acho que eu vou conseguir identificar pela matriz aqui.
- Eh, uma descarga de algum hormônio que quando o corpo precisa se autorregular, ele entra em dor, tá?
- Aí eu vou fazer o que aconteceu feliz ano novo ruim vai ser diferente não passa do dia três porque tá cansada mas é tá muito cansada não tem energia e não tá conseguindo e aí esse padrão muito baixo em todos os processos vai abrir a brecha obsessiva só que essa brecha obsessiva tá sendo mantida por essa estrutura sistêmica da psiqui dela nem motivo.
- Então se a gente precisa encontrar e eu como investigador eu vou fazer pergunta, vou fazer pergunta que lá já ficar em contentosa.
- E eu queria ver Andres assim, ver se eu entendi bem essa essa questão que eu achei muito legal, porque eu fiz o atendimento agora do manoterapeuta um antes do outro da gente entrar aqui, que veio muito essa questão da enchaqueta e aí quando você falou da dor de cabeça ali, eu falei, hum, tem alguma coisa ali que agora tá fazendo ainda mais sentido.
- E aí quando eu paro de tomar aquele medicamento para de entrar aquela substância, o meu corpo precisa se autorregular.
- E aí eu sem fal, [ ] merda, no dia de descansar eu fico toda ferrada porque o meu corpo teve tanta descarga de mormônio, de controle, mas com muita descarga de adrenalina, de endorfina, de tudo que precisa disso, de tudo, principalmente de alé, mesmo que não tenha dado nada muito errado, porque eu não tenho medo, então não tenho cortisol, eu tá, poderia ter em…
- Então quando a gente começa a entender a ausência do medo, a confiança a minha dor nas costas, a minha cisol começa a seificar.
- Mas quando eu vou fazer essa análise que a gente tá a fazer agora, eu tenho sempre essa tendência de olhar para para a pessoa da relação da pessoa com ela mesma e bate sempre certo, sempre certo, porque é interno, a dor é interna e a projeção para para o externo é é sobre a dor dela.
- E quando estou a aplicar as perguntas da Mandala e passo para a próxima, também tenho dificuldade porque repete ou não apareceu para preencher no seguinte e volto atrás para confirmar.


## Citações e Formulações de Alta Densidade

- “Eu também consigo perguntar pra pessoa, a gente não precisa expor o assistido, mas eu consigo perguntando como é que foi, como é que aconteceu.”
- “Então ela tem força, eh, mas ela precisa reconhecer o quanto você tem energia de dedicação e paciência para construir algo.”
- “Então ó, o quando você sente que precisa sofrer ou se diminuir para que esse processo ou alguém fique por perto, ela diz conscientemente que é cinco, mas o inconsciente dela diz que tem um alguém que é oito.”
- “Ela diz que sete pode ser para fora, mas pode ser que ela menta ou a mente pro outro, o que eu não acredito que seja verdade porque ela coloca sete aqui, ela tem consciência, ela acha que ela não que ela se compromete, ela falha de vez em quando, que é só sete, mas ainda assim ela mente…”
- “Eh, uma descarga de algum hormônio que quando o corpo precisa se autorregular, ele entra em dor, tá?”
- “Então se a gente precisa encontrar e eu como investigador eu vou fazer pergunta, vou fazer pergunta que lá já ficar em contentosa.”
- “E eu queria ver Andres assim, ver se eu entendi bem essa essa questão que eu achei muito legal, porque eu fiz o atendimento agora do manoterapeuta um antes do outro da gente entrar aqui, que veio muito essa questão da enchaqueta e aí quando você falou da dor de cabeça ali, eu falei, hum, tem…”
- “E aí quando eu paro de tomar aquele medicamento para de entrar aquela substância, o meu corpo precisa se autorregular.”
- “E aí eu sem fal, [ ] merda, no dia de descansar eu fico toda ferrada porque o meu corpo teve tanta descarga de mormônio, de controle, mas com muita descarga de adrenalina, de endorfina, de tudo que precisa disso, de tudo, principalmente de alé, mesmo que não tenha dado nada muito errado, porque eu…”
- “Então quando a gente começa a entender a ausência do medo, a confiança a minha dor nas costas, a minha cisol começa a seificar.”
- “Mas quando eu vou fazer essa análise que a gente tá a fazer agora, eu tenho sempre essa tendência de olhar para para a pessoa da relação da pessoa com ela mesma e bate sempre certo, sempre certo, porque é interno, a dor é interna e a projeção para para o externo é é sobre a dor dela.”
- “E quando estou a aplicar as perguntas da Mandala e passo para a próxima, também tenho dificuldade porque repete ou não apareceu para preencher no seguinte e volto atrás para confirmar.”

## Conexões com a Wiki

- [[Conceito do Metodo HumanoSense]]
- [[Conceito da Ficha de Identificacao e Sintese da Dor]]
- [[Conceito de Personagens da Dor]]
- [[Arquitetura do HumanoSense]]

## Segunda Passada

Na segunda leitura, esta fonte foi comparada com as notas já existentes da wiki. A nota foi fortalecida como dossiê de rastreabilidade, com extração granular e links para os conceitos centrais já presentes. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## Referência

ANDRESA MOLINA. *Aula 03 - MasterSense - Andresa Molina*. Transcrição integral. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/03   Mastersense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.
