---
type: conceito
author: Andresa Molina
tags: [sombra, ectoplasma, obsessao, autossabotagem]
sources: ["[[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]]"]
---
# A Sombra Ectoplasmática (Autoobsessão Materializada)

- **Definição Precisa**: A materialização no campo astral de pensamentos e traumas recorrentes alimentados com a energia vital (ectoplasma) do próprio indivíduo.
- **Sinônimos/Variações**: Automagia, Formas-Pensamento Autoobsessivas, Alminhas Criadas, Sombras
- **Contexto de Uso**: Tratamento de autossabotagem severa, estagnação energética e processos obsessivos.
- **Relação com Princípios**: [[Principio da Semeadura e Karma]]
- **Exemplos do Material**: "a sombra não é só uma ideia, porque eu dou massa para ela quando quando eu ceder o meu ectoplasma, a minha energia vital. Quando eu dou a minha energia vital, eu materializo ela no campo astral. Então aquela sombra ela existe. Ela é uma alminha criada por mim, alimentada por mim, que causa o meu processo autoobsessivo e também pode se tornar o obsessor do outro. [...] eu sou o mago delas, né? Sou eu que sou criador delas... dessa magia..."
- **Aplicação Prática**: Uso de comandos e atuação de equipes da mesa HumanoSense para desatar e desobsessar essas alminhas densas que a simples lógica mental não consegue desmanchar.
- **Conexões Externas**: [[Conceito da Mesa HumanoSense]], [[Tecnica de Depuracao e Desobsessao de Fractais]]

## Perguntas Frequentes / Didática de Atendimento

### Como o ectoplasma humano alimenta o que a autora chama de "alminhas" ou "fractais de dor", gerando a dinâmica de autoobsessão comumente rotulada de autossabotagem?

A autora revela que os traumas e as sombras não são apenas lembranças na cabeça, mas ganham massa real porque o indivíduo drena a sua própria vitalidade biológica para nutri-los. Ela explica o processo físico-energético: **"eu dou massa para ela quando quando eu cedo o meu ectoplasma, a minha energia vital. Quando eu dou a minha energia vital, eu materializo ela no campo astral"**.

A nível somático, a pessoa sangra a sua força vital diária para sustentar o pensamento doloroso, transformando-o em uma entidade densa. A autora decreta que **"Ela é uma alminha criada por mim, alimentada por mim, que causa o meu processo autoobsessivo"**. A psicologia moderna chama essa paralisação de autossabotagem, mas a nível espiritual é uma possessão criada pelo próprio corpo, onde essa massa ectoplasmática consome a potência do indivíduo de tal forma que se torna **"o próprio processo obsessivo seu"**.

### Por que o trabalho tecnológico, energético e consciencial do Código HumanoSense é necessário para dissolver a "magia" que o próprio assistido fez em si mesmo e que amarra o outro?

O trabalho tecnológico e profundo é necessário porque a simples compreensão intelectual do problema (ressignificar) não destrói a massa energética que foi criada. A autora alerta que a pessoa é a causadora da própria trava: **"eu sou o mago delas, né? Sou eu que sou criador delas... dessa magia que você mesmo fez em você e tá amarrando o outro"**.

A nível somático and vibracional, como a pessoa doou ectoplasma durante anos para cristalizar essa dor (a magia), a **"sombra"** virou uma matéria no campo astral. Portanto, é obrigatório o uso de **"trabalho espiritual, energético, consciencial, profundo e tecnológico"** para extrair essa densidade, pois apenas mudar a forma de pensar **"não muda nada, porque a ideia continua lá, a minha [alminha] continua lá e o processo autoobsessivo continua lá"**. A técnica atua cirurgicamente para dissolver e limpar essa fração de dor impregnada no corpo vibracional do assistido.


## Referencia

ANDRESA MOLINA. *A Sombra Ectoplasmática (Autoobsessão Materializada)*. Aula 01 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]].
