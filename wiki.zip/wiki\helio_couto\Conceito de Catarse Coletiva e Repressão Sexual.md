---
type: conceito
author: Hélio Couto
tags: [sexo, reich, repressão, catarse]
sources: ["[[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_03_introdução.txt]]"]
---

# Conceito de Catarse Coletiva e Repressão Sexual

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_03_introdução.txt]]

## Referencia

HÉLIO COUTO. *Conceito de Catarse Coletiva e Repressão Sexual*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/mentes_in_formadas_e_book_hélio_couto/mentes_in_formadas_e_book_hélio_couto_cap_03_introdução.txt]]. Acesso em: 17 jun. 2026.
