---
type: technique
author: Andresa Molina
tags: [diagnostico-temporal, emocao-presente, dor-atual, radiestesia]
sources: ["[[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]"]
---

# Prática de Diagnóstico da Emoção Presente (A regra de testagem temporal)

- **Definição**: A diretriz de calibragem da mesa radiestésica que obriga o terapeuta a medir rigorosamente a emoção que reverbera no corpo do paciente "no dia de hoje", descartando angústias colossais (como raiva ou ódio) que a pessoa sentiu no passado, mas que já não habitam a biologia atual.
- **Como praticar e seu Propósito**:
  1. **Entrevista de Diferenciação**: Se a cliente relata ter tido ódio da mãe doente no passado (nota 10), mas hoje sente apenas dó e pena (nota 8), o terapeuta não usa o trauma antigo como âncora.
  2. **Calibragem Temporal**: O terapeuta anota a emoção do agora na Ficha: "eu trabalhar com a energia que tem hoje, que seria o oito da pena... Porque é o que tá na frente agora".
  O propósito biológico e radiestésico é evitar que o pêndulo e a mesa operem em frequências fantasmas e fictícias que já não geram estagnação ativa na biologia atual da pessoa.
- **Evidências**: "Ela diz para ela na percepção dela, ela agora tem dó porque a mãe tá totalmente... e ela falou para mim que a raiva era 10, né? E e que a dó era os oito. Aí a minha pergunta é quantos dois que eu levo em consideração? ...Que ela ela teve raiva e hoje ela tem dó. Isso ou hoje ela tem raiva e dó? ...Então eu entendo que como isso ela tem hoje e hoje é pena, eu trabalharia com a energia de hoje porque ela ainda tem... qual é a energia que você tem hoje? Então, nesse caso específico, eu trabalhar com a energia que tem hoje, que seria o oito da pena... Porque é o que tá na frente agora, né?"
- **Conexões**: [[Tecnica de Preenchimento da Ficha Cinza]], [[Tecnica de Rastreio Quantitativo de 0 a 10]]

## Perguntas Frequentes / Didática de Atendimento

### 15. Como o terapeuta deve decidir qual intensidade energética testar na mesa quando a dor do passado foi imensa, mas a emoção do dia de hoje é outra?
**Resposta**: O terapeuta deve focar unicamente na emoção que habita o paciente no momento presente. A autora ilustra isso com o caso de uma paciente que sentiu "raiva 10" da mãe no passado, mas que atualmente, com a mãe doente, sente "dó oito" (pena).

A nível somático e vibracional, o corpo não está doente pela carga extinta do passado, mas pela estagnação da vibração atual. A autora define a decisão clínica: **"eu trabalharia com a energia de hoje porque ela ainda tem... qual é a energia que você tem hoje? Então, nesse caso específico, eu trabalhar com a energia que tem hoje, que seria o oito da pena"**. O terapeuta foca no "oito da pena" estritamente **"Porque é o que tá na frente agora, né?"**.


## Referencia

ANDRESA MOLINA. *Técnica de Diagnóstico da Emoção Presente*. Aula 10 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]].
