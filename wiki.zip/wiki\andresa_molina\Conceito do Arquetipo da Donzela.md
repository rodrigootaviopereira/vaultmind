---
type: conceito
author: Andresa Molina
tags: [donzela, ilusao, sonho, conto-de-fadas]
sources: ["[[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]"]
---
# O Arquétipo da Donzela/Príncipe (O Sonho, a Fuga e a Ilusão)

- **Definição Precisa**: A faceta sonhadora e receptiva (polaridade feminina) do protagonismo, que abriga a leveza e a esperança, mas que desequilibra em fugas iludidas e procrastinação quando descolada do guerreiro.
- **Sinônimos/Variações**: Donzela, Príncipe, Feminino Infantilizado, O Sonhador
- **Contexto de Uso**: Identificação de dependências emocionais, ilusões românticas e vitimização.
- **Relação com Princípios**: [[Principio do Poder do Tres]]
- **Exemplos do Material**: "E quem é donzela do príncipe? um sonhador, só que ele é iludido... sonho que o príncipe que me feriu é o príncipe que vai me salvar... A ilusão é o conto de fadas do feminino. Não é criança, é feminino infantilizado, que não cresceu, que não quer encarar a vida como ela é. Não foge pro mundo da ilusão... Iludido de que o outro vai mudar, iludido de que você vai salvar o mundo."
- **Aplicação Prática**: Confrontar a passividade da donzela que espera salvação externa (ex: agressor se curar sozinho), ensinando-a a integrar a força do guerreiro.
- **Conexões Externas**: [[Conceito do Arquetipo do Guerreiro]]

## Perguntas Frequentes / Didática de Atendimento

**Pergunta 18: Como Andresa define o "Arquétipo da Donzela" e qual o mecanismo de "fuga para o conto de fadas" que gera procrastinação e dependência de um parceiro agressor?**

Andresa define a Donzela/Príncipe não como uma energia ruim, mas que em desequilíbrio se torna "um sonhador, só que ele é iludido". É caracterizado como "um feminino infantilizado, que não cresceu, que não quer encarar a vida como ela é".

A nível somático e psicológico, o mecanismo de fuga acontece quando o indivíduo "foge pro mundo da ilusão" para não suportar a dor da realidade. A dependência do agressor nasce desse delírio: a pessoa sustenta o "sonho que o príncipe que me feriu é o príncipe que vai me salvar". Por viver na ilusão e se recusar a pegar a espada do Guerreiro para se defender, o assistido "paralisa e procrastina no presente", preferindo sonhar com resgates mágicos ou esperar que o parceiro tóxico mude, em vez de enfrentar os embates da vida.

## Referencia

ANDRESA MOLINA. *O Arquétipo da Donzela/Príncipe (O Sonho, a Fuga e a Ilusão)*. Aula 02 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]].
