---
type: principio
author: Andresa Molina
tags: [criacao, fusao, masculino, feminino, poder-do-tres]
sources: ["[[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]]"]
---
# Princípio do Poder do Três (A Fusão Criacional do Masculino e Feminino)

- **Definição**: A lei existencial em que nenhuma criação ou materialização pode ocorrer na física tridimensional sem a fusão harmoniosa das forças masculina (impulso) e feminina (sustentação).
- **Justificativa**: Evita o aborto de ideias, metas e projetos de vida que ocorrem quando uma das polaridades energéticas está magiada ou em desequilíbrio interno.
- **Evidências**: "Tudo que existe passa pelo poder do três. O que é o poder do três? masculino, feminino e fusão. Se uma dessas duas forças, masculina e feminina não não estiver em equilíbrio, a fusão será comprometida e a materialização será bloqueada ou desequilibrada... Somente na união dos dois sagrados pode nascer o terceiro..."
- **Implicações**: O equilíbrio interno das forças masculina e feminina é pré-requisito para fecundar desejos que se consolidam no tempo.
- **Conexões**: [[Conceito da Polaridade Masculino e Feminino]], [[Tecnica de Depuracao e Desobsessao de Fractais]]
- **Notas Pessoais**: O 'Pai, Mãe e Filho' espiritual representa a trindade de toda materialização física bem-sucedida.

## Perguntas Frequentes / Didática de Atendimento

### O que são os "pequenos abortos" mencionados por Andresa Molina no contexto de projetos e objetivos iniciados e não sustentados, e como eles afetam a fertilidade do "solo"?

Os "pequenos abortos" representam todos os projetos, ideias e desejos que a pessoa iniciou com o impulso do masculino, mas que o feminino não teve paciência e força para nutrir até o fim. A autora define de forma literal: **"Todas as coisas que você falou que ia fazer, não fez, não sustentou, foram pequenos abortos"**. 

A nível somático e energético, a falência em gestar uma meta não desaparece no ar; ela deixa um resíduo de morte no campo vibracional do indivíduo. Andresa explica que acumular esses projetos mortos **"faz com que o solo não seja mais fértil"**. O corpo e o útero energético (o "solo sagrado") ficam sobrecarregados e intoxicados com esses fracassos inacabados, impedindo que qualquer nova semente vingue até que a pessoa passe pela **"limpeza de todos esses pequenos abortos"** na fase de depuração da técnica.

### Como o restabelecimento da harmonia entre o sentir feminino e o fazer masculino permite a fecundação responsável de novos desejos e criações?

A fecundação responsável ocorre quando o impulso cego da ação se alinha perfeitamente com a sabedoria da sustentação, unindo-se no **"tesão das duas forças aceitas como são"**.

A nível somático e energético, a cocriação na Fase 3 do método só avança após a limpeza das dores, **"facilitando a fusão entre o masculino e o feminino"**. A autora garante que **"Somente na fusão equilibrada entre a carga do masculino e a carga do feminino é que pode nascer, manifestar, materializar qualquer coisa"**. Sem o lixo emocional do passado, essa criação torna-se incrivelmente responsável porque o corpo e a mente do indivíduo estão integrados. Ele para de atirar para todos os lados e **"vai fazer aquilo que ela entende que ela vai dar conta de sustentar depois"**, garantindo que a semente plantada não vire um novo "aborto", mas tenha a força masculina para iniciar e o útero feminino para nutrir até nascer.


## Referencia

ANDRESA MOLINA. *Princípio do Poder do Três (A Fusão Criacional do Masculino e Feminino)*. Aula 01 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]].
