---
type: tecnica
author: Andresa Molina
tags: [avaliacao-estado, pausa-clinica, tempo-terapeutico, limite-somativo]
sources: ["[[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]"]
---

# A Técnica de Avaliação de Estado (O respeito ao limite de choque do paciente)

- **Objetivo**: Avaliar a fadiga mental e biológica do assistido no intervalo entre a fase diagnóstica (rastreio e choque de realidade com o gap) e a fase de desdobramento, definindo se o paciente possui estrutura energética para o transe no mesmo dia.
- **Pré-requisitos**: Conclusão da fase de perguntas na mesa de mandalas (Bloco Verde).
- **Passo a Passo**:
  1. **Pausa Clínica**: Após revelar a dissonância das notas conscientes/inconscientes (que frequentemente gera colapso das defesas e choro de desilusão racional), o terapeuta faz uma pausa investigativa silenciosa.
  2. **Análise Somática**: Observar a postura corporal, respiração e nível de agitação ou cansaço do assistido.
  3. **Decisão de Suspensão**: Se o assistido demonstrar exaustão severa ou resistência verbal em aprofundar, o terapeuta cancela o desdobramento e pula direto para a harmonização e encerramento, remarcando a regressão para a semana seguinte.
- **Duração/Frequência**: Executada no meio de cada atendimento terapêutico do Humanosense.
- **Indicadores de Sucesso**: Prevenção de regressões falsas causadas pela exaustão mental e proteção do campo energético contra descompensações.
- **Variações**: Condução de reavaliação de estado em atendimentos de emergência vs. sessões normais de tratamento.
- **Conceitos Envolvidos**: [[Conceito do Gap Vibracional]], [[Principio da Desilusao]], [[Tecnica de Retorno a Consciencia e Harmonizacao]]

## Perguntas Frequentes / Didática de Atendimento

### 18. Como é aplicada a "Avaliação de Estado" e em quais circunstâncias o terapeuta deve suspender a viagem astral e optar apenas pela harmonização?
**Resposta**: A avaliação é feita após a bateria de perguntas, observando a biologia e a psique da pessoa: "Observe o campo emocional. O assistido tá cansado, agitado, sensível demais por conta dessa conversa?".

A sessão deve ser suspensa ("encerre a sessão") se o choque de realidade causar um colapso na pessoa. A autora explica que "Às vezes a pessoa descobre que ela é uma mentira sem fim, ela fica mal e ela não quer continuar". O terapeuta, visando proteger o sistema nervoso do paciente de uma sobrecarga, decide não desdobrá-lo para o sangramento e aplica o pêndulo na mesa apenas para "harmonizar, vamos voltando para cá... vou te harmonizar para você ir se acalmando e fica bem".

## Referencia

ANDRESA MOLINA. *A Técnica de Avaliação de Estado*. Aula 07 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]].
