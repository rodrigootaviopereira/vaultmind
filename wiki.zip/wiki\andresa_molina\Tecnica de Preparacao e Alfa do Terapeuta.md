---
type: tecnica
author: Andresa Molina
tags: [preparacao, alfa, ambiente, concentracao-terapeutica]
sources: ["[[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]"]
---

# Prática de Preparação e Alfa do Terapeuta (A organização do campo antes da sessão)

- **Objetivo**: Conduzir o terapeuta ao estado mental e vibracional de neutralidade e foco absoluto (rebaixando a frequência cerebral para a onda Alfa), organizando a matéria física de trabalho antes da entrada do assistido no espaço terapêutico.
- **Pré-requisitos**: Isolamento de perturbações externas e silêncio.
- **Passo a Passo**:
  1. **Organização Física**: Disponibilizar e organizar todos os materiais de trabalho no consultório ou mesa de atendimento (pêndulo, fichas, bloco de comandos verde e azul, mesa).
  2. **Isolamento de Rituais**: O terapeuta executa qualquer ritual pessoal de purificação de forma individual e privada (incensos, banhos de ervas, acender velas) na sua própria casa ou antes do cliente chegar. O ambiente de atendimento clínico deve ser esteticamente neutro.
  3. **Conexão em Alfa**: O terapeuta fecha os olhos, respira profundamente e induz o rebaixamento de sua própria onda cerebral para o estado "Alfa" (podendo utilizar o áudio guia), conectando-se espiritualmente com a egrégora de amparo do método Humanosense.
- **Duração/Frequência**: Executada obrigatoriamente antes do início de todo atendimento, seja online ou presencial.
- **Indicadores de Sucesso**: Ausência de ansiedade pessoal no terapeuta, percepção de neutralidade emocional e foco para ler as coordenadas na mesa de forma precisa.
- **Variações**: Condução de preparação em consultório físico vs. preparação em ambiente de home office para atendimentos virtuais.
- **Conceitos Envolvidos**: [[Principio da Preparacao do Terapeuta]], [[Principio do Respeito a Tecnica e a Equipe Espiritual]]

## Perguntas Frequentes / Didática de Atendimento

### 10. Como o terapeuta deve conduzir a sua própria preparação mental e o que a autora orienta sobre o uso clínico de incensos, velas ou músicas?
**Resposta**: O terapeuta deve realizar a sua preparação energética e o rebaixamento de frequência cerebral estritamente "antes do seu cliente chegar". Ele deve primeiro "organizar o seu material de trabalho, é deixar tudo em ordem", e em seguida, "respirar, fazer o seu alfa, se conectar espiritualmente".

Sobre os rituais, a autora é clara ao dizer que, durante a sessão clínica, não os utiliza para criar atmosfera: "Eu não coloco música, eu não coloco luzinha, não coloco uma luz mais escurinha, nada. É desse jeito assim, do jeito que vocês estão vendo". Contudo, ela orienta que se o terapeuta gosta de "acender um incenso", "uma velinha cheirosa" ou tomar "banho de ervas", ele deve fazer isso de forma privada para a sua própria ancoragem somática: "Eu faço isso na minha casa, no meu espaço, enquanto eu estou comigo, não com o meu assistido".

## Referencia

ANDRESA MOLINA. *Prática de Preparação e Alfa do Terapeuta*. Aula 07 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]].
