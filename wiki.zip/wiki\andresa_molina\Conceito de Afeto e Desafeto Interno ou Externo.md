---
type: conceito
author: Andresa Molina
tags: [afeto, desafeto, odio-proprio, alvo-de-dor]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# Afeto e Desafeto Interno/Externo (A identificação dos alvos centrais da dor)

- **Definição Precisa**: A categorização diagnóstica que mapeia onde a dor e a energia vital do assistido estão fixados, dividindo-se entre afetos (objetos/pessoas amadas cuja perda gera luto) e desafetos (pessoas odiadas externamente ou o auto-ódio focado no próprio assistido — desafeto interno).
- **Sinônimos/Variações**: Alvos de apego e aversão, desafeto próprio, núcleos de atração emocional.
- **Contexto de Uso**: Rastreia-se a quem se direciona a dor para identificar o duto de vazamento de energia vital (ex: se o desafeto do cliente é ele mesmo, a cura envolve desarmar o auto-ataque celular do auto-ódio).
- **Relação com Princípios**: [[Principio do Foco Primordial]], [[Principio da Aceitacao dos Fatos]]
- **Exemplos do Material**: "Afeto é porque a pessoa vem, porque ela tá com dor em relação a alguma coisa que ela goste ou alguém que ela goste... Ah, eu vou ter que vender o meu carro porque eu tô sem grana... Então esse é um afeto e às vezes eu tô reclamando de dinheiro porque eu estou apegada num carro que é um afeto... às vezes o desafeto sou eu. Eu me odeio. Se uma pessoa fala eu quero me matar, por quê? Porque eu me odeio. O desafeto sou eu ou a minha vida ou alguma situação que aconteceu na minha vida."
- **Aplicação Prática**: Anotar na Ficha o alvo preciso da dor do cliente (interna ou externa) e focar a regressão e o sangramento do útero no corte desses cordões e auto-ataques.
- **Conexões Externas**: [[Conceito de Afetos e Desafetos]], [[Conceito de Eu Sou Lixo]]

## Perguntas Frequentes / Didática de Atendimento

## Referencia

ANDRESA MOLINA. *Afeto e Desafeto Interno/Externo*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
