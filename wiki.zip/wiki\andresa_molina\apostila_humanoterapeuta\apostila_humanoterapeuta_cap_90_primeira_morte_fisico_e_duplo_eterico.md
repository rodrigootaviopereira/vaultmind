---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_90_primeira_morte_fisico_e_duplo_eterico.md]]"]
---

# Cap 090 - Primeira Morte Fisico E Duplo Eterico

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_90_primeira_morte_fisico_e_duplo_eterico.md]]

## Referencia

ANDRESA MOLINA. *Cap 090 - Primeira Morte Fisico E Duplo Eterico*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_90_primeira_morte_fisico_e_duplo_eterico.md]]. Acesso em: 17 jun. 2026.
