---
type: sintese
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, modulo_10, baralho, arquetipos]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_126_baralho_cigano.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_129_arquetipo_na_psicologia_analitica.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_132_as_cartas_do_baralho_terapeutico.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_135_jogada_piramide.md]]"]
---

# HT - Modulo 10 - Baralho Cigano

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_126_baralho_cigano.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_129_arquetipo_na_psicologia_analitica.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_132_as_cartas_do_baralho_terapeutico.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_135_jogada_piramide.md]]


## Nucleos do Modulo

- O modulo aproxima o baralho de arquetipo e psicologia.
- A leitura sai do plano adivinhatorio simples e entra na direcao terapeutica.
- A jogada organiza o processo em linguagem simbolica.

## Síntese

- [INFERÊNCIA] HT - Modulo 10 - Baralho Cigano é uma nota de apoio dentro da wiki de Andresa Molina e precisa ser lida em conjunto com as aulas e mapas estruturais já conectados.

## Evidências do Material

- [INFERÊNCIA] Consultar fontes indicadas.

## Conexões

- [[Consolidacao Tematica - Andresa Molina]]

## Referencia

ANDRESA MOLINA. *HT - Modulo 10 - Baralho Cigano*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_126_baralho_cigano.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_129_arquetipo_na_psicologia_analitica.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_132_as_cartas_do_baralho_terapeutico.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_135_jogada_piramide.md]]. Acesso em: 17 jun. 2026.
