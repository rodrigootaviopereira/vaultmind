---
type: consolidacao
author: Andresa Molina
tags: [andresa_molina, consolidacao, humanosense, mapa_da_alma, mastersense, humanoterapeuta]
sources: []
---
# Consolidacao Tematica - Andresa Molina

- **Eixo central**: A wiki de Andresa Molina gira em torno de `Mapa da Alma`, `HumanoSense`, leitura de padrÃµes ancestrais e reorganizaÃ§Ã£o de polaridades, vÃ­nculos e missÃ£o.
- **Nucleo metodologico**: [[Arquitetura do HumanoSense]], [[Conceito do Metodo HumanoSense]], [[Conceito da Mesa HumanoSense]], [[Conceito da Camara HumanoSense]], [[Conceito da Ficha de Identificacao e Sintese da Dor]]
- **Nucleo de dor e memoria**: [[Principio da Memoria Celular Ancestral]], [[Principio da Causa Inconsciente e da Reconsolidacao]], [[Conceito do Ciclo de Autopunicao]], [[Conceito de Personagens da Dor]], [[Conceito de Ressignificacao vs Reconsolidacao]]
- **Nucleo de polaridade e vinculo**: [[Conceito da Polaridade Masculino e Feminino]], [[Conceito do EquilÃ­brio do Dar e Receber]], [[Conceito de Macho e Femea Alfa]], [[Principio da Hierarquia dos Papeis]], [[Conceito do Parceiro da Missao]]
- **Nucleo de sensibilidade e missao**: [[Principio da Chamado da Sensibilidade]], [[Conceito da Sensibilidade como Valor e Dinheiro]], [[Conceito de Clara Evidencia]], [[Conceito de Saudade do Futuro]], [[Conceito do Eixo da Liberdade]]
- **Nucleo pratico**: [[Tecnica de Identificacao do Cancaco Ancestral]], [[Tecnica de Libertacao da Raiva e Mapeamento da Culpa]], [[Tecnica de Enquadramento na Piramide]], [[Tecnica de Aplicacao Guiada na Camara HumanoSense]], [[Tecnica de Retorno a Consciencia e Harmonizacao]]
- **Pontes prioritarias**: As notas sobre `amor condicionado`, `autopunicao`, `campo emocional`, `modo sobrevivencia no cuidado` e `plenitude` devem ser lidas como um mesmo circuito de autoabandono e reparacao.

## Camada MasterSense

- **Notas novas**: [[MasterSense - Mentoria do HumanoSense]], [[Aula 01 - MasterSense - Andresa Molina]], [[Aula 02 - MasterSense - Andresa Molina]]
- **Ponte HumanoSense/MasterSense**: O HumanoSense fornece a tecnica, a ficha, a camara e a leitura das dores. O MasterSense supervisiona a aplicacao real, aprofunda a leitura fria da ficha e fortalece a postura espiritual-profissional do terapeuta.
- **Eixo de continuidade**: a mentoria nao substitui o HumanoSense; ela transforma o metodo em pratica acompanhada, com casos reais, uso do sistema digital, estudo das equipes espirituais e lapidacao da seguranca terapeutica.

## Camada Humanoterapeuta


- **Espelho de fonte**: [[wiki/andresa_molina/apostila_humanoterapeuta/index_apostila_humanoterapeuta|HT - Fonte da Apostila Humanoterapeuta]]
- **Ponte com o restante da autora**: o Humanoterapeuta amplia o repertorio espiritual, energetico e diagnostico da autora, mas nao deve ser lido como sinonimo de HumanoSense.
- **Leitura correta**: use [[Mapa dos Sistemas Terapeuticos de Andresa Molina]] quando a duvida for sobre fronteiras, afinidades e diferencas entre Humanoterapeuta, HumanoSense e MasterSense.

## Arquitetura Consolidada

- **Mapa comparativo**: [[Mapa dos Sistemas Terapeuticos de Andresa Molina]]
- **Base formativa ampla**: [[HT - Apostila Humanoterapeuta - Andresa Molina]]
- **Metodo de atendimento proprio**: [[Arquitetura do HumanoSense]] e [[Conceito do Metodo HumanoSense]]
- **Camada de lapidacao profissional**: [[MasterSense - Mentoria do HumanoSense]]


