---
type: tecnica
author: Andresa Molina
tags: [somatizacao, mapeamento, empatia, escavacao, 7a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]]"]
---

# Técnica de Mapeamento Somático de Dores e Desejos

## Objetivo

- Rastrear a coordenada biológica e ancestral ("marcar o X") no corpo físico do assistido através da exposição consciente a gatilhos emocionais coletivos e aspirações viscerais, identificando a localização dos registros inconscientes que travam a cura.

## Pré-requisitos

- Ancoragem respiratória e relaxamento mental concluídos por meio da [[Tecnica de Conexao e Respiracao das Coordenadas]].
- Suspensão do julgamento lógico.

## Passo a Passo

1. **Evocação de Gatilhos e Temas Coletivos**:
   - O terapeuta (ou o próprio assistido em autoanálise) expõe a mente de forma vívida aos cenários de dores históricas e injustiças que ressoam com a linhagem humana e familiar:
     - Situações de humilhação pública.
     - Notícias de abandono de crianças ou maus-tratos a seres vulneráveis.
     - Histórias de guerra, violência doméstica ou violência social.
     - Situações de extrema pobreza e miséria material.
2. **Evocação de Desejos de Libertação**:
   - Em seguida, conecte-se aos desejos e conquistas materiais mais urgentes que a alma busca:
     - Desejo de dinheiro, casa própria ou estabilidade financeira segura.
     - Desejo de um corpo bonito e saudável.
     - Desejo de relações afetivas saudáveis, intimidade e prazer.
     - Desejo de libertar-se de pessoas abusivas ou ambientes hostis.
3. **Registro do Eco Corporal**:
   - Observe a reação imediata do organismo a cada tema evocado. A dor gerada "porque você viveu ou porque seus ancestrais viveram" ecoará no físico.
   - Responda de forma somática a pergunta: *"Onde isso pega no meu corpo? O que eu sinto?"*.
   - Rastreie sensações táteis e cinéticas específicas:
     - Sensação de calor intenso ou frio súbito.
     - Aperto, peso ou pontada no peito (coração).
     - Ponto dolorido ou peso nas costas e ombros.
     - Sensação de fraqueza nas pernas.
     - Tensão ou enjoo na região estomacal.
4. **Marcação do X**:
   - A região corporal que apresentar a maior reação física representa a "coordenada somática" exata do problema (o "X" do mapa da alma).
   - Anote ou registre essa coordenada para ser trabalhada ativamente por meio da câmara e da mesa terapêutica.

## Duração/Frequência

- Executado em sessões de anamnese e identificação de queixas crônicas (10 a 15 minutos).

## Indicadores de Sucesso

- Localização física exata de um desconforto ou alteração biológica correlacionada à dor emocional.
- Percepção clara pelo assistido de que o sofrimento ou bloqueio não está "na cabeça", mas ancorado em uma memória material e hereditária viva.

## Conceitos Envolvidos

- [[Conceito da 7a Coordenada]]
- [[Conceito de Gatilho Somatico]]
- [[Principio da Memoria Celular vs Lembranca]]

## Notas Pessoais

- Reservado para observações do usuário.

## Referência

ANDRESA MOLINA. *Técnica de Mapeamento Somático de Dores e Desejos*. Aula 07 - Coordenada 7 (A Cura Buscada em Todo Lugar). Fontes: [[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. Como o corpo físico reage (calor, frio, aperto no peito, peso nas costas) como uma bússola de localização ("marca do X") no momento em que o indivíduo se conecta às coordenadas de sua dor ou desejo?
**Resposta**: A nível somático, essas reações físicas brutcas não são meros incômodos passageiros; elas são a manifestação literal da coordenada se revelando na biologia do indivíduo. A autora instrui que, ao se conectar com as dores e desejos, a pessoa deve atentar à fisiologia: "Veja onde isso pega no seu corpo". 

As reações instintivas de perceber "se tem algum calor, algum frio, se aperta o peito, dói a perna, pesa nas costas" são a bússola viva em funcionamento, pois "a coordenada vai te levando para esses lugares dentro de você". É apenas através da observação atenta dessa resposta somática (a dor ou o peso em um órgão/membro específico) que a pessoa consegue "encontrar o lugar certo, marcar o X". Esse "X" assinalado no corpo físico indica a coordenada exata onde o trauma (ou a trava da abundância) está escondido, preparando o terreno vibracional para que o indivíduo possa "cavar no lugar certo e encontrar o seu tesouro", sem desperdiçar esforço cavando ilusões mentais.

