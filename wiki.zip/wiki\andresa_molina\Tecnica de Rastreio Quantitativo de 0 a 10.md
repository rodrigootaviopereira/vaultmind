---
type: tecnica
author: Andresa Molina
tags: [rastreio-quantitativo, diagnostico, medicao, polaridade]
sources: ["[[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]"]
---
# Prática de Rastreio Quantitativo de 0 a 10 (Medição das Polaridades no Assistido)

- **Objetivo**: Mensurar de forma racional consciente as polaridades do assistido nas pétalas da Mandala do Amor no início da anamnese.
- **Pré-requisitos**: Fichas de atendimento do portal HumanoSense.
- **Passo a Passo**:
  1. Apresentar ao assistido as perguntas correspondentes aos polos masculino e feminino (ex: capacidade de realizar x conforto no silêncio).
  2. Pedir uma nota autoavaliativa de 0 a 10 para cada questão, sendo 10 muito bom e 0 muito ruim.
  3. Registrar as notas na ficha de atendimento para traçar o perfil inicial do desequilíbrio.
  4. Cruzar o resultado racional consciente com a medição radiestésica na Mesa.
- **Duração/Frequência**: Dura cerca de 10 minutos na abertura do atendimento.
- **Indicadores de Sucesso**: O assistido fornece um panorama quantificável consciente sobre seu próprio estado vibracional.
- **Variações**: Reaplicar ao final do tratamento para avaliar a evolução das notas.
- **Conceitos Envolvidos**: [[Conceito da Mandala do Amor]], [[Tecnica de Espelhamento do Consciente e Inconsciente]]
- **Notas Pessoais**: O rastreio numérico inicial ancora o racional do cliente e o engaja no processo terapêutico.

## Perguntas Frequentes / Didática de Atendimento

**Pergunta 23: Como é realizada a técnica de "Rastreio Quantitativo de 0 a 10" usando a mente racional (os "5% de capacidade") para posterior validação no campo vibracional e espiritual do paciente?**

A técnica baseia-se em forçar o assistido a classificar a si mesmo através de perguntas dicotômicas numéricas (ex: "De 0 a 10, o quanto você se perdoa por erros"). 

A autora explica que o propósito imediato dessa coleta é que "a pessoa vai responder com o racional dela". No entanto, Andresa esclarece clinicamente que "O racional é só 5% da nossa capacidade de toar o ído". Por isso, essa nota não é a verdade absoluta, mas o ponto de partida. Em etapas subsequentes da terapia, o profissional utilizará a radiestesia/campo para "conseguir identificar o campo espiritual dela, né? E identificar o quanto é verdade, o quanto bate o que ela fala com o que ela tem no campo energético... o quanto bate o interno, externo, consciente, inconsciente, o espiritual, o energético com o racional", uma vez que os outros 95% dos traumas "continuam acontecendo no nosso campo inconsciente".

## Referencia

ANDRESA MOLINA. *Prática de Rastreio Quantitativo de 0 a 10 (Medição das Polaridades no Assistido)*. Aula 02 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]].
