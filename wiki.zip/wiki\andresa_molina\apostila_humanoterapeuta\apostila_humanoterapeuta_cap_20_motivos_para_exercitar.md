---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_20_motivos_para_exercitar.md]]"]
---

# Cap 020 - Motivos Para Exercitar

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_20_motivos_para_exercitar.md]]

## Referencia

ANDRESA MOLINA. *Cap 020 - Motivos Para Exercitar*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_20_motivos_para_exercitar.md]]. Acesso em: 17 jun. 2026.
