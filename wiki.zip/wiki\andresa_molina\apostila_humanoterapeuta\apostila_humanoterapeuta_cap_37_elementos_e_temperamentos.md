---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_37_elementos_e_temperamentos.md]]"]
---

# Cap 037 - Elementos E Temperamentos

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_37_elementos_e_temperamentos.md]]

## Referencia

ANDRESA MOLINA. *Cap 037 - Elementos E Temperamentos*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_37_elementos_e_temperamentos.md]]. Acesso em: 17 jun. 2026.
