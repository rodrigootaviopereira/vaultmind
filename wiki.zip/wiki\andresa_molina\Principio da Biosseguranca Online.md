---
type: principio
author: Andresa Molina
tags: [biosseguranca-online, queda-de-conexao, isolamento-fisico, protecao-magnetica]
sources: ["[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio da Biossegurança Online (O protocolo de isolamento físico)

- **Definição**: A regra de segurança espacial e magnética inegociável para atendimentos à distância: a exigência de um ambiente estéril sem interferências orgânicas (pessoas ou animais) e o risco vibracional da queda de conexão no ápice do transe.
- **Justificativa**: A nível somático, a viagem astral para resgate de traumas é um procedimento de "cirurgia aberta". A pessoa entra num estado frequencial tão vulnerável que qualquer susto (uma porta batendo ou um cachorro latindo) pode colapsar o sistema nervoso, gerando choques de retorno. Por isso o paciente deve estar sozinho no ambiente. Além do isolamento espacial, o terapeuta deve contar com uma conexão tecnológica estável. Se a internet do terapeuta cair enquanto a pessoa está descarregando e "sangrando" uma dor profunda, o paciente fica sem o cabo de ancoragem sonoro, exigindo o encerramento forçado do processo.
- **Evidências**: "Você tem que estar sozinho no lugar que você tá. Não pode ter ninguém com você entrando, saindo gato, cachorro, batendo porta. Então preciso que você esteja sozinho, tá? Pra gente conseguir não ter processo de influência e e de distração sua... Andreas, se eu estiver atendendo e a internet cair ou acabar a luz, você vai ter que encerrar o processo. Então, não tem, porque você precisa conduzir a pessoa... não tem como você terminar o processo, sendo que ela está no meio do caminho."
- **Implicações**: O terapeuta online deve validar o ambiente do cliente e possuir um plano de contingência para falhas técnicas de rede ou eletricidade.
- **Conexões**: [[Tecnica de Manejo de Queda de Conexao]], [[Tecnica de Desdobramento e Conducao do Sangramento]]
- **Notas Pessoais**: Biossegurança não é frescura, é a proteção contra estresses biológicos traumáticos de retorno abrupto.

## Perguntas Frequentes / Didática de Atendimento

### 6. Quais são as exigências do espaço físico no atendimento online, e por que a queda de internet é tratada como um risco grave?
**Resposta**: As exigências espaciais e magnéticas para o assistido são absolutas: **"Você tem que estar sozinho no lugar que você tá. Não pode ter ninguém com você entrando, saindo gato, cachorro, batendo porta"**. Isso garante que a pessoa não sofra nenhum **"processo de influência e e de distração"**.

A queda de internet é um risco espiritual e somático severo porque a pessoa é desdobrada para outra dimensão e o terapeuta **"não tem como terminar o processo, sendo que ela está no meio do caminho"**. A nível somático, a falta de conexão abandona o paciente em um estado de vulnerabilidade biológica e psíquica extremas: **"Ela pode estar num momento bem profundo espiritual. Ela pode estar num momento de muita dor, onde ela tá sangrando e aí você tem que dar condição para ela ir voltando"**.


## Referencia

ANDRESA MOLINA. *Princípio da Biossegurança Online*. Aula 09 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]].
