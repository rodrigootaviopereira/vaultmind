---
type: conceito
author: Andresa Molina
tags: [alta-sensibilidade, mediunidade, processamento-sensorial, 6a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito da Alta Sensibilidade (Sensibilidade Mediúnica)

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: A Alta Sensibilidade (ou Sensibilidade Mediúnica) é a habilidade biológica, neurológica e energética inata na qual o indivíduo possui um processamento sensorial expandido, sendo capaz de captar, registrar e processar de forma acelerada as frequências e cargas do campo de outras pessoas e ambientes, operando além do espectro material óbvio.
- **Formulação de apoio**: Andresa unifica a definição científica à perspectiva espiritual: enquanto a neurociência classifica esse traço como "diferença de processamento sensorial" (alta sensibilidade), o campo energético-espiritual a reconhece como um canal mediúnico sensorial de clareza (mediunidade de captação e discernimento, e não mediunidade de incorporação de entidades). Longe de ser um desvio psiquiátrico ou uma fraqueza histérica, a alta sensibilidade é um dom receptor de alto valor que, quando treinado e decodificado pelo método, funciona como ferramenta de cura e intervenção sutil.

## Sinônimos/Variações

- Sensibilidade Mediúnica, Processamento Sensorial Atípico, Dom de Captação Frequencial.

## Contexto de Uso

- Usado para orientar sensitivos que sofrem de fadiga por sobrecarga empática, bocejos compulsivos em ambientes cheios, e dores reflexas absorvidas de terceiros sem explicação biológica local.

## Relação com Princípios

- [[Principio do Chamado da Sensibilidade]]
- [[Principio do Vazio como Bussola]]
- [[Principio da Plenitude Energetica e do Cuidado]]

## Exemplos do Material

- *"A neurociência chama essa essa alta habilidade de um uma diferença de processamento sensorial. Você capta as coisas muito rápido e precisa processar isso dentro do seu corpo e você capta do outro. [...] E os altamente sensíveis que não se dão conta disso ou que ignoram ou que não atendem esse chamado, vão ficar doentes, vão ficar pobres, vão ficar escassos..."*
- *"Nós que sentimos demais somos considerados ou bobos ou fomos de fato feito de bobos pelas outras pessoas. E nós hoje temos um nome, a neurociência vai chamar, traz isso como as pessoas que têm uma alta sensibilidade, né? no no no nosso universo energético espiritual, isso é chamado de um tipo de mediunidade, mas não a mediunidade de incorporação..."*

## Aplicação Prática

1. **Suspensão do Autojulgamento**: Validar a queixa do assistido, demonstrando que a sua sensibilidade ao campo alheio é real e orgânica, cessando a sensação interna de desespero e loucura.
2. **Treino de Ancoragem**: Ensinar o assistido a ancorar o seu sentir por meio da [[Tecnica de Alinhamento do Chamado|Técnica de Alinhamento do Chamado]] para discernir o que é seu e o que é do ambiente.
3. **Conversão de Dor em Dom**: Auxiliar o assistido a canalizar essa captação de egrégoras de forma construtiva na egrégora do HumanoSense, atuando na transmutação sutil.

## Conexões Externas

- [[Conceito de Clara Evidencia]]
- [[Conceito da Sensibilidade como Valor e Dinheiro]]
- [[Conceito do Bloqueio Sensorial pelo Batismo]]

## Referência

ANDRESA MOLINA. *Conceito da Alta Sensibilidade (Sensibilidade Mediúnica)*. Aula 06 - Coordenada 6 (O Chamado Ignorado). Fontes: [[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. Como a neurociência define a "alta sensibilidade" e de que maneira ela se manifesta na vida prática como um processamento sensorial acelerado e atípico?
**Resposta**: A neurociência define essa característica como uma **"diferença de processamento sensorial"** ou uma **"alta habilidade"** de percepção. Na vida prática e a nível somático, essa característica se manifesta por meio de um corpo que atua como uma antena de alta velocidade: o indivíduo **"capta as coisas muito rápido e precisa processar isso dentro do seu corpo e você capta do outro"**. Em vez de apenas observar o mundo, o corpo físico dessas pessoas absorve as vibrações do entorno para decodificá-las visceralmente.

### 2. Qual é a diferença no nível vibracional e de atuação entre a "mediunidade de incorporação" tradicional e a mediunidade baseada na "alta sensibilidade sensorial" abordada por Andresa?
**Resposta**:
*   **Mediunidade de Incorporação**: É o modelo mais tradicional (vivenciado pelos pais de Andresa na Umbanda) focado em receber diretamente uma entidade. A autora deixa claro que a mediunidade de que ela fala **"não [é] a mediunidade de incorporação, não a mediunidade de eh de receber o espírito"**.
*   **Mediunidade de Alta Sensibilidade Sensorial**: A nível vibracional, trata-se da **"capacidade de se conectar com as pessoas, de se conectar com o ambiente, de se conectar com um plano, uma outra camada [...] do mundo que não só material"**. Em termos de atuação prática, a pessoa altamente sensível usa o próprio corpo para sentir a frequência do outro. A metodologia terapêutica energética consiste na **"capacidade de captar do outro, transmutar, resolver, limpar, encaminhar pros hospitais astrais o que precisa ser tratado, trabalhado e devolver tratado para outra pessoa"**, sem que para isso precise haver transe ou incorporação.

### 3. Por que a sociedade tende a rotular pessoas altamente sensíveis como "exageradas", "neuróticas" ou "dramáticas", e quais as consequências desse julgamento na saúde emocional dessas pessoas na infância?
**Resposta**: Esses indivíduos são frequentemente chamados de **"exagerada[s], de louca[s]"**, **"neurótica[s]"** ou acusados de que dramatizam demais porque as suas reações somáticas são julgadas por outras pessoas que são **"menos sensíveis, mais intelectuais, mais racionais"**. Como a percepção dessa energia extra não é materialmente visível aos olhos dos lógicos, a manifestação somática da criança sensível é invalidada como se fosse um defeito.

As consequências na infância e no desenvolvimento emocional são drásticas: 
*   **Autossabotagem e Vazio**: A criança (como no relato da própria autora) desenvolve uma **"angústia profunda"** e um **"vazio absurdo"** por não conseguir entender o que sente, acreditando intimamente: *"Eu achava que eu tinha um defeito. Nada dava certo na minha vida"*.
*   **Bloqueio e Fechamento**: Ao ser julgada, a criança aprende a ignorar seus dons e a fechar o seu coração. Andresa descreve que *"você aprendeu que toda vez que você manifestava a sua sensibilidade, as suas emoções, você ia ser ferida, você ia ser machucada, você ia ser passada para trás, você ia ser feita de boba. E aí você fechou isso"*.

