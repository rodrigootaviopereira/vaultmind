---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_61_como_utilizar_e_convencionar_o_pendulo.md]]"]
---

# Cap 061 - Como Utilizar E Convencionar O Pendulo

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_61_como_utilizar_e_convencionar_o_pendulo.md]]

## Referencia

ANDRESA MOLINA. *Cap 061 - Como Utilizar E Convencionar O Pendulo*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_61_como_utilizar_e_convencionar_o_pendulo.md]]. Acesso em: 17 jun. 2026.
