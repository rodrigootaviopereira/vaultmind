---
type: tecnica
author: Andresa Molina
tags: [meditacao, respiracao, alinhamento, 7a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]]"]
---

# Técnica de Conexão e Respiração das Coordenadas

## Objetivo

- Alterar o estado de frequência cerebral e do sistema nervoso por meio de respiração ritmada coletiva (ou individual), preparando o corpo físico e sutil para acessar registros emocionais inconscientes e recapitular as marcas das 7 coordenadas do Mapa da Alma.

## Pré-requisitos

- Postura confortável, preferencialmente sentada, com a coluna alinhada.
- Ambiente silencioso para permitir a introspecção e a suspensão da racionalidade de 5%.

## Passo a Passo

1. **Ciclo de Respiração Ritmada (3 repetições)**:
   - Feche os olhos e respire profundamente pelo nariz, expandindo o abdômen e o tórax.
   - Segure o ar nos pulmões por alguns segundos.
   - Solte o ar lentamente e de uma vez pela boca.
   - Permaneça sem ar (pulmões vazios) por alguns segundos antes de reiniciar o ciclo.
   - Repita o processo por **três vezes** consecutivas.
2. **Conexão com a Linha do Tempo Corporal**:
   - Respire normalmente com os olhos fechados e direcione a consciência para o campo biológico.
   - Recapitule mentalmente e sinta no corpo a marca de cada uma das coordenadas trabalhadas:
     - **1ª Coordenada (O Cansaço Ancestral)**: Reconhecer a fadiga crônica que não passa com repouso físico.
     - **2ª Coordenada (O Amor Condicionado)**: Identificar o dar excessivo sem retorno.
     - **3ª Coordenada (A Raiva que Virou Culpa)**: Sentir a raiva reprimida voltando-se contra si mesma.
     - **4ª Coordenada (A Mulher antes de ser de Todos)**: Recordar o Eu essencial antes da divisão de papéis sociais.
     - **5ª Coordenada (O Cuidado que Esgota)**: Registrar o esgotamento no papel de cuidador do outro.
     - **6ª Coordenada (O Chamado Ignorado)**: Escutar o impulso intuitivo de evolução espiritual no peito.
     - **7ª Coordenada (A Cura Buscada em Todo Lugar)**: Mapear os vazios e dores crônicas que analgésicos externos não resolveram.
3. **Mapeamento Somático e Resposta do Corpo**:
   - Faça as três perguntas diagnósticas em silêncio:
     - *"O que eu busquei até hoje para me curar ou conquistar o que desejo?"*
     - *"O que melhorou e o que voltou?"* (analisar se foi apenas um analgésico temporário).
     - *"O que ainda falta? O que ainda precisa de cura em mim?"*
   - Monitore as reações do corpo (calor, frio, formigamento, peso nas costas, aperto no peito) sem julgamento mental.
4. **Retorno Gradual**:
   - Respire fundo, integre as sensações e abra os olhos devagar, ancorando as coordenadas somáticas mapeadas.

## Duração/Frequência

- 5 a 10 minutos, praticada na abertura de processos terapêuticos profundos ou como exercício diário de ancoragem energética.

## Indicadores de Sucesso

- Transição imediata de um estado de agitação racional para um campo de relaxamento e presença somática.
- Identificação física da "marca do X" no corpo (onde a dor/bloqueio ancestral se manifesta).
- Sensação de acolhimento pessoal e clareza diagnóstica sobre o que de fato requer cura.

## Conceitos Envolvidos

- [[Conceito da 7a Coordenada]]
- [[Principio da Memoria Celular vs Lembranca]]
- [[Principio do Chamado da Sensibilidade]]

## Notas Pessoais

- Reservado para observações do usuário.

## Referência

ANDRESA MOLINA. *Técnica de Conexão e Respiração das Coordenadas*. Aula 07 - Coordenada 7 (A Cura Buscada em Todo Lugar). Fontes: [[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. No exercício de meditação e respiração guiada da 7ª Coordenada, quais são os estados físicos e de frequência que se ativam e de que modo a contagem da respiração altera o campo de força e de frequência?
**Resposta**: A nível somático, o exercício desativa o estado de alerta mental e ativa o estado de conexão profunda ("muito mais do que racional agora"). A autora instrui a seguinte mecânica respiratória (repetida por 3 vezes): "respirar pelo nariz, segurar um pouquinho, soltar pela boca, segurar um pouquinho sem ar".

Essa contagem precisa cria o que a autora chama fisicamente de um "grande campo de força". O ato de interromper e ditar o ritmo da oxigenação corporal atua como um interruptor fisiológico imediato, onde "por alguns segundos a gente respirou, alguns minutinhos a gente se conectou e a gente já muda um estado de frequência". É apenas ao alterar esse estado de frequência somática que o indivíduo consegue baixar a barreira da mente lógica e se abrir para "encontrar curas, informações e existem muitas camadas" que residem no corpo inconsciente.

### 2. Como o roteiro de recapitulação das 6 coordenadas anteriores no corpo serve como ferramenta diagnóstica de auto-observação somática das dores e carências do assistido?
**Resposta**: O roteiro de recapitulação atua como uma ferramenta diagnóstica ao forçar o paciente a reviver mentalmente todos os seus desgastes profundos (o cansaço que não para, a raiva que virou culpa, o chamado ignorado), enquanto a atenção está ancorada em seu próprio corpo através dos olhos fechados e da respiração.

Para extrair o diagnóstico sem a interferência do raciocínio sabotador, Andresa dá um comando diretivo: "eu quero que você responda com a primeira coisa que vier na sua cabeça ou no seu corpo, sem se julgar". Ao trazer à tona as dores das coordenadas passadas e questionar o que o assistido tentou fazer para se curar, ela promove um mapeamento interno onde o paciente realiza uma "leitura que você faz de si mesmo no seu corpo". Isso permite que o próprio corpo do indivíduo evidencie a frustração dos tratamentos paliativos anteriores (o "analgésico") e identifique genuinamente "o que ainda precisa de cura", servindo como a base de rastreio para as intervenções mais profundas da 7ª Coordenada.

