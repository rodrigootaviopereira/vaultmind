---
type: conceito
author: Andresa Molina
tags: [ancestralidade, odus, destino, caminhos, 4a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito dos 16 Destinos ou Odus

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: Os Odus são caminhos ou canais de destino originais mapeados pela sabedoria ancestral. Andresa ensina que existem **16 destinos principais** que, ao se combinarem, geram mais de 200 possibilidades diferentes de rotas existenciais. Cada indivíduo possui um Odu ou destino principal e específico que rege a sua missão de vida, os seus talentos natos e os sonhos que o fazem verdadeiramente feliz.
- **Formulação de apoio**: O conhecimento do próprio Odu serve para que a pessoa compreenda a sua rota única e pare de sofrer tentando copiar o caminho dos outros. Ao alinhar-se com seu Odu original, o indivíduo recupera o fluxo de manifestação de projetos e vive em congruência com o plano de sua alma.

## Contexto de Uso

- Utilizado no diagnóstico e na intervenção energética com a Mandala Suspensa para ajudar o assistido a desatar nós e emaranhamentos que o afastam do seu destino correto.

## Relação com Princípios

- [[Principio da Saudade do Futuro]]
- [[Principio da Memoria Celular Ancestral]]
- [[Principio da Liberdade Consciente]]

## Exemplos do Material

- *"Existem 16 destinos que combinados fazem com que você identifique qual é o seu caminho... E eu vou deixar o centro vazio. Por que que eu vou deixar ele vazio? Porque a gente vai continuar essa caminhada. [...] O centro tá vazio e eu vou deixar de propósito. Ele tá suspenso. Não é vazio, é uma suspensão. E por que que eu tô fazendo isso? Porque é você quem vai encontrar essa saída."*
- O assistido que tenta trilhar um caminho que pertence a outro familiar ou expectativa social, gerando frustração persistente e "caminhada com muito sofrimento" por estar desalinhado com o seu Odu de nascimento.

## Aplicação Prática

1. **Reconhecer a Rota Única**: Durante o mapeamento das coordenadas, identificar se o assistido está tentando reproduzir o destino de seus pais ou parceiros, o que configura o autoabandono.
2. **Conexão Vibracional**: Utilizar a Mandala Suspensa para sintonizar o campo sutil do assistido com a sabedoria ancestral dos 16 destinos originais.
3. **Resgate do Programa**: Orientar o assistido a aceitar a sua própria rota, validando seus desejos de infância e projetos que haviam sido "engavetados" no corpo.

## Perguntas Frequentes / Didática de Atendimento

### O que são os Odus (destinos ancestrais) e qual é a consequência de caminhar desalinhada do seu Odu de nascimento?

Os Odus são "caminhos de destino que os nossos ancestrais nos ensinavam". Segundo o texto, existem 16 destinos básicos que, ao se combinarem, formam "mais de 200 possibilidades" de rotas para a vida. Cada pessoa possui um Odu principal que é único, inato e está diretamente ligado aos seus sonhos e à sua missão para ser feliz.

A consequência de caminhar desalinhada de seu Odu (perdida em automagias e papéis alheios) não é que a pessoa deixará de cumprir o seu destino, pois Andresa enfatiza que "se esse é o seu destino, você não tem como não chegar nele, você não tem como não viver ele". No entanto, a forma como essa caminhada ocorrerá muda drasticamente: a pessoa percorrerá a rota inevitável da vida "com muito sofrimento", através de traumas e bloqueios. Alinhar-se ao Odu serve para compreender qual é esse propósito e percorrê-lo "de maneira mais consciente" e leve.

*(Nota: Como os nomes exatos dos 16 Odus não constam na transcrição selecionada, essa informação específica precisaria ser buscada em aulas futuras ou materiais externos da autora).*

## Referência

ANDRESA MOLINA. *Conceito dos 16 Destinos ou Odus*. Aula 04 - Coordenada 4 (A Mulher Antes de Ser de Todos). Fontes: [[raw/archive/andresa_molina/transcriptions/04 - A MULHER ANTES DE SER DE TODOS 4ª Coordenada - O Mapa da Alma.md]].
