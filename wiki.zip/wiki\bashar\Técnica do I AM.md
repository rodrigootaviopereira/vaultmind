---
type: tecnica
author: Bashar (Darryl Anka)
tags: [bashar, tecnica, meditacao, dissolver_medo]
sources: ["[[Bashar's 'I AM' Technique: The 2 Words That Dissolve ALL Fear & Doubt]]"]
---

# TÉCNICA DO I AM

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[Bashar's 'I AM' Technique: The 2 Words That Dissolve ALL Fear & Doubt]]

## Referencia

BASHAR (DARRYL ANKA). *TÉCNICA DO I AM*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[Bashar's 'I AM' Technique: The 2 Words That Dissolve ALL Fear & Doubt]]. Acesso em: 17 jun. 2026.
