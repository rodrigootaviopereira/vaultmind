---
type: concept
author: Andresa Molina
tags: [falsa-culpa, julgamento-sistemico, ilusao, lealdade-invisivel, paralisia]
sources: ["[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"]
---

# A Falsa Culpa Sistêmica (A autossabotagem baseada no julgamento)

- **Definição**: O mecanismo vibracional em que o adulto bloqueia o seu próprio sucesso financeiro ou afetivo por "lealdade invisível" aos pais, punindo-se por acreditar, através de um julgamento presunçoso e equivocado, que a vida ou o casamento dos pais é "ruim".
- **Justificativa**: A nível sistêmico, o paciente trava a própria prosperidade porque acha que será uma "traição" ser feliz enquanto os pais supostamente sofrem num relacionamento cheio de brigas. A autora quebra essa arrogância filial. Ela prova que a vida dos pais não é necessariamente um sofrimento, mas apenas diferente do "padrão idealizado" do filho. Os pais podem reclamar o dia inteiro, mas, na dinâmica biológica deles, "eles são felizes juntos" e não trocariam aquela vida. Se o filho adoece de pena e culpa por uma tragédia que não existe (um sofrimento ilusório dos pais), ele afunda a própria vida agarrado a um fantasma criado pela sua própria mente julgadora.
- **Evidências**: "Você sente que é errado você viver uma vida boa e eles não e aí nesse processo você se sente desleal. Você sente culpa. Mas aí que eu quero que você olhe para isso. Se você sente culpa é porque você julga que a vida deles é ruim... Mas esse é um julgamento seu... de que a relação deles é ruim... Mas o quanto realmente é ruim ou é só um hábito de reclamar... Então você não vai para um pensamento equivocado de uma vida que é ruim, que não é para eles não é... Eles são felizes juntos, eles tiveram a família deles como eles puderam construir."
- **Implicações**: Desconstruir o papel de salvador dos pais e libertar o cliente para prosperar sem culpa por achar que a vida deles é miserável.
- **Conexões**: [[Principio da Hierarquia dos Papeis]], [[Conceito do Tratamento do Luto e o Deslocamento de Funcao]]
- **Notas Pessoais**: Quem julga a dor dos pais coloca-se acima deles, violando a ordem de precedência.

## Perguntas Frequentes / Didática de Atendimento

### 14. Como a culpa sabota a prosperidade do adulto com base no seu julgamento de que a vida dos pais é "ruim"?
**Resposta**: O assistido sabota o seu próprio progresso material e emocional (ficando **"impedida de prosperar"**) por uma lealdade invisível e tóxica àquilo que ele acha que é o sofrimento dos pais. Ele acredita que **"é errado você viver uma vida boa e eles não e aí nesse processo você se sente desleal. Você sente culpa"**.

A autora destrói essa autossabotagem revelando que o adulto está sofrendo por uma mentira que ele mesmo inventou. O corpo paralisa com base numa arrogância interpretativa: **"Se você sente culpa é porque você julga que a vida deles é ruim... Mas esse é um julgamento seu... de que a relação deles é ruim"**. Energeticamente, o paciente julga o padrão dos pais sem entender que, na biologia deles, **"eles são felizes juntos, eles tiveram a família deles como eles puderam construir. Tem um lugar de felicidade que a gente julga de maneira, né? Bagunçada"**. A transformação desfaz o bloqueio provando que o adulto está estagnado por um **"pensamento equivocado de uma vida que é ruim, que não é para eles não é"**.


## Referencia

ANDRESA MOLINA. *A Falsa Culpa Sistêmica*. Aula 09 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]].
