---
type: tecnica
author: Andresa Molina
tags: [tecnica, espiritualidade, conexao, sentir, 5a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]]"]
---

# Técnica de Conexão com a Equipe Espiritual (Sustentação do Sentir)

## Objetivo

- Burlar o controle do intelecto lógico e a necessidade racional de "entender" o trauma, ativando a autoridade sensorial interna e abrindo o campo para a atuação e nutrição da equipe espiritual e dos amparadores superiores na reconsolidação celular.

## Pré-requisitos

- Disposição para abandonar o julgamento lógico ("isso é bobagem") e seguir a inteligência vibracional do corpo.
- Isolamento energético de interferências externas.

## Passo a Passo

1. **Criação do Oráculo Pessoal**:
   - Sentar-se de olhos fechados e isolar completamente o campo de trabalho de influências de familiares, cônjuges ou autoridades terrenas e espirituais externas.
2. **Desconexão do Controle Mental**:
   - Deixar de lado a necessidade racional de compreender a causa ou comprovar cientificamente o processo.
   - Instruir a racionalidade lógica a silenciar, transferindo o foco de atenção para o sentir.
3. **Mapeamento e Ancoragem do "Negócio"**:
   - Ao escutar os comandos ou evocar marcas somáticas, focar estritamente nas sensações físicas inegáveis do corpo (ex: aperto no peito, calor no rosto, frio na barriga).
   - Ancorar a atenção no ponto corporal que reage à emoção evocada (o "negócio" que pega).
4. **Sintonização com a Equipe Espiritual**:
   - Emitir o comando interno de permissão para ser amparado.
   - Confiar no fluxo de transmutação gerado pelos guias superiores, sustentando a sensação física até que a reconsolidação celular se materialize.

## Duração/Frequência

- Executada como prática meditativa e de ancoragem energética em consultório durante a condução de desipnose na câmara HumanoSense.

## Indicadores de Sucesso

- Interrupção do fluxo de pensamentos analíticos sobre a dor.
- Percepção de calor, leveza ou liberação física no local da somatização.
- Sensação de amparo invisível e relaxamento profundo no sistema nervoso.

## Conceitos Envolvidos

- [[Principio da Plenitude Energetica e do Cuidado]]
- [[Principio da Responsabilidade Espiritual]]
- [[Conceito de Ressignificacao vs Reconsolidacao]]

## Referência

ANDRESA MOLINA. *Técnica de Conexão com a Equipe Espiritual (Sustentação do Sentir)*. Aula 05 - Coordenada 5 (O Cuidado que Esgota). Fontes: [[raw/archive/andresa_molina/transcriptions/05 - O CUIDADO QUE ESGOTA 5ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. De que maneira o bloqueio de receber cuidado da 5ª Coordenada fecha as portas do assistido inclusive para a atuação de sua própria equipe de amparadores espirituais?
**Resposta**: Embora o texto não use a expressão literal de "fechar as portas para a equipe de amparadores", Andresa explica essa desconexão através do estado de esvaziamento. O bloqueio de receber cuidado cria uma pessoa que atua no modo automático de sobrevivência, doando tudo o que tem até ficar *"vazia"*. A autora questiona: *"Vazio de quê, Andresa? do seu espírito"*.

A nível somático e vibracional, esse estado de exaustão e de estar apenas na *"racionalidade"* desconecta o indivíduo da sua própria força espiritual. O milagre e a atuação do amparo não operam no intelecto, mas no corpo e no espírito: *"O milagre tá no seu espírito, não tá na sua racionalidade, não tá na sua cabeça. É preciso conectar os fios para permitir que esse fluxo aconteça"*. Quando a pessoa não permite ser cuidada e vive como a *"âncora"* de todos, ela bloqueia esse fluxo e perde a capacidade de *"acreditar no seu sentir e na possibilidade que o seu espírito te diz"*. É apenas quando ela confia nas sensações do corpo (*"eu sinto um negócio aqui"*) que consegue receber a *"direção que a sua equipe espiritual tá dando para você"*.

