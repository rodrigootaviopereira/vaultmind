---
type: conceito
author: Andresa Molina
tags: [energia-masculina, acao, coragem, semear]
sources: ["[[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]"]
---
# Energia Masculina (A Semeadura, a Coragem e o Impulso)

- **Definição Precisa**: A polaridade arquetípica de criação (presente em todos os seres) que governa o impulso de ação, a externalização, a coragem de se expor e a força de semeadura de novos projetos.
- **Sinônimos/Variações**: Força Masculina, Carga Masculina, Energia de Expansão, Polaridade Masculina
- **Contexto de Uso**: Equilíbrio de atitude e proatividade perante a vida profissional e realizações.
- **Relação com Princípios**: [[Principio da Fusao Criacional]]
- **Exemplos do Material**: "A energia masculina é a que inicia, direciona, age, propõe... Então ela é a energia que semeia. Então fica mais fácil da gente entender, porque semeia, coloca no mundo. [...] O homem tem coragem. O masculino, perdão, ele tem coragem, ele vai lá e faz. Ele vai lá e mete a boca."
- **Aplicação Prática**: Usada para gerar impulso e coragem para materializar e apresentar propostas ao mundo, quebrando a passividade.
- **Conexões Externas**: [[Conceito de Energia Feminina]]

## Perguntas Frequentes / Didática de Atendimento

**Pergunta 4: Quais são as metáforas práticas usadas pela autora (como "dar com o pau na mesa" ou "meter a boca") para descrever o impulso da energia masculina?**

Para ilustrar o pulso visceral, protetor e externalizador da energia masculina, Andresa utiliza termos intensos de enfrentamento. A nível somático, a energia masculina é a faísca que tem "coragem, ele vai lá e faz. Ele vai lá e mete a boca". 

A autora utiliza também a metáfora do "guerreiro", que "é propositivo, ele vai pra vida, ele pega a espada" e tem a firmeza bruta de quem "vai lá e dá com pau na mesa". É a força literal da semeadura em ação, a coragem que tira a ideia do plano mental e a crava na realidade física, refletida no ímpeto assertivo: "fui lá e falei, fui lá e fiz, fui lá e cobrei, fui lá e decidi".

## Referencia

ANDRESA MOLINA. *Energia Masculina (A Semeadura, a Coragem e o Impulso)*. Aula 02 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]].
