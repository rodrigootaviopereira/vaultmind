---
type: conceito
author: Andresa Molina
tags: [coordenadas, chamados, dons, espiritualidade, 6a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]]"]
---

# A 6ª Coordenada (O Chamado Ignorado)

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: A 6ª Coordenada (O Chamado Ignorado) é a marca somática e a egrégora de dor acumulada que se instala no Mapa da Alma do sensitivo quando ele desconsidera a sua intuição e os convites vibracionais de sua equipe espiritual para manifestar a sua função curadora no mundo. Esse desalinhamento gera uma paralisia existencial profunda, bloqueio magnético-financeiro e angústia, motivada pela tentativa forçada de adaptar-se à hipnose puramente racionalista da sociedade.
- **Formulação de apoio**: Sob a atuação da 6ª Coordenada, o assistido ignora o seu chamado sutil de ajuda ao próximo e bloqueia os canais do sentir por medo de parecer desajustado, exagerado ou "louco" perante a família e amigos. Esse bloqueio rompe os fios de conexão com o plano superior. Sem o amparo de guias e sem canalizar seu dom, o assistido é consumido por um vazio que sabota seus negócios, esvazia sua atração financeira e adoece seus relacionamentos íntimos.

## Contexto de Uso

- Diagnosticada em consultório quando o assistido apresenta crises agudas de ansiedade, sentimentos crônicos de "desconexão da própria vida", fadiga ambiental e fracassos financeiros recorrentes que não encontram explicação causal na sua rotina prática.

## Relação com Princípios

- [[Principio do Chamado da Sensibilidade]]
- [[Principio do Vazio como Bussola]]
- [[Principio da Responsabilidade Espiritual]]

## Exemplos do Material

- *"O que eu falo de chamado ignorado é a espiritualidade o tempo inteiro nos convidando a voltar, a se conectar com esse nosso sentir... É por isso que você tá angustiada, vazia, doente, sem... com a escassez por causa dos valores, com relacionamentos adoecidos, porque você acha que você tá louco..."*
- *"Enquanto você não aceitar esse chamado, enquanto você ignorar esse chamado, esse vazio vai te consumir... Você não tá quebrado, você não tá com defeito, você não é dramático, você não é imperfeito, você não é exagerado, você não é louco, você só tem um dom que tem um nível de funcionamento diferente das outras pessoas."*

## Aplicação Prática

1. **Localização no Corpo (GPS)**: Utilizar a [[Tecnica de Alinhamento do Chamado|Técnica de Alinhamento do Chamado]] para ajudar o assistido a suspender a mente racional e registrar no peito a angústia invisível provocada pela rejeição do seu dom.
2. **Desprogramar o Bloqueio da Sensibilidade**: Identificar as memórias celulares e pactos inconscientes instalados de repressão (ex: medo do julgamento alheio na infância) e reconsolidar essas trilhas neurais.
3. **Aceitação do Valor de Dharma**: Mapear a transição profissional ou a integração das ferramentas energéticas no cotidiano do assistido para restabelecer a egrégora de atração e prosperidade.

## Conexões Externas

- [[Conceito da Sensibilidade como Valor e Dinheiro]]
- [[Conceito do Cuidado que Esgota]]
- [[Conceito de Clara Evidencia]]

## Referência

ANDRESA MOLINA. *A 6ª Coordenada (O Chamado Ignorado)*. Aula 06 - Coordenada 6 (O Chamado Ignorado). Fontes: [[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. Por que Andresa afirma que após os 33 anos de idade o espírito humano se acopla/incorpora por completo e como essa transição altera o foco dos desejos e do projeto de vida?
**Resposta**: Segundo a autora, os 33 anos marcam um ponto de virada biológico e espiritual: *"Se você passou dos 33 anos, seu espírito já incorporou inteiro. Seu projeto de vida já começou, já tá pronto"*.

Essa transição altera o foco das vontades do indivíduo porque a centelha divina instalada no corpo passa a *"pulsar forte"*, exigindo alinhamento. A nível somático e existencial, a pessoa sente uma ruptura com os desejos do passado (ego). Embora o texto não detalhe novos projetos específicos pessoais e profissionais, Andresa explica essa alteração de forma direta: *"Por isso, aquilo que você queria, agora você não quer mais, porque agora o seu espírito já te diz algo a mais"*, empurrando a pessoa para fora das metas limitadas e direcionando-a para a sua real missão de alma.

