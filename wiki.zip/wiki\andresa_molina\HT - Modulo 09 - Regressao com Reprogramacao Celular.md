---
type: sintese
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, modulo_09, regressao, reprogramacao_celular]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_120_regressao_com_reprogramacao_celular.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_121_inteligencia_ou_consciencia__informacao__energia.md]]", "[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_125_os_pontos_da_regressao_com_a_reprogramacao.md]]"]
---

# HT - Modulo 09 - Regressao com Reprogramacao Celular

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_120_regressao_com_reprogramacao_celular.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_121_inteligencia_ou_consciencia__informacao__energia.md]]
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_125_os_pontos_da_regressao_com_a_reprogramacao.md]]


## Nucleos do Modulo

- O modulo trabalha o inconsciente como deposito vivo de registros.
- A cura depende de entendimento e esgotamento do bloqueio.
- A reprogramacao fecha o processo pela informacao original da celula.

## Síntese

- [INFERÊNCIA] HT - Modulo 09 - Regressao com Reprogramacao Celular é uma nota de apoio dentro da wiki de Andresa Molina e precisa ser lida em conjunto com as aulas e mapas estruturais já conectados.

## Evidências do Material

- O MasterSense pega essa base e transforma em supervisao viva: o terapeuta aplica, registra, autoriza a analise e aprende a enxergar o que a ficha revela sobre afeto/desafeto, pai, mae, personagens, escassez, valor, fuga e memoria celular. ## Segunda Camada - Leitura de Conjunto - A aula 01 apresenta a moldura espiritual e profissional da mentoria. - A aula 02 confirma o metodo na pratica: a ficha nao e burocracia, e um mapa de fuga, defesa, desejo, dor e incoerencia. - A mentoria insiste que o terapeuta nao precisa sentir tudo mediunicamente para fazer um bom trabalho; primeiro ele deve aprender a ler bem o material que o assistido oferece. - O MasterSense nao substitui o HumanoSense. (MasterSense - Mentoria do HumanoSense)

## Conexões

- [[MasterSense - Mentoria do HumanoSense]]

## Referencia

ANDRESA MOLINA. *HT - Modulo 09 - Regressao com Reprogramacao Celular*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_120_regressao_com_reprogramacao_celular.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_121_inteligencia_ou_consciencia__informacao__energia.md]], [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_125_os_pontos_da_regressao_com_a_reprogramacao.md]]. Acesso em: 17 jun. 2026.
