---
type: tecnica
author: Andresa Molina
tags: [alfa-profundo, rebaixamento-cerebral, inducao-sonora, relaxamento]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# Prática de Rebaixamento Cerebral / Alfa (A indução mecânica antes do transe)

- **Objetivo**: Conduzir mecanicamente o assistido a acalmar a sua respiração e batimentos cardíacos, reduzindo a velocidade das ondas cerebrais de Beta para Alfa para permitir a viagem astral e o desdobramento na Câmara.
- **Pré-requisitos**: Conclusão da fase de choque racional de perguntas.
- **Passo a Passo**:
  1. O terapeuta usa uma voz calma e pausada, instruindo o assistido a relaxar o abdômen e a perceber seu próprio corpo físico.
  2. Inicia a contagem regressiva e pausada (ex: *"10, 9, 8, 7, 6"*).
  3. Ao atingir a marca intermediária da indução (ex: *"555"*), reforça o comando somático: *"Relaxa, abdômen. Sinta a sua respiração mais calma e os batimentos cardíacos mais tranquilos"*. O corpo físico se acalma, transferindo o foco neurológico do modo sobrevivência lógica para a plasticidade sutil do transe.
- **Duração/Frequência**: Executada antes de iniciar o comando de desdobramento.
- **Indicadores de Sucesso**: Diminuição dos batimentos cardíacos do assistido, relaxamento muscular visível e foco estrito no sentir sutil.
- **Variações**: Uso de áudios de indução do método vs. contagem verbal personalizada.
- **Conceitos Envolvidos**: [[Tecnica de Desdobramento e Conducao do Sangramento]], [[Conceito da Camara HumanoSense]]

## Perguntas Frequentes / Didática de Atendimento

### 23. Como é conduzido o alfa com a contagem decrescente, incluindo o relaxamento abdominal no "555"?
**Resposta**: A indução mecânica e neurológica exige que o terapeuta ordene a contagem regressiva para forçar "movimento mecânico do nosso corpo" a acalmar: "É 10 9 8 10 9 8 7 6". No meio do processo, o terapeuta aplica um gatilho somático: "quando eu chego no 555, eu falo: 'Relaxa, abdómen'". A nível biológico, soltar as vísceras faz com que "a sua respiração já tá mais calma, seus batimentos cardicos já estão mais tranquilos, tudo já tá mais leve", promovendo um rebaixamento cerebral tão veloz que, na "metade do relacionamento, a gente já tá mais calmo".


## Referencia

ANDRESA MOLINA. *Prática de Rebaixamento Cerebral / Alfa*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
