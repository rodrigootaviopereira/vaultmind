---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_39_temperamentos_e_signos.md]]"]
---

# Cap 039 - Temperamentos E Signos

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_39_temperamentos_e_signos.md]]

## Referencia

ANDRESA MOLINA. *Cap 039 - Temperamentos E Signos*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_39_temperamentos_e_signos.md]]. Acesso em: 17 jun. 2026.
