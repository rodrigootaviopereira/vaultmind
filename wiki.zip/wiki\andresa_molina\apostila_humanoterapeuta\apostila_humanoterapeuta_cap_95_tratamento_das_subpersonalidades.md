---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_95_tratamento_das_subpersonalidades.md]]"]
---

# Cap 095 - Tratamento Das Subpersonalidades

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_95_tratamento_das_subpersonalidades.md]]

## Referencia

ANDRESA MOLINA. *Cap 095 - Tratamento Das Subpersonalidades*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_95_tratamento_das_subpersonalidades.md]]. Acesso em: 17 jun. 2026.
