---
type: conceito
author: Andresa Molina
tags: [somatizacao, obesidade, energia, sobrecarga, lixeiro, fronteiras]
sources: ["[[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]]"]
---

# Conceito de Obesidade Somatica por Sobrecarga

- **Definição**: A somatização biológica em que o corpo expande sua massa física (engorda) para estocar energia e lidar com o fardo de carregar a responsabilidade pela vida de múltiplas pessoas.
- **Justificativa**: Somaticamente, o corpo pede comida para suprir a energia necessária para carregar a si e ao entorno. Se o assistido assume o papel de mãe/pai dos seus familiares (Ocupado/Lixeiro), seu cérebro exige a ampliação do corpo físico para caber essa sobrecarga.
- **Evidências**: "possemente eu sou uma pessoa que cuido de três, quatro cinco vidas, porque eu tenho um corpo para cuidar de uma vida que é a minha. Se eu cuido da vida de quatro pessoas, eu preciso de um corpo maior. Eu preciso de quatro corpos e eu preciso de energia. [...] O que que eu entendo como energia? Comida. Meu corpo pede energia. [...] Aumento o meu corpo, minha massa. [...] é um campo de energia."
- **Implicações**: O terapeuta deve orientar a devolução das tarefas e das 'cruzes' de terceiros para desarmar o gatilho biológico do acúmulo de peso do assistido.
- **Conexões**: [[Conceito do Eu Sou Lixeiro]], [[Principio de Lugar Funcao e Potencia]]
- **Notas Pessoais**: A devolução dos fardos alheios esvazia a necessidade de expansão da massa física.

## Referencia

ANDRESA MOLINA. *Conceito de Obesidade Somatica por Sobrecarga*. Aula 04 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]].
