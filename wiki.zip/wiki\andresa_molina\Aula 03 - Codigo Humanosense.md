---
type: aula
author: Andresa Molina
tags: [codigo-humanosense, humanosense, aula-03, reingestao-2026-06-19]
sources:
  - "[[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]"
---
# Aula 03 - Código Humanosense

## Rastreabilidade da Fonte

- **Fonte integral arquivada**: [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]
- **Arquivo ingerido em segunda passada**: `03   Código Humanosense - Andresa Molina.md`
- **Extensão aproximada da transcrição**: 17.335 palavras; 616 frases longas extraídas para análise.
- **Critério desta nota**: [INFERÊNCIA OPERACIONAL] preservar a progressão da aula por mapa granular, reforçar conceitos já existentes e criar conexões sem duplicar cegamente a wiki. As listas de síntese, conceitos, práticas, padrões e citações abaixo priorizam formulações textuais da própria transcrição.

## Síntese Executiva

> [INFERÊNCIA OPERACIONAL] Esta seção organiza os trechos de maior densidade da aula; a formulação dos itens preserva o texto da transcrição sempre que possível.

- Então, tô bem feliz com as que estão chegando, com aquelas que eu consigo identificar e responder, claro, de uma maneira de uma maneira simples, porque é um um espaço pequeno paraa elaboração, então não tem como fazer uma elaboração profunda, mas a gente vai ter aqui também espaços para vocês perguntarem, não vai ser ainda, tá?
- Então, vai ter uma grande união, um grande processamento de informação para você poder identificar e ajudar ainda mais o seu assistido, né?
- Então já pra gente ir quebrando o processo, eu quero que você esteja atento aos seus clientes, aos seus assistidos, né, como a gente chama aqui, aqueles que você vai atender, aqueles que você já atende em casos específicos, tá?
- Então, mandalador é um campo invisível que ancora medos, memórias e crenças, um círculo de repetições internas que paralisa, sabota e pesa a vida.
- Então sempre de entender que existe uma dor, ninguém procura terapia se não tivesse dor.
- Então essa pessoa, ela normalmente está para baixo, está nada anda na vida dela, não anda mesmo, porque conforme ela explora dor, ela precisa ficar nesse lugar, esse lugar não tem energia, a energia fica parada, ela fica estagnada, realmente nada tá dando certo na vida dela, é bem possível, tá?
- E aí de repente você identifica que ele tem um padrão cobrador muito grande, porque tudo ele vai lá para trás, tudo ele vai lá para trás, tudo ele conta uma coisa lá atrás, porque o meu e sempre a culpa é o de alguém, nunca dele, entende?
- Então a vida dele não anda, não destrava, porque ele tem esse processo de dependência, não consegue liberar, ele não consegue se autorizar fazer porque ele se vai sentir culpa ou ele não vai se sentir mais amado e aí é possível que as pessoas falam: "Nossa, enricou agora ficou metido".
- No trabalho terapêutico, o dinheiro deixa de ser só matéria e passa a ser um espelho que mostra onde a energia do assistido precisa ser liberada, curada ou fortalecida.
- As pessoas que apanham e assumem para si, porque é tão enlouquecedor que assumem para si que é culpa delas. e que se elas não tivessem feito, não tivessem saído com aquela roupa, ela não teria apanhado, ele não precisaria bater.
- É naquela situação, naquela dor específica, naquele momento específico, ele tá carregado naquela personagem, porque ele está cheio de fractais, ele está cheio de criações, que é o que a gente vai trabalhar no desfazimento no campo energético.
- Pr as próximas, porque a gente vai aprender a usar mesa, fazer as perguntas e identificar também coisas no inconsciente e aí vocês vão entender bastante coisa, tá bom, gente?

## Mapa Granular da Aula

> Segunda passada aplicada: os blocos abaixo funcionam como trilha de auditoria para retornar à fala integral arquivada.

### Bloco 1 - frases 1-77
- Então, tô bem feliz com as que estão chegando, com aquelas que eu consigo identificar e responder, claro, de uma maneira de uma maneira simples, porque é um um espaço pequeno paraa elaboração, então não tem como fazer uma elaboração profunda, mas a gente vai ter aqui também espaços para vocês perguntarem, não vai ser ainda, tá?
- Então já pra gente ir quebrando o processo, eu quero que você esteja atento aos seus clientes, aos seus assistidos, né, como a gente chama aqui, aqueles que você vai atender, aqueles que você já atende em casos específicos, tá?
- Então, mandalador é um campo invisível que ancora medos, memórias e crenças, um círculo de repetições internas que paralisa, sabota e pesa a vida.

### Bloco 2 - frases 78-154
- Então sempre de entender que existe uma dor, ninguém procura terapia se não tivesse dor.
- Então essa pessoa, ela normalmente está para baixo, está nada anda na vida dela, não anda mesmo, porque conforme ela explora dor, ela precisa ficar nesse lugar, esse lugar não tem energia, a energia fica parada, ela fica estagnada, realmente nada tá dando certo na vida dela, é bem possível, tá?
- E aí de repente você identifica que ele tem um padrão cobrador muito grande, porque tudo ele vai lá para trás, tudo ele vai lá para trás, tudo ele conta uma coisa lá atrás, porque o meu e sempre a culpa é o de alguém, nunca dele, entende?

### Bloco 3 - frases 155-231
- Ou ele é o que precisa carbar, não deixa o filho ir, não deixa o relacionamento terminar, não deixa, porque ele fica conduzindo e manipulando tudo aquilo.
- É um campo invisível que encara medos, memórias e crenças, um círculo de repetição interna que paralisa, sabota e pesa a vida.
- Ninguém tem que perceber porque cada um tá cuidando da sua vida e a pessoa chega em terapia com essa dor e a gente precisa ajudando a desconstruir isso, tá?

### Bloco 4 - frases 232-308
- Então assim, é uma pessoa reativa, julga e entra em confronto o tempo inteiro, cria lutas onde não há nenhuma batalha, usa o julgamento como defesa contra a dor.
- Então, zer 10, quando você sente que precisa estar sempre certa, em alerta e pronta para se defender.
- Aqui em alguns momentos tem algumas pessoas, né, aqui na dor, tá? quando quando tá na mandala da dor e quando a pessoa traz isso, que são as pessoas extremamente quando ela tá em dor manipuladoras, elas ela quer mexer as peças taboleira xadrez do jeito que ela quer, do jeito que ele quer.

### Bloco 5 - frases 309-385
- Então a vida dele não anda, não destrava, porque ele tem esse processo de dependência, não consegue liberar, ele não consegue se autorizar fazer porque ele se vai sentir culpa ou ele não vai se sentir mais amado e aí é possível que as pessoas falam: "Nossa, enricou agora ficou metido".
- Isso vai ser terapeuta trazendo pro consciente e ajudando a atravessar, fazer essa travessia nesse processo que é difícil, porque ela sente que não vai ser amada, sente que naquilo vai existir um abandono, que em alguns momentos não existe, é ilusório, em alguns momentos é real, porque o outro tá ali só porque tá tendo um ganho também, né?
- Então ó lá de 0 a 10, o quanto você sente que nunca tem tempo para si porque sempre está resolvendo o problema de alguém.

### Bloco 6 - frases 386-462
- Então a gente vai perguntar para essa pessoa: 0 a 10: quanto você sente que nunca viveu um relacionamento verdadeiro ou duradouro?
- Então o dinheiro é fluxo, é a energia que revela merecimento, autorresponsabilidade, confiança e limites.
- No trabalho terapêutico, o dinheiro deixa de ser só matéria e passa a ser um espelho que mostra onde a energia do assistido precisa ser liberada, curada ou fortalecida.

### Bloco 7 - frases 463-539
- Então você tem dinheiro para pagar conta, nunca sofre, sempre fica naquele limite, nunca sustenta mais.
- As pessoas que apanham e assumem para si, porque é tão enlouquecedor que assumem para si que é culpa delas. e que se elas não tivessem feito, não tivessem saído com aquela roupa, ela não teria apanhado, ele não precisaria bater.
- Quando você acredita que só poderá ter paz se todos ao seu redor estiverem curados, porque você é o lixo, você é o causador da dor de todo mundo.

### Bloco 8 - frases 540-616
- E tome isso para você como um uma jornada interior mesmo, um lugar de mais do que de chegar em algum lugar, mas um retorno pr pra casa, pra sua essência, para esse lugar incrível que é você que é o seu assistido, que é a pessoa que tá em dor, que é a pessoa que tá enfermizando, mas a pessoa precisa querer, né?
- É naquela situação, naquela dor específica, naquele momento específico, ele tá carregado naquela personagem, porque ele está cheio de fractais, ele está cheio de criações, que é o que a gente vai trabalhar no desfazimento no campo energético.
- Pr as próximas, porque a gente vai aprender a usar mesa, fazer as perguntas e identificar também coisas no inconsciente e aí vocês vão entender bastante coisa, tá bom, gente?

## Princípios Extraídos

> Exceção autorizada pelo usuário para esta reingestão: por se tratar de aulas longas e contínuas, esta seção pode preservar até 10 princípios quando a densidade do conteúdo justificar.

- Não importa qual é o problema que ele trouxe, ele traz aquela dor e ele fala da dor dele e tudo que você fala nada resolve porque ele quer ficar, ele tem um ganho secundário, ele ganha com aquilo.
- Então sempre de entender que existe uma dor, ninguém procura terapia se não tivesse dor.
- Então essa pessoa, ela normalmente está para baixo, está nada anda na vida dela, não anda mesmo, porque conforme ela explora dor, ela precisa ficar nesse lugar, esse lugar não tem energia, a energia fica parada, ela fica estagnada, realmente nada tá dando certo na vida dela, é bem possível, tá?
- E aí de repente você identifica que ele tem um padrão cobrador muito grande, porque tudo ele vai lá para trás, tudo ele vai lá para trás, tudo ele conta uma coisa lá atrás, porque o meu e sempre a culpa é o de alguém, nunca dele, entende?
- Ou ele é o que precisa carbar, não deixa o filho ir, não deixa o relacionamento terminar, não deixa, porque ele fica conduzindo e manipulando tudo aquilo.
- Ninguém tem que perceber porque cada um tá cuidando da sua vida e a pessoa chega em terapia com essa dor e a gente precisa ajudando a desconstruir isso, tá?
- Aqui em alguns momentos tem algumas pessoas, né, aqui na dor, tá? quando quando tá na mandala da dor e quando a pessoa traz isso, que são as pessoas extremamente quando ela tá em dor manipuladoras, elas ela quer mexer as peças taboleira xadrez do jeito que ela quer, do jeito que ele quer.
- Isso vai ser terapeuta trazendo pro consciente e ajudando a atravessar, fazer essa travessia nesse processo que é difícil, porque ela sente que não vai ser amada, sente que naquilo vai existir um abandono, que em alguns momentos não existe, é ilusório, em alguns momentos é real, porque o outro tá ali só porque tá tendo um ganho também, né?
- No trabalho terapêutico, o dinheiro deixa de ser só matéria e passa a ser um espelho que mostra onde a energia do assistido precisa ser liberada, curada ou fortalecida.
- As pessoas que apanham e assumem para si, porque é tão enlouquecedor que assumem para si que é culpa delas. e que se elas não tivessem feito, não tivessem saído com aquela roupa, ela não teria apanhado, ele não precisaria bater.

## Conceitos-Chave Extraídos

- Então trouxe o conceito de todas as as variações do masculino e feminino e de todas as etapas da mandala do amor.
- Esse processo de resistência que vocês imprimem no campo energético, ele é cansado de iso ficar derrubando essas barreiras que vocês mesmos criam por conta da dor, tá?
- Então por isso eu vou começar na mandala da dor falando de eh da personalidade de dor.
- Então já pra gente ir quebrando o processo, eu quero que você esteja atento aos seus clientes, aos seus assistidos, né, como a gente chama aqui, aqueles que você vai atender, aqueles que você já atende em casos específicos, tá?
- Eu vou compartilhar com vocês aqui a minha tela pra gente então seguir na mandala da dor.
- Então tentem prestar atenção aqui, depois vocês tm esse material todo para para consultar e tem até mais do que o que eu vou trazer aqui, que é o que tá na parte de trás como orientação, como explicação, como apoio para você terapeuta na hora que você estiver atendendo o seu assistido.
- Então, primeiro conceito, depois a gente vai partir, vai pra parte prática no próximo momento.
- Então, a primeira, a mandalador, ela é dividida em algumas eh em algumas faixas.
- Então, mandalador é um campo invisível que ancora medos, memórias e crenças, um círculo de repetições internas que paralisa, sabota e pesa a vida.
- E aí de repente você identifica que ele tem um padrão cobrador muito grande, porque tudo ele vai lá para trás, tudo ele vai lá para trás, tudo ele conta uma coisa lá atrás, porque o meu e sempre a culpa é o de alguém, nunca dele, entende?
- Então, primeiro conce entende o conceito do cobrador, tá?
- Ou ele é o que precisa carbar, não deixa o filho ir, não deixa o relacionamento terminar, não deixa, porque ele fica conduzindo e manipulando tudo aquilo.
- É um campo invisível que encara medos, memórias e crenças, um círculo de repetição interna que paralisa, sabota e pesa a vida.
- Aqui em alguns momentos tem algumas pessoas, né, aqui na dor, tá? quando quando tá na mandala da dor e quando a pessoa traz isso, que são as pessoas extremamente quando ela tá em dor manipuladoras, elas ela quer mexer as peças taboleira xadrez do jeito que ela quer, do jeito que ele quer.
- É naquela situação, naquela dor específica, naquele momento específico, ele tá carregado naquela personagem, porque ele está cheio de fractais, ele está cheio de criações, que é o que a gente vai trabalhar no desfazimento no campo energético.
- Então, quantas vezes a pessoa precisa passar por por pela pelo pelo código?


## Técnicas, Procedimentos e Orientações Práticas

- Então, aquelas que não foram respondidas, até porque eu me comprometi em responder três, né? e também das perguntas que fazem sentido nesse momento em que a gente tá.
- Então, tô bem feliz com as que estão chegando, com aquelas que eu consigo identificar e responder, claro, de uma maneira de uma maneira simples, porque é um um espaço pequeno paraa elaboração, então não tem como fazer uma elaboração profunda, mas a gente vai ter aqui também espaços para vocês perguntarem, não vai ser ainda, tá?
- Então, vai ter uma grande união, um grande processamento de informação para você poder identificar e ajudar ainda mais o seu assistido, né?
- Então já pra gente ir quebrando o processo, eu quero que você esteja atento aos seus clientes, aos seus assistidos, né, como a gente chama aqui, aqueles que você vai atender, aqueles que você já atende em casos específicos, tá?
- Então, esse é um material para você terapeuta conseguir elaborar com os seus clientes, com seus assistidos, tá bom?
- Então tentem prestar atenção aqui, depois vocês tm esse material todo para para consultar e tem até mais do que o que eu vou trazer aqui, que é o que tá na parte de trás como orientação, como explicação, como apoio para você terapeuta na hora que você estiver atendendo o seu assistido.
- Então, primeiro conceito, depois a gente vai partir, vai pra parte prática no próximo momento.
- Então ele usa daquela dor, ele explora aquilo, ou uma doença física, ou a pobreza, ou ai como eu sofro com o seu pai, você não sabe o que eu passo, o meu trabalho é muito difícil, você não sabe o que eu vivo.
- Então a pergunta é de 0 a 10: o quanto você sente que precisa sofrer ou se diminuir para que a sua mãe fique por perto?
- Então a gente vai perguntar para essa pessoa: 0 a 10: quanto você sente que nunca viveu um relacionamento verdadeiro ou duradouro?
- No trabalho terapêutico, o dinheiro deixa de ser só matéria e passa a ser um espelho que mostra onde a energia do assistido precisa ser liberada, curada ou fortalecida.
- E tome isso para você como um uma jornada interior mesmo, um lugar de mais do que de chegar em algum lugar, mas um retorno pr pra casa, pra sua essência, para esse lugar incrível que é você que é o seu assistido, que é a pessoa que tá em dor, que é a pessoa que tá enfermizando, mas a pessoa precisa querer, né?
- Então depois eu assisti a aula com essas pinceladas que a gente colocou aqui, porque às vezes tá atendendo cliente, depois a gente vai ver como faz atendimento, tá atendendo o cliente, nossa, o que que era isso mesmo?
- Pr as próximas, porque a gente vai aprender a usar mesa, fazer as perguntas e identificar também coisas no inconsciente e aí vocês vão entender bastante coisa, tá bom, gente?


## Padrões Mentais, Defesas e Dinâmicas Recorrentes

- Então, mandalador é um campo invisível que ancora medos, memórias e crenças, um círculo de repetições internas que paralisa, sabota e pesa a vida.
- Eh, cada uma delas revela não só um padrão de comportamento, mas também o tipo de dor que está sendo carregada e o motivo pelo qual essa armadura foi construída, que é proteger-se da exclusão, garantir o amor e evitar o abandono.
- Não importa qual é o problema que ele trouxe, ele traz aquela dor e ele fala da dor dele e tudo que você fala nada resolve porque ele quer ficar, ele tem um ganho secundário, ele ganha com aquilo.
- Então ele usa daquela dor, ele explora aquilo, ou uma doença física, ou a pobreza, ou ai como eu sofro com o seu pai, você não sabe o que eu passo, o meu trabalho é muito difícil, você não sabe o que eu vivo.
- Então sempre de entender que existe uma dor, ninguém procura terapia se não tivesse dor.
- Então essa pessoa, ela normalmente está para baixo, está nada anda na vida dela, não anda mesmo, porque conforme ela explora dor, ela precisa ficar nesse lugar, esse lugar não tem energia, a energia fica parada, ela fica estagnada, realmente nada tá dando certo na vida dela, é bem possível, tá?
- E aí de repente você identifica que ele tem um padrão cobrador muito grande, porque tudo ele vai lá para trás, tudo ele vai lá para trás, tudo ele conta uma coisa lá atrás, porque o meu e sempre a culpa é o de alguém, nunca dele, entende?
- É um campo invisível que encara medos, memórias e crenças, um círculo de repetição interna que paralisa, sabota e pesa a vida.
- Ninguém tem que perceber porque cada um tá cuidando da sua vida e a pessoa chega em terapia com essa dor e a gente precisa ajudando a desconstruir isso, tá?
- Então a vida dele não anda, não destrava, porque ele tem esse processo de dependência, não consegue liberar, ele não consegue se autorizar fazer porque ele se vai sentir culpa ou ele não vai se sentir mais amado e aí é possível que as pessoas falam: "Nossa, enricou agora ficou metido".
- As pessoas que apanham e assumem para si, porque é tão enlouquecedor que assumem para si que é culpa delas. e que se elas não tivessem feito, não tivessem saído com aquela roupa, ela não teria apanhado, ele não precisaria bater.
- É naquela situação, naquela dor específica, naquele momento específico, ele tá carregado naquela personagem, porque ele está cheio de fractais, ele está cheio de criações, que é o que a gente vai trabalhar no desfazimento no campo energético.


## Citações e Formulações de Alta Densidade

- “Então a pergunta é de 0 a 10: o quanto você sente que precisa sofrer ou se diminuir para que a sua mãe fique por perto?”
- “Então sempre de entender que existe uma dor, ninguém procura terapia se não tivesse dor.”
- “Então essa pessoa, ela normalmente está para baixo, está nada anda na vida dela, não anda mesmo, porque conforme ela explora dor, ela precisa ficar nesse lugar, esse lugar não tem energia, a energia fica parada, ela fica estagnada, realmente nada tá dando certo na vida dela, é bem possível, tá?”
- “E aí de repente você identifica que ele tem um padrão cobrador muito grande, porque tudo ele vai lá para trás, tudo ele vai lá para trás, tudo ele conta uma coisa lá atrás, porque o meu e sempre a culpa é o de alguém, nunca dele, entende?”
- “Ou ele é o que precisa carbar, não deixa o filho ir, não deixa o relacionamento terminar, não deixa, porque ele fica conduzindo e manipulando tudo aquilo.”
- “Ninguém tem que perceber porque cada um tá cuidando da sua vida e a pessoa chega em terapia com essa dor e a gente precisa ajudando a desconstruir isso, tá?”
- “Aqui em alguns momentos tem algumas pessoas, né, aqui na dor, tá? quando quando tá na mandala da dor e quando a pessoa traz isso, que são as pessoas extremamente quando ela tá em dor manipuladoras, elas ela quer mexer as peças taboleira xadrez do jeito que ela quer, do jeito que ele quer.”
- “Então ó lá de 0 a 10, o quanto você sente que nunca tem tempo para si porque sempre está resolvendo o problema de alguém.”
- “No trabalho terapêutico, o dinheiro deixa de ser só matéria e passa a ser um espelho que mostra onde a energia do assistido precisa ser liberada, curada ou fortalecida.”
- “As pessoas que apanham e assumem para si, porque é tão enlouquecedor que assumem para si que é culpa delas. e que se elas não tivessem feito, não tivessem saído com aquela roupa, ela não teria apanhado, ele não precisaria bater.”
- “Quando você acredita que só poderá ter paz se todos ao seu redor estiverem curados, porque você é o lixo, você é o causador da dor de todo mundo.”
- “E tome isso para você como um uma jornada interior mesmo, um lugar de mais do que de chegar em algum lugar, mas um retorno pr pra casa, pra sua essência, para esse lugar incrível que é você que é o seu assistido, que é a pessoa que tá em dor, que é a pessoa que tá enfermizando, mas a pessoa…”

## Conexões com a Wiki

- [[Conceito da Mesa HumanoSense]]
- [[Conceito da Polaridade Masculino e Feminino]]
- [[Conceito do Equilíbrio do Dar e Receber]]
- [[Principio da Liberdade Consciente]]
- [[Principio de Lugar Funcao e Potencia]]
- [[Conceito de Matar o Pai e a Mae]]
- [[Conceito de Personagens da Dor]]
- [[Tecnica de Identificacao da Raiz na Anamnese]]
- [[Conceito do Divorcio Energetico]]
- [[Conceito do Parceiro da Missao]]

## Segunda Passada

Na segunda leitura, esta aula foi tratada como parte de uma sequência contínua: os conceitos foram ligados às notas estruturais existentes, e os blocos acima funcionam como trilha de auditoria para voltar ao ponto da fala sem depender apenas de uma síntese curta. Onde houver dúvida interpretativa, prevalece a fonte integral arquivada.

## Referência

ANDRESA MOLINA. *Aula 03 - Código Humanosense*. Transcrição integral do Curso Código Humanosense. Fonte arquivada em [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]. Ingestão revista em 2026-06-19.


## FAQs para NotebookLM (Fase 2)

### Bloco 1: A Estrutura da Mandala da Dor e o Ego Defensivo
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
1. Como Andresa Molina descreve a "Mandala da Dor" e quais são as seis faixas ou divisões que a compõem graficamente?
2. Qual é a função biológica e social do ego na formação da identidade e de que forma o egoísmo atua como sua doença?
3. Como a personalidade do assistido se molda de maneira defensiva quando aliada à dor, ao medo e ao instinto de proteção?
4. Quais são as três necessidades humanas básicas no inconsciente que motivam a construção das armaduras de defesa (personalidades de dor)?

### Bloco 2: As Personalidades de Dor: Explorador, Cobrador e Limitador
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
5. O que caracteriza a personalidade do "Explorador da Dor" e como ele utiliza doenças físicas ou pobreza para obter ganhos secundários?
6. Por que Andresa Molina afirma que o Explorador é um sugador de energia que puxa a vibração do ambiente "para baixo"? Como o terapeuta deve agir?
7. Como a personalidade do "Cobrador da Dor" mantém as pessoas presas ao passado? De que maneira vibrar em dívida afeta a prosperidade material?
8. De que forma o "Limitador da Dor" utiliza o pretexto do cuidado como contenção para bloquear a evolução de seus familiares e amigos?

### Bloco 3: Personagens em Dor e o Mecanismo de Fuga
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
9. Qual é a diferença na atuação somática e psíquica entre a essência e o personagem quando cristalizado como armadura de sobrevivência?
10. O que caracteriza o "Príncipe ou Donzela" na Mandala da Dor e qual é o erro ilusório em acreditar que "aquele que feriu será quem irá curar"?
11. De que maneira o "Guerreiro ou Guerreira" adoece ao lutar em confrontos cegos sem saber qual é a causa ou a batalha real a ser travada?
12. O que caracteriza a "Rainha Má ou Rei Governador Corrupto" e qual é a diferença entre manipular pelo bem do reino do lar ou pelo egoísmo?

### Bloco 4: O Campo Emocional e a Dinâmica do Relacionamento
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
13. O que caracteriza o "Dependente Emocional" e por que ele se sabota para não deixar amigos ou familiares para trás em sua ascensão?
14. Como o perfil do "Preocupado Emocional" sabota o seu próprio progresso usando demandas e problemas de terceiros para não encarar sua própria dor?
15. Como a autora classifica os três perfis de travamento nos relacionamentos amorosos (Perdido, Inconstante, Solitário) e de que forma eles refletem a biologia das polaridades?

### Bloco 5: Lixo Emocional e Identidade: Eu Sou vs. Eu Me Sinto Lixo
Responda com base estritamente no texto fornecido. Sempre que possível, utilize as metáforas e termos literais da autora. Caso um detalhe não conste, declare. Inclua citações textuais entre aspas. Explique a nível somático.
16. De que forma a crença de identidade profunda "Eu Sou um Lixo" somatiza-se fisicamente no corpo do assistido, levando-o a se decompor e gerar doenças graves?
17. Qual é a diferença somática e financeira entre a crença interna "Eu Sou um Lixo" e a reação externa "Eu Me Sinto um Lixo"?
18. Como Andresa Molina descreve o perfil do "Salvador Lixeiro" e por que ele confunde a própria exaustão corporal severa com amor?
19. Por que o tratamento terapêutico eficiente exige desarmar as lealdades do lixeiro, deixando-o temporariamente "sem nenhum problema" alheio para que ele encare sua essência?
20. Como o terapeuta Humanosense pode utilizar o pêndulo e as perguntas de 0 a 10 para identificar as contradições entre a narrativa do assistido e a verdade de seu campo inconsciente?
