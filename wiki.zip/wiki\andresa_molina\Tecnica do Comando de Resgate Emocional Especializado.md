---
type: technique
author: Andresa Molina
tags: [comando-especializado, resgate-emocional, bloqueio-astral, egrégora-direcionada]
sources: ["[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"]
---

# Comando de Resgate Emocional Especializado (A dissolução dos obstáculos na cena)

- **Definição**: O uso da convocação cirúrgica no momento em que a entidade que feriu o paciente (ex: o holograma do pai) não consegue se curar por ter um "coração de pedra". O terapeuta invoca equipes focadas na dissolução magnética para amolecer a situação e promover o perdão mútuo no plano sutil.
- **Como praticar e seu Propósito**:
  1. **Diagnosticar o Bloqueio Astral**: Na Câmara, se o paciente relata que a figura agressora "não deixa eu chegar lá. O coração dele parece que tem uma pedra", o terapeuta detecta a resistência estrutural do cenário.
  2. **Decreto Direcionado**: Invocar a presença especializada sob autoridade do Eu Sou: "Em nome da minha amada presença de Deus... eu invoco a presença de todas as entidades com habilidade, disponibilidade e autorização... Quem que pode chegar aí e ajudar?".
  3. **Direcionamento de Frequência**: Chamar a equipe vibracional correspondente (ex: a egrégora Cigana para afeto amoroso): "A energia das ciganas é esse. Isso. Deixa elas trabalharem, potencializarem a força... que conseguem de alguma maneira entrar em corações duros".
  O propósito é desbloquear o cenário congelado, liberando a paciente da culpa sistêmica de não conseguir "salvar" seus pais agressores, entregando o destino deles à equipe de luz.
- **Evidências**: "O coração dele parece que tem uma pedra lá... Eu não consigo deixar de me sentir impotente e de ficar triste por não conseguir ajudar. >> Você quer ajudar ele? ...Em nome da minha amada presença de Deus... eu invoco a presença de todas as entidades com habilidade, disponibilidade e autorização... Deixa entrar quem tem aí. Quem que pode chegar aí e ajudar? ...A energia das ciganas é esse. Isso. Deixa elas trabalharem, potencializarem a força para sua mãe, das mulheres amorosas, fortes, mas que conseguem de alguma maneira entrar nos em corações duros."
- **Conexões**: [[Tecnica do Comando de Intervencao Especializada]], [[Conceito de Entidades de Resgate vs Especialistas]]

## Perguntas Frequentes / Didática de Atendimento

### 20. Como o terapeuta opera o resgate quando a figura na Câmara apresenta uma resistência de "coração de pedra"?
**Resposta**: Quando a paciente relata impotência porque o pai **"não deixa eu chegar lá. O coração dele parece que tem uma pedra lá"**, o terapeuta atua não forçando a própria energia, mas invocando a egrégora correspondente para quebrar essa rigidez.

O terapeuta decreta: **"Em nome da minha amada presença de Deus... eu invoco a presença de todas as entidades com habilidade... Quem que pode chegar aí e ajudar?"**. A nível somático e vibracional, o terapeuta percebe a necessidade de uma força de amor e convoca a **"energia das ciganas"**. Ele determina que elas atuem na psique do holograma: **"Deixa elas trabalharem, potencializarem a força para sua mãe, das mulheres amorosas, fortes, mas que conseguem de alguma maneira entrar nos em corações duros"**. Isso alivia o corpo da paciente, que não precisa mais gastar sua biologia tentando curar a rigidez do pai, sentindo-se **"melhor, mas tranquila"**.


## Referencia

ANDRESA MOLINA. *Comando de Resgate Emocional Especializado*. Aula 09 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]].
