---
type: tecnica
author: Andresa Molina
tags: [diagnostico, pendulo, consciente-inconsciente, radiestesia, alinhamento]
sources: ["[[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]]"]
---

# Técnica de Diagnóstico de Alinhamento Consciente-Inconsciente

- **Definição**: O procedimento clínico que confronta a resposta verbal racional do assistido (consciente) com a medição vibracional na mesa através do pêndulo (inconsciente), localizando os desalinhamentos.
- **Justificativa**: O assistido frequentemente mente para si mesmo ou é inconsciente dos seus traumas (os '95% da mente'). Esse teste clínico escancara o gap energético, desarmando a máscara do ego.
- **Evidências**: "Você vai escolher a pergunta de zero a 10... o consciente aqui na sua folha... O que ela respondeu, você vai colocar no consciente [...] vai vir aqui com o pêndulo... E aí o inconsciente dela vai responder [...] O que que você consegue entender? Onde tá o gap de entendimento dela? [...] Ela acredita que ela faz uma coisa, ela está iludida [...] o seu consciente, seu inconsciente estarem alinhados."
- **Implicações**: O terapeuta deve selecionar perguntas dicotômicas correspondentes nas pétalas masculinas e femininas (ex: a primeira de cada na pétala selecionada) para cruzar dados e apresentar as contradições sem julgamento.
- **Conexões**: [[Tecnica de Rastreio Quantitativo de 0 a 10]], [[Principio da Identidade Vibracional]]
- **Notas Pessoais**: Confrontar esse descompasso tira a pessoa da ilusão intelectual, iniciando a travessia de cura.

## Referencia

ANDRESA MOLINA. *Técnica de Diagnóstico de Alinhamento Consciente-Inconsciente*. Aula 04 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/04   Código Humanosense - Andresa Molina.md]].
