---
type: principio
author: Andresa Molina
tags: [mandala-da-dor, personalidade, personagem, emocional, lixo-emocional]
sources: ["[[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio da Mandala da Dor

- **Definição**: O campo estrutural invisível que ancora medos, memórias e crenças, formando um círculo de repetições internas que paralisa, sabota e pesa a vida do assistido.
- **Justificativa**: A Mandala da Dor funciona como um mapa defensivo do ego que organiza as defesas do assistido contra a exclusão, o abandono ou a falta de amor. Compreendê-la é crucial para desarmar os padrões repetitivos antes de acessar a essência do paciente.
- **Evidências**: "Então, mandalador é um campo invisível que ancora medos, memórias e crenças, um círculo de repetições internas que paralisa, sabota e pesa a vida. [...] Cada uma delas revela não só um padrão de comportamento, mas também o tipo de dor que está sendo carregada e o motivo pelo qual essa armadura foi construída, que é proteger-se da exclusão, garantir o amor e evitar o abandono. No fundo, a personalidade não é o problema, ela é uma resposta inconsciente a algo que doeu demais."
- **Implicações**: O terapeuta deve utilizar as divisões da mandala (Personalidade, Personagem, Emocional, Relacionamento, Dinheiro, Lixo) para identificar qual armadura reativa o assistido está utilizando no momento para manipular ou compensar a dor.
- **Conexões**: [[Conceito de Explorador Limitador e Cobrador]], [[Conceito de Personagens da Dor]], [[Conceito de Lixo Emocional]]
- **Notas Pessoais**: A Mandala da Dor é o exato contraponto à Mandala do Amor, mapeando o egoísmo e o medo em vez de expansão e nutrição.

## Referencia

ANDRESA MOLINA. *Princípio da Mandala da Dor*. Aula 03 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]].
