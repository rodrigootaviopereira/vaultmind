---
type: conceito
author: Andresa Molina
tags: [cura, tratamentos-energeticos, alivio, raiz, 7a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito de Cura-Raiz vs. Alívio Analgésico (Tratamento Energético Superficial)

- **Definição Precisa**: A distinção clínica entre processos que mitigam temporariamente a dor física ou emocional (Alívio Analgésico, incluindo a maioria das terapias verbais ou alinhamentos energéticos superficiais como o Reiki) e a erradicação definitiva da egrégora do problema em sua causa geracional ou de alma profunda (Cura-Raiz).
- **Sinônimos/Variações**: Cura Efetiva vs. Analgésico Energético.
- **Contexto de Uso**: Utilizado em consultas para analisar a rastro de tratamentos anteriores do assistido e explicar por que certas dores ou conflitos sempre retornam após um período de melhora temporária.
- **Relação com Princípios**:
  - [[Principio da Causa Inconsciente e da Reconsolidacao]]
  - [[Principio da Memoria Celular vs Lembranca]]
  - [[Principio da Proporcao Inconsciente]]
- **Exemplos do Material**:
  - *"O que importa é que você não desistiu de si. E tudo isso que você buscou, que você tentou para se curar... O que melhorou e o que voltou? Porque às vezes teve uma melhora temporária, mas voltou. Então não curou. Foi só um analgésico para dor de cabeça, mas a causa continuou lá."*
  - *"Energético não é cura. Energético é alívio e é bom. Mas quando a gente vai na causa, na raiz do problema, seja ela nesta vida, em outra vida, no plano espiritual ou numa camada ancestral muito profunda... você pode curar..."*
- **Aplicação Prática**:
  1. **Anamnese Diagnóstica**: Aplicar a [[Tecnica de Rastreamento da Cura Incompleta]] identificando quais buscas do paciente foram "analgésicos" lógicos/sutis.
  2. **Quebra da Hipnose do Alívio**: Orientar o assistido de que o Reiki ou a harmonização sutil são excelentes para a estabilização temporária, mas não removem a trilha epigenética de dor.
  3. **Acesso à Causa Primária**: Guiar o paciente através do Mapa da Alma à raiz ancestral do problema (ex: miséria ou violência sistêmica) para aplicar a reconsolidação definitiva.

## Conexões Externas

- [[Conceito de Ressignificacao vs Reconsolidacao]]
- [[Conceito da 7a Coordenada]]

## Referência

ANDRESA MOLINA. *Conceito de Cura-Raiz vs. Alívio Analgésico (Tratamento Energético Superficial)*. Aula 07 - Coordenada 7 (A Cura Buscada em Todo Lugar). Fontes: [[raw/archive/andresa_molina/transcriptions/07 - A Cura Buscada em Todo Lugar 7ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. Segundo o texto, por que o uso de alívios energéticos superficiais (como "harmonizaçãozinha" ou Reiki) funciona apenas como "analgésico" temporário e não resolve a causa raiz dos problemas nas camadas profundas?
**Resposta**: O texto aponta que o uso dessas práticas falha em trazer cura definitiva porque elas atuam apenas na superfície do sintoma. Andresa é taxativa: "Energético não é camada profunda. Energético não é cura. Energético é alívio e é bom".

A nível somático, quando o indivíduo tenta controlar seus gatilhos "só com um alívio energético, ai com uma harmonizaçãozinha ou com um heake [Reiki]", ele aplica um remédio paliativo: "Foi só um analgésico para dor de cabeça, mas a causa continuou lá". O problema não é resolvido porque essas energias amorosas "não vai na raiz, na causa do problema, lá aonde tudo começou". A verdadeira "raiz" está alocada profundamente nas células, nas memórias herdadas desde "quando o corpo... está sendo feito na barriga da sua mãe". Enquanto o terapeuta não descer nessas camadas somáticas e ancestrais para transmutar o gatilho celular original, o analgésico passará e a dor "voltou".

