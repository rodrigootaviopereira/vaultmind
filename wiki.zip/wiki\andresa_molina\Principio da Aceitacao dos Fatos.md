---
type: principio
author: Andresa Molina
tags: [fatos, ilusao, aceitacao, maturidade, realidade]
sources: ["[[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio da Aceitação dos Fatos (A vida como ela é e a desconstrução das ilusões sobre o passado)

- **Definição**: A premissa clínica e existencial de que a cura requer a aceitação inegociável de que a realidade física e o comportamento dos outros são fatos inalteráveis, e não moldes adaptáveis aos nossos desejos infantis de controle.
- **Justificativa**: O sofrimento humano e o adoecimento crônico nascem da luta constante contra a realidade. A mente do assistido em dor drena sua energia vital tentando consertar o passado ou exigindo explicações racionais de por que seus pais, parceiros ou patrões agem de determinada forma. A cura no HumanoSense ocorre puxando a consciência do plano da ilusão ("invenções sobre os fatos") para a aceitação crua do "fato duro". Aceitar que "as rosas têm espinhos" é o primeiro passo para o indivíduo assumir a autoria do seu próprio caminho a partir da realidade material.
- **Evidências**: "Quando eu sempre falo que a vida é como é, não como eu quero que ela seja, a gente precisa entender que eu tô falando de fatos. Então, eu não queria que a minha mãe fosse desse jeito, mas ela é. Isso é um fato. Eu não queria ter perdido emprego, mas você perdeu. Isso é um fato... Eu não queria que as rosas tivessem espinhos, mas elas têm. E isso é um fato... Então a vida é como é? É sobre fatos. É sobre não querer criar uma invenção em cima de fatos. É olhar pro fato e a partir do fato ver o que eu posso fazer."
- **Implicações**: O terapeuta deve confrontar as defesas infantis do assistido que buscam justificar ou mudar fatos consumados. A sessão deve transicionar a postura da queixa e dor para a decisão do adulto sobre o que fazer com os fatos reais.
- **Conexões**: [[Conceito de Aconteceu vs Acontece]], [[Conceito de Matar o Pai e a Mae]], [[Conceito do Mapa da Alma]]
- **Notas Pessoais**: Aceitar a realidade liberta o fluxo criativo para semear uma nova realidade.

## Perguntas Frequentes / Didática de Atendimento

## Perguntas Frequentes / Didática de Atendimento

### 5. Como Andresa Molina descreve o "Princípio da Aceitação dos Fatos" e qual a relação clínica entre a briga contra a realidade e o adoecimento crônico?
**Resposta**: Andresa Molina descreve o princípio da aceitação decretando que **"a vida é como é? É sobre fatos"**. A aceitação consiste na maturidade de **"não querer criar uma invenção em cima de fatos. É olhar pro fato e a partir do fato ver o que eu posso fazer"**.

A nível somático e biológico, não aceitar a realidade (a "briga" contra o que é natural) desencadeia consequências e dores diretamente no corpo do assistido. A autora exemplifica a tolice dessa resistência com a biologia e as patologias físicas: **"Eu não queria que as rosas tivessem espinhos, mas elas têm... Eu não queria que o urso de pelúcia me desse rinite, mas ele te dá. E isso é um fato. Eu não queria ter dor nas costas, mas você tem"**. A relação clínica que rege o adoecimento e o sofrimento é justamente a recusa do assistido em encarar os atritos inevitáveis da matéria, preferindo fugir da realidade a assumir que, se não quer lidar com as consequências orgânicas, deve escolher outra semente para a sua vida: **"Toda rosa tem espinho. Ah, mas eu não quero espinha, então não planta rosa, colega. Planta outra coisa"**.

## Referencia

ANDRESA MOLINA. *Princípio da Aceitação dos Fatos*. Aula 06 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]].
