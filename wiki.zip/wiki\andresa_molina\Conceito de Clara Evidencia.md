---
type: conceito
author: Andresa Molina
tags: [mediunidade, sensibilidade, clara-evidencia, decodificacao, 6a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]]"]
---

# Conceito de Clara Evidência

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]]

## Definição Precisa

- **Definição**: A Clara Evidência é a capacidade de perceber, sentir e decodificar com clareza as frequências energéticas, intenções ocultas de pessoas e egrégoras de ambientes, utilizando como guia sensorial a resposta sutil do corpo físico (em especial a região do peito). Ela difere da vidência tradicional (ver formas espirituais) e da audiência (ouvir vozes), pois baseia-se na autoridade da resposta interna, permitindo ao indivíduo identificar o real campo por trás de aparências inofensivas ou lógicas.
- **Formulação de apoio**: Andresa pontua que a mera vidência não é suficiente para o discernimento espiritual, pois obsessores ou pessoas mal-intencionadas podem assumir faces angélicas ("anjos de luz") para enganar a mente visual. A clara evidência, contudo, bura a ilusão ótica: ao sintonizar a vibração interna do corpo, o indivíduo sente "o negócio apertar" ou repuxar, permitindo decodificar a real densidade daquela presença e agir de forma assertiva.

## Contexto de Uso

- Essencial na anamnese e na condução de processos de desobsessão e desipnose de fractais, permitindo ao terapeuta guiar o assistido a discernir entre reações emocionais próprias e captações externas do ambiente ou de terceiros.

## Relação com Princípios

- [[Principio do Chamado da Sensibilidade]]
- [[Principio do Respeito a Tecnica e a Equipe Espiritual]]
- [[Principio da Responsabilidade Espiritual]]

## Exemplos do Material

- *"Ter vidência não quer dizer nada. Você precisa ter clara evidência. Ter audiência, ouvir, não é nada... ter sensibilidade, você tem, você precisa ter a sensibilidade com clareza para você conseguir decodificar o que você sente... clara evidência é quando você vê e consegue decodificar a partir do seu sentir que aquilo pode ter cara de anjo. Só que você sabe que ali dentro é uma coisa ruim."*

## Aplicação Prática

1. **Acessar a Resposta do Peito**: Diante de dúvidas relacionais ou profissionais, orientar o assistido a fechar os olhos e consultar a "resposta do peito" (Respeito) em vez de raciocinar mentalmente.
2. **Decodificação de Sintomas Repentinos**: Ao sentir dores físicas bruscas (enjoo, dor de cabeça, irritação) após um diálogo ou entrada em novo espaço, parar e usar a clara evidência para identificar de quem é a captação original.
3. **Desativação de Ilusões Estéticas**: Treinar o terapeuta a não julgar o campo do assistido apenas pela fala mansa ou visual social "bonzinho", detectando a raiz energética real na Mesa ou Câmara do HumanoSense.

## Conexões Externas

- [[Conceito da Sensibilidade como Valor e Dinheiro]]
- [[Tecnica de Conexao com a Equipe Espiritual]]
- [[Tecnica de Identificacao da Carecia e Cuidado]]

## Referência

ANDRESA MOLINA. *Conceito de Clara Evidência*. Aula 06 - Coordenada 6 (O Chamado Ignorado). Fontes: [[raw/archive/andresa_molina/transcriptions/06 - O Chamado Ignorado 6ª Coordenada - O Mapa da Alma.md]].

## Perguntas Frequentes / Didática de Atendimento

### 1. Qual é a diferença clínica e diagnóstica explicada por Andresa Molina entre possuir apenas "vidência/audiência" (fenômenos visuais e auditivos) e possuir "clara evidência/clara audiência"?
**Resposta**: A diferença fundamental reside na capacidade somática de decodificação. 
*   **Vidência/Audiência (O Fenômeno Isolado):** Possuir apenas vidência ou audiência significa que o indivíduo capta o estímulo através do canal visual ou auditivo, mas sem o discernimento vibracional. A autora explica que *"Ter vid[ência] [...] significa que você vê, só que você vê uma coisa boa, uma coisa ruim"*. O perigo clínico disso é a ilusão, pois a forma visual pode ser enganosa. Da mesma forma, *"Ter audiência, ouvir, não é nada"*.
*   **Clara Evidência/Clara Audiência (A Decodificação Somática):** É a integração do estímulo (visual ou auditivo) com o **"sentir"** do corpo. A clara evidência atua como um diagnóstico preciso porque o corpo físico da pessoa não se deixa enganar pela forma visual. A autora define que *"Clara evidência é quando você vê e consegue decodificar a partir do seu sentir"*. Ou seja, o indivíduo não apenas enxerga a energia, mas sente no próprio corpo a verdadeira intenção e densidade daquela vibração, garantindo a *"clareza para você conseguir decodificar o que você sente"*.

### 2. Como a "clara evidência" baseada no sentir corporal e na resposta do peito permite ao terapeuta identificar a real densidade espiritual de pessoas que se disfarçam sob aparências ou narrativas de "anjos de luz"?
**Resposta**: Embora o termo literal "obsessores" não conste neste documento, Andresa alerta que, no mundo espiritual e físico, a aparência visual é facilmente manipulável: existem *"pessoas fofas com aquela carinha de anjo de luz, os olhinhos claros, de anjinho"*, ou ainda *"gente aí com aquela cara de fofa, de anjo de luz, cominho clarinho, parece um santo"*.

Se a pessoa tiver apenas "vidência", ela será enganada pela estética angelical. No entanto, através da **clara evidência**, o terapeuta acessa a verdade porque o corpo físico não mente na captação de densidade. Mesmo que os olhos físicos ou espirituais vejam um "anjo", o corpo somatiza o alerta. A autora questiona: *"Cão, como é que você vai saber? Decodificando a partir do seu sentido"*. É através do incômodo e da leitura sensorial do próprio corpo que o indivíduo *"sabe que ali dentro é uma coisa ruim"*, permitindo identificar *"Pessoas encarnadas que estão conectadas com os desencarnados"* disfarçados de luz.

### 3. No caso prático citado por Andresa, de que maneira um diálogo aparentemente harmonioso com uma pessoa racional ativou dores físicas bruscas (dor de cabeça, enjoo, irritação) em ambas e como a decodificação da frequência externa desarmou esses sintomas?
**Resposta**: Embora o termo literal "egrégora externa" não conste no documento, o caso ilustra perfeitamente a somatização por captação involuntária de uma frequência ou energia alheia. Andresa e uma pessoa "muito racional" estavam *"super bem... conversando, fazendo um movimento ali muito bacana"*. No entanto, ao mencionarem um determinado assunto, o corpo físico de ambas colapsou *"do nada, entre aspas"*, somatizando bruscamente sintomas intensos: *"Começou a dar uma dor de cabeça, começou a dar uma dor de estômago, começou a dar um enjoo"* e irritação.

A nível somático, isso ocorreu porque elas *"acessaram a energia de uma pessoa"* e o corpo delas passou a **"sentir o que ela [a terceira pessoa] tava sentindo"** (que era medo, angústia, raiva e nojo). 

Para desarmar esses sintomas e dores corporais, Andresa utilizou a decodificação da frequência (aplicando o Princípio da Consciência que Cura). Ela fez a pergunta-chave de rastreio: *"O que que nós fizemos que mudou essa frequência?"*. Ao analisar o assunto e decodificar racionalmente de onde a energia invasora veio, o sistema nervoso entendeu que aquele peso não pertencia a elas. A autora explica o efeito somático imediato dessa compreensão: *"Quando você passa a transmutar essa energia [...] ela começa a esvaziar esse esse peso e volta o equilíbrio do corpo"*, desarmando as dores e a irritação.

