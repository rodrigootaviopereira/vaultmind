---
type: conceito
author: Andresa Molina
tags: [rainha, rei, integracao, lideranca]
sources: ["[[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]"]
---
# A Soberania do Rei/Rainha (A Fusão Protagonista)

- **Definição Precisa**: O estado integrado de protagonismo alcançado pela fusão da força de defesa do Guerreiro com a pureza e a doçura do sonho da Donzela.
- **Sinônimos/Variações**: Soberania Interior, Estado de Rei/Rainha, Protagonismo Integrado
- **Contexto de Uso**: Cura da reatividade e empoderamento consciente do assistido perante seu próprio destino.
- **Relação com Princípios**: [[Principio da Fusao Criacional]], [[Principio de Lugar Funcao e Potencia]]
- **Exemplos do Material**: "Quando eu tenho a Dosell e a guerreira, o príncipe e o guerreiro unidos que mantém o sonho e vai pr pra batalha... eu vou ser o rei ou a rainha. A rainha do lar ou a rainha do reino... A rainha integra a força da guerreira com a visão da donzela. Ela não luta por sobrevivência, nem se perde em ilusões. A rainha é o sol da própria galáxia, centrada, consciente, soberana no seu trono interior."
- **Aplicação Prática**: Reunir o sonho (Donzela) e a ação (Guerreiro) para assumir as rédeas da própria vida, agindo com diplomacia e firmeza.
- **Conexões Externas**: [[Conceito de Macho e Femea Alfa]]

## Perguntas Frequentes / Didática de Atendimento

**Pergunta 19: Como se dá a fusão soberana do "Rei ou Rainha" no trono interior e de que maneira ela integra a força letal da espada do Guerreiro com a magia e "malemolência" da Donzela?**

A fusão soberana ocorre "Quando eu tenho a Dosell e a guerreira, o príncipe e o guerreiro unidos que mantém o sonho e vai pr pra batalha para a realização do seu sonho". 

A nível de integração arquetípica, o Rei/Rainha governa porque domina as duas polaridades sem se tornar refém de nenhuma. A autora explica que essa soberania "integra a força da guerreira com a visão da donzela. Ela não luta por sobrevivência, nem se perde em ilusões". Na prática relacional, a Rainha sabe transitar perfeitamente: "ela sabe onde ela tem que guerrear e ela sabe onde ela tem que jogar o charme". Ela funde a contundência com a sedução energética, usando "Dosçura, jeito, malemolência, né? Encantamento para lidar com aquilo... E ao mesmo tempo força para ir em busca", tornando-se "o sol da própria galáxia, centrada, consciente, soberana no seu trono interior".

## Referencia

ANDRESA MOLINA. *A Soberania do Rei/Rainha (A Fusão Protagonista)*. Aula 02 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]].
