---
type: principio
author: Andresa Molina
tags: [ancestralidade, autoabandono, amor-condicionado, 2a-coordenada]
sources: ["[[raw/archive/andresa_molina/transcriptions/02 - O AMOR QUE NUNCA VOLTOU - 2ª Coordenada - O Mapa da Alma.md]]"]
---

# Princípio do Amor Condicionado e Autoabandono

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/transcriptions/02 - O AMOR QUE NUNCA VOLTOU - 2ª Coordenada - O Mapa da Alma.md]]

## Definição

- **Definição**: O Princípio do Amor Condicionado estabelece que a ferida emocional de abandono, traição ou rejeição na vida adulta decorre do aprendizado infantil de que o amor e a aceitação dos pais/cuidadores dependiam de regras e exigências de conduta específicas (como ser "boazinha", calada ou obediente). Para garantir a sobrevivência e o pertencimento ao sistema, a criança reprime a própria essência, configurando o **Autoabandono** — a origem primária da autossabotagem e da sensação de desvalor.
- **Formulação de apoio**: O autoabandono pessoal sintoniza a pessoa na frequência vibracional de abandono. Inconscientemente, ela emana essa frequência e atrai relações e situações onde é usada, traída ou deixada para trás por parceiros, amigos ou empregadores.

## Justificativa

- É uma regra essencial no HumanoSense porque demonstra que o sofrimento por abandono não é uma questão de "azar" ou "karma injusto". O outro apenas atende ao comando interno de abandono que o próprio assistido executa contra si mesmo todos os dias para pertencer ou agradar.

## Evidências

- *"Se você aprendeu que amor é algo que você precisa merecer para receber, se você aprendeu que amor é algo que você precisa se esforçar para ter, porque senão você perde... você registrou como falta de amor. Isso aconteceu com você, isso aconteceu com a sua mãe, isso aconteceu com a sua avó..."*
- *Exemplo da prima "rebelde" vs "boazinha"*: A assistida cresceu sendo elogiada por ser "boazinha", comportada e não incomodar, enquanto a prima rebelde apanhava e era rejeitada pela família. Para reter o afeto da avó e tias, ela aprendeu a calar os próprios desejos, não reclamar e fazer tudo pelos outros (Amor Condicionado), gerando um autoabandono crônico na vida adulta.
- *"Se você emitiu a frequência de abandono, que é o que você fez com você, você emanou essa frequência, essa vibração... o outro só está respondendo ao seu comando interno. Você se abandonou. Quando você se abandonou, você vibrou o abandono."*

## Implicações

- **Desativação do Agrade Compulsivo**: O assistido deve compreender que tentar merecer ou "comprar" o amor através de agradar a todos de forma excessiva é um reforço da ferida original do Amor Condicionado e perpetua o autoabandono.
- **Reconexão com o Eu Sou**: O processo de cura consiste em aprender a sustentar a própria autenticidade (usando a força do Masculino/Feminino equilibrados) mesmo sob o risco de desobedecer ou desagradar as expectativas externas.

## Conexões

- [[Conceito do Sistema FER]]
- [[Tecnica de Mapeamento do Amor Condicionado]]
- [[Conceito das Camadas da Dor]]
- [[Principio da Automagia e Autoabandono Feminino]]

## Notas Pessoais

- Reservado para observações do usuário.

## Referência

ANDRESA MOLINA. *Princípio do Amor Condicionado e Autoabandono*. Aula 02 - Coordenada 2 (O Amor que Nunca Voltou). Fontes: [[raw/archive/andresa_molina/transcriptions/02 - O AMOR QUE NUNCA VOLTOU - 2ª Coordenada - O Mapa da Alma.md]].
