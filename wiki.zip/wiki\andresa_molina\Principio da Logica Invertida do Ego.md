---
type: principio
author: Andresa Molina
tags: [logica-invertida, ego-do-terapeuta, autossabotagem, confianca-clinica, estagio]
sources: ["[[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio da Lógica Invertida do Ego (A desconstrução da necessidade do cliente)

- **Definição**: O diagnóstico cirúrgico da ilusão profissional onde o terapeuta iniciante mente para si mesmo acreditando que "precisa ter clientes pagantes" para finalmente "ganhar confiança", invertendo a ordem orgânica do magnetismo, que exige que a confiança venha antes da venda.
- **Justificativa**: A nível energético, o universo não entrega responsabilidades a quem não suporta a própria estrutura. A autora destrói a narrativa da terapeuta que deseja "materializar clientes" para sentir-se segura. O cliente é quem precisa de ajuda. Se a terapeuta quer o cliente apenas para usá-lo como "muleta" para a sua própria autovalidação (para ele provar que ela é boa), o campo quântico repele a atração. O dinheiro é apenas uma "resposta de um posicionamento" interno de quem se assume e sabe que sabe fazer.
- **Evidências**: "Você só vai ter clientes quando se sente segura, certo? Né? E você tá querendo ter cliente para ele pagar para que você se sinta segura. Então você não tá fazendo para ele, mas sim para você. E a terapeuta é para o outro. Então ele paga para você ajudar ele e não, ele paga para ele ajudar você. Percebe que tá invertido a lógica? ...Eu primeiro tenho que trabalhar em mim a minha autoestima e a minha confiança para depois então poder ajudar o outro."
- **Implicações**: Focar primeiro na cura pessoal da insegurança e realizar atendimentos de estágio antes de cobrar valores profissionais cheios.
- **Conexões**: [[Principio do Posicionamento de Valor]], [[Tecnica da Anamnese por Desconstrucao]]
- **Notas Pessoais**: Cobrar do cliente a função de nos dar segurança é uma violação do contrato terapêutico de neutralidade.

## Perguntas Frequentes / Didática de Atendimento

### 2. De que maneira a inversão de lógica sabota o terapeuta iniciante que condiciona a atração de clientes pagantes à conquista de sua autoconfiança?
**Resposta**: Essa inversão sabota o terapeuta porque ele tenta usar o cliente como uma "muleta" para curar a própria insegurança. O paciente relata o autoengano: "só me vou sentir terapeuta quando eu tiver mais clientes e e ganhar mais confiança".

A autora desmascara essa autossabotagem mostrando que o fluxo energético está corrompido: "você inverteu o processo, você só vai ter clientes quando se sente segura... E você tá querendo ter cliente para ele pagar para que você se sinta segura". A nível somático e magnético, a egrégora de cura repele o terapeuta porque a intenção dele é egoísta ("você não tá fazendo para ele, mas sim para você"). A lei orgânica do atendimento exige que o terapeuta primeiro trabalhe "a minha autoestima e a minha confiança para depois então poder ajudar o outro".


## Referencia

ANDRESA MOLINA. *Princípio da Lógica Invertida do Ego*. Aula 09 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/09   Código Humanosense - Andresa Molina.md]].
