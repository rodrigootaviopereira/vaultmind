---
type: conceito
author: Andresa Molina
tags: [lixo-emocional, magoa, cobrador, prosperidade, externo]
sources: ["[[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]]"]
---

# Conceito de Eu Me Sinto Lixo

- **Definição**: O estado reativo focado no exterior em que o indivíduo se sente humilhado ou desvalorizado pelas ações dos outros, buscando reparação e controle externo através de mágoas e cobranças.
- **Justificativa**: Diferente do 'eu sou lixo' (que destrói o corpo/interno), o 'eu me sinto lixo' volta-se para fora. O indivíduo culpa os outros pelo seu estado emocional e passa a vibrar em cobrança (masculino ferido), destruindo sua prosperidade material e seus relacionamentos.
- **Evidências**: "Eu me sinto um lixo, que parece a mesma coisa, mas é completamente diferente, porque o eu me sinto um lixo, ele é algo externo. Então eu estou bem, você fez alguma coisa que fez eu me sentir mal. Então a culpa não é minha, sua. [...] Você vai destruir o quê? A sua prosperidade, as suas relações. [...] a probabilidade de eu me tornar um cobrador aí é gigante."
- **Implicações**: A cura exige aceitar que quem feriu não é quem curará, saindo da dependência de pedidos de desculpas externos para restaurar o valor interno.
- **Conexões**: [[Conceito de Lixo Emocional]], [[Conceito do Cobrador da Dor]]
- **Notas Pessoais**: Vibrar em cobrança externa atrai boletos e endividamento.

## Referencia

ANDRESA MOLINA. *Conceito de Eu Me Sinto Lixo*. Aula 03 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/03   Código Humanosense - Andresa Molina.md]].
