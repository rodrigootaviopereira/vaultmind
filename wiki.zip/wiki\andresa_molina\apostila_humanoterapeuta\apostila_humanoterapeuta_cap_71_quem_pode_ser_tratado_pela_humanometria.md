---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_71_quem_pode_ser_tratado_pela_humanometria.md]]"]
---

# Cap 071 - Quem Pode Ser Tratado Pela Humanometria

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_71_quem_pode_ser_tratado_pela_humanometria.md]]

## Referencia

ANDRESA MOLINA. *Cap 071 - Quem Pode Ser Tratado Pela Humanometria*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_71_quem_pode_ser_tratado_pela_humanometria.md]]. Acesso em: 17 jun. 2026.
