---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_13_mente_consciente_inconsciente_e_cosmica.md]]"]
---

# Cap 013 - Mente Consciente Inconsciente E Cosmica

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_13_mente_consciente_inconsciente_e_cosmica.md]]

## Referencia

ANDRESA MOLINA. *Cap 013 - Mente Consciente Inconsciente E Cosmica*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_13_mente_consciente_inconsciente_e_cosmica.md]]. Acesso em: 17 jun. 2026.
