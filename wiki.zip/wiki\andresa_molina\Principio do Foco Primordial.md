---
type: principio
author: Andresa Molina
tags: [foco, queixa-principal, dor-raiz, objetivo-terapeutico]
sources: ["[[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio do Foco Primordial (A exigência de não desviar da dor principal)

- **Definição**: A diretriz metodológica que exige que toda a sessão (perguntas, rastreio de mandalas, regressão e encaminhamentos) gravite em torno da queixa principal formulada no início do atendimento, impedindo a fragmentação da potência magnética do campo.
- **Justificativa**: Tanto o assistido quanto o terapeuta tendem a fugir da dor raiz principal direcionando a atenção a problemas secundários (ex: focar na relação amorosa quando o nó da prosperidade reside na casa da mãe). Tentar resolver múltiplos problemas na mesma sessão dilui o foco energético e impede a exaustão/catarse do nó central. A síntese inicial da dor deve atuar como a única âncora a nortear o tratamento de ponta a ponta.
- **Evidências**: "A principal questão dele sempre fica com o objetivo do que ele trouxe pela primeira vez. E aí você vai tendo fluxo na conversa... Coisa mais importante, não viajem para um outro lugar que não seja a questão que ele trouxe. Aquilo é o ponto focal, aquele é o ponto... você vai ficar tudo, é isso, essa principal questão que vai nortear o tratamento inteiro. Você não vai para outro lugar, tudo é relacionado a esta dor. Então, isso é o que fica na sua caixinha de observação."
- **Implicações**: O terapeuta deve ignorar temas de curiosidade paralela levantados pelo cliente, puxando o foco da conversa ativamente de volta à queixa-âncora.
- **Conexões**: [[Tecnica de Preenchimento da Ficha Cinza]], [[Principio da Objetividade Terapeutica]]
- **Notas Pessoais**: Manter o foco evita que o atendimento se disperse em conversas sociais e ineficazes.

## Perguntas Frequentes / Didática de Atendimento

### 5. O que é o foco da sessão e por que desviar do objetivo primário trazido pelo assistido prejudica o processo?
**Resposta**: O foco da sessão é a regra absoluta de que "A principal questão dele sempre fica com o objetivo do que ele trouxe pela primeira vez". A autora instrui o terapeuta a não se desviar: "não viajem para um outro lugar que não seja a questão que ele trouxe. Aquilo é o ponto focal".

A nível somático e energetico, desviar do objetivo prejudica a sessão porque a dor sistêmica do paciente está ancorada na queixa original. A autora enfatiza que "essa principal questão que vai nortear o tratamento inteiro. Você não vai para outro lugar, tudo é relacionado a esta dor". Se o terapeuta abrir outros caminhos investigativos que não o original ("se você for para outro lugar"), ele quebra o fluxo de cura daquela ferida específica, e o assistido "nunca vai achar que isso resolveu". O terapeuta deve reter a energia estritamente na dor raiz: "Fica com a questão da venda da casa da mãe que morreu. Que dor é essa? O que que você sente?".

## Referencia

ANDRESA MOLINA. *Princípio do Foco Primordial*. Aula 07 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/07   Código Humanosense - Andresa Molina.md]].
