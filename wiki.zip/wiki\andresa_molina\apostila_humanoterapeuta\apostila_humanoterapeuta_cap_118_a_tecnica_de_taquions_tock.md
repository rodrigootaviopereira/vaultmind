---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_118_a_tecnica_de_taquions_tock.md]]"]
---

# Cap 118 - A Tecnica De Taquions Tock

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_118_a_tecnica_de_taquions_tock.md]]

## Referencia

ANDRESA MOLINA. *Cap 118 - A Tecnica De Taquions Tock*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_118_a_tecnica_de_taquions_tock.md]]. Acesso em: 17 jun. 2026.
