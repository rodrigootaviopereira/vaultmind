---
type: fonte
author: Andresa Molina
tags: [andresa_molina, humanoterapeuta, apostila, fonte, capitulo]
sources: ["[[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_92_terapia_de_desbloqueio_emocional.md]]"]
---

# Cap 092 - Terapia De Desbloqueio Emocional

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_92_terapia_de_desbloqueio_emocional.md]]

## Referencia

ANDRESA MOLINA. *Cap 092 - Terapia De Desbloqueio Emocional*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/andresa_molina/livros/apostila_humanoterapeuta/apostila_humanoterapeuta_cap_92_terapia_de_desbloqueio_emocional.md]]. Acesso em: 17 jun. 2026.
