---
type: tecnica
author: Andresa Molina
tags: [encerramento, harmonizacao, pendulo, reacoplamento]
sources: ["[[raw/archive/andresa_molina/transcriptions/06   Código Humanosense - Andresa Molina.md]]"]
---

# Prática de Encerramento e Harmonização (Reacoplamento em 5 a 1 e a rotação do pêndulo "Harmoniza, Potencializa e Liberta")

- **Objetivo**: Fechar o portal interdimensional ativado com a egrégora do Espaço Humanidade, promover o reacoplamento seguro dos corpos sutis do assistido no corpo físico biológico e irradiar a nova frequência instalada através da rotação do pêndulo na mesa.
- **Pré-requisitos**: Conclusão da etapa de [[Tecnica de Esvaziamento e Fecundacao|fecundação e plantio da semente]].
- **Passo a Passo**:
  1. **Limpeza do Campo**: O terapeuta decreta (direcionado aos guias): *"Dê um comando para recolher todos os equipamentos, um solvente cósmico e água crística para limpeza"*.
  2. **Fechamento de Portal e Reacoplamento**: Utilizando pulsos magnéticos, o terapeuta comanda de forma decrescente: *"Reacoplar os corpos em 5, 4, 3, 2 e 1. Tô fechando o portal com a câmara humanos e encerrando o trabalho"*.
  3. **Harmonização do Selo**: O terapeuta (ou o cliente se presencial) posiciona o dedo no selo central da mesa. O terapeuta gira o pêndulo no sentido horário sobre o selo, repetindo a trindade verbal por 4 vezes: *"Harmoniza (a habilidade), potencializa (a disponibilidade) e liberta (a autorização)"*.
  4. **Desconexão do Assistido**: O terapeuta desliza o dedo do selo central até a ponta superior da pirâmide traçada na mesa e tira a mão, decretando verbalmente: *"Devolvo ele para o campo energético dele"*.
- **Duração/Frequência**: Executada no final de todas as sessões terapêuticas do HumanoSense.
- **Indicadores de Sucesso**: Retorno consciente e harmonioso do assistido sem tonturas, dores de cabeça ou fragmentações, com total ancoragem no corpo físico presente.
- **Variações**: Condução online vs. presencial do posicionamento do dedo na mesa.
- **Conceitos Envolvidos**: [[Conceito da Mesa HumanoSense]], [[Principio da Liberdade Consciente]]

## Perguntas Frequentes / Didática de Atendimento

### 19. Quais são os procedimentos e comandos exatos de encerramento da câmara?
**Resposta**: Após a etapa de fecundação, o terapeuta limpa e desfaz a estrutura astral criada. Os comandos literais são:
"Tô recolhendo todos os equipamentos, tô passando um solvente cósmico, tô passando uma água crítica para limpeza e vamos reacoplando os nossos corpos em 5 4 3 2 e chegando em um. Tô fechando o portal com a câmera mancência e encerrando o trabalho".

### 20. Como o terapeuta opera o pêndulo infundindo "Harmoniza, Potencializa e Liberta" e como desliza o dedo para desligar o assistido da mesa?
**Resposta**: A nível energético, com o dedo no centro da mesa, o terapeuta gira "o pêndulo no sentido do horário e repetindo as palavras harmoniza, potencializa e liberta... Harmoniza, potencializa, liberta" em voz alta. Esse giro infunde força vital no assistido exausto.

Para realizar a desconexão (tirar a energia da pessoa da mesa quântica), o terapeuta aguarda até que o pêndulo "gira normal" e então executa o desligamento físico, "escorregando o seu dedo daqui da bolinha para cima, ó, e devolver ele lá pro campo energético", arrastando a intenção magnética para fora da pirâmide e encerrando o processo.

