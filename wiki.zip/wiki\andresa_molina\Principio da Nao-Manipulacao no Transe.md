---
type: principio
author: Andresa Molina
tags: [nao-manipulacao, livre-arbitrio, transe, conducao, sugestao]
sources: ["[[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio da Não-Manipulação no Transe (A condução através de convites e perguntas)

- **Definição**: A diretriz ética e técnica que proíbe o terapeuta de dar ordens imperativas ao assistido durante o desdobramento na Câmara Astral, exigindo que a condução seja feita estritamente através de convites e perguntas abertas.
- **Justificativa**: A nível energético, a egrégora do Humanosense obedece ao livre-arbítrio. Ao contrário da hipnose tradicional, que sugestiona e comanda a mente, o terapeuta Humanosense atua como um facilitador do cenário que a própria alma da pessoa está construindo. Se o paciente relata estar num campo vazio e com medo, o terapeuta jamais diz "traga sua família". Ele empodera o paciente fazendo perguntas: "Você quer trazer alguém?". A autora decreta que "dar poder pro povo" é a real função da espiritualidade atual. Tentar manipular o cenário do assistido (seja para forçar um perdão ou uma visão) desconecta a sessão da egrégora, pois "a equipe espiritual tá olhando". O terapeuta deve apenas observar e oferecer o espaço de decisão ao assistido.
- **Evidências**: "Eu nunca vou falar, faça isso, porque não é hipnose, não é comando de faça, é um faz sentido para você? Você quer ir lá, quer trazer alguém ou você não quer trazer... é uma decisão particular dela, não um comando meu, tá? Então sempre lembrar disso, deixar não e manipular, sugestionar... A minha espiritualidade me ensinou que eu tenho que dar poder pro povo e que que é isso que eles precisam, ver quem é quem com o poder na mão."
- **Implicações**: O terapeuta deve guiar o assistido por meio de indagações que respeitem o livre-arbítrio.
- **Conexões**: [[Conceito da Camara HumanoSense]], [[Tecnica de Desdobramento e Conducao do Sangramento]]
- **Notas Pessoais**: Conduzir sem impor o próprio julgamento do que é "certo" ou "curado" é o maior desafio do terapeuta.

## Perguntas Frequentes / Didática de Atendimento

### 1. Como Andresa Molina justifica a proibição de dar ordens ao assistido durante o desdobramento, e de que forma a condução por "convites e perguntas" preserva o livre-arbítrio?
**Resposta**: Andresa Molina proíbe as ordens diretas porque o método **"não é hipnose, não é comando de faça, é um faz sentido para você?"**. O terapeuta não pode manipular o cenário do assistido forçando-o a perdoar ou agir.

A condução deve ser feita através de convites e perguntas ("Você quer ir lá, quer trazer alguém ou você não quer trazer alguma pessoa, faz sentido isso para você?"). Isso preserva o livre-arbítrio energético porque o caminhar na cena deve ser sempre **"uma decisão particular dela, não um comando meu"**. A nível somático e espiritual, a autora explica que a egrégora não valida manipulações (**"A equipe espiritual tá olhando, tá vendo?"**) e que a cura só ocorre quando o paciente ancora a própria força existencial. O terapeuta não manda, ele empodera: **"A minha espiritualidade me ensinou que eu tenho que dar poder pro povo e que que é isso que eles precisam, ver quem é quem com o poder na mão"**.


## Referencia

ANDRESA MOLINA. *Princípio da Não-Manipulação no Transe*. Aula 08 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/08   Código Humanosense - Andresa Molina.md]].
