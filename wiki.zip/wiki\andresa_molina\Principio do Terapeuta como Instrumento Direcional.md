---
type: principio
author: Andresa Molina
tags: [terapeuta-instrumento, comando-direcional, equipe-espiritual, foco-clinico]
sources: ["[[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]]"]
---

# Princípio do Terapeuta como Instrumento Direcional (A obrigação do comando ativo)

- **Definição**: A regra interdimensional de que a equipe espiritual, por mais avançada que seja, necessita do comando verbal/mental específico do terapeuta (o operador na matéria) para executar o resgate, não agindo de forma passiva "por conta própria".
- **Justificativa**: A nível vibracional, o terapeuta não é um espectador inútil esperando os guias resolverem tudo. Ele é a ponta da lança física. A autora ilustra isso com a metáfora do pão e da faca: a ideia espiritual de cura ("podemos pegar essa faca") paira no ar, mas a matéria só é cortada se o terapeuta emitir a ordem: "com essa faca corta o pão". O nível de profundidade da cura do paciente depende da genialidade do operador de ler a cena astral e convocar exatamente o que falta. O terapeuta captura, decodifica e autoriza a intervenção na tridimensionalidade.
- **Evidências**: "Quanto mais consciência você tiver, um instrumento, melhor você se torna. Então, assim, eles fazem o que tiver que ser feito, mas eh se você é um instrumento melhor, a potência do seu tratamento é muito maior... Vem uma coisa na minha cabeça, a gente pode pegar essa faca e cortar esse pão... Mas quando eu alguém fala na minha cabeça, olha, com essa faca você corta o pão. Como se eu tivesse no campo passar pegando a faca e entregando pro corte de pão, entende? ...Quando você coloca o magnetismo com essa mente vai ser executado exatamente aquilo que você deu como comando."
- **Implicações**: O terapeuta deve estudar e refinar seus comandos para se tornar um direcionador preciso das forças sutis.
- **Conexões**: [[Principio do Respeito a Tecnica e a Equipe Espiritual]], [[Tecnica do Comando de Intervencao Especializada]]
- **Notas Pessoais**: A equipe espiritual respeita o livre-arbítrio da matéria; se não há comando na terra, nada se move no astral.

## Perguntas Frequentes / Didática de Atendimento

### 2. Por que a equipe espiritual necessita do comando mental do operador? (Metáfora do pão e da faca)
**Resposta**: A equipe espiritual não atua sozinha porque o terapeuta é o "instrumento" encarnado que transfere a intenção para a matéria. A autora usa a metáfora de uma ideia que paira no ar: "Vem uma coisa na minha cabeça, a gente pode pegar essa faca e cortar esse pão... mas eu não dou o comando. Então o pão não vai ser cortado".

A nível somático e magnético, a ação real (cortar o pão) só se materializa na dimensão astral/física quando o terapeuta verbaliza ou intenciona ativamente essa ordem com sua biologia: "quando eu alguém fala na minha cabeça, olha, com essa faca você corta o pão. Como se eu tivesse no campo passar pegando a faca e entregando pro corte de pão, entende?". Quando o terapeuta "coloca o magnetismo com essa mente", a equipe espiritual executa "exatamente aquilo que você deu como comando".


## Referencia

ANDRESA MOLINA. *Princípio do Terapeuta como Instrumento Direcional*. Aula 10 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/10   Código Humanosense - Andresa Molina.md]].
