---
type: conceito
author: Andresa Molina
tags: [campo_emocional, dependente, preocupado, lealdade, autoabandono]
sources: ["[[raw/archive/transcriptions/03 Código Humanosense  - Andresa Molina.md]]"]
---

# Conceito de Campo Emocional e Dependencia

## Rastreabilidade da Fonte

- **Fontes principais no arquivo bruto**:
  - [[raw/archive/transcriptions/03 Código Humanosense  - Andresa Molina.md]]

## Definição Precisa

- **Definição**: [INFERÊNCIA] Conceito de Campo Emocional e Dependencia nomeia um eixo recorrente da obra de Andresa Molina que deve ser lido dentro do HumanoSense/Humanoterapeuta como categoria de diagnóstico, leitura de campo ou condução terapêutica.
- **Formulação de apoio**: Eles aparecem como movimentos concretos na ficha: espera, dependencia, vergonha, defesa, guerra antiga e dificuldade de sustentar valor proprio. ## Referencia ANDRESA MOLINA. *Camada MasterSense - Personagens da Dor*.

## Sinônimos/Variações

- [INFERÊNCIA] Varia conforme a aula: pode aparecer como campo, código, mandala, personagem, sistema, memória, técnica ou postura terapêutica.

## Contexto de Uso

- Usado para orientar leitura do assistido, organização da sessão, compreensão de padrões emocionais/energéticos e conexão entre método, ficha, mesa, câmara e condução espiritual.

## Relação com Princípios

- [[Camada MasterSense - Personagens da Dor]]
- [[MasterSense - Mentoria do HumanoSense]]

## Exemplos do Material

- Eles aparecem como movimentos concretos na ficha: espera, dependencia, vergonha, defesa, guerra antiga e dificuldade de sustentar valor proprio. ## Referencia ANDRESA MOLINA. *Camada MasterSense - Personagens da Dor*. (Camada MasterSense - Personagens da Dor)
- Ele aprofunda o HumanoSense no campo real dos atendimentos. - A aula 03 reforca que receber sem culpa e reconhecer o que ja chegou sao etapas centrais da maturidade terapeutica e relacional. - A aula 04 mostra que o terapeuta precisa modular linguagem, timing e intensidade para ajudar sem ferir a aliança com o assistido. ## Limite do Sistema - O MasterSense e uma camada de lapidacao do HumanoSense, nao uma tecnica-base separada do nucleo do metodo. - Para nao confundir MasterSense com Humanoterapeuta ou com o proprio HumanoSense, usar [[Mapa dos Sistemas Terapeuticos de Andresa Molina]]. ## Referencia ANDRESA MOLINA. *MasterSense - Mentoria do HumanoSense*. (MasterSense - Mentoria do HumanoSense)

## Aplicação Prática

- [INFERÊNCIA] Ao encontrar este tema em atendimento, use-o como pergunta de aprofundamento: onde ele aparece na queixa, no corpo, na ficha, no afeto/desafeto e na relação entre consciência e inconsciente?
- [INFERÊNCIA] Verifique se a pessoa está usando este padrão como defesa, fuga, repetição de dor ou caminho de reorganização.

## Conexões Externas

- [[Camada MasterSense - Personagens da Dor]]
- [[MasterSense - Mentoria do HumanoSense]]

## Referencia

ANDRESA MOLINA. *Conceito de Campo Emocional e Dependencia*. Nota derivada de material-fonte arquivado na base de conhecimento. Fontes: [[raw/archive/transcriptions/03 Código Humanosense  - Andresa Molina.md]]. Acesso em: 17 jun. 2026.
