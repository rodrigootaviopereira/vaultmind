---
type: conceito
author: Andresa Molina
tags: [autossabotagem, melindre, feminino-ferido, aborto-energetico]
sources: ["[[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]]"]
---
# O Aborto de Projetos (A Falência do Feminino Melindroso/Imaturo)

- **Definição Precisa**: O processo de abandono e paralisação de projetos e relacionamentos pela metade decorrente da fragilidade e melindre do feminino ferido perante críticas ou pressões.
- **Sinônimos/Variações**: Aborto Existencial, Abortar Projetos, Falha de Sustentação
- **Contexto de Uso**: Tratamento de autossabotagem e incapacidade de concluir metas iniciadas.
- **Relação com Princípios**: [[Principio do Poder do Tres]]
- **Exemplos do Material**: "Tudo que a gente faz e que a gente não sustenta é porque o nosso feminino está ferido e ele prefere abortar... feminino ferido, ele é ofendido, julgador, magoado. O que o outro fala, ele melindra. Isso não é só sobre mulher e homem... O que que a gente faz? Como é que a gente bloqueia e aborta todas as nossas coisas? Eu vou lá, eu falo e depois eu mesmo me julgo e falar: 'Ah, por que que eu falei aquilo?'... é o meu feminino que não sustenta o meu impulso e julga."
- **Aplicação Prática**: Fortalecer a resiliência do feminino do paciente para suportar o atrito da gestação de seus projetos, eliminando a autocrítica ácida.
- **Conexões Externas**: [[Conceito de Energia Feminina]]

## Perguntas Frequentes / Didática de Atendimento

**Pergunta 6: O que é um "feminino ferido" ou "melindroso" e como ele reage diante de atritos ou críticas, provocando o que a autora chama de "aborto"?**

O "feminino ferido" é a polaridade de sustentação (presente em homens e mulheres) que se tornou reativa e imatura. A autora o define como um estado em que o indivíduo "é ofendido, julgador, magoado. O que o outro fala, ele melindra". 

A nível somático, quando o corpo enfrenta oposição, contrariedade ou atrito no mundo externo ("não aceita tomar um toco. Ele não aceita tomar um não"), o sistema nervoso entra em colapso e perde a estabilidade. A reação é irracional e explosiva: "toda vez que a gente dá um chilique, um surto... é o nosso feminino que não sustenta, não suporta a potência do masculino". 
O "aborto" ocorre como consequência dessa fragilidade orgânica. Como a pessoa não tem estrutura vibracional para aguentar o peso das críticas e da frustração, o seu "feminino está ferido e ele prefere abortar", jogando fora a ideia ou a relação, largando tudo pela metade porque não deu conta de sustentar a pressão.

**Pergunta 7: De que forma o julgamento interno que ocorre logo após a manifestação de um impulso de ação expressa o desequilíbrio do feminino em dor?**

O desequilíbrio se expressa através do ataque da própria energia feminina contra a energia masculina que acabou de agir. A nível somático, o masculino toma a frente com coragem: "fui lá e falei, fui lá e fiz, fui lá e cobrei, fui lá e decidi". 

Logo após essa ação ("o impulso"), o feminino deveria nutrir essa atitude. Porém, por estar em dor e não ter força, ele entra em retração e pune o corpo através da dúvida: "Eu vou lá, eu falo e depois eu mesmo me julgo e falar: 'Ah, por que que eu falei aquilo?'... É o meu feminino que não sustenta o meu impulso e julga". 
A autora detalha que a pessoa "julga que você foi falou que não devia ter falado... que falou mais alto". Esse atrito vibracional, alimentado por crenças de "certo errado", impede a pessoa de dar "continuidade porque eu tenho dificuldade em sustentar", fazendo com que o feminino interno age como o carrasco da própria potência.

**Pergunta 8: Qual é a correlação somática e comportamental entre a atitude de "fazer manha ou birra" e o travamento de projetos de longo prazo?**

A correlação reside na recusa orgânica de amadurecer e suportar o tempo das coisas ("a frequência"). Projetos de longo prazo (como finanças, amizades e relações) exigem "energia de dedicação e paciência". 

Andresa explica que, quando não desenvolvido, o feminino age como "um feminino imaturo. Não é sobre uma criança ferida, é sobre um feminino imaturo... ele ficou criança fazendo manha, fazendo birra". A nível comportamental e vibracional, essa "birra" trava a evolução porque a pessoa rejeita as dificuldades naturais do projeto e se recusa a ser contrariada: "not aceito, que não quero, porque não concordo, porque eu não aceito nada que venha de fora".
A autora garante que "birra é coisa de feminino ferido". Somaticamente, o corpo não suporta o desconforto prolongado necessário para criar bases sólidas e cede à frustração infantil, de modo que o indivíduo "não sustenta nada, não constrói nada de longo prazo", paralisando e destruindo as próprias realizações por pura incapacidade de sustentar a realidade de forma madura.

## Referencia

ANDRESA MOLINA. *O Aborto de Projetos (A Falência do Feminino Melindroso/Imaturo)*. Aula 02 - Código Humanosense. Fonte: [[raw/archive/andresa_molina/transcriptions/02   Código Humanosense - Andresa Molina.md]].
