---
type: conceito
author: Andresa Molina
tags: [cura, sentir, transformar, transmutar, estados]
sources: ["[[raw/archive/andresa_molina/transcriptions/01   Código Humanosense - Andresa Molina.md]]"]
---
# Conceito dos Três Estados de Cura

- **Definição Precisa**: Os três momentos indispensáveis pelos quais qualquer processo de cura deve passar: sentir (autorizar a dor/alegria), transformar (ressignificar a forma lógica) e transmutar (espiritualizar o estado vibracional).
- **Sinônimos/Variações**: Três Estados de Cura, Ciclo de Cura HumanoSense, Sentir-Transformar-Transmutar
- **Contexto de Uso**: Condução clínica do assistido nas mandalas de cura.
- **Relação com Princípios**: [[Principio do Poder do Tres]]
- **Exemplos do Material**: "nada pode se curar ou se criar sem passar pelos três estados: o sentir, o transformar e o transmutar. [...] Sentir é se autorizar sentir a dor ou a alegria... Transformar é mudar de forma, ressignificar. E ela precisa transmutar, que é mudar de estado, espiritualizar."
- **Aplicação Prática**: Estruturar o fluxo terapêutico estimulando a descarga somática da dor bloqueada (sentir), clareza sobre o porquê do travamento (transformar) e comandos na mesa para reorientar o campo astral (transmutar).
- **Conexões Externas**: [[Conceito do Metodo HumanoSense]]

## Perguntas Frequentes / Didática de Atendimento

### Como Andresa Molina diferencia somática e energeticamente os três estados fundamentais da cura: "sentir", "transformar" e "transmutar"?

A autora decreta que "nada pode se curar ou se criar sem passar pelos três estados". Eles são definidos da seguinte maneira:
*   **Sentir:** É o estado de "se autorizar sentir a dor ou a alegria". A nível somático, é quando o corpo manifesta o que estava travado ("sangrar" a ferida), porque a pessoa antes "não pôde sentir ou a dor ou a raiva ou o medo", e agora precisa expurgar essa sensação.
*   **Transformar:** É "mudar de forma, ressignificar". Atua no nível do entendimento mental.
*   **Transmutar:** É "mudar de estado, espiritualizar". Diferente da transformação que só muda o jeito de pensar, a transmutação é energética e atua no "campo vibracional", retirando o peso ectoplasmático da memória doente e convertendo sua frequência para abrir espaço pro novo.

## Referencia ANDRESA MOLINA. *HT - Apostila Humanoterapeuta - Andresa Molina*.

## Sinônimos/Variações

- [INFERÊNCIA] Varia conforme a aula: pode aparecer como campo, código, mandala, personagem, sistema, memória, técnica ou postura terapêutica.

## Contexto de Uso

- Usado para orientar leitura do assistido, organização da sessão, compreensão de padrões emocionais/energéticos e conexão entre método, ficha, mesa, câmara e condução espiritual.

## Relação com Princípios

- [[HT - Apostila Humanoterapeuta - Andresa Molina]]

## Exemplos do Material

- Nesta wiki, as notas do Humanoterapeuta ficam nomeadas explicitamente como `Humanoterapeuta`. - Para uma visao integrada sem mistura de sistemas, usar [[Mapa dos Sistemas Terapeuticos de Andresa Molina]]. ## Leitura Integrada - O material sustenta uma visao tripla do ser humano: corpo, mente e espirito. - A cura e descrita como ganho de consciencia, desbloqueio energetico, tratamento espiritual e restabelecimento da informacao original. - A obra insiste na ordem, no metodo e na integridade da aplicacao. - O fechamento em cosmoetica impede que a tecnica seja lida apenas como instrumento de poder. 